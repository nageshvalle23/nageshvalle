# rD-admin-serverless-backend

After installing (instructions TK):

`sam local start-api` and cross your fingers.

trigger build
