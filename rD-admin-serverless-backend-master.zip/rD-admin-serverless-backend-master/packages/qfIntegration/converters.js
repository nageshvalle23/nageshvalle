exports.convertToCCRecord = (rloc, travelerInformation, flightsWithCCAttributes, isBoardingPass = false) => {
    const ccPassengers = [];

    for (const eachCustomer of travelerInformation) {
        const { givenName, familyName, customerId, type: ageCategory, title, products } = eachCustomer;
        const coupons = createCouponsObject(customerId, products, flightsWithCCAttributes, isBoardingPass)
        const ccPassenger = {
            givenName, familyName, title, ageCategory, coupons
        }
        ccPassengers.push(ccPassenger)
    }

    const ccFlights = convertToCCFlights(flightsWithCCAttributes);
    return {
        pnr: {
            rloc,
            passengers: ccPassengers,
            flights: ccFlights
        }
    }
}


exports.convertToCCPassengers = (newTravelerInformation, productsToCheckIn, flightsWithCCAttributes, isBoardingPass = false) => {
    const ccPassengers = [];
    const flightIdsForCheckIn = productsToCheckIn.map((product) => product.flightId);

    for (const eachCustomer of newTravelerInformation) {
        const { givenName, familyName, customerId, type: ageCategory, title, products } = eachCustomer;
        const productsForCheckIn = products.filter((product) => flightIdsForCheckIn.includes(product.flightId));
        const coupons = createCouponsObject(customerId, productsForCheckIn, flightsWithCCAttributes, isBoardingPass)
        const ccPassenger = {
            givenName, familyName, title, ageCategory, coupons
        }
        ccPassengers.push(ccPassenger)
    }

    return ccPassengers;
}


function convertToCCBoardingPassObject(qfBoardingPassResponse, customerId, product) {

    const { customers } = qfBoardingPassResponse;

    /* find the customer you need the cc boarding pass object for */
    const bpInformation = customers.find((customer) => customer.customerId == customerId);
    const { products } = bpInformation;

    /* find the product  */
    const bpForTheProduct = products.find((eachProduct) => eachProduct.productId == product.productId);

    const { boardingPass } = bpForTheProduct;
    const { googleWalletUrl, passbookImage, seatSection, boardingTime, barcode, seatAllocated, boardingPriority } = boardingPass;
    const boardingPassObject = {
        barcodeData: barcode[0]?.data || null,
        seatNumber: seatAllocated || null,
        passengerClass: seatSection || null,
        boardingTime,
        eTicketNumber: product.eTicketNumber,
        frequentFlierNumber: null,
        gate: null,
        terminal: null,
        securityNumber: null,
        boardingGroup: boardingPriority || null,
        allowTSA: null,
        allowFastTrack: null,
        mobilewalletURL_ios: passbookImage || null,
        mobilewalletURL_android: googleWalletUrl || null
    }

    return boardingPassObject
}

function createCouponsObject(customerId, products, flightsWithCCAttributes, isBoardingPass) {
    const coupons = [];
    for (const product of products) {
        const correspondingFlight = flightsWithCCAttributes.find((flight) => (product.flightId == flight.flightId));
        if (correspondingFlight) {
            const { flightNumber, carrierCode, origin, destination, date, time } = correspondingFlight;
            const { isCheckInInhibited, status, eTicketNumber } = product;
            const couponObject = {
                flightNumber,
                departureDateTime: `${date} ${time}`,
                carrierCode,
                origin,
                eTicketNumber,
                destination,
                isCheckedIn: status == 'EC_CHECK-IN_ACCEPTANCE' ? true : false,
                isCheckInInhibited,
                boardingPass: isBoardingPass ? convertToCCBoardingPassObject(isBoardingPass, customerId, product) : null/* show boarding pass only when the cc request is a boarding pass request */
            }
            coupons.push(couponObject);
        }
    }
    return coupons;
}

function convertToCCFlights(flights) {
    const ccFlights = [];
    for (const flight of flights) {
        const { flightNumber, carrierCode, origin, destination, date } = flight;
        ccFlights.push({
            flightNumber, date, carrierCode, origin, destination
        })
    }
    return ccFlights
}