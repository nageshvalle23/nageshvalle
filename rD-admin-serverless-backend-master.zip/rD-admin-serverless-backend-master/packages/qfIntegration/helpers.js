const { phoneMap } = require('./phoneMap.js');
const getCountryISO3 = require("country-iso-2-to-3");

exports.getCountryCode = (phoneExtension) => {
    const details = phoneMap.find((element) => element.dial_code === phoneExtension)
    if (!details) throw Error('Invalid country phone extension');
    return getCountryISO3(details.code);
}

exports.dateFormatter = (dateString) => {
    const year = dateString.slice(0, 4);
    const month = dateString.slice(4, 6);
    const day = dateString.slice(6, 8);

    const formattedDate = `${year}-${month}-${day}`;
    return formattedDate; // Output: 2023-05-31
}

exports.timeFormatter = (timeString) => {
    const hours = timeString.slice(0, 2);
    const minutes = timeString.slice(2, 4);
    const seconds = timeString.slice(4, 6);

    const formattedTime = `${hours}:${minutes}:${seconds}`;
    return formattedTime; // Output: 12:15:00

}
