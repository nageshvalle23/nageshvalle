const api = require('./index.js')

const flightLookups =
  {
    "origin": '',
    "destination": "",
    "flightNumber": "89",
    "carrier": "QF",
    "date": "2019-10-09"
  };

api.flifo({
  body: JSON.stringify(flightLookups)
}, null, (err, res) => {
  console.log(JSON.stringify(JSON.parse(res.body), null, 2));
});
