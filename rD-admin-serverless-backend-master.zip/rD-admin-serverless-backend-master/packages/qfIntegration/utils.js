const helpers = require('./helpers');
const dynamoDbHelpers = require('./dynamoDbHelpers');
const api = require('./api');
const uuid = require("uuid").v1;
const _ = require('lodash');

exports.retrieveQfEligibility = async (session, lookup,cache=true) => {
    const { rloc,familyName,ccTransactionId } = lookup;
    let qfEligibility;

    // below check in cache
    let rlocInCache = null
    if(cache) rlocInCache = await dynamoDbHelpers.getPnr(rloc,familyName);

    if (rlocInCache) {
        console.log('--- IN CACHE ---',ccTransactionId,rlocInCache)
        qfEligibility = JSON.parse(rlocInCache.eligibilityResponse);
    } else {
        console.log('--- rloc NOT FOUND IN CACHE ---',ccTransactionId)
        qfEligibility = (await api.fetchQfEligibility(session, lookup)).data;

        const { customers, products, flights } = qfEligibility;

        if (qfEligibility.errorDetails) {
            const errorMessages = JSON.stringify(qfEligibility.errorDetails);
            const err = {
                id: uuid(),
                CARRIER_ERROR_CODE: 500,
                CARRIER_ERROR_MESSAGE: JSON.stringify({
                    id: uuid(),
                    message: errorMessages,
                    code: 500
                })
            }
            throw err;
        }
        else if (!customers || !products || !flights || (customers.length == 0) || (products.length == 0) || (flights.length == 0)) {
            throw ('----QF Eligibility Target Error',ccTransactionId);
        }

        await dynamoDbHelpers.insertPnr(rloc,familyName, qfEligibility);
    }
    return qfEligibility;
}

exports.validatePassengerRequest = (travelerInformation, passengerRequests) => {
    const requestedPassengers = [];
    if (!Array.isArray(passengerRequests)) passengerRequests = [passengerRequests]
    for (passengerRequest of passengerRequests) {
        const { givenName, familyName, eTicketNumber } = passengerRequest;
        const found = travelerInformation.find((customer) => {
            if (customer.givenName.toLowerCase() == givenName.toLowerCase() && customer.familyName.toLowerCase() == familyName.toLowerCase()) {
                const { products } = customer;
                const matchingETicketNumber = products.find((product) => product.eTicketNumber == eTicketNumber);
                if (matchingETicketNumber) return customer
            }
        })
        if (!found) throw Error('Invalid passenger request'); // validating whether all details in passenger request match
        requestedPassengers.push(found);
    }
    return requestedPassengers
}

exports.getTravelerInformation = (qfEligibility) => {

    const { customers, flights, products } = qfEligibility;

    const travelerInformation = [];
    for (const customer of customers) {

        const { surname: familyName, givenName, requiredDocuments, populatedDocuments, id: customerId, type, title } = customer;

        // get product ids associated with each customer id
        const productsForTraveler = products.filter((product) => (product.customerId == customerId))

        const traveler = {
            customerId, familyName, givenName, requiredDocuments, populatedDocuments, type, title, products: productsForTraveler
        };
        travelerInformation.push(traveler);

    }

    return travelerInformation;

}

exports.getFlightsWithCCAttributes = (qfEligibility) => {

    const { flights } = qfEligibility;

    const flightsAtCCLevel = [];

    for (let flight of flights) {
        const { number: flightNumber, id: flightId, companyIdentifier: { operatingCarrier: { code: carrierCode } }, departure: { date, time, code: origin }, arrival: { code: destination } } = flight;

        const flightWithCCAttributes = {
            flightNumber, flightId, carrierCode, date: helpers.dateFormatter(date), time: helpers.timeFormatter(time), origin, destination
        };
        flightsAtCCLevel.push(flightWithCCAttributes);
    }

    return flightsAtCCLevel
}

exports.validateFlightsRequest = (passengers, flightsRequest, flightsWithCCAttributes) => {
    /* create a deep copy and test against it */
    const deepCopy = _.cloneDeep(flightsWithCCAttributes);

    /* validate flight requests */
    const flightsWithCCAttributesModified = deepCopy.map((flight) => {
        delete flight['flightId'];
        delete flight['time'];
        return flight
    })
    const isValidFlights = _.isEqual(flightsRequest, flightsWithCCAttributesModified);
    if (!isValidFlights) throw Error('Invalid Flight Requests!');

    const productsToBeCheckedIn = [];

    for (let passenger of passengers) {
        const { products } = passenger;

        for (const flight of flightsRequest) {
            const { flightNumber, date, carrierCode, origin, destination } = flight;
            for (const flightWithCCAttributes of flightsWithCCAttributes) {
                if ((flightNumber == flightWithCCAttributes.flightNumber) && (date == flightWithCCAttributes.date)
                    && (carrierCode == flightWithCCAttributes.carrierCode) && (origin == flightWithCCAttributes.origin) && (destination == flightWithCCAttributes.destination)) {
                    const productToBeCheckedIn = products.find((product) => product.flightId == flightWithCCAttributes.flightId);
                    productsToBeCheckedIn.push(productToBeCheckedIn);
                }
            }
        }
    }

    return productsToBeCheckedIn;
}

exports.validateCheckinEligibility = (products) => {
    const notAllowedToCheckIn = products.some((product) => product.isCheckInInhibited == true);
    if (notAllowedToCheckIn) throw Error('Passenger is not eligible for checkin.');
    return
}


exports.validateBoardingPassEligibility = (products) => {
    const cannotBeIssuedBoardingPass = products.some((product) => product.isBPInhibited == true);
    if (cannotBeIssuedBoardingPass) throw Error('Cannot Retreive Boarding pass. Please see an agent at the airport');
    return
}