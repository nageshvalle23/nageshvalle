const axios = require( "axios" );
const jsJoda = require( '@js-joda/core' )
require( '@js-joda/timezone' )
const API_URL = process.env.QF_FLIFO_API_URL || "https://api.qantas.com/api/flight/flightstatus/";

// url looks like this: 149?departureFrom=201903150000&departureTo=201903170000
// TODO: it appears that QF puts sectors in reverse chron which conflicts with logic below
const QF_DATE_FORMAT = 'yyyMMdd';

const { DateTimeFormatter, LocalDate, LocalDateTime, ZonedDateTime, ZoneOffset } = jsJoda

const utcDatetime = ts => {
  return ZonedDateTime.parse( ts, DateTimeFormatter.ISO_OFFSET_DATE_TIME )
    .withZoneSameInstant( ZoneOffset.UTC )
    .format( DateTimeFormatter.ISO_OFFSET_DATE_TIME );
};

const localDatetime = ts => {
  return ZonedDateTime.parse( ts, DateTimeFormatter.ISO_OFFSET_DATE_TIME )
    .format( DateTimeFormatter.ISO_OFFSET_DATE_TIME );
};

const statusMap = {
  LANDED: 'LANDED',
  CANCELLED: 'CANCELLED',
  DIVERTED: 'DIVERTED',
  ESTIMATED: 'SCHEDULED',
  DEPARTED: 'DEPARTED',
  DELAYED: 'DELAYED',
};

exports.index = async function ( lookup ) {
  const d = LocalDate.parse( lookup.date ).atStartOfDay();

  const start = d.format( DateTimeFormatter.ofPattern( QF_DATE_FORMAT ) );
  const end = d.plusDays( 1 ).format( DateTimeFormatter.ofPattern( QF_DATE_FORMAT ) );
  const options = {
    timeout: process.env.QF_API_TIMEOUT,
    headers: { 'User-Agent': 'carrier-connect' },
    params: {
      departureFrom: start + '0000',
      departureTo: end + '0000',
    }
  };
  const endpoint = API_URL + lookup.flightNumber;
  console.info( '\n---REQUEST:flifo ', endpoint, JSON.stringify( options ) )
  let res = null;
  try {
    res = await axios.get( endpoint, options )
    console.info( '\n---RESPONSE:flifo ', res.status, JSON.stringify( res.data ) )
  } catch ( error ) {
    if ( res && typeof res.data !== 'undefined' ) {
      console.info( '\n---RESPONSE:flifo ', res.status, JSON.stringify( res.data ) )
    } else {
      console.error( '----ERROR:', error.code, error.message )
      throw new Error( "Internal Server Error!" );
    }
  }

  if ( !lookup.origin && !lookup.destination ) {
    return res.data.flights.map( converter );
  } else {
    return converter( res.data.flights[ 0 ] );
  }
};

function converter( qfFlifo ) {
  // returns cc flifo schema
  const flight = {
    flightNumber: null,
    carrierCode: null,
    // airlineName: null, // TODO: can we get this?
    // aircraftType: null, // TODO: can we get this?

    sectors: [],
    summary: {
      notice: false,
      departure: {
        at: {
          utc: null,
          local: null,
          type: null, // estimated, or actual
        },
      },
      arrival: {
        at: {
          utc: null,
          local: null,
          type: null, // estimated, or actual
        },
      },
    },
  };

  qfFlifo.flightNumbers.forEach( f => {
    if ( f.primary === true ) {
      flight.carrierCode = f.airline;
      flight.flightNumber = f.code.toString();
    }
  } );

  qfFlifo.sectors.forEach( ( s, i ) => {
    const sector = {
      codeShares: [],
      status: 'UNKNOWN',
      sourceStatus: null,
      departure: {
        airportCode: null,
        airportName: null,
        cityName: null,
        countryId: null,
        terminal: null,
        gate: null,
        scheduled: {
          local: null,
          utc: null,
          source: null,
        },
        estimated: {
          local: null,
          utc: null,
          source: null,
        },
        actual: {
          local: null,
          utc: null,
          source: null,
        },
      },
      arrival: {
        airportCode: null,
        airportName: null,
        cityName: null,
        countryId: null,
        terminal: null,
        gate: null,
        scheduled: {
          local: null,
          utc: null,
          source: null,
        },
        estimated: {
          local: null,
          utc: null,
          source: null,
        },
        actual: {
          local: null,
          utc: null,
          source: null,
        },
      },
    };

    qfFlifo.flightNumbers.forEach( f => {
      if ( f.primary !== true ) {
        sector.codeShares.push( {
          flightNumber: f.code.toString(),
          carrierCode: f.airline,
        } );
      }
    } );

    // Summary section
    if ( s.sectorDiversion !== 'PLANNED' ) {
      flight.summary.notice = true;
    }

    // The purpose of this code is to surface summary information about the sectors at the flight level
    if ( i === 0 ) {
      if ( s.departure.actual ) {
        flight.summary.departure.at.local = localDatetime( s.departure.actual );
        flight.summary.departure.at.utc = utcDatetime( s.departure.actual );
        flight.summary.departure.at.type = 'ACTUAL';
      } else {
        flight.summary.departure.at.local = localDatetime( s.departure.estimated );
        flight.summary.departure.at.utc = utcDatetime( s.departure.estimated );
        flight.summary.departure.at.type = 'ESTIMATED';
      }
    }

    if ( i === qfFlifo.sectors.length - 1 ) {
      if ( s.arrival.actual ) {
        flight.summary.arrival.at.local = localDatetime( s.arrival.actual );
        flight.summary.arrival.at.utc = utcDatetime( s.arrival.actual );
        flight.summary.arrival.at.type = 'ACTUAL';
      } else {
        flight.summary.arrival.at.local = localDatetime( s.arrival.estimated );
        flight.summary.arrival.at.utc = utcDatetime( s.arrival.estimated );
        flight.summary.arrival.at.type = 'ESTIMATED';
      }
    }
    // end summary section
    sector.departure.airportCode = s.from;
    sector.arrival.airportCode = s.to;

    sector.departure.gate = s.departure.gate;
    sector.departure.terminal = s.departure.terminal;

    sector.arrival.gate = s.arrival.gate;
    sector.arrival.terminal = s.arrival.terminal;

    /**
     * Updated logic because prioritizing arrival status meant missing status
     * abnormalities only speicified on the departure (delay, diversion, etc.)
     *
     * If arrival is 'SCHEDULED' we prioritize using the departure status
     *
     * Examples fixed by this update:
     *    1. https://oneworld-digital.slack.com/archives/CA3EPB8KE/p1571224387005500
     *    2. https://oneworld-digital.slack.com/archives/CA3EPB8KE/p1571305864016000
     *
     */
    let status, sourceStatus;

    if ( s.arrival.status ) {
      sourceStatus = s.arrival.status.toUpperCase();
      status = statusMap[ sourceStatus ];
    }
    if ( s.departure.status && ( status === 'SCHEDULED' || status === 'UNKNOWN' ) ) {
      sourceStatus = s.departure.status.toUpperCase();
      status = statusMap[ sourceStatus ];
    }

    sector.status = status ? status : 'UNKNOWN';
    sector.sourceStatus = sourceStatus;

    const addTimeInfo = ( phaseObject, scheduled, estimated, actual ) => {
      if ( scheduled ) {
        phaseObject.scheduled.local = localDatetime( scheduled );
        phaseObject.scheduled.utc = utcDatetime( scheduled );
        phaseObject.scheduled.source = 'QF';
      }

      if ( estimated ) {
        phaseObject.estimated.local = localDatetime( estimated );
        phaseObject.estimated.utc = utcDatetime( estimated );
        phaseObject.estimated.source = 'QF';
      }

      if ( actual ) {
        phaseObject.actual.local = localDatetime( actual );
        phaseObject.actual.utc = utcDatetime( actual );
        phaseObject.actual.source = 'QF';
      }
    };

    addTimeInfo( sector.departure, s.departure.scheduled, s.departure.estimated, s.departure.actual );
    addTimeInfo( sector.arrival, s.arrival.scheduled, s.arrival.estimated, s.arrival.actual );

    flight.sectors.push( sector );
  } );

  return flight;
}


// **********************************OLD CODE***************************************

// const utcDatetime = ts => {
//   return ZonedDateTime.parse(ts)
//     .withZoneSameInstant(ZoneOffset.UTC)
//     .toString();
// };

// const localDatetime = ts => {
//   return ZonedDateTime.parse(ts).toString();
// };