const { DynamoDBClient, PutItemCommand, GetItemCommand, UpdateItemCommand, DeleteItemCommand } = require("@aws-sdk/client-dynamodb");
const dynamoDBClient = new DynamoDBClient({ region: process.env.AWS_REGION });
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");

const STAGE = process.env.stage;

// Function to create an item in DynamoDB
exports.insertPnr = async (rloc, familyName, eligibilityResponse) => {
    const startTime = new Date().getTime();
    const key = rloc + familyName.replace(/\s/g,'').toUpperCase();
    let params = {
        TableName: `qf-pnr-cache-${STAGE}`,
        Item: marshall({
            rloc: key,
            eligibilityResponse: JSON.stringify(eligibilityResponse),
            ttlAttribute: Math.floor(Date.now() / 1000) + (5 * 60) // 5 minutes in seconds
        })
    };
    const command = new PutItemCommand(params);
    await dynamoDBClient.send(command);
    console.info(`---- Response Time for Insert PNR ---- ${new Date().getTime() - startTime} ms`);
}

// Function to retrieve an item from DynamoDB
exports.getPnr = async (rloc, familyName) => {
    const startTime = new Date().getTime();
    const key = rloc + familyName.replace(/\s/g,'').toUpperCase();
    const params = {
        TableName: `qf-pnr-cache-${STAGE}`,
        Key: {
            rloc: {
                S: key
            }
        },
    };

    const command = new GetItemCommand(params);
    const data = await dynamoDBClient.send(command);
    console.info(`---- Response Time for Get PNR ---- ${new Date().getTime() - startTime} ms`);

    if ( data.Item ) {
        const resp = unmarshall( data.Item );
        const curTime = Math.floor( Date.now() / 1000 )

        /* delete the expired records */
        if ( curTime >= resp.ttlAttribute ) {
            const command2 = new DeleteItemCommand( {
                TableName: `qf-pnr-cache-${ STAGE }`,
                Key: {
                    rloc: {
                        S: key
                    }
                },
            } );

            await dynamoDBClient.send( command2 );
            console.log('----DELETED EXPIRED RECORD: ',key,resp.ttlAttribute)
        } else {
            return resp;
        }

    }
    return null
}

exports.updatePnr = async (rloc, familyName, eligibilityResponse) => {
    const startTime = new Date().getTime();
    const key = rloc + familyName.replace(/\s/g,'').toUpperCase();
    const updateExpression = 'SET eligibilityResponse = :value1, ttlAttribute = :value2';
    const expressionAttributeValues = marshall({
        ':value1': JSON.stringify(eligibilityResponse),
        ':value2': Math.floor(Date.now() / 1000) + (5 * 60)
    });

    // Create the update command
    const command = new UpdateItemCommand({
        TableName: `qf-pnr-cache-${STAGE}`,
        Key: marshall({ rloc: key }),
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });

    // Execute the update command
    await dynamoDBClient.send(command)
    console.info(`---- Response Time for Update PNR ---- ${new Date().getTime() - startTime} ms`);
}