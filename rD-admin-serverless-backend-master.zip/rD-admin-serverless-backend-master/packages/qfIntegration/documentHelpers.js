const api = require('./api');
const helpers = require('./helpers');
const statesConverter = require('us-state-codes');


exports.handleDocument = async (session, lookup, customer, flightsWithCCAttributes, document) => {
    // we need find what products are under the customer and their ids

    const { customerId, type: ageCategory, products, givenName, familyName } = customer;

    console.log('----handleDocument.customer: ',lookup.ccTransactionId,customer)

    /* filter out the document with passport as */
    const isPassport = document.find((doc) => doc.type.toLowerCase() == 'PASSPORT'.toLowerCase());

    if (isPassport) {

        /* construct products array for doc update when passport */
        const docUpdateProducts = constructProducts(products, flightsWithCCAttributes, isDocumentPassport = true);

        const { payload } = isPassport;

        const { givenName, familyName, dateOfBirth, gender, passportNumber, expiryDate, nationality, countryOfIssue } = payload;

        const requestToQf = [
            {
                meta: {
                    products: docUpdateProducts
                },
                customer: {
                    dateOfBirth: dateOfBirth.replace(/-/g, ""),
                    expiryDate: expiryDate.replace(/-/g, ""),
                    givenName,
                    passportNumber,
                    customerId,
                    gender: gender[0],
                    surname: familyName,
                    customerType: ageCategory == 'INFANT' ? ageCategory.splice(0, 2) : ageCategory[0],
                    nationality
                }
            }
        ]

        console.log(JSON.stringify(requestToQf), '= passport update request')

        const docUpdateResponse = await api.updatePassport(session, requestToQf, lookup);

        console.log(JSON.stringify(docUpdateResponse.data), '= passport update response')

        /* remove passport from the list of documents to be updated */
        document = document.filter((doc) => doc.type.toLowerCase() != 'PASSPORT'.toLowerCase());
    }

    /* if document is not passport */
    else {
        /* construct products array for doc update when not passport */
        const docUpdateProducts = constructProducts(products, flightsWithCCAttributes);

        const customerInformationToUpdate = {
            products: docUpdateProducts,
            givenName,
            customerId,
            surname: familyName,
            customerType: ageCategory == 'INFANT' ? ageCategory.splice(0, 2) : ageCategory[0]
        }

        const requestToQf = {
            customers: [
                customerInformationToUpdate
            ]
        }

        for (const doc of document) {
            const { type, payload } = doc;
            if (type.toLowerCase() == 'DESTINATION_ADDRESS'.toLowerCase()) {
                const { street, city, stateProv, postalCode, country } = payload;

                let stateCode = stateProv;
                if(country.toLowerCase() === 'usa' && stateProv.length > 2){
                    stateCode = statesConverter.getStateCodeByStateName(stateProv)
                    if(typeof stateCode !== 'string'){
                        console.log('----invalid_state:',lookup.ccTransactionId,stateProv,stateCode)
                        throw Error('Invalid State/Province in Destination Address');
                    }
                }

                const destinationAddress = {
                    state: stateCode,
                    street,
                    city,
                    isIntransit: false,
                    countryCode: country,
                    postCode: postalCode
                }

                customerInformationToUpdate.destinationAddress = destinationAddress
            }

            else if (type.toLowerCase() == 'RESIDENT_ADDRESS'.toLowerCase()) {
                const { countryOfResidence } = payload;
                customerInformationToUpdate.countryOfResidence = countryOfResidence;
            }

            else if (type.toLowerCase() == 'EMERGENCY_CONTACT'.toLowerCase()) {

                const { familyName, givenName, phone, email, refused } = payload;

                const { countryCode, number } = phone;

                const emergencyContact = {
                    phoneNumber: number,
                    surname: familyName,
                    countryOfResidence: helpers.getCountryCode(countryCode.replace(/\+0*(\d+)/, "+$1")),
                    isDeclined: refused
                }

                customerInformationToUpdate.emergencyContact = emergencyContact;
            }

            else if (type.toLowerCase() == 'CONTACT'.toLowerCase()) {
                customerInformationToUpdate.personalContact = {
                    "phoneNumber": payload.primary_contact.phone.number,
                    "email": payload.primary_contact.email
                }
            }

        }

        console.log(JSON.stringify(requestToQf), '= doc update request to qf',lookup.ccTransactionId);

        const docUpdateResponse = await api.updateDocument(session, requestToQf, lookup);

        console.log(JSON.stringify(docUpdateResponse.data), '= doc update response for other docs from QF',lookup.ccTransactionId);
    }


}

function constructProducts(products, flights, isDocumentPassport = null) {
    const constructedProducts = [];
    for (const product of products) {
        const correspondingFlight = flights.find((flight) => (product.flightId == flight.flightId));
        if (correspondingFlight) {
            const { flightNumber, carrierCode, origin, destination, date, time } = correspondingFlight;
            const constructedProduct = {
                isInternational: true,
                boardPoint: origin,
                productId: product.productId,
                departureDate: date.replace(/-/g, ""),
                flightNo: flightNumber
            }
            isDocumentPassport ? (constructedProduct['operatingCarrier'] = carrierCode) : (constructedProduct['marketingCarrier'] = carrierCode)
            constructedProducts.push(constructedProduct)
        }
    }
    return constructedProducts;
}