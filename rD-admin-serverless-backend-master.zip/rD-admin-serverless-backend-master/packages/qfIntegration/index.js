require("dotenv").config();

const { v1: uuid } = require('uuid');

const flifoApi = require('./flifoApi').index;
const warmer = require("lambda-warmer");
const api = require('./api');

const _handleErrors = require('./handleErrorsMethod');

const { params, body, response } =
  require("@oneworld-digital/integration-utils").request;
const { isV2Request, convertToV1Params, convertToV1Body, v1RecordToV2Record } =
  require("@oneworld-digital/integration-utils").versionConverter;

const dynamoDbHelpers = require('./dynamoDbHelpers');


const utils = require('./utils')
const converters = require('./converters');
const documentHelpers = require('./documentHelpers');

exports.record = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id']

  try {
    const isV2 = isV2Request(event);
    console.info("----INCOMING REQUEST: ",ccTransactionId, JSON.stringify(body(event), null, 2))

    let { givenName, familyName, rloc, targetAirlineCode, requestingCarrier } =
      isV2 ? convertToV1Params(body(event)) : params(event);


    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    console.info(ccTransactionId, '= CC transaction id');

    const lookup = { givenName, familyName, rloc, requestingCarrier, ccTransactionId };

    console.log('----cc transaction id: ',ccTransactionId)
    const session = await api.getSession(lookup,ccTransactionId);

    // check for qf Eligibility
    const qfEligibility = await utils.retrieveQfEligibility(session, lookup);

    const travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    // below to convert to cc record
    const ccRecord = converters.convertToCCRecord(rloc, travelerInformation, flightsWithCCAttributes);

    return cb(null, response(200, ccRecord));
  } catch (e) {
    console.log(ccTransactionId,e);
    return _handleErrors(e, cb);
  }
};

exports.eligibility = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id']
  try {

    const isV2 = isV2Request(event);
    console.info("----INCOMING REQUEST", ccTransactionId, JSON.stringify(body(event), null, 2));

    let { rloc, targetAirlineCode, requestingCarrier } =
      isV2 ? convertToV1Params(body(event)) : params(event);

    const passengerRequest = body(event).passengerRequest;

    const {
      givenName, familyName, eTicketNumber
    } = passengerRequest;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    console.log(ccTransactionId, '= CC transaction id');

    const lookup = { givenName, familyName, rloc, ccTransactionId, requestingCarrier };

    const session = await api.getSession(lookup);

    // check for qf Eligibility
    const qfEligibility = await utils.retrieveQfEligibility(session, lookup, ccTransactionId);

    const travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    const requestedPassenger = utils.validatePassengerRequest(travelerInformation, passengerRequest)

    const { requiredDocuments, populatedDocuments } = requestedPassenger[0];

    const ccEligibility = { requiredDocuments, populatedDocuments }

    return cb(null, response(200, ccEligibility));

  } catch (e) {
    console.log(ccTransactionId, e)
    return _handleErrors(e, cb);
  }
}

exports.multieligibility = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id'];
  try {
    const isV2 = isV2Request(event);
    console.info("----INCOMING REQUEST: ",ccTransactionId, JSON.stringify(body(event), null, 2));

    let { familyName, rloc, targetAirlineCode, requestingCarrier } =
      isV2 ? convertToV1Params(body(event)) : params(event);

    const passengerRequests = body(event).passengerRequests;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }


    console.log(ccTransactionId, '= CC transaction id');

    const lookup = { familyName, rloc, requestingCarrier, ccTransactionId };

    const session = await api.getSession(lookup);

    const ccMultiEligibility = [];


    // check for qf Eligibility
    const qfEligibility = await utils.retrieveQfEligibility(session, lookup, ccTransactionId);

    const travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    for (const passenger of passengerRequests) {

      const { givenName, familyName, eTicketNumber } = passenger;

      const requestedPassenger = utils.validatePassengerRequest(travelerInformation, passenger)

      ccMultiEligibility.push({
        givenName, familyName, eTicketNumber, requiredDocuments: requestedPassenger[0].requiredDocuments, populatedDocuments: requestedPassenger[0].populatedDocuments
      })

    }

    return cb(null, response(200, ccMultiEligibility));
  } catch (e) {
    console.log(ccTransactionId, e);
    return _handleErrors(e, cb);
  }
}

exports.documentsupdate = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id'];
  try {
    const isV2 = isV2Request(event);


    let { rloc, targetAirlineCode, requestingCarrier } =
      isV2 ? convertToV1Params(body(event)) : params(event);
    console.info("----INCOMING REQUEST: ",ccTransactionId, JSON.stringify(body(event), null, 2));

    const document = body(event).document;

    const passengerRequest = body(event).passengerRequest;

    const {
      givenName, familyName, eTicketNumber
    } = passengerRequest;

    console.log(ccTransactionId, '= CC transaction id');

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const lookup = { familyName, rloc, requestingCarrier, ccTransactionId };

    const session = await api.getSession(lookup);

    // check for qf Eligibility
    let qfEligibility = await utils.retrieveQfEligibility(session, lookup);

    const travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    //validate the passenger request
    const passenger = utils.validatePassengerRequest(travelerInformation, passengerRequest);

    // handle doc update
    await documentHelpers.handleDocument(session, lookup, passenger[0], flightsWithCCAttributes, document);

    // call qf eligibility again
    qfEligibility = await utils.retrieveQfEligibility(session, lookup, false);

    /* update the cache with latest eligibility response */
    await dynamoDbHelpers.updatePnr(rloc , familyName, qfEligibility);

    const newTravelerInformation = utils.getTravelerInformation(qfEligibility);

    const pax = newTravelerInformation.find((customer) => {
      if (customer.givenName == givenName && customer.familyName == familyName) {
        const { products } = customer;
        const matchingETicketNumber = products.find((product) => product.eTicketNumber == eTicketNumber);
        if (matchingETicketNumber) return customer
      }
    })

    const newCCEligibilityResponse = {
      requiredDocuments: pax.requiredDocuments,
      populatedDocuments: pax.populatedDocuments
    }


    return cb(null, response(200, newCCEligibilityResponse));

  } catch (e) {
    console.log(ccTransactionId, e);
    return _handleErrors(e, cb);
  }
}


exports.singleAcceptance = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id'];
  try {
    const isV2 = isV2Request(event);

    let { rloc, targetAirlineCode, requestingCarrier, familyName } =
      isV2 ? convertToV1Params(body(event)) : params(event);
    console.info("----INCOMING REQUEST: ",ccTransactionId, JSON.stringify(body(event), null, 2));

    const passengerRequest = body(event).passengerRequest;

    const flightsRequest = body(event).flightRequests;

    const requirements = body(event).requirements;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    console.log(ccTransactionId, '= CC transaction id');

    const lookup = { familyName, rloc, targetAirlineCode, ccTransactionId, requestingCarrier };

    const session = await api.getSession(lookup);

    // check for qf Eligibility
    let qfEligibility = await utils.retrieveQfEligibility(session, lookup, ccTransactionId);

    let travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    //validate the passenger request
    const requestedPassenger = utils.validatePassengerRequest(travelerInformation, passengerRequest);

    //validate the flights request - also returns the products that pax wants to checkin to
    const productsToCheckIn = utils.validateFlightsRequest(requestedPassenger, flightsRequest, flightsWithCCAttributes);

    utils.validateCheckinEligibility(productsToCheckIn);

    if (productsToCheckIn != 0) {
      const { customerId } = requestedPassenger[0];

      const requestToQfAcceptance = {
        carryingDangerousGoods: requirements.acknowledgeDGTerms ? false : true,
        checkinTime: '',
        pnr: rloc,
        surname: familyName,
        customers: [
          {
            purposeOfStay: 'vacation', // default it
            customerId
          }
        ],
        products: productsToCheckIn.map((product) => product.productId)
      }

      const acceptanceResponse = await api.qfCheckin(session, requestToQfAcceptance, lookup);

      const isAcceptanceFailed = acceptanceResponse.data.every((acceptanceResponse) => acceptanceResponse.status == 'FAIL');

      console.log('All acceptances failed = ',ccTransactionId, isAcceptanceFailed);

      if (isAcceptanceFailed) {
        const errorMessages = acceptanceResponse.data.map((failureAcceptance) => failureAcceptance.errorMessage);
        const err = {
          id: uuid(),
          CARRIER_ERROR_CODE: 500,
          CARRIER_ERROR_MESSAGE: JSON.stringify({
            id: uuid(),
            message: JSON.stringify(errorMessages),
            code: 500
          })
        }
        return _handleErrors(err, cb);
      }


      /* call QF eligibility to fetch the latest checkin statuses */
      qfEligibility = (await api.fetchQfEligibility(session, lookup)).data;

      /* update the cache with latest eligibility response */
      await dynamoDbHelpers.updatePnr(rloc, familyName, qfEligibility);
    }

    travelerInformation = utils.getTravelerInformation(qfEligibility);

    const acceptancePassengersResponse = converters.convertToCCPassengers(travelerInformation, productsToCheckIn, flightsWithCCAttributes);

    const acceptanceResponse = {
      pnr: rloc,
      passengers: acceptancePassengersResponse,
      flights: flightsRequest
    }

    return cb(null, response(200, acceptanceResponse));

  } catch (e) {
    console.log(ccTransactionId,e);
    return _handleErrors(e, cb);
  }
}

exports.multiAcceptance = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id'];
  try {
    const isV2 = isV2Request(event);

    let { familyName, rloc, targetAirlineCode, requestingCarrier } =
      isV2 ? convertToV1Params(body(event)) : params(event);
    console.info("----INCOMING REQUEST:",ccTransactionId, JSON.stringify(body(event), null, 2));

    const passengerRequests = body(event).passengerRequests;

    const flightsRequest = body(event).flightRequests;

    const requirements = body(event).requirements;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    console.log(ccTransactionId, '= CC transaction id');


    const lookup = { rloc, requestingCarrier, familyName, ccTransactionId };

    const session = await api.getSession(lookup);

    // check for qf Eligibility
    let qfEligibility = await utils.retrieveQfEligibility(session, lookup);

    let travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    //validate the passenger request
    const requestedPassengers = utils.validatePassengerRequest(travelerInformation, passengerRequests);

    /* validate the flights request - also returns the products that pax wants to checkin to */
    const productsToCheckIn = utils.validateFlightsRequest(requestedPassengers, flightsRequest, flightsWithCCAttributes);

    utils.validateCheckinEligibility(productsToCheckIn);

    let isPartial;

    if (productsToCheckIn.length != 0) {
      const requestToQfAcceptance = {
        carryingDangerousGoods: requirements.acknowledgeDGTerms ? false : true,
        checkinTime: '',
        pnr: rloc,
        surname: familyName,
        customers: requestedPassengers.map((pax) => { return { purposeOfStay: 'vacation', customerId: pax.customerId } }),
        products: productsToCheckIn.map((product) => product.productId)
      }

      const qfAcceptanceResponse = await api.qfCheckin(session, requestToQfAcceptance, lookup);

      const isAcceptanceFailed = qfAcceptanceResponse.data.every((acceptanceResponse) => acceptanceResponse.status == 'FAIL');

      console.log('All acceptances failed = ',ccTransactionId, isAcceptanceFailed);

      /* checking if all the acceptance failed*/
      if (isAcceptanceFailed) {
        const errorMessages = qfAcceptanceResponse.data.map((failureAcceptance) => failureAcceptance.errorMessage);
        const err = {
          id: uuid(),
          CARRIER_ERROR_CODE: 500,
          CARRIER_ERROR_MESSAGE: JSON.stringify({
            id: uuid(),
            message: JSON.stringify(errorMessages),
            code: 500
          })
        }
        return _handleErrors(err, cb);
      }

      /* Checking if any of the passengers check-in has failed */
      isPartial = qfAcceptanceResponse.data.some((acceptanceResponse) => acceptanceResponse.status == 'FAIL');

      console.log('Partially accepted?  = ',ccTransactionId, isPartial);

      /* call qf eligibility */
      qfEligibility = (await api.fetchQfEligibility(session, lookup)).data;

      /* update the new checkin status in cache */
      await dynamoDbHelpers.updatePnr(rloc, familyName, qfEligibility);

      travelerInformation = utils.getTravelerInformation(qfEligibility);
    }


    const acceptancePassengersResponse = converters.convertToCCPassengers(travelerInformation, productsToCheckIn, flightsWithCCAttributes);

    const acceptanceResponse = {
      pnr: rloc,
      passengers: acceptancePassengersResponse,
      flights: flightsRequest
    }

    return cb(null, response(isPartial ? 206 : 200, acceptanceResponse));

  } catch (e) {
    console.log(ccTransactionId,e);
    return _handleErrors(e, cb);
  }
}

exports.boardingPass = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id'];

  try {
    const isV2 = isV2Request(event);

    let { rloc, targetAirlineCode, requestingCarrier, familyName } =
      isV2 ? convertToV1Params(body(event)) : params(event);
    console.info("----INCOMING REQUEST:",ccTransactionId, JSON.stringify(body(event), null, 2));

    const passengerRequest = body(event).passengerRequest;

    const flightsRequest = body(event).flightRequests;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }
    console.log(ccTransactionId, '= CC transaction id');

    const lookup = { familyName, rloc, targetAirlineCode, ccTransactionId, requestingCarrier };

    const session = await api.getSession(lookup);

    /* check for QF Eligibility */
    let qfEligibility = await utils.retrieveQfEligibility(session, lookup);

    let travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    /* validate the passenger request */
    const requestedPassenger = utils.validatePassengerRequest(travelerInformation, passengerRequest);

    /* validate the flights request - also returns the products that pax wants to retrieve boardingpass to */
    const requestedProductsForBoardingPass = utils.validateFlightsRequest(requestedPassenger, flightsRequest, flightsWithCCAttributes);

    utils.validateBoardingPassEligibility(requestedProductsForBoardingPass);

    const bpRequestForSinglePax = {
      booking: {
        pnr: rloc,
        surname: familyName
      },
      customers: [
        {
          customerId: requestedPassenger[0].customerId,
          products: requestedProductsForBoardingPass.map((product) => {
            return ({
              passbookRequired: true,
              googleWalletRequired: true,
              productId: product.productId,
            })
          })
        }
      ]
    }

    const qfBoardingPass = await api.qfBoardingPass(session, bpRequestForSinglePax, lookup);

    /* Handling QF boarding pass response can have a 200 code error */
    if (qfBoardingPass.data.errorDetail) {
      const errorMessages = JSON.stringify(qfBoardingPass.data.errorDetail);
      const err = {
        id: uuid(),
        CARRIER_ERROR_CODE: 500,
        CARRIER_ERROR_MESSAGE: JSON.stringify({
          id: uuid(),
          message: errorMessages,
          code: 500
        })
      }
      return _handleErrors(err, cb);
    }


    const boardingPassPassengersResponse = converters.convertToCCPassengers(requestedPassenger, requestedProductsForBoardingPass, flightsWithCCAttributes, isBoardingPass = qfBoardingPass.data);

    const ccBoardingPassResponse = {
      pnr: rloc,
      passengers: boardingPassPassengersResponse,
      flights: flightsRequest
    }

    return cb(null, response(200, ccBoardingPassResponse));

  } catch (e) {
    console.log(ccTransactionId,e);
    return _handleErrors(e, cb);
  }
}

exports.multiBoardingpass = async (event, context, cb) => {
  const ccTransactionId = event.headers['x-cc-request-id'];
  try {
    const isV2 = isV2Request(event);

    let { rloc, targetAirlineCode, requestingCarrier, familyName } =
      isV2 ? convertToV1Params(body(event)) : params(event);
    console.info("----INCOMING REQUEST: ", JSON.stringify(body(event), null, 2));

    const passengerRequests = body(event).passengerRequests;

    const flightsRequest = body(event).flightRequests;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    console.log(ccTransactionId, '= CC transaction id');

    const lookup = { familyName, rloc, targetAirlineCode, requestingCarrier, ccTransactionId };

    const session = await api.getSession(lookup);

    /* check for QF Eligibility */
    let qfEligibility = await utils.retrieveQfEligibility(session, lookup, ccTransactionId);

    let travelerInformation = utils.getTravelerInformation(qfEligibility);
    const flightsWithCCAttributes = utils.getFlightsWithCCAttributes(qfEligibility);

    /* validate the passenger request */
    const requestedPassengers = utils.validatePassengerRequest(travelerInformation, passengerRequests);

    /* validate the flights request - also returns the products that pax wants to retrieve boardingpass to */
    const requestedProductsForBoardingPass = utils.validateFlightsRequest(requestedPassengers, flightsRequest, flightsWithCCAttributes);

    utils.validateBoardingPassEligibility(requestedProductsForBoardingPass);

    const bpRequestForMultiPax = {
      booking: {
        pnr: rloc,
        surname: familyName
      },
      customers: requestedPassengers.map((customerInformation) => {
        return (
          {
            customerId: customerInformation.customerId,
            products: customerInformation.products.filter((product) => requestedProductsForBoardingPass.includes(product)).map((product) => {
              return ({
                passbookRequired: true,
                googleWalletRequired: true,
                productId: product.productId,
              })
            })
          }
        )
      })
    }

    const qfBoardingPass = await api.qfBoardingPass(session, bpRequestForMultiPax, lookup);

    /* Handling QF boarding pass response can have a 200 code error */
    if (qfBoardingPass.data.errorDetail) {
      const errorMessages = JSON.stringify(qfBoardingPass.data.errorDetail);
      const err = {
        id: uuid(),
        CARRIER_ERROR_CODE: 500,
        CARRIER_ERROR_MESSAGE: JSON.stringify({
          id: uuid(),
          message: errorMessages,
          code: 500
        })
      }
      return _handleErrors(err, cb);
    }


    const boardingPassPassengersResponse = converters.convertToCCPassengers(requestedPassengers, requestedProductsForBoardingPass, flightsWithCCAttributes, isBoardingPass = qfBoardingPass.data);

    const ccBoardingPassResponse = {
      pnr: rloc,
      passengers: boardingPassPassengersResponse,
      flights: flightsRequest
    }

    return cb(null, response(200, ccBoardingPassResponse));

  } catch (e) {
    console.log(ccTransactionId,e);
    return _handleErrors(e, cb);
  }
}

exports.flifo = async (event, context, cb) => {
  try {
    if (await warmer(event)) return "warmed";

    const lookup = body(event);

    const res = await flifoApi(lookup);

    cb(null, response(200, res));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};
