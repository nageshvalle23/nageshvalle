const axios = require( "axios" );
const API_URL = process.env.QF_API_URL || "https://api-stage.qantas.com/checkin/carrier-connect/v1";
const API_AUTH_URL = process.env.QF_AUTH_API_URL || "https://api-stage.qantas.com/token?grant_type=client_credentials";
//const REQ_TIMEOUT_IN_MS = 500000;

const apiCredentials = {
    QF: {
        clientSecret: process.env.QF_API_KEY,
    }
};

exports.getSession = async function ( lookup ) {

    const startTime = new Date().getTime();
    const options = {
        method: "POST",
        url: API_AUTH_URL,
        timeout: process.env.QF_API_TIMEOUT,
        headers: {
            'Authorization': `Basic ${ apiCredentials[ 'QF' ].clientSecret }`,
            channel: 'CARRIER_CONNECT',
            userSessionId: lookup.ccTransactionId,
            carrierCode: lookup.requestingCarrier,
            'User-Agent': 'carrier-connect'
        }
    };
    console.info( '\n---REQUEST:auth ', JSON.stringify( options ) )
    let res = null;
    try {
        res = await axios( options );
        console.info( '\n---RESPONSE:auth ', res.status, JSON.stringify( res.data ) )
    } catch ( error ) {
        if ( res && typeof res.data !== 'undefined' ) {
            console.info( '\n---RESPONSE:auth ', res.status, ( res.data ) )
        } else {
            console.error( '----ERROR:', error.code, error.message )
            throw new Error( "Internal Server Error!" );
        }

    }
    if ( res.status === 200 && res.data ) {
        const endTime = new Date().getTime();
        console.info( `--- Response time --- ${ endTime - startTime }ms`, lookup.ccTransactionId )
        return res.data;
    }
    else {
        console.error( '----ERROR:', res.status, JSON.stringify( res.data ) )
        throw new Error( "Internal Server Error!" );
    }

};

exports.fetchQfEligibility = async function ( session, lookup ) {

    const startTime = new Date().getTime();
    const options = {
        method: "POST",
        url: `${ API_URL }/passenger/eligibility`,
        timeout: process.env.QF_API_TIMEOUT,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${ session.access_token }`,
            channel: 'CARRIER_CONNECT',
            userSessionId: lookup.ccTransactionId,
            carrierCode: lookup.requestingCarrier,
            'User-Agent': 'carrier-connect'
        },
        data: {
            pnr: lookup.rloc,
            surname: lookup.familyName
        }
    };
    console.info( '\n---REQUEST:eligibility ', JSON.stringify( options ) )
    let res = null;
    try {
        res = await axios( options );
        console.info( '\n---RESPONSE:eligibility ', res.status, JSON.stringify( res.data ) )
    } catch ( error ) {
        if ( res && typeof res.data !== 'undefined' ) {
            console.info( '\n---RESPONSE:eligibility ', res.status, JSON.stringify( res.data ) )
        } else {
            console.error( '----ERROR:', error.code, error.message )
            throw new Error( "Internal Server Error!" );
        }

    }
    console.info( `-- Response time for QF Eligibility --- ${ new Date().getTime() - startTime } ms---`, lookup.ccTransactionId );
    return res;

}

exports.updatePassport = async function ( session, data, lookup ) {
    const startTime = new Date().getTime();
    const options = {
        method: "POST",
        url: `${ API_URL }/passenger/passport`,
        timeout: process.env.QF_API_TIMEOUT,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${ session.access_token }`,
            channel: 'CARRIER_CONNECT',
            userSessionId: lookup.ccTransactionId,
            carrierCode: lookup.requestingCarrier,
            'User-Agent': 'carrier-connect'
        },
        data
    };
    console.info( '\n---REQUEST:passport ', JSON.stringify( options ) );
    let res = null;
    try {
        res = await axios( options );
        console.info( '\n---RESPONSE:passport ', res.status, res.data )
    } catch ( error ) {
        if ( res && typeof res.data !== 'undefined' ) {
            console.info( '\n---RESPONSE:passport ', res.status, JSON.stringify( res.data ) )
        } else {
            console.error( '----ERROR:', error.code, error.message )
            throw new Error( "Internal Server Error!" );
        }
    }
    console.info( `-- Response time for QF Passport Update --- ${ new Date().getTime() - startTime } ms---`, lookup.ccTransactionId );
    return res;
}

exports.updateDocument = async function ( session, data, lookup ) {
    const startTime = new Date().getTime();
    const options = {
        method: "POST",
        url: `${ API_URL }/passenger/document`,
        timeout: process.env.QF_API_TIMEOUT,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${ session.access_token }`,
            channel: 'CARRIER_CONNECT',
            userSessionId: lookup.ccTransactionId,
            carrierCode: lookup.requestingCarrier,
            'User-Agent': 'carrier-connect'
        },
        data
    };
    console.info( '\n---REQUEST:document ', JSON.stringify( options ) )
    let res = null;
    try {
        res = await axios( options );
        console.info( '\n---RESPONSE:document ', res.status, JSON.stringify( res.data ) )
    } catch ( error ) {
        if ( res && typeof res.data !== 'undefined' ) {
            console.info( '\n---RESPONSE:document ', res.status, JSON.stringify( res.data ) )
        } else {
            console.error( '----ERROR:', error.code, error.message )
            throw new Error( "Internal Server Error!" );
        }
    }
    console.info( `-- Response time for QF Document Update --- ${ new Date().getTime() - startTime } ms---`, lookup.ccTransactionId );
    return res;
}

exports.qfCheckin = async function ( session, data, lookup ) {
    const startTime = new Date().getTime();
    const options = {
        method: "POST",
        url: `${ API_URL }/passenger/acceptance`,
        timeout: process.env.QF_API_TIMEOUT,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${ session.access_token }`,
            channel: 'CARRIER_CONNECT',
            userSessionId: lookup.ccTransactionId,
            carrierCode: lookup.requestingCarrier,
            'User-Agent': 'carrier-connect'
        },
        data
    };
    console.info( '\n---REQUEST:acceptance ', JSON.stringify( options ) )
    let res = null;
    try {
        res = await axios( options );
        console.info( '\n---RESPONSE:acceptance ', res.status, JSON.stringify( res.data ) )
    } catch ( error ) {
        if ( res && typeof res.data !== 'undefined' ) {
            console.info( '\n---RESPONSE:acceptance ', res.status, JSON.stringify( res.data ) )
        } else {
            console.error( '----ERROR:', error.code, error.message )
            throw new Error( "Internal Server Error!" );
        }
    }
    console.info( `-- Response time for QF Acceptance --- ${ new Date().getTime() - startTime } ms---`, lookup.ccTransactionId );
    return res;
}

exports.qfBoardingPass = async function ( session, data, lookup ) {
    const startTime = new Date().getTime();
    const options = {
        method: 'POST',
        url: `${ API_URL }/passenger/boarding-pass`,
        timeout: process.env.QF_API_TIMEOUT,
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${ session.access_token }`,
            channel: 'CARRIER_CONNECT',
            userSessionId: lookup.ccTransactionId,
            carrierCode: lookup.requestingCarrier,
            'User-Agent': 'carrier-connect'
        },
        data
    };
    console.info( '\n---REQUEST:boarding-pass ', JSON.stringify( options ) )
    let res = null;
    try {
        res = await axios( options );
        console.info( '\n---RESPONSE:boarding-pass ', res.status, JSON.stringify( res.data ) )
    } catch ( error ) {
        if ( res && typeof res.data !== 'undefined' ) {
            console.info( '\n---RESPONSE:boarding-pass ', res.status, JSON.stringify( res.data ) )
        } else {
            console.error( '----ERROR:', error.code, error.message )
            throw new Error( "Internal Server Error!" );
        }
    }
    console.info( `--- Response time for QF Boarding pass --- ${ new Date().getTime() - startTime } ms -----`, lookup.ccTransactionId );
    return res;
}