const api = require('./')

async function run(event) {
  await api.handler(event, {}, (err, res) => {
    const body = JSON.parse(res.body);
    console.log(JSON.stringify(body, null, 2));
  })
}

const lookup = {
  carrierCode: process.argv[2],
  flightNumber: process.argv[3],
  origin: process.argv[4],
  destination: process.argv[5],
  date: process.argv[6]
}

const event = {
  queryStringParameters: {},
  body: JSON.stringify(lookup)
}

run(event);
