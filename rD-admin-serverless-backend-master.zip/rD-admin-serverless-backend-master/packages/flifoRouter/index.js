const warmer = require("lambda-warmer");
const uuid = require('uuid').v1;
const parser = require('fast-xml-parser');
const he = require('he');
const fetch = require('node-fetch');
const dlv = require('dlv');
const {DateTime} = require('luxon');

exports.handler = async (event, ctx, cb) => {
  try {
    if (await warmer(event)) return "warmed";

    const lookup = body(event);

    const res = await routeLookup(lookup);

    cb(null, response(200, res));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

async function routeLookup (lookup) {
  console.log(isWithinLookupWindow(lookup))
  if (isWithinLookupWindow(lookup)) {
    console.log('OAG')
    return fetchOAG(lookup);
  }
  console.log('CTK')
  return fetchCTK(lookup);
}


async function fetchOAG (lookup) {

  const res = await fetch(
    'https://0vb5uring2.execute-api.us-east-1.amazonaws.com/Prod/flight', {
      method: 'POST',
      body: JSON.stringify(lookup),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.RD_API_KEY_PROD
      }
  })

  return res.json();
}

async function fetchCTK ({origin, destination, date, flightNumber, carrierCode}) {
  const scheduleData = await fetchScheduleCTK(origin, destination, date);

  const flights = dlv(scheduleData,
                      ['flights',
                       0,
                       'flight']);

  const flight = flights.filter(f => {
    const legs = dlv(f, ['legs', 0, 'leg']);
    return legs &&
           legs.length === 1 &&
           f.carFlight === [carrierCode.toUpperCase(), flightNumber].join(' ')})[0]

  return convertFlightScheduleToFlifoObj(flight, date);
}

async function fetchScheduleCTK (origin, dest, date) {
  const [year, month, day] = date.split('-')

  const res = await fetch(
    'http://ctk.innovataw3svc.com/ctk.asmx',
    {
      method: 'post',
      body: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:cus="http://CustomDataTimeTableToolKit.com/">
   <soapenv:Header>
      <cus:WSAuthenticate>
         <!--Optional:-->
         <cus:CustomerRefCode>ONW-CTK</cus:CustomerRefCode>
         <!--Optional:-->
         <cus:Password>skelkcid</cus:Password>
         <!--Optional:-->
         <cus:WebServicesRefCode>TKC</cus:WebServicesRefCode>
         <!--Optional:-->
         <cus:SrcIPAddress>?</cus:SrcIPAddress>
      </cus:WSAuthenticate>
   </soapenv:Header>
   <soapenv:Body>
      <cus:GetSchedules>
         <cus:_sSchedulesSearchXML>
     	  <![CDATA[<GetSchedules_Input customerCode="ONW-CTK" productCode="External"  dptCode="${origin}" dptCodeType="STA"  arvCode="${dest}" arvCodeType="STA" MM="${month}" DD="${day}" YYYY="${year}" searchType="B" cnxType="B" IncludeSummary="false" />]]>
         </cus:_sSchedulesSearchXML>
      </cus:GetSchedules>
   </soapenv:Body>
</soapenv:Envelope>`,
      headers: {
        'Content-Type': 'text/xml;charset=UTF-8',
        'soapAction': 'http://CustomDataTimeTableToolKit.com/GetSchedules'
      }
  })

  const text = await res.text();

  const options = {
    attributeNamePrefix : "",
    attrNodeName: false,
    ignoreAttributes : false,
    ignoreNameSpace : false,
    allowBooleanAttributes : true,
    parseNodeValue : true,
    parseAttributeValue : false,
    trimValues: true,
    parseTrueNumberOnly: false,
    arrayMode: true,
    attrValueProcessor: (val, attrName) => he.decode(val, {isAttributeValue: true}),
    tagValueProcessor : (val, tagName) => he.decode(val),
  };


  const tObj = parser.getTraversalObj(he.decode(text), options);
  const jsObj = parser.convertToJson(tObj,options);

  return dlv(jsObj, ['soap:Envelope',
                     0,
                     'soap:Body',
                     0,
                     'GetSchedulesResponse',
                     0,
                     'GetSchedulesResult',
                     0,
                     'flightResults',
                     0
  ]);
}

function convertFlightScheduleToFlifoObj (schedule, date) {
  const leg = dlv(schedule, ['legs', 0, 'leg', 0]);

  const dptTime = leg.dptTime.padStart(4, '0');
  const arvTime = leg.arvTime.padStart(4, '0');

  const dptDateTime = DateTime.fromFormat(date + ' '  + dptTime + ' ' + leg.dptGmtOffset, 'yyyy-MM-dd HHmm ZZZ', { setZone: true }).plus({days: parseInt(leg.dptDayIndicator)})

  const arvDateTime = DateTime.fromFormat(date + ' '  + arvTime + ' ' + leg.arvGmtOffset, 'yyyy-MM-dd HHmm ZZZ', { setZone: true }).plus({days: parseInt(leg.arvDayIndicator)});

  const flightNumber = leg.flightNumber;
  const carrierCode = leg.carCode;

  const departure = {
    airportCode: dlv(leg, ['dpt', 0, 'aptCode']),
    terminal: dlv(leg, ['dpt', 0, 'terminal']),
    scheduled: {
      local: dptDateTime.toFormat("yyyy-MM-dd'T'HH:mm:ssZZZ"),
      utc: dptDateTime.setZone('GMT').toFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"),
      source: 'CTK'
    },
    estimated: {
      local: null,
      utc: null,
      source: 'CTK'
    },
    actual: {
      local: null,
      utc: null,
      source: 'CTK'
    }
  };

  const arrival = {
    airportCode: dlv(leg, ['arv', 0, 'aptCode']),
    terminal: dlv(leg, ['arv', 0, 'terminal']),
    scheduled: {
      local: arvDateTime.toFormat("yyyy-MM-dd'T'HH:mm:ssZZZ"),
      utc: arvDateTime.setZone('GMT').toFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"),
      source: 'CTK'
    },
    estimated: {
      local: null,
      utc: null,
      source: 'CTK'
    },
    actual: {
      local: null,
      utc: null,
      source: 'CTK'
    }
  }

  const sector = {
    status: 'SCHEDULED',
    sourceStatus: 'SCHEDULED',
    codeshares: [],
    arrival,
    departure
  };

  const flight = {
    source: 'CTK',
    flightNumber,
    carrierCode,
    sectors: [sector],
  };

  flight.summary = {
    departure: {
      at: {
        local: dptDateTime,
        type: 'schedule'
      }
    },
    arrival: {
      at: {
        local: arvDateTime,
        type: 'schedule'
      }
    }
  }

  return flight;
}

function isWithinLookupWindow(lookup) {
  const flightDate = DateTime.fromISO(lookup.date)
  const {days: daysApart} = flightDate.diff(DateTime.local().startOf('day'), 'days').toObject();

  return daysApart < (({
    // Days each carrier allows for flight status lookups
    AA: 3,
    QR: 7,
    CX: 5,
    BA: 10,
    AT: 7,
    S7: 30,
    UL: Infinity,
    MH: 4,
    AY: 2,
    IB: 4,
    QF: 3,
    JL: 3,
    RJ: 5,
    FJ: 3 })[lookup.carrierCode] || Infinity); // default is no window AKA Infinity
}


function body (event) {
  return JSON.parse(event.body) || {}
}

function response(status, res) {
  return {
    statusCode: status,
    body: JSON.stringify(res) || '',
    headers: {
      'Content-Type':'application/json'
    }
  };
}


function _handleErrors(err, cb) {

  // Flights not found
  if (err.statusCode === 404) {
    return cb(null, response(200, []));
  }

  const body = {
    id: uuid(),
    message: 'Failed to retrieve flight.',
    type: 'Internal',
    code: '502',
  };

  console.error(`Request failed with status ${body.code} and body ${JSON.stringify(body, null, 2)}`);

  return cb(null, response(body.code, body));
}
