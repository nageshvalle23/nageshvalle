exports.PAX_ID = ['passengerIdentifier', 'productIdentifier'].join('.')
exports.TICKET_NUMBER = ['couponDetail', 'eticketNumber'].join('.')

exports.FLIGHT_PAX_ID = ['paxFlightIdentifier', exports.PAX_ID].join('.')
exports.FLIGHT_ID = ['paxFlightIdentifier', 'flightIdentifier', 'uniqueIdentifier'].join('.')
exports.FLIGHT_PRODUCT_ID = ['paxFlightIdentifier', 'flightIdentifier', 'productIdentifier'].join('.')

exports.ORIGIN = ['departureStation', 'airportCode'].join('.')
exports.DEST = ['arrivalStation', 'airportCode'].join('.')
exports.CARRIER = ['carrier', 'operatingCarrier'].join('.')
exports.FLIGHT_NUMBER = ['flightNumber'].join('.')
exports.DATE = ['carrier', 'carrier'].join('.')
exports.STATUS = ['pasengerTimelineInfo', 'checkinStatus'].join('.')
