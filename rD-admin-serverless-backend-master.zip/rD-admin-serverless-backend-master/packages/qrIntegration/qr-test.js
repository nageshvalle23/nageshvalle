const api = require('./index');

const rloc = process.argv[2];
const family  = process.argv[3];
const given = process.argv[4];

const recordRequest = {
  rloc: rloc || 'RMOEQK',
  givenName: given || 'JESSE',
  familyName: family || 'JAMES',
  targetCarrierCode: 'QR',
  requestingCarrierCode: 'IB'
}

const passengerRequest = {
  familyName: recordRequest.familyName,
  givenName: recordRequest.givenName,
  eTicketNumber: '0012371322531', 
};

const flightRequests = [
  {
    "origin": "DOH",
    "destination": "HKG",
    "flightNumber": "0818",
    "carrier": "QR",
    "date": "2019-10-17"
},
{
    "origin": "HKG",
    "destination": "TPE",
    "flightNumber": "0464",
    "carrier": "CX",
    "date": "2019-10-17"
}
];

const requirements = {
  acknowledgeDGTerms: true
};

const updateRequest = {
  recordRequest, 
  passengerRequest, 
  flightRequests, 
  regulatoryInfo: {
    gender: 'M',
    dateOfBirth: '1978-01-05', 
    countryOfResidenceCode: 'USA',
    nationalityCode: 'USA',
    travelDoc: {
      'PASSPORT': {
        regulatoryGivenName: 'jesses',
        regulatoryFamilyName: 'jamess',
        expiryDate: '2022-01-05',
        issuedDate: '2019-01-05',
        countryOfIssue: 'USA',
        documentType: 'PASSPORT',
        documentNumber: '999995'
      },
      'VISA': {
        regulatoryGivenName: 'jesses',
        regulatoryFamilyName: 'jamess',
        expiryDate: '2022-01-05',
        issuedDate: '2019-01-05',
        countryOfIssue: 'USA',
        documentType: 'VISA',
        documentNumber: '999995'
      }
    }

  },
  destinationAddress: {
    city: 'new york', 
    state: 'NY', 
    country: 'USA', 
    street: '2 park ave fl 5', 
    zipCode: '10036'
  },
  // emergencyContact: {      TODO not implemented yet
  //   phone: '1234567890', 
  //   email: 'ifly@high.com'
  // }, 
}; // updateRequest



console.log(`Getting record for lookup ${JSON.stringify(recordRequest, null, 2)}`)
var event = {
  queryStringParameters: recordRequest,
  body: null
}

const res = api.record(event, {}, (err, res) => {
  const body = JSON.parse(res.body);
  console.log(JSON.stringify(body, null, 2));

    console.log('>>>>>>>>>>>>>>>>>>>>>>> Update passenger')
    console.log('')
    console.log('')
    console.log('')
    console.log('')

    event.body = JSON.stringify(updateRequest, null, 2);
    console.log(`Trying to update passenger for ${event.body}`);

    api.passenger(event, {}, (err, res2) => {
      console.log('update result', JSON.stringify(res2, null, 2));
  
        // console.log('>>>>>>>>>>>>>>>>>>>>>>> check in')
        // console.log('')
        // console.log('')
        // console.log('')
        // console.log('')  

        // event = {
        //   queryStringParameters: recordRequest,
        //   body: JSON.stringify({
        //     checkIn: true, 
        //     passengerLookups: [ passengerRequest ], 
        //     flightLookups: flightRequests, 
        //     requirements
        //   })
        // };
        // console.log(`Attempting to check lookup in for `,JSON.stringify(event));

        // api.checkin(event, {}, (err, res2) => {
        //   console.log(JSON.stringify(res2, null, 2));

    //     event = {
    //       queryStringParameters: recordRequest,
    //       body: JSON.stringify({
    //         passengerLookups: [ passengerRequest ], 
    //         flightLookups: flightRequests, 
    //       })
    //     };
    //     console.log(`Attempting boardingpass for `,JSON.stringify(event));

    //     api.boardingpass(event, {}, (err, res3) => {
    //       console.log(JSON.stringify(JSON.parse({event}), null, 2));
    //     }).then(() => {}); // boarding pass
    //    }).then(() => {}); // check in
    }).then(() => {}); // passenger

}).then(() => {})
