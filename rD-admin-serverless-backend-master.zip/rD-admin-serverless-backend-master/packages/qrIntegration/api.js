const axios = require('axios');

const helpers = require('./helpers');

const QR_API_URL = process.env.QR_API_URL || 'https://qoresit.qatarairways.com.qa/cki-services';

const QR_APP_CHANNEL = process.env.QR_APP_CHANNEL || 'CCF';

// 1
const RETRIEVE_TRIP_PATH = '/search/retrieveTrip';
// 2
const GET_TRIP_PATH = '/search/getTrip';

// 2b
const RELOAD_TRIP_PATH = '/search/reloadTrip';

// 3
const ACK_DG_PATH = '/apis/acknowledgeDGTerms';

// 3 - travel docs
const APIS_UPDATE_PATH = '/apis/update';

const APIS_EMERGENCY_PATH = '/apis/updateECDetails';

// 4
const CKIN_PATH = '/acceptance/confirm';

// 4b
const CANCEL_CKIN_PATH = '/acceptance/cancel';

const REGULATORY_CHECK_PATH = '/apis/performRegulatoryCheck'

/* "apisDetailsComplete": false, -- determines if docs are up valid t/f
 *
 * reloadTrip -- refresh from amadeus
 *
 * confirmation pass vs boarding pass
 *
 * can i send entire trip?
 *
 * HPCP/HPBP HPCP has no barcode
 *
 * "pasengerTimelineInfo": {
 * "checkinStatus": "CHECKED_IN", -- definitive place to confirm checkin */

exports.retrieveSession = async function(rloc, familyName) {
  if ((!rloc || /.+/.test(rloc) === false) || (!familyName || /.+/.test(familyName) === false)) {
    throw new Error('Missing parameters');
  }

  console.info(`In Session. Session Request Url = ${QR_API_URL + RETRIEVE_TRIP_PATH}`);
  console.info(
    `In Session, Request payload = ${JSON.stringify({
      searchType: "BOOKINGREFERENCENUMBER",
      searchValue: rloc,
      lastName: familyName,
      appChannel: QR_APP_CHANNEL,
      principal: rloc,
      locale: "en_global",
      appModule: "CCF",
    }, null, 2)}`
  );

  // returns conversation token and auth
  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + RETRIEVE_TRIP_PATH,
    data: {
      searchType: 'BOOKINGREFERENCENUMBER',
      searchValue: rloc,
      lastName: familyName,
      appChannel: QR_APP_CHANNEL,
      principal: rloc,
      locale: 'en_global',
      appModule: 'CCF'
    },
    headers: {
      'Content-Type': 'application/json',
    },
  }));

  const authorization = res.headers['authorization'];
  const conversationToken = res.data.conversationToken;

  if (!authorization || !conversationToken) {
    throw new Error('Failed to retrieve session data');
  }

  console.info(
    `In Session, Session Response: ${JSON.stringify(
      {
        conversationToken,
        authorization: "Bearer " + "QR_AUTH_TOKEN",
      },
      null,
      2
    )}`
  );
  
  return {
    conversationToken,
    authorization: 'Bearer ' + authorization,
  };
};

exports.getTrip = async function(sessionData) {
  const {conversationToken, authorization} = sessionData;

  if (!conversationToken || !authorization) {
    throw new Error('Unable to get trip');
  }

  console.info(`In Trip. Trip Request Url = ${QR_API_URL + GET_TRIP_PATH}`);
  console.info(`In Trip. Request payload = ${JSON.stringify({
    conversationToken: sessionData.conversationToken,
  }, null, 2)}`);
  
  // returns a trip object
  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + GET_TRIP_PATH,
    data: {
      conversationToken: sessionData.conversationToken,
    },
    headers: {
      'Authorization': sessionData.authorization,
      'Content-Type': 'application/json',
    },
  }));

  const {data} = res;

  if (!data.trip) {
    throw new Error('Failed to retrieve trip data');
  }
  console.log("After Successfull Trip API..!!");
  console.log(`Trip API response = ${JSON.stringify(data, null, 2)}`);

  return data;
};

exports.ackDgTerms = async function(sessionData, fullTrip, paxs, flights) {
  const {conversationToken, authorization} = sessionData;

  if (!conversationToken || !authorization || (!flights || !flights.length) || (!paxs || !paxs.length) ) {
    throw new Error('Missing parameters: DG');
  }

  const req = helpers.filterTrip(fullTrip, sessionData, paxs, flights);

  console.info(`In ackTerms. Request Url = ${QR_API_URL + ACK_DG_PATH}`);
  console.info(`In ackTerms. Request payload = ${JSON.stringify(req, null, 2)}`);

  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + ACK_DG_PATH,
    data: req,
    headers: {
      'Authorization': sessionData.authorization,
    },
  }));

  const {data} = res;

  if (!data.trip) {
    throw new Error('Failed to retrieve trip selection data');
  }

  console.log("After Successfull ackTerms API..!!");
  console.info(`AckTerms API response = ${JSON.stringify(data, null, 2)}`);

  return data;
};

exports.regulatoryInfoCheck = async function(sessionData, fullTrip, paxs, flights) {
  const {conversationToken, authorization} = sessionData;

  if (!conversationToken || !authorization || (!flights || !flights.length) || (!paxs || !paxs.length) ) {
    throw new Error('Missing parameters: DG');
  }

  const req = helpers.filterTrip(fullTrip, sessionData, paxs, flights);

  console.info(`In regulatoryInfoCheck. Request Url = ${QR_API_URL + REGULATORY_CHECK_PATH}`);
  console.info(`In regulatoryInfoCheck. Request payload = ${JSON.stringify(req, null, 2)}`);

  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + REGULATORY_CHECK_PATH,
    data: req,
    headers: {
      'Authorization': sessionData.authorization,
    },
  }));

  const {data} = res;

  if (!data.trip) {
    throw new Error('Failed to retrieve trip selection data');
  }

  console.log("After Successfull regulatoryInfoCheck API..!!");
  console.info(`regulatoryInfoCheck API response = ${JSON.stringify(data, null, 2)}`);

  return data;
};

exports.updateTravelDoc = async function(sessionData, fullTrip, updateRequest) {
  const {conversationToken, authorization} = sessionData;
  const {passengerRequest, flightRequests, regulatoryInfo, destinationAddress} = updateRequest;

  if (!conversationToken || !authorization || !passengerRequest || !regulatoryInfo || !flightRequests || !flightRequests.length) {
    throw new Error('Missing parameters: APIS update');
  }

  const travelDoc = helpers.buildTravelDoc(fullTrip, sessionData, updateRequest);

  console.info(`In updateTravelDoc. Request Url = ${QR_API_URL + APIS_UPDATE_PATH}`);
  console.info(`In updateTravelDoc. Request payload = ${JSON.stringify(travelDoc, null, 2)}`);

  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + APIS_UPDATE_PATH,
    data: travelDoc,
    headers: {
      'Authorization': sessionData.authorization,
    },
  }));

  const {data} = res;

  if (!data.trip) {
    const err = new Error('QR error');
    err.CARRIER_ERROR_CODE = '000';

    if ((data.apisErrors[0]) && (data.apisErrors[0].errorCategory)) {
      err.CARRIER_ERROR_MESSAGE = 'Documents update failed. APIS error: ' + data.apisErrors[0].errorCategory;
      throw err;
    } else {
      err.CARRIER_ERROR_MESSAGE = 'Documents update failed.';
      throw err;
    }
  }

  console.info(`In updateTravelDoc API response = ${JSON.stringify(data, null, 2)}`);
  return res;
};

exports.updateEmergencyDoc = async function(sessionData, fullTrip, updateRequest) {
  const {conversationToken, authorization} = sessionData;
  const {passengerRequest, flightRequests, regulatoryInfo} = updateRequest;

  if (!conversationToken || !authorization || !passengerRequest || !regulatoryInfo || !flightRequests || !flightRequests.length) {
    throw new Error('Missing parameters: APIS update');
  }

  const emergencyDoc = helpers.buildEmergencyDoc(fullTrip, sessionData, updateRequest);

  console.info(`In updateEmergencyDoc. Request Url = ${QR_API_URL + APIS_EMERGENCY_PATH}`);
  console.info(`In updateEmergencyDoc. Request payload = ${JSON.stringify(emergencyDoc, null, 2)}`);

  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + APIS_EMERGENCY_PATH,
    data: emergencyDoc,
    headers: {
      'Authorization': sessionData.authorization,
    },
  }));

  const {data} = res;

  if (!data.trip) {
    const err = new Error('QR error');
    err.CARRIER_ERROR_CODE = '000';

    if ((data.apisErrors[0]) && (data.apisErrors[0].errorCategory)) {
      err.CARRIER_ERROR_MESSAGE = 'Documents update failed. APIS error: ' + data.apisErrors[0].errorCategory;
      throw err;
    } else {
      err.CARRIER_ERROR_MESSAGE = 'Documents update failed.';
      throw err;
    }
  }

  console.info(`In updateEmergencyDoc API response = ${JSON.stringify(data, null, 2)}`);
  return res;
};


exports.checkin = async function(sessionData, tripSelection) {
  const {conversationToken, authorization} = sessionData;

  if ( !conversationToken || !authorization || !tripSelection ) {
    throw new Error('Missing parameters: checkin');
  }

  console.info(`In checkin. Request Url = ${QR_API_URL + CKIN_PATH}`);
  console.info(`In checkin. Request payload = ${JSON.stringify({
    conversationToken,
    trip: tripSelection,
  }, null, 2)}`);

  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + CKIN_PATH,
    data: {
      conversationToken,
      trip: tripSelection,
    },
    headers: {
      'Authorization': sessionData.authorization,
    },
  }));

  const {data} = res;

  if ( !data.trip || !helpers.isCheckedIn(data.trip) ) {
    const err = new Error('QR error');
    err.CARRIER_ERROR_CODE = '000';

    if ((data.initCustAccepErrors[0]) && (data.initCustAccepErrors[0].errorCategory)) {
      err.CARRIER_ERROR_MESSAGE = 'Failed to check passenger(s) in' + data.initCustAccepErrors[0].errorCategory;
      throw err;
    } else {
      const err = new Error('QR error');
      err.CARRIER_ERROR_MESSAGE = 'Failed to check passenger(s) in';
      throw err;
    }
  }

  console.log("After Successfull CheckIn API..!!");
  console.info(`In checkin API response = ${JSON.stringify(data, null, 2)}`);

  return data;
};

exports.cancelCheckin = async function(sessionData, qrRes) {
  const {conversationToken, authorization} = sessionData;

  if (!conversationToken || !authorization || !qrRes ) {
    throw new Error('Missing parameters: CANCEL CKIN');
  }

  if (helpers.isCheckedIn(qrRes.trip) === false) {
    throw new Error('Cannot cancel: trip not checked in');
  }

  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + CANCEL_CKIN_PATH,
    data: qrRes,
    headers: {
      'Authorization': sessionData.authorization,
    },
  }));

  const {status, reloadTripRequired} = res.data;

  if (status !== 'SUCCESS') {
    throw new Error('Failed to cancel checkin data');
  }

  return {status, reloadTripRequired};
};

exports.reloadTrip = async function(sessionData) {
  const {conversationToken, authorization} = sessionData;

  if (!conversationToken || !authorization) {
    throw new Error('Unable to reload trip');
  }

  // returns a trip object
  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: QR_API_URL + RELOAD_TRIP_PATH,
    data: {
      conversationToken: sessionData.conversationToken,
    },
    headers: {
      'Authorization': sessionData.authorization,
      'Content-Type': 'application/json',
    },
  }));

  const {data} = res;

  if (!data.trip) {
    throw new Error('Failed to retrieve trip data');
  }

  return data;
};

async function _gatherAndReportErrors(promisedApiCall) {
  const res = await promisedApiCall;

  // TODO: do we ever get more than one of these back?
  if (res.data && res.data.errorObject && Array.isArray(res.data.errorObject)) {
    const err = new Error('QR error');
    err.CARRIER_ERROR_MESSAGE = res.data.errorObject[0].errorDescription;
    err.CARRIER_ERROR_CODE = res.data.errorObject[0].errorName;
    throw err;
  }

  return res;
}
