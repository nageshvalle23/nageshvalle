exports.QRToQRMapping = {
  dobReqd: 'dateOfBirth',
  nationalityReqd: 'nationalityCode',
  countryOfResidenceReqd: 'countryOfResidenceCode',
  surnameReqd: 'regulatoryLastName',
  givenNameReqd: 'regulatoryFirstName',
  genderReqd: 'gender',
  titleReqd: 'title',
  passportReqd: {
    documentType: "PASSPORT",
    value: 'documentType'
  },
  passportNumberReqd: {
    documentType: "PASSPORT",
    value: 'documentReferenceNumber'
  },
  passportExpiryDateReqd: {
    documentType: "PASSPORT",
    value: 'expiryDate'
  },
  passportCountryOfIssueReqd: {
    documentType: "PASSPORT",
    value: 'countryOfIssue'
  },
  passportIssueDateReqd: {
    documentType: "PASSPORT",
    value: 'issueDate'
  },
    applicableCountryReqd: {
    documentType: "VISA",
    value: 'applicableCountry'
  },
  visaReqd: {
    documentType: "VISA",
    value: 'documentType'
  },
  visaNumberReqd: {
    documentType: "VISA",
    value: 'documentReferenceNumber'
  },
  visaExpiryDateReqd: {
    documentType: "VISA",
    value: 'expiryDate'
  },
  visaCountryOfIssueReqd: {
    documentType: "VISA",
    value: 'countryOfIssue'
  },
  visaCityIssueReqd: {
    documentType: "VISA",
    value: 'cityOfIssue'
  },
  visaIssueDateReqd: {
    documentType: "VISA",
    value: 'issueDate'
  },
  purposeOfVisitReqd: {
    documentType: "VISA",
    value: 'purposeOfVisit'
  },
  destinationAddressReqd: {
    addressType: 'DESTINATION',
    value: 'type'
  },
  destinationCityReqd: {
    addressType: 'DESTINATION',
    value: 'city'
  },
  destinationCountryReqd: {
    addressType: 'DESTINATION',
    value: 'country'
  },
  destinationStateReqd: {
    addressType: 'DESTINATION',
    value: 'state'
  },
  destinationStreetReqd: {
    addressType: 'DESTINATION',
    value: 'street'
  },
  destinationZipReqd: {
    addressType: 'DESTINATION',
    value: 'zipCode'
  },
  emergencyContactNameReqd: {
    emergencyContact: 'EMERGENCY_CONTACT',
    value: 'lastName'
  },
  emergencyContactNumberReqd: {
    emergencyContact: 'EMERGENCY_CONTACT',
    value: 'contactNumber'
  },
  emergencyContactCountryCodeReqd: {
    emergencyContact: 'EMERGENCY_CONTACT',
    value: 'contactCountry'
  }
};
exports.QRToCCMapping = {
  //QR To CC

  'PASSPORT': {
    firstName: "givenName",
    lastName: "familyName",
    dateOfBirth: "dateOfBirth",
    gender: "gender",
    documentReferenceNumber: "passportNumber",
    expiryDate: "expiryDate",
    nationalityCode: "nationality",
    countryOfIssue: "countryOfIssue",
    documentType: 'PASSPORT'
  },

  'VISA': {
    documentReferenceNumber: 'documentNumber',
    expiryDate: 'expiryDate',
    countryOfIssue: 'countryOfIssue',
    documentType: 'VISA'
  },

  'RESIDENT_ADDRESS': {
    countryOfResidenceCode: 'countryOfResidence'
  },

  'DESTINATION_ADDRESS': {
    state: 'stateProv',
    street: 'street',
    city: 'city',
    country: 'country',
    zipCode: 'postalCode',
    type: 'DESTINATION'
  },

  'EMERGENCY_CONTACT': {
    lastName: 'familyName',
    contactNumber: 'phone',
    contactCountry: 'countryCode'
  },
  'SEE_AGENT': {
    "message": 'If CC returns SEE_AGENT, Online-Checkin is not possible'
  }
}
