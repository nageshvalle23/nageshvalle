const dlv = require("dlv")
const paths = require("./paths");
const airportCodes = require('airport-codes');
const lookup = require('country-code-lookup');
const { codes } = require('country-calling-code');
const helpers = require('./helpers');
const api = require('./api');
const db = require('./db');
const {QRToQRMapping, QRToCCMapping} = require('./map');

function params(event) {
  return event.queryStringParameters || {}
}

function body(event) {
  return JSON.parse(event.body) || {}
}

function response(status, res) {
  return {
    statusCode: status,
    body: JSON.stringify(res) || '',
    headers: {
      'Content-Type': 'application/json'
    }
  };
}

function convertToV2Params({ recordRequest }) {
  const { rloc, familyName } = recordRequest;
  return {
    rloc,
    familyName,
  };
}

function convertToV2Body({ requirements, flightRequests, passengerRequests }) {
  const v2Body = {
    flightLookups: flightRequests.map(_flightRequestToLookup),
    passengerLookups: passengerRequests
  }

  if (typeof requirements === 'object') {
    v2Body.requirements = {
      acknowledgeDGTerms: requirements.acknowledgeDGTerms
    };
    v2Body.checkIn = requirements.acceptance;
  }
  return v2Body;
}

function isPaxCheckedIn(trip, paxs) {
  const isPaxCheckedInStatus = paxs.every((pax) => {

    const paxFromTrip = helpers.findPassengerByLookup(trip, pax)

    const paxIdentifier = dlv(paxFromTrip, paths.PAX_ID)

    const paxCoupons = trip.passengerFlightMapping.filter((mapping) => {
      return dlv(mapping, paths.FLIGHT_PAX_ID) === paxIdentifier
    })

    return paxCoupons.every(helpers.isCouponCheckedIn)
  })

  console.log('I am at isPaxCheckedIn: ', isPaxCheckedInStatus);

  return isPaxCheckedInStatus;
}

function validateAndExtractCCPaxs(trip, paxs, ccPaxs) {
  const result = {};
  for (let productIdentifier in paxs) {
    for (let pax of ccPaxs) {
      const filteredPax = helpers.findPassengerByLookup(trip, pax);

      if (dlv(filteredPax, paths.PAX_ID) === productIdentifier) {
        result[productIdentifier] = filteredPax
      }

    }
  }

  return result;
}

function validateAndExtractCCFlights(flights, ccFlights) {
  let result = {};

  for (let flightIdentifier in flights) {
    for (let flight of ccFlights) {

      const uniqueIdentifier = `${flight.carrier}${flight.flightNumber}${flight.date.replace(/-/g, '')}${flight.origin}${flight.destination}`;

      if (uniqueIdentifier === flightIdentifier) {
        result[flightIdentifier] = flights[flightIdentifier]
      }
    }
  }

  return result;
}

function getFieldsWithTrue(requirements) {
  const fieldsWithTrue = [];

  for (const field in requirements) {
    if (requirements.hasOwnProperty(field) && requirements[field] === true) {
      fieldsWithTrue.push(field);
    }
  }

  return fieldsWithTrue;
}

function getAllFieldsForEligibility(requirements, eligibilePassenger, qrEligibility) {
  let missingFields = new Set(); // Use a Set to store unique missing fields
  let populatedFields = new Set();

  //All requiredFields with boolean
  for (let field of requirements) {
    if (QRToQRMapping[field] && findFieldPlace(QRToQRMapping[field]) === 'document') {
      const documentType = QRToQRMapping[field]['documentType']; //QR documentType
      const value = QRToQRMapping[field]['value']; // QR field

      if (!isCCSupportsQRField(value, documentType)) {
        missingFields.add({ ['SEE_AGENT']: documentType })
      }
      else {
        const isMissingField = !eligibilePassenger.apisInformation.documents.some(doc =>
          doc.documentType === documentType && doc.hasOwnProperty(value) && !isEmpty(doc[value])
        );

        if (isMissingField) {
          missingFields.add({ [documentType]: value });
        }
        else {
          populatedFields.add({ [documentType]: value })
        }
      }
    }

    else if (QRToQRMapping[field] && findFieldPlace(QRToQRMapping[field]) === 'address') {
      const addressType = QRToQRMapping[field]['addressType']; //QR documentType
      const value = QRToQRMapping[field]['value']; // QR field

      if (!isCCSupportsQRField(value, `${addressType}_ADDRESS`)) {
        missingFields.add({ ['SEE_AGENT']: addressType })
      }
      else {
        const isMissingField = !eligibilePassenger.address.some(addrDoc =>
          addrDoc.type === addressType && addrDoc.hasOwnProperty(value) && !isEmpty(addrDoc[value])
        );

        if (isMissingField) {
          missingFields.add({ [`${addressType}_ADDRESS`]: value });
        }
        else {
          populatedFields.add({ [`${addressType}_ADDRESS`]: value })
        }
      }
    }

    else if (QRToQRMapping[field] && findFieldPlace(QRToQRMapping[field]) === 'emergencyContact') {
      const contactType = QRToQRMapping[field]['emergencyContact']; //QR documentType
      const value = QRToQRMapping[field]['value']; // QR field

      // const destination = qrEligibility.trip.journeys[-1].flightList[-1].carrier.carrier;
      const destination = getDestinationForEC(qrEligibility.trip);
      // console.log('Destination for EC: ', destination);

      if (destination === 'US') {

        if (!isCCSupportsQRField(value, contactType)) {
          missingFields.add({ ['SEE_AGENT']: contactType })
        }
        else {
          const isMissingField = !qrEligibility.trip.emergencyContactDetails.some(contactDoc =>
            contactDoc.hasOwnProperty(value) && !isEmpty(contactDoc[value])
          );

          if (isMissingField) {
            missingFields.add({ [contactType]: value });
          }
          else {
            populatedFields.add({ [contactType]: value })
          }
        }
      }
      else {
        console.log('Non-US destination found, hence EmeregencyContact not required');
      }
    }

    else {
      const fieldKey = QRToQRMapping[field];

      if (
        (eligibilePassenger.hasOwnProperty(fieldKey) && !isEmpty(eligibilePassenger[fieldKey])) ||
        (eligibilePassenger.apisInformation.hasOwnProperty(fieldKey) && !isEmpty(eligibilePassenger.apisInformation[fieldKey]))
      ) {
        populatedFields.add(fieldKey)
      }
      else {
        missingFields.add(fieldKey);
      }
    }
  }

  missingFields = Array.from(missingFields);
  console.log(`Missing fields for ${eligibilePassenger.firstName}-${eligibilePassenger.lastName} = ${JSON.stringify(missingFields, null, 2)}`);

  populatedFields = Array.from(populatedFields);
  console.log(`Populated fields for ${eligibilePassenger.firstName}-${eligibilePassenger.lastName} = ${JSON.stringify(populatedFields, null, 2)}`);

  return Object.assign({}, {missingFields, populatedFields})
}

async function retrieveEligibilityResponse(session, trip, ccRequest, cachedPaxs, isMultiEligibility = false) {
  const { passengerLookups, flightLookups, rloc, familyName } = ccRequest;
  const { checkedInPaxs, nonCheckedInPaxs } = helpers.getCheckedInAndNonCheckedInPaxs(trip, passengerLookups);

  if (!isCCPaxFoundInTrip(passengerLookups, trip)) {
    throw new Error('Matching CC Passenger not found in QR Trip');
  }

  const eligibilityResponseForCheckedInPaxs = await getEligibilityResponseForCheckedInPaxs(session, trip, checkedInPaxs, flightLookups, isMultiEligibility);
  const eligibilityResponseForNonCheckedInPaxs = await getEligibilityResponseForNonCheckedInPaxs(session, trip, { nonCheckedInPaxs, flightLookups, rloc, familyName }, cachedPaxs, isMultiEligibility);

  const eligibilityResponse = eligibilityResponseForCheckedInPaxs.concat(eligibilityResponseForNonCheckedInPaxs);

  return isMultiEligibility ? eligibilityResponse : eligibilityResponse[0];
}

async function getEligibilityResponseForCheckedInPaxs(session, trip, checkedInPaxs, flightLookups, isMultiEligibility) {
  if (!checkedInPaxs || checkedInPaxs.length === 0) {
    return [];
  }

  const qrEligibility = await api.regulatoryInfoCheck(session, trip, checkedInPaxs, flightLookups);
  return getPopulatedDocsForEligibilityAfterAccept(qrEligibility, checkedInPaxs, isMultiEligibility);
}

async function getEligibilityResponseForNonCheckedInPaxs(session, trip, { nonCheckedInPaxs, flightLookups, rloc, familyName }, cachedPaxs, isMultiEligibility) {
  if (!nonCheckedInPaxs || nonCheckedInPaxs.length === 0) {
    return [];
  }

  let qrEligibility;

  if (cachedPaxs.length > 0 && isCCPaxFoundInCache(nonCheckedInPaxs, cachedPaxs)) {
    qrEligibility = Object.assign({}, { trip });
  } else {
    qrEligibility = await api.ackDgTerms(session, trip, nonCheckedInPaxs, flightLookups);
    await db.updatePassengers(`${rloc}/${familyName}`, nonCheckedInPaxs);
  }

  return nonCheckedInPaxs.map((passenger) => {
    const eligiblePassenger = helpers.findPassengerByLookup(qrEligibility.trip, passenger);
    const requiredFields = getFieldsWithTrue(eligiblePassenger.apisInformation.apisRequirements);
    const emergencyRequirements = qrEligibility.trip.journeys[qrEligibility.trip.journeys.length - 1].checkIn;
    const ecFields = getEmergencyContactFields(emergencyRequirements);
    const ECRequiredFields = getFieldsWithTrue(ecFields);
    const combinedRequiredFields = requiredFields.concat(ECRequiredFields);

    const { qrToCCMissingDocs, qrToCCPopulatedDocs, familyName, givenName } = helpers.qrPaxEligibility(combinedRequiredFields, eligiblePassenger, qrEligibility, isMultiEligibility);

    return isMultiEligibility ? Object.assign({}, { requiredDocuments: qrToCCMissingDocs, populatedDocuments: qrToCCPopulatedDocs, familyName, givenName, eTicketNumber: passenger.eTicketNumber }) : Object.assign({}, { requiredDocuments: qrToCCMissingDocs, populatedDocuments: qrToCCPopulatedDocs });
  });
}

function setQrUpdateRequest(CCDocuments, familyName, givenName, trip) {

  const paxToUpdate = trip.passengers.find((pax) => pax.firstName.toLowerCase() === givenName.toLowerCase() && pax.lastName.toLowerCase() === familyName.toLowerCase());

  if (paxToUpdate) {
    let updateRequest = {};
    updateRequest["regulatoryInfo"] = {
      gender:
        CCDocuments.find((doc) => doc.payload.hasOwnProperty("gender"))?.payload
          ?.gender[0] || dlv(paxToUpdate, 'gender'),
      dateOfBirth:
        CCDocuments.find((doc) => doc.payload.hasOwnProperty("dateOfBirth"))
          ?.payload?.dateOfBirth || dlv(paxToUpdate, 'dateOfBirth'),
      countryOfResidenceCode:
        CCDocuments.find((doc) =>
          doc.payload.hasOwnProperty("countryOfResidence")
        )?.payload?.countryOfResidence || dlv(paxToUpdate, 'apisInformation.countryOfResidenceCode'),
      nationalityCode:
        CCDocuments.find((doc) => doc.payload.hasOwnProperty("nationality"))
          ?.payload?.nationality || dlv(paxToUpdate, 'apisInformation.nationalityCode'),
      regulatoryFamilyName: dlv(paxToUpdate, 'lastName'),
      regulatoryGivenName: dlv(paxToUpdate, 'firstName'),
      travelDoc: {}, // Initialize an empty object to hold the travel documents
    };

    //Check for CC Documents and update

    for (let document of CCDocuments) {
      if (document.type === "PASSPORT") {
        const docObject = {
          expiryDate: document?.payload?.expiryDate,
          issuedDate: new Date(
            new Date(document?.payload?.expiryDate).setFullYear(
              new Date(document?.payload?.expiryDate).getFullYear() - 10
            )
          )
            .toISOString()
            .slice(0, 10),
          countryOfIssue: document?.payload?.countryOfIssue,
          documentType: document.type,
          documentNumber: document?.payload?.passportNumber,
        };
        // Use bracket notation to dynamically assign the properties to updateRequest["regulatoryInfo"]["travelDoc"]
        updateRequest["regulatoryInfo"]["travelDoc"][document.type] = docObject;
      }


      if (document.type === "VISA") {
        const docObject = {
          expiryDate: document?.payload?.expiryDate,
          issuedDate: new Date(
            new Date(document?.payload?.expiryDate).setFullYear(
              new Date(document?.payload?.expiryDate).getFullYear() - 10
            )
          )
            .toISOString()
            .slice(0, 10),
          countryOfIssue: document?.payload?.countryOfIssue,
          documentType: document.type,
          documentNumber: document?.payload?.documentNumber,
          cityOfIssue: this.getRandomCity(document?.payload?.countryOfIssue) || 'New York',
        };
        // Use bracket notation to dynamically assign the properties to updateRequest["regulatoryInfo"]["travelDoc"]
        updateRequest["regulatoryInfo"]["travelDoc"][document.type] = docObject;
      }

      if (document.type === 'DESTINATION_ADDRESS') {
        updateRequest['destinationAddress'] = {
          city: document?.payload?.city,
          state: document?.payload?.stateProv,
          country: document?.payload?.country,
          street: document?.payload?.street,
          zipCode: document?.payload?.postalCode,
        };
      }

      if (document.type === "EMERGENCY_CONTACT") {
        updateRequest['emergencyContact'] = {
          "lastName": document?.payload?.hasOwnProperty('familyName') && document?.payload?.hasOwnProperty('givenName') ? `${document?.payload?.familyName} ${document?.payload?.givenName}` : undefined,
          "contactCountry": getCountryCodeForEC(document?.payload?.phone),
          "contactNumber": document?.payload?.phone?.number,
          "refused": document?.payload?.refused
        }
      }
    }

    return updateRequest;
  }
  else {
    throw new Error('Matching passenger not Found: APIS Update');
  }

}

function getPopulatedDocsForEligibilityAfterAccept(qrEligibility, paxs, multiEligibility) {
  const CCDocuments = ['PASSPORT', 'VISA', 'DESTINATION_ADDRESS', 'RESIDENT_ADDRESS', 'EMERGENCY_CONTACT'];

  function isDocumentTypeFound(documents, documentType) {
    return documents.some(qrDoc => qrDoc.documentType === documentType);
  }

  function isAddressTypeFound(addresses, addressType) {
    return addresses.some(qrAddress => qrAddress.type === addressType);
  }

  const destination = getDestinationForEC(qrEligibility.trip);

  const eligibilityResponse = [];

  for (const pax of paxs) {
    const { givenName, familyName, eTicketNumber } = pax;
    const requiredDocuments = [];
    const populatedDocuments = [];

    const paxFound = helpers.findPassengerByLookup(qrEligibility.trip, pax)

    for (const document of CCDocuments) {
      switch (document) {
        case 'PASSPORT':
          const isPSPTFound = isDocumentTypeFound(paxFound.apisInformation.documents, document);
          if (isPSPTFound) {
            populatedDocuments.push('PASSPORT');
          }
          break;
        case 'VISA':
          const isVisaFound = isDocumentTypeFound(paxFound.apisInformation.documents, document);
          if (isVisaFound) {
            populatedDocuments.push('VISA');
          }
          break;
        case 'DESTINATION_ADDRESS':
          if (destination === 'US') {
            const isDestinationFound = isAddressTypeFound(paxFound.address, 'DESTINATION');
            if (isDestinationFound) {
              populatedDocuments.push('DESTINATION_ADDRESS');
            }
          }
          break;
        //Since countryOfResidence is mandatory for QR, eliminating destination check
        case 'RESIDENT_ADDRESS':
          const isResidentFound = paxFound.apisInformation.hasOwnProperty('countryOfResidenceCode');
          if (isResidentFound) {
            populatedDocuments.push('RESIDENT_ADDRESS');
          }
          break;
        case 'EMERGENCY_CONTACT':
          if (destination === 'US') {
            const hasEmergencyContact = qrEligibility.trip.emergencyContactDetails.length > 0;
            if (hasEmergencyContact) {
              populatedDocuments.push('EMERGENCY_CONTACT');
            }
          }
          break;
      }
    }

    eligibilityResponse.push({ requiredDocuments, populatedDocuments, familyName, givenName, eTicketNumber });
  }

  if (!multiEligibility) {
    delete eligibilityResponse[0].familyName;
    delete eligibilityResponse[0].givenName;
    delete eligibilityResponse[0].eTicketNumber;
  }

  return eligibilityResponse;
};

function retrieveCCDocs(updateQRRes, passengerLookup) {
  const eligibilePassenger = updateQRRes.trip.passengers.filter((tripPax) => tripPax.firstName.toLowerCase() === passengerLookup.givenName.toLowerCase() && tripPax.lastName.toLowerCase() === passengerLookup.familyName.toLowerCase())[0]
  let regulatoryRequiredFields = getFieldsWithTrue(eligibilePassenger.apisInformation.apisRequirements);

  let emergencyRequirements = updateQRRes.trip.journeys[updateQRRes.trip.journeys.length - 1].checkIn;
  const ecFields = getEmergencyContactFields(emergencyRequirements)

  const ECRequiredFields = getFieldsWithTrue(ecFields);
  const allRequiredFields = regulatoryRequiredFields.concat(ECRequiredFields);
  console.info('Requirement fields : ', allRequiredFields);

  return helpers.qrPaxEligibility(allRequiredFields, eligibilePassenger, updateQRRes);

};

function removeEmergencyRequirements(qrRes) {
  return qrRes.trip.journeys.map((journey) => {
    if (journey.hasOwnProperty('checkIn')) {
      for (const prop in journey.checkIn) {
        // Check if the property starts with 'emergency'
        if (prop.startsWith('emergency')) {
          // Set the property value to its opposite boolean value
          journey.checkIn[prop] = !journey.checkIn[prop];
        }
      }
      return journey;
    }
  });
}

function isCCPaxFoundInCache(ccPaxs, cachedPaxs) {
  const result = ccPaxs.every((ccPax) => {
    const { familyName, givenName, eTicketNumber } = ccPax;

    if (!familyName || !givenName || !eTicketNumber) {
      throw new Error('CC Request required Parameters missing..!!');
    }
    let isFound;

    if (cachedPaxs) {
      isFound = cachedPaxs.some((cachePax) => (
        cachePax.familyName.toLowerCase() === ccPax.familyName.toLowerCase() &&
        cachePax.givenName.toLowerCase() === ccPax.givenName.toLowerCase() &&
        cachePax.eTicketNumber === ccPax.eTicketNumber
      ))
    }
    else {
      isFound = false
    }
    return isFound;

  });
  console.log('Cache Validation ----> Found CC pax(s) in Cache: ', result);

  return result;
};

function isCCPaxFoundInTrip(ccPaxs, trip) {
  const isFound = ccPaxs.every((ccPax) => {
    const { familyName, givenName, eTicketNumber } = ccPax;

    if (!familyName || !givenName || !eTicketNumber) {
      throw new Error('CC Request required Parameters missing..!!');
    }

    const paxFoundInTrip = helpers.findPassengerByLookup(trip, ccPax)

    return paxFoundInTrip
  })

  console.log(`Trip Validation ----> At isCCPaxFoundInTrip, CC Paxs and Trip Paxs are ${isFound ? 'equal' : 'Not equal'}`);

  return isFound
};

function isCCPaxAndCachedPaxEqual(ccPaxs, cachedPaxs) {
  let isEqual;

  if (cachedPaxs) {
    isEqual = ccPaxs.length === cachedPaxs.length && isCCPaxFoundInCache(ccPaxs, cachedPaxs)
  }
  else {
    isEqual = false;
  }
  console.log(`Accept Cache Validation ----> CC Request paxs and Cached Paxs are ${isEqual ? 'equal' : 'not equal'}`);

  return isEqual;
};

function isCCSupportsQRField(field, document) {
  // console.info('Document Type: ', document)
  // console.info(`${document} --- QR field '${field}' ${QRToCCMapping[document].hasOwnProperty(field) ? 'supported' : 'unsupported'} by CC`)
  return QRToCCMapping[document].hasOwnProperty(field)
};

function getDestinationForEC(trip) {
  let destinationFlight;

  if (trip.journeys.length > 0) {
    // Get the last journey element
    const lastJourney = trip.journeys[trip.journeys.length - 1];

    // Check if flightList array is not empty
    if (lastJourney.flightList && lastJourney.flightList.length > 0) {
      // Get the last flightList element
      destinationFlight = lastJourney.flightList[lastJourney.flightList.length - 1];
    }
  }
  else {
    console.log('Journeys array is empty.');
  }

  const airportCode = dlv(destinationFlight, 'arrivalStation.airportCode');
  const airport = airportCodes.findWhere({ iata: airportCode.toUpperCase() })
  const countryName = airport.get('country');
  const countryCode = lookup.byCountry(countryName)?.iso2

  return countryCode
}

function getCountryCodeForEC(contactDetails) {
  if (contactDetails?.hasOwnProperty('countryCode')) {
    const CCCountry = contactDetails?.countryCode.includes('+') ? contactDetails?.countryCode.replace(/\+/g, '') : contactDetails?.countryCode;
    
    const countryCode = codes.filter((country) => country?.countryCodes[0] === CCCountry)[0]?.isoCode3;
    console.log('CountyryCode to sent for EC: ', countryCode);

    return countryCode
  }
}
//flightNumkber - 
function isEmpty(val) {
  return val === null || val === undefined || (typeof val === 'string' ? val.trim() === '' : false);
}


function getEmergencyContactFields(emergencyRequirements) {
  const ecFields = {};
  for (let prop in emergencyRequirements) {
    if (prop.startsWith('emergency')) {
      ecFields[prop] = emergencyRequirements[prop];
    }
  }
  return ecFields;
}

function padFlightNumberWithZeros(flightNumber) {
  if (flightNumber.length < 4) {
    const numberOfZerosToAdd = 4 - flightNumber.length;
    const zeroPadding = '0'.repeat(numberOfZerosToAdd);
    return zeroPadding + flightNumber;
  } else {
    return flightNumber;
  }
};

exports.params = params;
exports.body = body;
exports.response = response;
exports.convertToV2Params = convertToV2Params;
exports.convertToV2Body = convertToV2Body;
exports.isPaxCheckedIn = isPaxCheckedIn;
exports.validateAndExtractCCPaxs = validateAndExtractCCPaxs;
exports.validateAndExtractCCFlights = validateAndExtractCCFlights;
exports.getFieldsWithTrue = getFieldsWithTrue;
exports.getAllFieldsForEligibility = getAllFieldsForEligibility;
exports.retrieveEligibilityResponse = retrieveEligibilityResponse;
exports.setQrUpdateRequest = setQrUpdateRequest;
exports.getPopulatedDocsForEligibilityAfterAccept = getPopulatedDocsForEligibilityAfterAccept;
exports.retrieveCCDocs = retrieveCCDocs;
exports.removeEmergencyRequirements = removeEmergencyRequirements;
exports.isCCPaxFoundInCache = isCCPaxFoundInCache;
exports.isCCPaxFoundInTrip = isCCPaxFoundInTrip;
exports.isCCPaxAndCachedPaxEqual = isCCPaxAndCachedPaxEqual;
exports.padFlightNumberWithZeros = padFlightNumberWithZeros;



//QE Update Request setup...
// regulatoryInfo: {
//   gender: 'M',
//   dateOfBirth: '1978-01-05',
//   countryOfResidenceCode: 'USA',
//   nationalityCode: 'USA',
//   regulatoryGivenName: 'jesses',
//   regulatoryFamilyName: 'jamess',
//   travelDoc: {
//     'PASSPORT': {
//       expiryDate: '2022-01-05',
//       issuedDate: '2019-01-05',
//       countryOfIssue: 'USA',
//       documentType: 'PASSPORT',
//       documentNumber: '999995'
//     },
//     'VISA': {
//       expiryDate: '2022-01-05',
//       issuedDate: '2019-01-05',
//       countryOfIssue: 'USA',
//       documentType: 'VISA',
//       documentNumber: '999995'
//     }
//   }

// },
// destinationAddress: {
//   city: 'new york',
//   state: 'NY',
//   country: 'USA',
//   street: '2 park ave fl 5',
//   zipCode: '10036'
// },








function findFieldPlace(field) {
  if (typeof field === 'object' && field.hasOwnProperty('documentType')) {
      return 'document'
  }
  else if (typeof field === 'object' && field.hasOwnProperty('addressType')) {
      return 'address'
  }
  else if (typeof field === 'object' && field.hasOwnProperty('emergencyContact')) {
    return 'emergencyContact'
  }
  else {
      return 'basic'
  }
}

function _flightRequestToLookup({ date, flightNumber, carrierCode, origin, destination }) {

  return {
      carrier: carrierCode,
      date, flightNumber, origin, destination,
  };
}
