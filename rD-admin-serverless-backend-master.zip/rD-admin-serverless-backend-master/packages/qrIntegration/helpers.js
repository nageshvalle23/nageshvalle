const dlv = require('dlv')
const paths = require('./paths')
const dateUtil = require('./dateUtils');
const utils = require('./utils');
const converter = require('./converter');
const api = require('./api');
const db = require('./db');
const { params, body } = require('@oneworld-digital/integration-utils').request;
const { convertToV1Params, v1RecordToV2Record } = require('@oneworld-digital/integration-utils').versionConverter;

function findPassengerByLookup (trip, lookup) {
  const {familyName, givenName, eTicketNumber} = lookup

  if (!familyName || !givenName || !eTicketNumber) {
    return undefined;
  }

  const pax = trip.passengers.find(passenger => {
    const paxId = dlv(passenger, paths.PAX_ID)

    if (passenger.lastName.toLowerCase() === familyName.toLowerCase() &&
        passenger.firstName.toLowerCase() === givenName.toLowerCase() &&
        isPaxTicketMatch(trip, paxId, eTicketNumber)) {
      return passenger;
    }

    return false
  });

  if (!pax) {
    throw new Error('Matching passenger not found');
  }

  return pax
}

function findProductIdByLookup (trip, lookup) {
  return dlv(findPassengerByLookup (trip, lookup), paths.PAX_ID);
}

function buildJourneyIdFromFlights(flights) {
  return flights.reduce((id, flight) => {
    const {carrier, flightNumber, origin, destination, date} = flight

    if (!carrier || !flightNumber || !origin || !destination || !date) {
      throw new Error('Missing required flight properties')
    }
    const d = dateUtil.toSimpleDate(new Date(date))

    return [
      id,
      flight.carrier,
      flight.flightNumber,
      d,
      flight.origin,
      flight.destination
    ].join('')
  }, '')
}

function findJourneyByJourneyId(trip, journeyId) {
  if (!journeyId) {
    return new Error('Missing required journey identifier');
  }
  const journey = trip.journeys.find(j => {
    //QR confirmed they will add '-' for more than 2 segments
    const jId = dlv(j, 'uniqueJourneyIdentifier.uniqueIdentifier').replace(/-/g, '');
    if (trip?.journeys?.flightList?.length > 2) console.info('At findJourneyByJourneyId method---Modified journeyID for more than 2 legs: ', jId);

    if (jId.toUpperCase() === journeyId.toUpperCase()) {
      return j;
    }
    return false;
  })

  return journey;
}

async function checkin(session, trip, {passengerLookups, flightLookups}, acknowledgeNonChecked, normalTrip) {
  let qrCheckInRes;

  if (!utils.isPaxCheckedIn(trip, passengerLookups)) {
    qrCheckInRes = await api.checkin(session, trip)
  }
  else {
    console.log("Ignoring ackDgTerms API since checkIn status of paxs is CHECKED_IN");
    qrCheckInRes = Object.assign({}, {trip})
  }

  //This logic will done only for acknowledgeing paxs - A-checkedIn, B-unCheckedIn
  if (acknowledgeNonChecked) {
    const missedPaxs = [];
    const missedCpns = [];
    //CheckIn Response have only Acknowledge passenger
    for (let ccPax of acknowledgeNonChecked?.allRequestedPaxs) {
      const {familyName, givenName, eTicketNumber} = ccPax;

      const pax = qrCheckInRes.trip.passengers.find(passenger => {
        const paxId = dlv(passenger, paths.PAX_ID)
    
        if (passenger.lastName.toLowerCase() === familyName.toLowerCase() &&
            passenger.firstName.toLowerCase() === givenName.toLowerCase() &&
            isPaxTicketMatch(trip, paxId, eTicketNumber)) {
          return passenger;
        }
    
        return false
      });

      //If pax is not found in qrCheckInResponse then append that pax to qrCheckInResponse
      if (!pax) {
        console.info('Passenger not found in QR Confirm response, getting pax from new trip..!!')
        const paxToAdd = findPassengerByLookup(normalTrip, ccPax); //One who is checkedIn will miss in qrCheckInRes since he is non-acknowledged
        const couponsToAdd = normalTrip.passengerFlightMapping.filter((coupon) => (dlv(coupon, paths.FLIGHT_PAX_ID) === findProductIdByLookup(normalTrip, ccPax)));
        missedPaxs.push(paxToAdd);
        missedCpns.push(...couponsToAdd);
      }
    }

    qrCheckInRes = { ...qrCheckInRes, trip: {...qrCheckInRes.trip, passengers: [...qrCheckInRes.trip.passengers, ...missedPaxs], passengerFlightMapping: [...qrCheckInRes.trip.passengerFlightMapping, ...missedCpns]}};
  };

  passengerLookups = acknowledgeNonChecked?.isAcknowledged ? acknowledgeNonChecked?.allRequestedPaxs : passengerLookups;
  
  return converter.execute(qrCheckInRes.trip, passengerLookups, flightLookups);
}

async function uncheckin(session, qrRes) {
  // the only possible error is caught in the cancelCheckin call
  await api.cancelCheckin(session, qrRes);

  const { trip } = await api.reloadTrip(session);

  return converter.execute(trip);
}

function canCheckIn(trip) {
  // The following must all be true to complete the checkin
  return trip.passengerFlightMapping.every(couponOkForCheckIn) &&
         trip.passengers.every(paxOkForCheckIn)
}

function isCheckedIn(trip) {
  // TODO: filter by lookup?
  return trip.passengerFlightMapping.every(isCouponCheckedIn)
}

function isCouponCheckInInhibited(cpn) {
  return dlv(cpn, paths.STATUS) === 'INHIBITED'
}

function isCouponCheckedIn(cpn) {
  return dlv(cpn, paths.STATUS) === 'CHECKED_IN'
}

function couponOkForCheckIn (cpn) {
  const path = ['pasengerTimelineInfo', 'checkinStatus'].join('.')
  return dlv(cpn, path) === 'OPEN'
}

function paxOkForCheckIn (pax) {
  const path = ['checkIn', 'apisDetailsComplete'].join('.')
  return dlv(pax, path)
}

function isPaxTicketMatch (trip, targetPaxId, eTicketNumber) {
  const paxFlightIdPath = ['paxFlightIdentifier', paths.PAX_ID].join('.')

  const index = trip.passengerFlightMapping.findIndex(mapping => {
    return targetPaxId === dlv(mapping, paxFlightIdPath) &&
           eTicketNumber === dlv(mapping, paths.TICKET_NUMBER)
  })

  return index !== -1
}

function filterTrip(trip, session, paxs, flights) {
  const journeyId = buildJourneyIdFromFlights(flights);

  const passengers = paxs.map(pax => {
    return {
      passengerIdentifier: {
        productIdentifier: findProductIdByLookup(trip, pax)
      }
    };
  });

  return {
    conversationToken: session.conversationToken,
    trip: {
      tripReference: trip.tripReference,
      journeys: [{
        uniqueJourneyIdentifier: {
          uniqueIdentifier: journeyId
        }
      }],
      passengers
    }
  };

}

// trip = trip object from qr ack dg endpoint
function buildTravelDoc(trip, session, updateRequest) {
  const { flightRequests, passengerRequest, regulatoryInfo, destinationAddress, emergencyContact } = updateRequest;

  const journeyId = buildJourneyIdFromFlights(flightRequests);
  const passenger = buildTravelDocPassenger(trip, passengerRequest, journeyId, regulatoryInfo, destinationAddress);
  const passengerFlightMapping = buildTravelDocPassengerFlightMapping(trip.passengerFlightMapping);
  const journeys = buildTravelDocJourneys(journeyId, trip);

  if (!passenger || !passengerFlightMapping || !journeys) {
    throw new Error('Travel document update: error creating request.');
  }

  return {
    primaryDocumentUpdate: 'PASSPORT',
    byPassVisaCheck: regulatoryInfo.travelDoc.hasOwnProperty('VISA') ? true : false,
    additionalDocumentUpdate: regulatoryInfo.travelDoc.hasOwnProperty('VISA') ? 'VISA': null,
    trip: {
      tripReference: trip.tripReference,
      journeys,
      passengers: [passenger],
      passengerFlightMapping,
    },
    conversationToken: session.conversationToken,
  };

};

function buildEmergencyDoc(trip, session, updateRequest) {
  const { flightRequests, passengerRequest, emergencyContact } = updateRequest;

  const journeyId = buildJourneyIdFromFlights(flightRequests);

  const passengers = [passengerRequest].map(pax => {
    return {
      passengerIdentifier: {
        productIdentifier: findProductIdByLookup(trip, pax)
      }
    };
  });

  const passengerFlightMapping = buildTravelDocPassengerFlightMapping(trip.passengerFlightMapping);
  const journeys = buildTravelDocJourneys(journeyId, trip);
  const emergencyContactDetails = buildEmergencyContactDetails(emergencyContact, journeyId);

  if (!passengers || !passengerFlightMapping || !journeys) {
    throw new Error('EmergencyContact document update: error creating request.');
  }

  return {
    channel: 'CCF',
    updatingNonAPISData: true,
    trip: {
      tripReference: trip.tripReference,
      journeys,
      emergencyContactDetails,
      passengers,
      passengerFlightMapping,
    },
    conversationToken: session.conversationToken,
  };

};


function buildTravelDocPassenger(trip, pax, journeyId, regulatoryInfo, destinationAddress) {
  const currentPax = findPassengerByLookup(trip, pax);

  if (!currentPax) {
    throw Error('Travel doc update: mismatched pax request');
  }

  return {
    title: dlv(currentPax, 'title'),
    firstName: dlv(currentPax, 'firstName'),
    lastName: dlv(currentPax, 'lastName'),
    gender: dlv(regulatoryInfo, 'gender'),
    dateOfBirth: dlv(regulatoryInfo, 'dateOfBirth'),
    passengerType: dlv(currentPax, 'passengerType'),
    passengerIdentifier: {
      productIdentifier: dlv(currentPax, paths.PAX_ID)
    },
    apisInformation: buildTravelDocPassengerApisInformation(regulatoryInfo),
    address: buildTravelDocPassengerDestinationAddress(destinationAddress, journeyId)
  };
};

function buildTravelDocPassengerDestinationAddress(address, journeyId) {
  if (address) {
    return [{
      city: dlv(address, 'city'),
      state: dlv(address, 'state'),
      country: dlv(address, 'country'),
      journeyIdentifiers: [
        journeyId
      ],
      street: dlv(address, 'street'),
      type: 'DESTINATION',
      zipCode: dlv(address, 'zipCode')
    }];
  }
};

function buildTravelDocPassengerApisInformation(regInfo) {
  if (regInfo) {
    var apis = {
      countryOfResidenceCode: dlv(regInfo, 'countryOfResidenceCode'),
      nationalityCode: dlv(regInfo, 'nationalityCode'),
      regulatoryFirstName: dlv(regInfo, 'regulatoryGivenName'),
      regulatoryLastName: dlv(regInfo, 'regulatoryFamilyName')
    };

    if (regInfo.travelDoc) {
      let resultDocuments = [];

      if (regInfo.travelDoc.hasOwnProperty('PASSPORT')) {
        resultDocuments.push({
          documentReferenceNumber: dlv(regInfo.travelDoc['PASSPORT'], 'documentNumber'),
          expiryDate: dlv(regInfo.travelDoc['PASSPORT'], 'expiryDate'),
          countryOfIssue: dlv(regInfo.travelDoc['PASSPORT'], 'countryOfIssue'),
          documentType: dlv(regInfo.travelDoc['PASSPORT'], 'documentType'),
          issuedDate: dlv(regInfo.travelDoc['PASSPORT'], 'issuedDate'),
        });
      }

      //TODO: Awaiting update from QR to remove VISA check

      if (regInfo.travelDoc.hasOwnProperty('VISA')) {
        resultDocuments.push({
          documentReferenceNumber: dlv(regInfo.travelDoc['VISA'], 'documentNumber'),
          expiryDate: dlv(regInfo.travelDoc['VISA'], 'expiryDate'),
          countryOfIssue: dlv(regInfo.travelDoc['VISA'], 'countryOfIssue'),
          documentType: dlv(regInfo.travelDoc['VISA'], 'documentType'),
          cityOfIssue: dlv(regInfo.travelDoc['VISA'], 'cityOfIssue'),
          applicableCountry: dlv(regInfo.travelDoc['VISA'], 'applicableCountry'),
          issuedDate: dlv(regInfo.travelDoc['VISA'], 'issuedDate'),
        });
      }

      apis.documents = resultDocuments;
    }
    return apis;
  }
}

function buildTravelDocPassengerFlightMapping(passengerFlightMapping) {
  return passengerFlightMapping.map(flight => {
    return {
      paxFlightIdentifier: {
        passengerIdentifier: {
          productIdentifier: dlv(flight, paths.FLIGHT_PAX_ID),
        },
        flightIdentifier: {
          productIdentifier: dlv(flight, paths.FLIGHT_PRODUCT_ID),
          uniqueIdentifier: dlv(flight, paths.FLIGHT_ID),
        }
      }
    }
  });
}

function buildTravelDocJourneys(journeyId, trip) {
  const journey = findJourneyByJourneyId(trip, journeyId);

  // typically issues with journey occurs due to timezone issues
  // when working locally - machine timezone should be utc
  if (!journey) {
    throw Error('Travel doc update: mismatched journey request');
  }

  return [
    {
      uniqueJourneyIdentifier: {
        uniqueIdentifier: journeyId,
      },
      flightList: journey.flightList.map(flight => {
        return {
            flightIdentifier: {
              productIdentifier: flight.flightIdentifier.productIdentifier,
              uniqueIdentifier: flight.flightIdentifier.uniqueIdentifier
            }
        }
      }),
      departureDate: journey.departureDate
    }
  ];
};

function buildEmergencyContactDetails(emergencyContact, journeyId) {
    if (emergencyContact) {
      let emergencyContactDetailsArray = [];

      //If Client Ok to send EC details
      if (!emergencyContact.refused) {
        console.info("Updating Emergency Contact details for a PNR");
        const {lastName, contactCountry, contactNumber} = emergencyContact;
        const journeyIdentifiers = [journeyId];

        const emergencyContactDetails = {
          lastName,
          contactCountry,
          contactNumber,
          updatingEmDetails: true,
          journeyIdentifiers
        };
        emergencyContactDetailsArray.push(emergencyContactDetails);
      }

      return emergencyContactDetailsArray;
    }
}

function getCheckedInAndNonCheckedInPaxs(trip, paxs) {

  const checkedInPaxs = [];
  const nonCheckedInPaxs = [];

  paxs.forEach((pax) => {
    const { familyName, givenName, eTicketNumber } = pax;

    if (!familyName || !givenName || !eTicketNumber) {
      return undefined;
    }

    const productId = findProductIdByLookup(trip, pax)
    const paxCoupons = trip.passengerFlightMapping.filter((paxFlightMap) => (dlv(paxFlightMap, paths.FLIGHT_PAX_ID) === productId));

    if (!paxCoupons) {
      return undefined;
    }

    if (paxCoupons.every(isCouponCheckedIn)) {
      checkedInPaxs.push(pax)
    }
    else {
      nonCheckedInPaxs.push(pax)
    }
  });

  return Object.assign({}, { checkedInPaxs, nonCheckedInPaxs });
}

async function getSessionFromCacheOrAPI({ rloc, familyName, passengerLookups }, operationType) {
  let session;
  let isTokenFound = await db.getPnr(`${rloc}/${familyName}`);

  if (
    isTokenFound &&
    (operationType === "record") ||
    (operationType === "eligibility" && (isTokenFound?.Session?.passengers?.length === 0 || utils.isCCPaxFoundInCache(passengerLookups, isTokenFound?.Session?.passengers))) ||
    ((operationType === "document" || operationType === "boardingpass") && utils.isCCPaxFoundInCache(passengerLookups, isTokenFound?.Session?.passengers)) ||
    (operationType === "checkin" && utils.isCCPaxAndCachedPaxEqual(passengerLookups, isTokenFound?.Session?.passengers))
  ) {
    console.log('-----------------------------------Getting Session from Cache-------------------------------------------------------')
    session = {
      conversationToken: isTokenFound?.Session?.conversationToken,
      authorization: isTokenFound?.Session?.authorization
    };
  }
  else {
    session = await api.retrieveSession(rloc, familyName);
    await db.insertPnr(`${rloc}/${familyName}`, session);
    isTokenFound = await db.getPnr(`${rloc}/${familyName}`);
  }

  return { session, isTokenFound };
};

//This method will call QR Update API if passengerFoundInCache && passengerFoundInTrip else it will acknowledge the pax and stores in Cache
async function processCCPassengerUpdates(session, flightLookups, passengerLookups, isTokenFound, rloc, familyName, document) {
  let { trip } = await api.getTrip(session);

  if (!(utils.isCCPaxFoundInTrip(passengerLookups, trip))) {
    throw new Error('Matching CC Passenger not found in QR Trip')
  };

  const { nonCheckedInPaxs } = getCheckedInAndNonCheckedInPaxs(trip, passengerLookups);

  if (!nonCheckedInPaxs) throw new Error('Cannot update due to CheckedIn Status');

  const passengerFoundInCache = utils.isCCPaxFoundInCache(passengerLookups, isTokenFound?.Session?.passengers);
  const passengerFoundInTrip = utils.isCCPaxFoundInTrip(passengerLookups, trip);

  console.log('At processCCPassengerUpdates function, passengerFoundInCache: ', passengerFoundInCache);
  console.log('At processCCPassengerUpdates function, passengerFoundInTrip: ', passengerFoundInTrip);

  if (!(passengerFoundInCache && passengerFoundInTrip)) {
    const selection = await api.ackDgTerms(session, trip, nonCheckedInPaxs, flightLookups);
    await db.updatePassengers(`${rloc}/${familyName}`, nonCheckedInPaxs); // Update DB with Acknowledged Pax(s)
    trip = selection.trip;
  }

  const updateRequest = utils.setQrUpdateRequest(document, nonCheckedInPaxs[0].familyName, nonCheckedInPaxs[0].givenName, trip);
  updateRequest.passengerRequest = nonCheckedInPaxs[0];
  updateRequest.flightRequests = flightLookups;
  console.log('Update Request is:', JSON.stringify(updateRequest, null, 2));

  const { requiredDocuments, populatedDocuments } = await processQRPassengerUpdates(session, trip, updateRequest, document);

  return Object.assign({}, { requiredDocuments, populatedDocuments });
}

//This function will process below endpoints:-
//1. Regulatory API      -      To update Regulatory documents such as PASSPORT, VISA, DESTINATION_ADDRESS and RESIDENT_ADDRESS etc.
//2. Emergency API       -      To update EmergencyContact via CC API

async function processQRPassengerUpdates(session, trip, updateRequest, ccReqDocuments) {
  if (!updateRequest.regulatoryInfo) {
    throw new Error('Request must contain one passenger update.');
  }

  if (isCheckedIn(trip)) {
    throw new Error('Cannot update passenger due to check-in status.');
  }

  let emergencyApiCCDocs = null;
  let regulatoryApiCCDocs = null;
  let documentUpdateResponse = {};
  const validRegulatoryDocuments = ['PASSPORT', 'VISA', 'DESTINATION_ADDRESS', 'RESIDENT_ADDRESS']; //Valid CC Docs

  if (ccReqDocuments.length > 1) {
    if (updateRequest.emergencyContact) {
      emergencyApiCCDocs = await processEmergencyDocs(session, trip, updateRequest);
      console.info('Emergency API CC Documents were = ', emergencyApiCCDocs);
    }

    //Process Regulatory API if request has any valida RegulatoryDocument
    if (updateRequest.regulatoryInfo && ccReqDocuments.some((doc) => validRegulatoryDocuments.includes(doc.type))) {
      regulatoryApiCCDocs = await processRegulatoryDocs(session, trip, updateRequest);

      //This line will basically remove regulatoryDocs from emergencyApiCCDocs['qrToCCMissingDocs'] when processRegulatoryDocs was seuccessful
      if (emergencyApiCCDocs) {
        regulatoryApiCCDocs.qrToCCPopulatedDocs.forEach((doc) => {
          if (emergencyApiCCDocs.qrToCCMissingDocs.includes(doc)) {
            emergencyApiCCDocs.qrToCCMissingDocs = emergencyApiCCDocs.qrToCCMissingDocs.filter((missingDoc) => missingDoc !== doc)
          }
        })
      }

      console.info('Regulatory API CC Documents were = ', regulatoryApiCCDocs);
    }

    documentUpdateResponse.requiredDocuments = Array.from(new Set(
      ((emergencyApiCCDocs?.qrToCCMissingDocs) || []).concat(
        (regulatoryApiCCDocs?.qrToCCMissingDocs) || []
      )
    ));
    documentUpdateResponse.populatedDocuments = Array.from(new Set(
      ((emergencyApiCCDocs?.qrToCCPopulatedDocs) || []).concat(
        (regulatoryApiCCDocs?.qrToCCPopulatedDocs) || []
      )
    ));
  }
  else {
    if (updateRequest.emergencyContact) {
      emergencyApiCCDocs = await processEmergencyDocs(session, trip, updateRequest);
      console.info('Emergency API CC Documents were = ', emergencyApiCCDocs);
      documentUpdateResponse.requiredDocuments = emergencyApiCCDocs.qrToCCMissingDocs;
      documentUpdateResponse.populatedDocuments = emergencyApiCCDocs.qrToCCPopulatedDocs;
    }

    if (updateRequest.regulatoryInfo && ccReqDocuments.some((doc) => validRegulatoryDocuments.includes(doc.type))) {
      regulatoryApiCCDocs = await processRegulatoryDocs(session, trip, updateRequest);
      console.info('Regulatory API CC Documents were = ', regulatoryApiCCDocs);
      documentUpdateResponse.requiredDocuments = regulatoryApiCCDocs.qrToCCMissingDocs;
      documentUpdateResponse.populatedDocuments = regulatoryApiCCDocs.qrToCCPopulatedDocs;
    }
  }

  return documentUpdateResponse;
}

//This method do below actions:
//1. Validate CC Pax(s) with Trip paxs
//2. If every CC pax(s) in a request is checked-in, then it will establish new Session and Call Trip to get the acceptance status of all paxs in a PNR
//3. If Pax is unchecked-in && CCPax - CachedPax not equal, then it will acknowledge, stores in DB and call Confirm API
//4. If Pax is unchecked-in && CCPax - CachedPax equal, then requested paxs were acknowledged, good to proceed with Confrim API
//5. Reason for checking CC Pax- Cached Pax equlaity check is to make sure we proceed Confirm for CC Requested Acknowledged pax(s) otherwise Acceptance will done for all pax(s) (if acknowledged)

async function processCCAcceptance(session, ccRequest, cachedPaxs, isV2 = false) {
  const { passengerLookups, flightLookups, rloc, familyName, checkIn } = ccRequest;
  const qrRes = await api.getTrip(session);

  if (!(utils.isCCPaxFoundInTrip(passengerLookups, qrRes.trip))) {
    throw new Error('Matching CC Passenger not found in QR Trip');
  }

  const { checkedInPaxs, nonCheckedInPaxs } = getCheckedInAndNonCheckedInPaxs(qrRes.trip, passengerLookups);

  let travelerRecord;

  if (utils.isCCPaxAndCachedPaxEqual(passengerLookups, cachedPaxs)) {
    // console.log('CC Paxs and Cached Paxs equal, so proceeding with CheckIn');
    travelerRecord = await processCheckInOrUncheckIn(session, qrRes.trip, { checkIn, passengerLookups, flightLookups });
  } 
  else if (nonCheckedInPaxs && nonCheckedInPaxs.length > 0) {
    // console.log('CC Paxs and Cached Paxs not equal....!!');
    console.log('Acknowledging for non checkedIn passengers ', JSON.stringify(nonCheckedInPaxs, null, 2));
    const ackDGTermsResponse = await api.ackDgTerms(session, qrRes.trip, nonCheckedInPaxs, flightLookups);
    await db.updatePassengers(`${rloc}/${familyName}`, nonCheckedInPaxs);
    travelerRecord = await processCheckInOrUncheckIn(session, ackDGTermsResponse.trip, {checkIn, passengerLookups: nonCheckedInPaxs, flightLookups }, { allRequestedPaxs: passengerLookups, isAcknowledged: true }, qrRes.trip);
  } 
  else {
    // console.log('CC Paxs and Cached Paxs not equal....!!');
    travelerRecord = await processCheckInOrUncheckIn(session, qrRes.trip, {checkIn, passengerLookups: checkedInPaxs, flightLookups });
  }
  
  if (isV2) {
    travelerRecord = v1RecordToV2Record(travelerRecord);
  }

  return travelerRecord;
}

async function processCheckInOrUncheckIn(session, trip, {checkIn, passengerLookups, flightLookups}, additionalParams, normalTrip) {
  //normalTrip - Trip obtained in new Session - All paxs present
  if (checkIn) {
    return await checkin(session, trip, {passengerLookups, flightLookups}, additionalParams, normalTrip);
  } else {
    return await uncheckin(session, trip);
  }
}

//This method will check eligibility requiremnents in QR API response and mark it missing if requiredFields not present in response else mark it as populated
function qrPaxEligibility(requirements, eligibilePassenger, qrEligibility, multiEligibility) {
  const { missingFields, populatedFields } = utils.getAllFieldsForEligibility(requirements, eligibilePassenger, qrEligibility);
  const docsWithSeeAgent = Array.from(
    new Set(
      missingFields.map((qrField) => {
        if (qrField?.hasOwnProperty('SEE_AGENT')) {
          return qrField['SEE_AGENT']
        }
      }).filter((field) => (field !== undefined))
    )
  );
  console.info('List of documents with SEE_AGENT: ', docsWithSeeAgent);

  let qrToCCMissingDocs = converter.convertQrToCCMapping(missingFields, docsWithSeeAgent);

  let qrToCCPopulatedDocs = converter.convertQrToCCMapping(populatedFields, docsWithSeeAgent);


  for (let document of qrToCCMissingDocs) {
    if (qrToCCPopulatedDocs.includes(document)){
      qrToCCPopulatedDocs = qrToCCPopulatedDocs.filter((item) => item !== document)
    }
  }

  //change Eligibility response when both PASSPORT&RESIDENT_ADDRESS are Required
  qrToCCMissingDocs = retrieveNestedArrayDocuments(qrToCCMissingDocs)

  if (multiEligibility) {
    return Object.assign({}, {qrToCCMissingDocs, qrToCCPopulatedDocs, familyName: eligibilePassenger.lastName, givenName: eligibilePassenger.firstName});
  }
  return Object.assign({}, {qrToCCMissingDocs, qrToCCPopulatedDocs});
}

async function processEmergencyDocs(session, trip, updateRequest) {
  //handle emergency api
  console.info('Processing Emergency API');

  let { status, data } = await api.updateEmergencyDoc(session, trip, updateRequest);
  data = isEmergencyContactRefused({status, data}, updateRequest)

    return utils.retrieveCCDocs(data, updateRequest.passengerRequest);
}

async function processRegulatoryDocs(session, trip, updateRequest) {
  console.info('Processing RegulatoryUpate API');

  let {data, status} = await api.updateTravelDoc(session, trip, updateRequest);
  data = isEmergencyContactRefused({status, data}, updateRequest)

  return utils.retrieveCCDocs(data, updateRequest.passengerRequest)
};

function isEmergencyContactRefused(qrResponse, updateRequest) {
  let {status, data} = qrResponse;

  const isECRefused = updateRequest?.emergencyContact?.refused;

  //This is the case to understood pax refused to add EC details
  if (isECRefused && (status === 200 && data.trip.emergencyContactDetails.length === 0)) {
    const updatedJourney = utils.removeEmergencyRequirements(data);
    data = { ...data, trip: { ...data.trip, journeys: updatedJourney } };
  }

  return data;
};

function retrieveNestedArrayDocuments(qrToCCMissingDocs) {
  if (qrToCCMissingDocs.includes('PASSPORT') && qrToCCMissingDocs.includes('RESIDENT_ADDRESS')) {
    const  nestedDataResponse= qrToCCMissingDocs.filter(item => item === 'PASSPORT' || item === 'RESIDENT_ADDRESS');
    return [nestedDataResponse, ...qrToCCMissingDocs.filter(item => item !== 'PASSPORT' && item !== 'RESIDENT_ADDRESS')];
  } else {
    return qrToCCMissingDocs;
  }
}

exports.processQRPassengerUpdates = processQRPassengerUpdates;
exports.processCCPassengerUpdates = processCCPassengerUpdates;
exports.processCCAcceptance = processCCAcceptance;
exports.qrPaxEligibility = qrPaxEligibility;
exports.isCheckedIn = isCheckedIn;
exports.isCouponCheckedIn = isCouponCheckedIn;
exports.isCouponCheckInInhibited = isCouponCheckInInhibited;
exports.canCheckIn = canCheckIn
exports.findPassengerByLookup = findPassengerByLookup;
exports.findProductIdByLookup = findProductIdByLookup;
exports.buildJourneyIdFromFlights = buildJourneyIdFromFlights;
exports.isPaxTicketMatch = isPaxTicketMatch;
exports.filterTrip = filterTrip;
exports.getSessionFromCacheOrAPI = getSessionFromCacheOrAPI;
exports.buildTravelDoc = buildTravelDoc;
exports.buildEmergencyDoc = buildEmergencyDoc;
exports.getCheckedInAndNonCheckedInPaxs = getCheckedInAndNonCheckedInPaxs;
