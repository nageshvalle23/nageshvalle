const uuid = require('uuid/v1');
const converter = require('./converter');
const api = require('./api');
const helpers = require('./helpers');
const utils = require('./utils');
const flifoApi = require('./flifo/api');
const convertToFlight = require('./flifo/converter');
const warmer = require("lambda-warmer");

const { response, params, body } = require('@oneworld-digital/integration-utils').request;
const { isV2Request, convertToV1Params, convertToV1Body, v1RecordToV2Record } = require('@oneworld-digital/integration-utils').versionConverter;

exports.record = async (event, context, cb) => {
  try {
    console.log("CC Record Request is: ", JSON.stringify(body(event), null, 2));

    const isV2 = isV2Request(event);

    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    if (!familyName || !rloc) {
      throw new Error('Missing parameters')
    }

    const {session} = await helpers.getSessionFromCacheOrAPI({rloc, familyName}, 'record');

    // 2. get the trip
    const { trip } = await api.getTrip(session);

    // 3. convert the object from qr to a cc specific object
    let travelerRecord = converter.execute(trip, null, null, null, true);
    if (isV2) {
      travelerRecord = v1RecordToV2Record(travelerRecord);
    }
    console.log('CC Record response: ', JSON.stringify(travelerRecord, null, 2));
    
    cb(null, response(200, travelerRecord));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.passenger = async (event, context, cb) => {
  try {

    const updateRequest = body(event);
    const { recordRequest, flightRequests, passengerRequest } = updateRequest;

    const session = await api.retrieveSession(recordRequest.rloc, recordRequest.familyName);
    const qrRes = await api.getTrip(session);
    const selection = await api.ackDgTerms(session, qrRes.trip, [passengerRequest], flightRequests);

    await helpers.processQRPassengerUpdates(session, selection.trip, updateRequest, ["PASSPORT", "VISA", "DESTINATION_ADDRESS", "RESIDENT_ADDRESS"]);

    cb(null, response(200));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.checkin = async (event, context, cb) => {
  try {
    console.log("CC Checkin Request is: ", JSON.stringify(body(event), null, 2));

    const isV2 = isV2Request(event);

    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    let { passengerLookups, flightLookups, requirements, checkIn } = isV2 ? convertToV1Body(body(event)) : body(event);

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session, isTokenFound} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'checkin');

    const travelerRecord = await helpers.processCCAcceptance(session, { passengerLookups, flightLookups, rloc, familyName, requirements, checkIn }, isTokenFound?.Session?.passengers, isV2)

    console.info('CC Check-in Response body: ', JSON.stringify(travelerRecord, null, 2));
    
    cb(null, response(200, travelerRecord));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.multicheckin = async (event, context, cb) => {
  try {
    console.log("CC Multi-Checkin Request is: ", JSON.stringify(body(event), null, 2));

    const { familyName, rloc } = utils.convertToV2Params(body(event))

    let { passengerLookups, flightLookups, requirements, checkIn } = utils.convertToV2Body(body(event));

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session, isTokenFound} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'checkin');

    const travelerRecord = await helpers.processCCAcceptance(session, { passengerLookups, flightLookups, rloc, familyName, requirements, checkIn }, isTokenFound?.Session?.passengers)

    console.info('CC Multi-Checkin Response body: ', JSON.stringify(travelerRecord, null, 2));

    cb(null, response(200, travelerRecord));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.boardingpass = async (event, context, cb) => {
  try {
    console.info('CC boardingpass Request body: ', JSON.stringify(body(event), null, 2));

    const isV2 = isV2Request(event);
    
    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    let { passengerLookups, flightLookups } = isV2 ? convertToV1Body(body(event)) : body(event);

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'boardingpass');

    // 2. get the trip
    const { trip } = await api.getTrip(session);

    let travelerRecord = converter.execute(trip, passengerLookups, flightLookups, true);

    if (isV2) {
      travelerRecord = v1RecordToV2Record(travelerRecord);
    }

    console.info('CC Boardingpass Response body: ', JSON.stringify(travelerRecord, null, 2));

    cb(null, response(200, travelerRecord));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.multiboardingpass = async (event, context, cb) => {
  try {
    console.log('CC Multi-Boarding pass Request is: ', JSON.stringify(body(event), null, 2));

    const { familyName, rloc } = utils.convertToV2Params(body(event))

    let { passengerLookups, flightLookups } = utils.convertToV2Body(body(event));

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'boardingpass');

    // 2. get the trip
    const { trip } = await api.getTrip(session);

    let travelerRecord = converter.execute(trip, passengerLookups, flightLookups, true);

    travelerRecord = v1RecordToV2Record(travelerRecord);

    console.info('CC Multi-Boardingpass Response body: ', JSON.stringify(travelerRecord, null, 2));

    cb(null, response(200, travelerRecord));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.eligibility = async (event, context, cb) => {
  try {
    const requestBody = body(event);
    console.log('Eligibility request body: ', JSON.stringify(requestBody, null, 2));

    const isV2 = true;
    const { familyName, rloc } = isV2 ? convertToV1Params(requestBody) : params(event);

    let { passengerLookups, flightLookups } = isV2 ? convertToV1Body(requestBody) : requestBody;

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session, isTokenFound} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'eligibility');

    const { trip } = await api.getTrip(session);

    const eligibilityResponse = await utils.retrieveEligibilityResponse(session, trip, {passengerLookups, flightLookups, rloc, familyName}, isTokenFound?.Session?.passengers)

    console.log('CC Eligibility Response: ', JSON.stringify(eligibilityResponse, null, 2));

    cb(null, response(200, eligibilityResponse));

  } catch (err) {
    console.log('Error:', err);
    return _handleErrors(err, cb);
  }
};

exports.multieligibility = async (event, context, cb) => {
  try {
    console.log('Multi Eligibility request body: ', JSON.stringify(body(event), null, 2));

    const { familyName, rloc } = utils.convertToV2Params(body(event))

    let { passengerLookups, flightLookups } = utils.convertToV2Body(body(event));

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session, isTokenFound} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'eligibility');

    const { trip } = await api.getTrip(session);

    const multiEligibilityResponse = await utils.retrieveEligibilityResponse(session, trip, {passengerLookups, flightLookups, rloc, familyName}, isTokenFound?.Session?.passengers, true)

    console.log('CC Multi Eligibility Response: ', JSON.stringify(multiEligibilityResponse, null, 2));

    cb(null, response(200, multiEligibilityResponse));
  }
  catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.document = async (event, context, cb) => {
  try {
    console.log('Document Update request body: ', JSON.stringify(body(event), null, 2));

    const isV2 = true;
    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);
    let { passengerLookups, flightLookups } = isV2 ? convertToV1Body(body(event)) : body(event);

    flightLookups = flightLookups.map((flight) => ({...flight, flightNumber: utils.padFlightNumberWithZeros(flight.flightNumber)}));

    const {session, isTokenFound} = await helpers.getSessionFromCacheOrAPI({rloc, familyName, passengerLookups}, 'document')

    const updateCCResponse = await helpers.processCCPassengerUpdates(session, flightLookups, passengerLookups, isTokenFound, rloc, familyName, body(event).document)

    console.log('CC Document Update Response: ', JSON.stringify(updateCCResponse, null, 2));

    cb(null, response(200, updateCCResponse));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.flifo = async (event, context, cb) => {
  try {
    if (await warmer(event)) return "warmed";

    // Parse request data
    const {flightNumber, date} = body(event);

    if (!date || !flightNumber) {
      const err = new Error()
      err.message = 'Must provide date and flightNumber in lookup.'

      throw err;
    }

    const result = await flifoApi(date, flightNumber)

    const flifoResponse = convertToFlight(result);

    return cb(null, response(200, flifoResponse));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};



async function _handleErrors(err, cb) {

  const body = {
    id: uuid(),
    message: err.CARRIER_ERROR_MESSAGE || err.message,
    type: err.CARRIER_ERROR_CODE ? 'OA' : 'Internal',
    code: err.CARRIER_ERROR_CODE || '500'
  };

  let responseCode;
  if (err.CARRIER_ERROR_MESSAGE && err.CARRIER_ERROR_CODE) {
    responseCode = 502;
  } else {
    responseCode = 500;
  }

  console.error(`Request failed with status ${responseCode} and body ${JSON.stringify(body, null, 2)}`);

  return cb(null, response(responseCode, body));
}