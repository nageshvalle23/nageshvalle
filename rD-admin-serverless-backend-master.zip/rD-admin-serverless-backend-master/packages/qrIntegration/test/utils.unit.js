const chai = require('chai');
const assert = chai.assert;

describe('Helper utils for API functionality', () => {
  const m = require('../utils')

  describe('Params', () => {
    it('Should get the qs params if they exist', () => {
      const params = m.params({queryStringParameters: {foo: 'bar'}})

      assert.deepEqual(params, {foo: 'bar'})
    })

    it('Should return empty object when there are no params', () => {
      const params = m.params({notTheRightKey: {foo: 'bar'}})

      assert.deepEqual(params, {})
    })
  })

  describe('Body', () => {
    it('Should stringify the body', () => {
      const body = m.body({body: '{"foo": "bar"}'})

      assert.deepEqual(body, {foo: 'bar'})
    })

    it('Should return an empty object if the body is empty or missing', () => {
      const body = m.body({body: '""'})

      assert.deepEqual(body, {})
    })
  })


  describe('Response', () => {
    it('Should produce a valid response', () => {
      const res = m.response(200, {foo: 'bar'})

      assert.deepEqual(res, {
        statusCode: 200,
        body: '{"foo":"bar"}',
        headers: {
          'Content-Type':'application/json'
        }
      })
    })

    it('Should produce an valid error response when no body specified', () => {
      const res = m.response(400)

      assert.equal(res.statusCode, 400)
      assert.equal(res.body, '')
    })
  })
})
