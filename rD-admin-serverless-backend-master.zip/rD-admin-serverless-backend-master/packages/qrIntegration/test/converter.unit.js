const chai = require('chai');
const assert = chai.assert;

describe('Data conversion functions', () => {
  const m = require('../converter')
  let passengerLookups = [{
    "familyName": "CONNECT",
    "givenName": "CARRIER",
    "eTicketNumber": "1572371376243"
  }]
  let flightLookups = [
    {
      "carrier": "QR",
      "date": "2018-08-04",
      "flightNumber": "0818",
      "origin": "DOH",
      "destination": "HKG"
    },
    {
      "carrier": "CX",
      "date": "2018-08-04",
      "flightNumber": "0470",
      "origin": "HKG",
      "destination": "TPE"
    }
  ];

  describe('execute', () => {
    it('Should produce a traveler record', () => {
      const { trip } = require('./mocks/valid_getTrip');
      const rec = m.execute(trip, passengerLookups, flightLookups, null, true);

      assert.equal(rec.pnr.rloc, 'M3OPMS')
      assert.equal(rec.pnr.passengers.length, 1)
      assert.equal(rec.pnr.flights.length, 2)
    })

    it('Should produce a traveler record with bp info', () => {
      const { trip } = require('./mocks/valid_acceptanceConfirm')
      const rec = m.execute(trip, passengerLookups, flightLookups, true);

      assert.equal(rec.pnr.rloc, 'M3OPMS')
      assert.equal(rec.pnr.passengers.length, 1)
      assert.equal(rec.pnr.flights.length, 2)
    })

    it('Should throw an error if there is anything wrong with the trip', () => {
      assert.throws(() => m.execute({}))
      assert.throws(() => m.execute(undefined))
      assert.throws(
        () => m.execute({
          passengers: [],
          journeys: [],
          passengerFlightMapping: []
        })
      )
    })
  })
});
