const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const assert = chai.assert;

const moduleName = '../api'

const placeholderStub = fnName => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = customStubs => _.defaults({}, customStubs, {
  ['axios']: placeholderStub('params'),
  ['./helpers']: {
    buildJourneyIdFromFlights: placeholderStub('buildJourneyIdFromFlights'),
    findProductIdByLookup: placeholderStub('findProductIdByLookup'),
    canCheckIn: placeholderStub('canCheckIn'),
    isCheckedIn: placeholderStub('isCheckedIn'),
  }
});

describe('API for QR DCS integration', () => {
  const axios = sinon.stub();
  const buildTravelDoc = sinon.stub();
  const buildJourneyIdFromFlights = sinon.stub();
  const findProductIdByLookup = sinon.stub();
  const canCheckIn = sinon.stub();
  const isCheckedIn = sinon.stub();
  const filterTrip = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    ['axios']: axios,
    ['./helpers']: {
      buildTravelDoc,
      buildJourneyIdFromFlights,
      findProductIdByLookup,
      canCheckIn,
      isCheckedIn,
      filterTrip
    }
  }))

  describe('retrieveSession', () => {
    after(() => {
      axios.reset();
    });

    it('should return a properly formatted session object', async () => {
      const res = {
        headers: {
          authorization: 'foo'
        },
        data: {
          conversationToken: 'bar'
        }
      }

      axios.returns(res)

      const session = await m.retrieveSession('abc123', 'smith')

      assert(axios.calledOnce)

      assert.deepEqual(session, {authorization: 'Bearer foo', conversationToken: 'bar'})
    });

    it('should throw an error if the function is not called with the correct params', async () => {
      await assert.isRejected(m.retrieveSession('abc123'), Error)
    });

    it('should throw an error if the response does not have expected values', async () => {

      axios.returns({
        headers: {
          authorization: 'foo'
        },
        data: {
          bar: 'baz'
        }
      })
      await assert.isRejected(m.retrieveSession('abc123', 'smith'), Error)


      axios.returns({
        headers: {
          foo: 'bar'
        },
        data: {
          conversationToken: 'baz'
        }
      })
      await assert.isRejected(m.retrieveSession('abc123', 'smith'), Error)
    });
  })

  describe('getTrip', () => {
    after(() => {
      axios.reset();
    });

    it('should throw an error if the session object is missing properties', async () => {
      await assert.isRejected(m.getTrip({conversationToken: 'bar'}), Error)
      await assert.isRejected(m.getTrip({authorization: 'bar'}), Error)
    })

    it('should throw an error if the response does not contain a trip', async () => {
      const session = {authorization: 'Bearer foo', conversationToken: 'bar'}
      axios.returns({
        data: {
          foo: 'bar'
        }
      })
      await assert.isRejected(m.getTrip(session), Error)
    })

    it('should return a properly formatted trip object', async () => {
      const session = {authorization: 'Bearer foo', conversationToken: 'bar'}
      axios.returns({
        data: {
          trip: {
            foo: 'bar'
          }
        }
      })
      assert.deepEqual(await m.getTrip(session), {trip: {foo: 'bar'}})
    })
  })


  describe('ackDgTerms', () => {
    after(() => {
      axios.reset();
    });

    it('should throw an error if the session object is missing properties', async () => {
      const session = {conversationToken: 'bar'}
      await assert.isRejected(m.ackDgTerms(session), Error)
    })

    it('should throw an error if the response does not contain a trip', async () => {
      const session = {authorization: 'Bearer foo', conversationToken: 'bar'}

      axios.returns({
        data: {
          foo: 'bar'
        }
      })

      await assert.isRejected(m.ackDgTerms(session, {}, [{}], [{}]), Error)
    })

    it('should return a properly formatted trip object', async () => {
      const session = {authorization: 'Bearer foo', conversationToken: 'bar'}
      axios.returns({
        data: {
          trip: {
            foo: 'bar'
          }
        }
      })

      const qrRes = await m.ackDgTerms(session, {}, [{}], [{}])

      assert.deepEqual(qrRes, {trip: {foo: 'bar'}})
    })
  })

  describe('checkin', () => {
    after(() => {
      axios.reset();
    });

    it('should throw an error if the session object is missing properties', async () => {
      await assert.isRejected(m.checkin({conversationToken: 'bar'}, {}))
      await assert.isRejected(m.checkin({conversationToken: 'bar', authorization: 'baz'}))
      await assert.isRejected(m.checkin({conversationToken: 'bar', authorization: 'baz'}, {}))
    })

    it('should throw an error if the trip is not eligible for checkin', async () => {
      canCheckIn.returns(false)
      await assert.isRejected(m.checkin({conversationToken: 'bar', authorization: 'baz'}, {trip: {baz: 'qux'}}))
    })

    it('should throw an error if qr does not return a trip', async () => {
      canCheckIn.returns(true)
      axios.returns({
        data: {
          foo: {
            bar: 'baz'
          }
        }
      })
      await assert.isRejected(m.checkin({conversationToken: 'bar', authorization: 'baz'}, {trip: {baz: 'qux'}}))
    })

    it('should throw an error if qr the trip returned is not checked in', async () => {
      canCheckIn.returns(true)
      isCheckedIn.returns(false)
      axios.returns({
        data: {
          trip: {
            bar: 'baz'
          }
        }
      })
      await assert.isRejected(m.checkin({conversationToken: 'bar', authorization: 'baz'}, {trip: {baz: 'qux'}}))
    })

    /* it('should return a trip if already checked in', async () => {

     * }) */

    it('should return a trip when all checks pass', async () => {
      canCheckIn.returns(true)
      isCheckedIn.returns(true)

      axios.returns({
        data: {
          trip: {
            bar: 'baz'
          }
        }
      })

      const qrRes = await m.checkin({conversationToken: 'bar', authorization: 'baz'}, {trip: {baz: 'qux'}})

      assert.deepEqual(qrRes, {trip: {bar: 'baz'}})
    })
  })

  describe('cancelCheckin', () => {
    beforeEach(() => {
      axios.reset();
      canCheckIn.reset();
      isCheckedIn.reset();
    });

    it('should throw an error if the session object is missing properties', async () => {
      const session = {conversationToken: 'foo'}
      await assert.isRejected(m.cancelCheckin(session), Error)
    })

    it('should throw an error if the trip is not checked in yet', async () => {
      const session = {
        conversationToken: 'foo',
        authorization: 'bar'
      }

      isCheckedIn.returns(false);

      await assert.isRejected(m.cancelCheckin(session, {}, [{}], [{}]), Error)
    })

    it('should throw an error if qr api request errors out', async () => {
      axios.returns({foo: 'bar'})

      isCheckedIn.returns(true);

      await assert.isRejected(m.cancelCheckin({
        conversationToken: 'foo',
        authorization: 'bar'
      }, {}, [{}], [{}]), Error)
    })

    it('should throw an error if qr api does not return success', async () => {
      axios.returns({data: { status: 'ACK'}})

      isCheckedIn.returns(true);

      await assert.isRejected(m.cancelCheckin({
        conversationToken: 'foo',
        authorization: 'bar'
      }, {}, [{}], [{}]), Error)
    })

    it('should return a success message when all checks pass', async () => {
      axios.returns({
        data: {
          status: 'SUCCESS',
          reloadTripRequired: true
        }
      })
      isCheckedIn.returns(true);

      const res = await m.cancelCheckin({
        conversationToken: 'foo',
        authorization: 'bar'
      }, {}, [{}], [{}]);

      assert.deepEqual(res, {status: 'SUCCESS', reloadTripRequired: true})
    })
  })

  describe('reloadTrip', () => {
    beforeEach(() => {
      axios.reset();
    });

    it('should throw an error if the session object is missing properties', async () => {
      const session = {conversationToken: 'foo'}
      await assert.isRejected(m.reloadTrip(session), Error)
    })

    it('should throw an error if qr does not return a trip', async () => {
      const session = {
        conversationToken: 'foo',
        authorization: 'bar'
      }

      axios.returns({ data: {foo: 'bar'}})

      await assert.isRejected(m.reloadTrip(session), Error)
    })

    it('should return a trip when all checks pass', async () => {
      const session = {
        conversationToken: 'foo',
        authorization: 'bar'
      }

      axios.returns({data: {trip: {good: 'deal'}}})
      const res = await m.reloadTrip(session);
      assert.deepEqual(res, {trip: {good: 'deal'}})
    })
  })


  describe('update travel docs', () => {
    after(() => {
      axios.reset();
    });

    const updateRequest = {
      passengerRequest: {
        familyName: 'familyName',
        givenName: 'givenName',
        eTicketNumber: '1234567890'
      }, 
      flightRequests: [
      {
        f: 'flight1'
      },{
        f: 'flight2'
      }], 
      regulatoryInfo: {
        gender: 'M',
        dateOfBirth: '1978-01-01', 
        countryOfResidenceCode: 'USA',
        nationalityCode: 'USA',  
        travelDoc: {
          regulatoryGivenName: 'jesses',
          regulatoryFamilyName: 'jamess',
          expiryDate: '2022-01-05',
          issuedDate: '2019-01-05',
          countryOfIssue: 'USA',
          documentType: 'PASSPORT',
          documentNumber: '999999'
        }
      }, 
      destinationAddress: {
        city: 'new york', 
        state: 'NY', 
        country: 'USA', 
        street: '2 park ave', 
        zipCode: '10036'
      },
    };

    it('should throw an error if the session object is missing properties', async () => {
      await assert.isRejected(m.updateTravelDoc({conversationToken: 'bar'}, {}))
      await assert.isRejected(m.updateTravelDoc({conversationToken: 'bar', authorization: 'baz'}))
      await assert.isRejected(m.updateTravelDoc({conversationToken: 'bar', authorization: 'baz'}, {}))
    })

    // TODO -- to keep or not....
    // it('should throw an error if the passenger request object is missing properties', async () => {
    //   const session = {conversationToken: 'bar', authorization: 'baz'};

    //   var request = JSON.parse(JSON.stringify(updateRequest));
    //   delete request.regulatoryInfo.gender;
    //   await assert.isRejected(m.updateTravelDoc(session, {}, request));

    //   var request2 = JSON.parse(JSON.stringify(updateRequest));
    //   delete request2.destinationAddress.state;
    //   await assert.isRejected(m.updateTravelDoc(session, {}, request2));

    //   // should succeed -- destination address is not required.
    //   var request3 = JSON.parse(JSON.stringify(updateRequest));
    //   delete request3.destinationAddress;
    //   m.updateTravelDoc(session, {}, request3);
    // })

    it('should throw an error if qr does not return a trip', async () => {
      const session = {conversationToken: 'bar', authorization: 'baz'};
      const fulltrip = {trip: {baz: 'qux'}};
      buildTravelDoc.returns('travel doc payload');
      axios.returns({
        data: {
          foo: {
            bar: 'baz'
          }
        }
      })

      await assert.isRejected(m.updateTravelDoc(session, fulltrip, updateRequest));
    })

    it('should return data when update successful', async () => {
      const session = {conversationToken: 'bar', authorization: 'baz'};
      const fulltrip = {trip: {baz: 'qux'}};
      buildTravelDoc.returns('travel doc payload');
      axios.returns({
        data: {
          trip: {
            bar: 'baz'
          }
        }
      })

      await m.updateTravelDoc(session, fulltrip, updateRequest);
    })
  })  
})
