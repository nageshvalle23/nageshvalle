const chai = require('chai');
const assert = chai.assert;
const _ = require("lodash");

describe('Helpers for searching and translating data', () => {
  const m = require('../helpers')

  describe('findProductIdByLookup', () => {
    it('Should find the id with the given lookup', () => {
      const { trip } = require('./mocks/valid_getTrip')

      const lookup = {
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '1572371376243'
      }

      const paxId = m.findProductIdByLookup(trip, lookup)

      assert.equal(paxId, '2301CB23000083C9')
    })

    it('Should return undefined when first name, last name or ticket number does not match', () => {
      const { trip } = require('./mocks/valid_getTrip')

      assert.throws(() => m.findProductIdByLookup(trip, {
        givenName: 'carrier',
        familyName: 'foo',
        eTicketNumber: '1572371376243'
      }), Error);

      assert.throws(() => m.findProductIdByLookup(trip, {
        givenName: 'foo',
        familyName: 'connect',
        eTicketNumber: '1572371376243'
      }), Error);

      assert.throws(() => m.findProductIdByLookup(trip, {
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '0000000000'
      }), Error);
    })

    it('Should return undefined if any of the lookup properties are missing', () => {
      const { trip } = require('./mocks/valid_getTrip')

      assert(typeof m.findProductIdByLookup(trip, {
        familyName: 'connect',
        eTicketNumber: '1572371376243'
      }) === 'undefined')

      assert(typeof m.findProductIdByLookup(trip, {
        givenName: 'carrier',
        eTicketNumber: '1572371376243'
      }) === 'undefined')

      assert(typeof m.findProductIdByLookup(trip, {
        givenName: 'carrier',
        familyName: 'connect',
      }) === 'undefined')

    })
  })

  describe('canCheckIn', () => {
    it('Should return true when trip object is available for checkin', () => {
      const trip = {
        passengerFlightMapping: [
          {
            pasengerTimelineInfo: {
              checkinStatus: 'OPEN'
            }
          },
          {
            pasengerTimelineInfo: {
              checkinStatus: 'OPEN'
            }
          }
        ],
        passengers: [
          {
            checkIn: {
              apisDetailsComplete: true
            }
          }
        ]
      }
      assert(m.canCheckIn(trip))
    })

    it('Should return true when trip object is available for checkin', () => {
      const trip = {
        passengerFlightMapping: [
          {
            pasengerTimelineInfo: {
              checkinStatus: 'OPEN'
            }
          },
          {
            pasengerTimelineInfo: {
              checkinStatus: 'OPEN'
            }
          }
        ],
        passengers: [
          {
            checkIn: {
              apisDetailsComplete: false
            }
          }
        ]
      }

      assert(m.canCheckIn(trip) === false)
    })

    it('Should fail because the checkin status is not open', () => {
      const trip = {
        passengerFlightMapping: [
          {
            pasengerTimelineInfo: {
              checkinStatus: 'OPEN'
            }
          },
          {
            pasengerTimelineInfo: {
              checkinStatus: 'FOO'
            }
          }
        ],
        passengers: [
          {
            checkIn: {
              apisDetailsComplete: true
            }
          }
        ]
      }

      assert(m.canCheckIn(trip) === false)
    })
  })

  describe('isCheckedIn', () => {
    it('Should return false if the checkin field is not set CHECKED_IN', () => {
      const trip = {
        passengerFlightMapping: [
          {
            pasengerTimelineInfo: {
              checkinStatus: 'FOO'
            }
          },
          {
            pasengerTimelineInfo: {
              checkinStatus: 'FOO'
            }
          }
        ]
      }

      assert(!m.isCheckedIn(trip))

    })

    it('Should return true if the checkin field is set CHECKED_IN', () => {
      const trip = {
        passengerFlightMapping: [
          {
            pasengerTimelineInfo: {
              checkinStatus: 'CHECKED_IN'
            }
          },
          {
            pasengerTimelineInfo: {
              checkinStatus: 'CHECKED_IN'
            }
          }
        ]
      }
      assert(m.isCheckedIn(trip))
    })
  })

  describe('isCouponCheckInInhibited', () => {
    it('Should return false if the status field is not set INHIBITED', () => {
      const passengerFlightMapping = {
        pasengerTimelineInfo: {
          checkinStatus: 'FOO'
        }
      }
      assert(!m.isCouponCheckInInhibited(passengerFlightMapping));
    })

    it('Should return true if the checkin field is set CHECKED_IN', () => {
      const passengerFlightMapping = {
        pasengerTimelineInfo: {
          checkinStatus: 'INHIBITED'
        }
      }

      assert(m.isCouponCheckInInhibited(passengerFlightMapping));
    })
  })

  describe('buildJourneyIdFromFlights', () => {

    it('Should create a valid journey id', () => {
      const flights = [
        {
          carrier: 'AA',
          flightNumber: '123',
          date: '2018-09-30',
          origin: 'FOO',
          destination: 'BAR'
        },
        {
          carrier: 'BB',
          flightNumber: '456',
          date: '2018-09-30',
          origin: 'BAR',
          destination: 'BAZ'
        }
      ]

      assert(m.buildJourneyIdFromFlights(flights) === 'AA12320180930FOOBARBB45620180930BARBAZ')
    })

    it('Should create a valid journey id with date month > 9', () => {
      const flights = [
        {
          carrier: 'AA',
          flightNumber: '123',
          date: '2018-10-3',
          origin: 'FOO',
          destination: 'BAR'
        },
        {
          carrier: 'BB',
          flightNumber: '456',
          date: '2018-10-3',
          origin: 'BAR',
          destination: 'BAZ'
        }
      ]

      assert(m.buildJourneyIdFromFlights(flights) === 'AA12320181003FOOBARBB45620181003BARBAZ')
    })


    it('Should throw an error if any fields are missing', () => {
      const flights = [
        {
          foo: 'AA',
          flightNumber: '123',
          date: '2018-09-30',
          origin: 'FOO',
          destination: 'BAR'
        },
        {
          carrier: 'BB',
          flightNumber: '456',
          date: '2018-09-30',
          origin: 'BAR',
          destination: 'BAZ'
        }
      ]

      assert.throws(() => m.buildJourneyIdFromFlights(flights), Error)

    })
  })

  describe('filterTrip', () => {

    it('Should pull the correct values off the trip', () => {
      const { trip } = require('./mocks/valid_getTrip')

      const flights = [
        {
          carrier: 'AA',
          flightNumber: '123',
          date: '2018-10-3',
          origin: 'FOO',
          destination: 'BAR'
        },
        {
          carrier: 'BB',
          flightNumber: '456',
          date: '2018-10-3',
          origin: 'BAR',
          destination: 'BAZ'
        }
      ]

      const paxs = [{

        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '1572371376243'

      }]

      const filtered = m.filterTrip(trip, { conversationToken: 'foo' }, paxs, flights);

      assert.deepEqual(filtered,
        {
          "conversationToken": "foo",
          "trip": {
            "tripReference": "M3OPMS",
            "journeys": [
              {
                "uniqueJourneyIdentifier": {
                  "uniqueIdentifier": "AA12320181003FOOBARBB45620181003BARBAZ"
                }
              }
            ],
            "passengers": [
              {
                "passengerIdentifier": {
                  "productIdentifier": "2301CB23000083C9"
                }
              }
            ]
          }
        })

    })

  })


  describe('buildTravelDoc', () => {

    const { trip } = require('./mocks/valid_ackDgTerms')

    const passport = {
      expiryDate: '2022-01-03',
      issuedDate: '2019-01-03',
      countryOfIssue: 'USA',
      documentType: 'PASSPORT',
      documentNumber: '010103'
    };

    const visa = {
      expiryDate: '2022-01-03',
      issuedDate: '2019-01-03',
      countryOfIssue: 'USA',
      documentType: 'VISA',
      documentNumber: '010103',
      applicableCountry: 'USA',
      cityOfIssue: 'New York'
    };

    const requestPassport = {
      passengerRequest: {
        familyName: 'CONNECT',
        givenName: 'CARRIER',
        eTicketNumber: '1572371376243',
      },
      regulatoryInfo: {
        regulatoryGivenName: 'Carrierer',
        regulatoryFamilyName: 'Connectect',
        gender: 'M',
        dateOfBirth: '1980-01-01',
        countryOfResidenceCode: 'USA',
        nationalityCode: 'USA',
        travelDoc: {
          'PASSPORT': passport
        }
      },
      destinationAddress: {
        city: 'new york',
        state: 'NY',
        country: 'USA',
        street: '2 park ave',
        zipCode: '10036'
      },
      // emergencyContact: {
      //   lastName: 'TEST',
      //   contactCountry: 'GBR',
      //   contactNumber: '384293990'
      // },
      flightRequests: [{
        carrier: 'QR',
        flightNumber: '0818',
        origin: 'DOH',
        destination: 'HKG',
        date: '2018/08/04'
      }, {
        carrier: 'CX',
        flightNumber: '0470',
        origin: 'HKG',
        destination: 'TPE',
        date: '2018/08/04'
      }]
    };
    var requestVisa = JSON.parse(JSON.stringify(requestPassport));
    requestVisa.regulatoryInfo.travelDoc['VISA'] = visa;
    console.log('Request visa is: ', JSON.stringify(requestVisa, null, 2));

    const session = { conversationToken: 'iconversate' };
    const expectedResult = {
      primaryDocumentUpdate: 'PASSPORT',
      additionalDocumentUpdate: null,
      byPassVisaCheck: false,

      trip: {
        tripReference: 'M3OPMS',
        journeys: [
          {
            "uniqueJourneyIdentifier": {
              "uniqueIdentifier": "QR081820180804DOHHKGCX047020180804HKGTPE"
            },
            "flightList": [
              {
                "flightIdentifier": {
                  "productIdentifier": "2301CB2600027E1B",
                  "uniqueIdentifier": "QR081820180804DOHHKG"
                }
              },
              {
                "flightIdentifier": {
                  "productIdentifier": "2301CB2600027E1C",
                  "uniqueIdentifier": "CX047020180804HKGTPE"
                }
              }
            ],
            "departureDate": "Sat Aug 04 2018 02:55"
          }
        ],
        // emergencyContactDetails: [{
        //       lastName: 'TEST',
        //       contactCountry: 'GBR',
        //       contactNumber: '384293990',
        //       updatingEmDetails: true,
        //       journeyIdentifiers: ["QR081820180804DOHHKGCX047020180804HKGTPE"],
        // }],
        passengers: [
          {
            "passengerIdentifier": {
              "productIdentifier": "2301CB23000083C9"
            },
            "title": "MR",
            "firstName": "CARRIER",
            "lastName": "CONNECT",
            "gender": "M",
            "dateOfBirth": "1980-01-01",
            "passengerType": "ADULT",
            "address": [{
              "city": "new york",
              "country": "USA",
              "journeyIdentifiers": [
                "QR081820180804DOHHKGCX047020180804HKGTPE"
              ],
              "state": "NY",
              "street": "2 park ave",
              "type": "DESTINATION",
              "zipCode": "10036"
            }],
            "apisInformation": {
              "countryOfResidenceCode": "USA",
              "nationalityCode": "USA",
              "regulatoryFirstName": "Carrierer",
              "regulatoryLastName": "Connectect",
              "documents": [
                {
                  "expiryDate": "2022-01-03",
                  "countryOfIssue": "USA",
                  "documentType": "PASSPORT",
                  "documentReferenceNumber": "010103",
                  "issuedDate": "2019-01-03"
                }
              ]
            }
          }
        ],
        passengerFlightMapping: [
          {
            "paxFlightIdentifier": {
              "passengerIdentifier": {
                "productIdentifier": "2301CB23000083C9"
              },
              "flightIdentifier": {
                "productIdentifier": "2301CB2600027E1B",
                "uniqueIdentifier": "QR081820180804DOHHKG"
              }
            }
          },
          {
            "paxFlightIdentifier": {
              "passengerIdentifier": {
                "productIdentifier": "2301CB23000083C9"
              },
              "flightIdentifier": {
                "productIdentifier": "2301CB2600027E1C",
                "uniqueIdentifier": "CX047020180804HKGTPE"
              }
            }
          }
        ]
      },
      conversationToken: session.conversationToken,
    };

    it('Should create the travelDoc update objects based upon trip & lookup objects', () => {

      const actualResult = m.buildTravelDoc(trip, session, requestPassport);
      console.log('Actual result == ', JSON.stringify(actualResult));
      assert.deepEqual(actualResult, expectedResult);
    })

    it('Should create the VISA travelDoc update objects based upon trip & lookup objects', () => {

      var visaExpectedResult = JSON.parse(JSON.stringify(expectedResult));
      visaExpectedResult.primaryDocumentUpdate = 'PASSPORT';
      visaExpectedResult.additionalDocumentUpdate = 'VISA'
      visaExpectedResult.byPassVisaCheck = true;

      visaExpectedResult.trip.passengers[0].apisInformation.documents[0].documentType = 'VISA';
      visaExpectedResult.trip.passengers[0].apisInformation.documents[0].cityOfIssue = 'New York';
      visaExpectedResult.trip.passengers[0].apisInformation.documents[0].applicableCountry = 'USA';

      //delete PASSPORT from requestVisa
      delete requestVisa.regulatoryInfo.travelDoc['PASSPORT'];

      const actualResult = m.buildTravelDoc(trip, session, requestVisa);
      assert.deepEqual(actualResult, visaExpectedResult);
    })

    it('Should create the PASSPORT travelDoc update objects based upon trip & lookup objects - no destination address', () => {

      // set up scenario for the test 
      var destAddressTest = JSON.parse(JSON.stringify(requestPassport));
      var noAddressExpectedResult = JSON.parse(JSON.stringify(expectedResult));

      delete destAddressTest.destinationAddress;
      noAddressExpectedResult.trip.passengers[0].address = undefined;
      const actualResult = m.buildTravelDoc(trip, session, destAddressTest);
      assert.deepEqual(actualResult, noAddressExpectedResult);
    })

    it('Should throw an error if the pax is not on the trip', () => {

      const currentName = requestPassport.passengerRequest.givenName;
      requestPassport.passengerRequest.givenName = 'IamNotaPassenger';
      assert.throws(() => m.buildTravelDoc(trip, session, requestPassport), Error);
      requestPassport.passengerRequest.givenName = currentName;
    })

    it('Should throw an error if the flight is not on the trip', () => {

      requestPassport.flightRequests[0].flightNumber = '0000';
      assert.throws(() => m.buildTravelDoc(trip, session, requestPassport), Error);
    })

  })
})
