const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const assert = chai.assert;
const chaiAsPromised = require('chai-as-promised');
const { updateEmergencyDoc } = require('../api');

chai.use(chaiAsPromised);

const moduleName = '../index';

const placeholderStub = (fnName) => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = (customStubs) => _.defaults({}, customStubs, {
  ['./converter']: {
    execute: placeholderStub('execute'),
  },

  ['@oneworld-digital/integration-utils']: {
    request: {
      body: placeholderStub('body'),
      params: placeholderStub('params'),
      response: placeholderStub('response'),
    },
  },

  ['./helpers']: {
    isCheckedIn: placeholderStub('isCheckedIn'),
    getSessionFromCacheOrAPI: placeholderStub('getSessionFromCacheOrAPI'),
    processQRPassengerUpdates: placeholderStub('processQRPassengerUpdates'),
  },

  ['./api']: {
    retrieveSession: placeholderStub('retrieveSession'),
    getTrip: placeholderStub('getTrip'),
    ackDgTerms: placeholderStub('ackDgTerms'),
    reloadrip: placeholderStub('reloadTrip'),
    checkin: placeholderStub('checkin'),
    cancelCheckin: placeholderStub('cancelCheckin'),
    updateTravelDoc: placeholderStub('updateTravelDoc'),
  },
});

// describe('Localization libraries', ()=>{
//   let lib = require('../localization');
//     it('should convert input strings to the QR time format', async () => {
//       const convertedString = await lib.makeDateString('Tue Jul 16 2019 09:40');
//       // console.log(JSON.parse(convertedString.body).date)
//       assert.equal(2019, convertedString.substring(0,4));
//     });
// })

describe('CC API interface to QR REST services', () => {
  const params = sinon.stub();
  const body = sinon.stub();
  const response = sinon.stub();
  const tripConverter = sinon.stub();
  // const callRecordForCheckin = sinon.stub();

  const isPaxCheckedIn = sinon.stub();

  const retrieveSession = sinon.stub();
  const getTrip = sinon.stub();
  const ackDgTerms = sinon.stub();
  const checkin = sinon.stub();
  const cancelCheckin = sinon.stub();
  const reloadTrip = sinon.stub();
  const updateTravelDoc = sinon.stub();
  const updateEmergencyDoc = sinon.stub();
  const isCheckedIn = sinon.stub();
  const getSessionFromCacheOrAPI =sinon.stub();
  const processQRPassengerUpdates = sinon.stub();

  const versionConverter = require('@oneworld-digital/integration-utils').versionConverter;

  // Stub the versionConverter module functions
  const convertToV1Params = sinon.stub(versionConverter, 'convertToV1Params');
  const convertToV1Body = sinon.stub(versionConverter, 'convertToV1Body');

  const m = proxyquire(moduleName, createStubs({
    ['./api']: {
      retrieveSession,
      getTrip,
      ackDgTerms,
      checkin,
      cancelCheckin,
      reloadTrip,
      updateTravelDoc,
      updateEmergencyDoc
    },
    ['./utils']: {
      isPaxCheckedIn,
    },
    ['@oneworld-digital/integration-utils']: {
      request: {
        body,
        params,
        response,
      },
      versionConverter
    },
    ['./converter']: {
      execute: tripConverter,
    },
    ['./helpers']: {
      isCheckedIn: isCheckedIn,
      getSessionFromCacheOrAPI: getSessionFromCacheOrAPI,
      processQRPassengerUpdates: processQRPassengerUpdates,
    },
  }));

  describe('GET a record', () => {
    beforeEach(() => {
      body.reset();
      params.reset();
      response.reset();
      getTrip.reset();
      retrieveSession.reset();
      ackDgTerms.reset();
      checkin.reset();
    });

    it('should send a bad res if rloc is missing', () => {
      const qs = {
        familyName: 'foo',
      };

      params.returns(qs);

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();
      retrieveSession.throws(new Error('Missing parameters'));

      m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it('should send a bad res if familyName is missing', () => {
      const qs = {
        rloc: 'bar123',
      };

      retrieveSession.throws(new Error('Missing parameters'));
      params.returns(qs);

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();
      m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it('should return 500 if retrieveSession fails', async () => {
      const qs = {
        rloc: 'bar123',
        familyName: 'foo',
      };
      retrieveSession.throws(new Error());
      // getTrip.returns(require('./mocks/valid_getTrip'))

      params.returns(qs);

      tripConverter.returns({trip: {foo: 'bar'}});

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();
      await m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it('should return 500 if getTrip fails', async () => {
      const qs = {
        rloc: 'bar123',
        familyName: 'foo',
      };

      params.returns(qs);

      // downstream services
      retrieveSession.returns(require('./mocks/valid_retrieveTrip'));
      getTrip.throws(new Error('Failed to retrieve trip data'));

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();
      await m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });


    it('should send an OK res', async () => {
      // retrieveSession.returns(require('./mocks/valid_retrieveTrip'));
      getSessionFromCacheOrAPI.returns({session: {conversationToken: 'my_conversation_token', authorization: 'my_authorization_token'}, isTokenFound: {}})
      getTrip.returns(require('./mocks/valid_getTrip'));

      const qs = {
        rloc: 'bar123',
        familyName: 'foo',
      };

      params.returns(qs);

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();
      await m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  });

  describe('checkin function', () => {
    it('should send a bad res if any API call throws an error', async () => {
      const cb = sinon.spy();
  
      // params.returns({});
      // body.returns({ foo: 'bar' });
      convertToV1Params.returns({ familyName: 'abc', rloc: 'ABC' });
      convertToV1Body.returns({});
  
      retrieveSession.throws(new Error());
  
      await m.checkin({}, {}, cb);
  
      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });
  
    it('should send a bad res if dgterms are not ackd', async () => {
      const cb = sinon.spy();
      
      convertToV1Params.returns({ familyName: 'abc', rloc: 'ABC' });
      convertToV1Body.returns({});
      
      getTrip.returns({});
      // params.returns({});
      retrieveSession.returns({});
      // body.returns({ requirements: { acknowledgeDGTerms: false }, checkIn: true });
      ackDgTerms.returns({});
      checkin.returns({});
      tripConverter.returns({});
      
      const updatedPayload = {
        requirements: { acknowledgeDGTerms: false },
        checkIn: true,
      };
      
      await m.checkin(updatedPayload, {}, cb);
  
      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });
  
    it('should return a happy response if all the API calls succeed', async () => {
      const cb = sinon.spy();
  
      convertToV1Params.returns({ familyName: 'abc', rloc: 'ABC' });
      convertToV1Body.returns({});
      getTrip.returns({});
      retrieveSession.returns({});
      // body.returns({ requirements: { acknowledgeDGTerms: true }, checkIn: true });
      isPaxCheckedIn.returns(true);
      ackDgTerms.returns({});
      checkin.returns({});
      tripConverter.returns({});
      // params.returns({});
  
      await m.checkin({}, {}, cb);
  
      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  
    it('should return a happy response for a cancel checkin if all the API calls succeed', async () => {
      const cb = sinon.spy();
  
      getTrip.returns({});
      retrieveSession.returns({});
      // body.returns({ checkIn: false });
      ackDgTerms.returns({});
      cancelCheckin.returns({});
      reloadTrip.returns({});
      tripConverter.returns({});
      // params.returns({});
      
      const updatedPayload = {
        body: JSON.stringify({
          requirements: { acknowledgeDGTerms: true },
        }),
      };
      
      await m.checkin(updatedPayload, {}, cb);
  
      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  });


  describe('update travel docs', () => {
    beforeEach(() => {
      body.reset();
      params.reset();
      response.reset();
      getTrip.reset();
      retrieveSession.reset();
      ackDgTerms.reset();
      updateTravelDoc.reset();
      updateEmergencyDoc.reset();
      isCheckedIn.reset();
    });


    it('should send a bad res if any api call throws an error', async () => {
      const qs = {
        familyName: 'foo',
      };

      params.returns(qs);
      body.returns({foo: 'bar'});

      const cb = sinon.spy();

      retrieveSession.throws(new Error());

      await m.passenger({}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it('should send a bad res if dgterms are not ackd', async () => {
      const cb = sinon.spy();

      getTrip.returns({});
      params.returns({});
      retrieveSession.returns({});
      body.returns({requirements: {acknowledgeDGTerms: false}});
      ackDgTerms.returns({});
      updateTravelDoc.returns({});

      await m.passenger({body: JSON.stringify({
        requirements: {acknowledgeDGTerms: false},
      })}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it('should return a happy response if all the api calls succeed', async () => {
      const cb = sinon.spy();

      const updateRequest = {
        passengerRequest: {givenName: 'pax1'},
        flightRequests: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        },
        regulatoryInfo: {
          here: 'there'
        },
        recordRequest: {
          givenName: 'jesse',
          familyName: 'james',
          rloc: 'abc123',
          eTicketNumber: 'hesOurFav' // verify case on this field name
        }
      };
      getTrip.returns({trip: {mock: 'tripobject', passengers: 'here'}});
      retrieveSession.returns({});
      body.returns(updateRequest);
      ackDgTerms.returns({trip: {mock: 'tripobject'}});
      processQRPassengerUpdates.returns({})
      params.returns({});
      isCheckedIn.returns(false);

      await m.passenger({body: JSON.stringify(updateRequest)}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });


    it('should fail the update if passenger is already checked in', async () => {
      const cb = sinon.spy();

      const updateRequest = {
        passengerRequest: {givenName: 'pax1'},
        flightRequests: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        },
        regulatoryInfo: {
          here: 'there'
        },
        recordRequest: {
          givenName: 'jesse',
          familyName: 'james',
          rloc: 'abc123',
          eTicketNumber: 'hesOurFav' // verify case on this field name
        }
      };
      getTrip.returns({trip: {mock: 'tripobject', passengers: 'here'}});
      retrieveSession.returns({});
      body.returns({updateRequest});
      ackDgTerms.returns({trip: {mock: 'tripobject'}});
      updateTravelDoc.returns({trip: {passengers: [{givenName: "pax1"}]}});
      params.returns({});
      isCheckedIn.returns(true);

      await m.passenger({body: JSON.stringify({updateRequest})}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

  });


});
