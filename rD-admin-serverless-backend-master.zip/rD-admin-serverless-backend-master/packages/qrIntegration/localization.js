// console.log(process.env.NODE_PATH)
// const fs = require('fs');

// console.log(fs.readdirSync('/opt/nodejs'))


//localization
// const {
//   DateTimeFormatter,
//   ZonedDateTime,
//   LocalDateTime,
//   ZoneId,
//   ZoneOffset
// } = require('@js-joda/core');
// require('@js-joda/timezone');
// const {Locale} = require('@js-joda/locale/dist/prebuilt/en-us');

// exports.makeDateString = async (dateString) => {
//   const QR_DATE_FORMAT = 'EEE MMM d yyyy H:m'; // Wed Jul 17 2019 15:55
//   return LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern(QR_DATE_FORMAT).withLocale(Locale.US)).toString()
// }

// exports.handler = async (event, context) => {
//     let dateString = 'Tue Jul 16 2019 09:40';
//     // console.log(exports.makeDateString(dateString))
//     return {
//         "statusCode": 200,
//         "body": JSON.stringify({date:await exports.makeDateString(dateString)}),
//         "headers": {
//             "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
//             "Access-Control-Allow-Methods": "GET,OPTIONS",
//             "Access-Control-Allow-Origin": "*",
//             "Content-Type":"application/json"
//         }
//     }
// }
