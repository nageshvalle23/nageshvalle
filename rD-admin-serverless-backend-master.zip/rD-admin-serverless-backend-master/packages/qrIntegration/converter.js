const dlv = require('dlv');
const paths = require('./paths');
const dateUtil = require('./dateUtils');
const helpers = require('./helpers');
const utils = require("./utils");
const {QRToCCMapping} = require('./map');

exports.execute = function (trip, ccPaxs, ccFlights, bp, isRecord=false) {
  let flights = extractFlights(trip);

  let paxs = extractPaxs(trip);
  paxs = isRecord ?  paxs : utils.validateAndExtractCCPaxs(trip, paxs, ccPaxs)

  let record = {
    pnr: {
      rloc: trip.tripReference,
      flights: Object.keys(isRecord ? flights: utils.validateAndExtractCCFlights(flights, ccFlights)).map((id) => qrDataToCcFlight(flights[id])),
      passengers: Object.keys(paxs).map((id) => {
        const pax = paxs[id];
        const paxId = dlv(pax, paths.PAX_ID);
        let qrPaxCoupons = extractPaxCoupons(trip, paxId);
        return qrDataToCcPax(pax, qrPaxCoupons, flights, bp, ccFlights);
      }),
    },
  };

  const {pnr} = record;

  if (!pnr.rloc || !pnr.passengers.length || !pnr.flights.length) {
    throw new Error('Failed to produce a valid record');
  }

  return record;
};

exports.convertQrToCCMapping = function convertQrToCCMapping(qrFields, SeeAgentDocs) {
  const ccDocuments = [];

  for (let qrField of qrFields) {
    for (let mappingCCDoc in QRToCCMapping) {
      if (typeof qrField === 'object' && qrField.hasOwnProperty(mappingCCDoc) && !SeeAgentDocs.includes(mappingCCDoc) &&!ccDocuments.includes(mappingCCDoc)) {
        ccDocuments.push(mappingCCDoc);
      } else if (QRToCCMapping[mappingCCDoc].hasOwnProperty(qrField) && !ccDocuments.includes(mappingCCDoc) && !SeeAgentDocs.includes(mappingCCDoc)) {
        ccDocuments.push(mappingCCDoc);
      }
    }
  }
  
  return ccDocuments;
}

// CONVERT
function qrDataToCcFlight(qrFlight) {
  return {
      origin: dlv(qrFlight, paths.ORIGIN),
      destination: dlv(qrFlight, paths.DEST),
      flightNumber: dlv(qrFlight, paths.FLIGHT_NUMBER),
      carrier: dlv(qrFlight, paths.CARRIER),
      date: dateUtil.toLookupDate(new Date(qrFlight.departureDateScheduled)),
    };
}

function qrDataToCcPax(qrPax, qrPaxCoupons, qrFlights, bp, ccFlights) {
  return {
    familyName: qrPax.lastName,
    givenName: qrPax.firstName,
    title: qrPax.title,
    ageCategory: qrPax.passengerType,
    coupons: qrPaxCoupons.map((c) => qrDataToCcCoupon(c, qrFlights, bp, ccFlights)),
  };
}


function qrDataToCcCoupon(qrCoupon, qrFlights, bp, ccFlights) {
  
  const flight = qrFlights[dlv(qrCoupon, paths.FLIGHT_ID)];
  const isCheckedIn = helpers.isCouponCheckedIn(qrCoupon);
  const isCheckInInhibited = helpers.isCouponCheckInInhibited(qrCoupon);

  const coupon = {
    origin: dlv(flight, paths.ORIGIN),
    eTicketNumber: dlv(qrCoupon, paths.TICKET_NUMBER),
    destination: dlv(flight, paths.DEST),
    flightNumber: dlv(flight, paths.FLIGHT_NUMBER),
    carrier: dlv(flight, paths.CARRIER),
    isCheckedIn: isCheckedIn,
    isCheckInInhibited: isCheckInInhibited,
    departureDateTime: dateUtil.toCcDateTime(new Date(flight.departureDateScheduled)),
    boardingPass: null,
  };

  //Validation for CC flights to generate bp
  if (isCheckedIn && bp) {
    ccFlights.forEach((ccFlight) => {
      let uniqueIdentifier = `${ccFlight.carrier}${ccFlight.flightNumber}${ccFlight.date.replace(/-/g, '')}${ccFlight.origin}${ccFlight.destination}`;
      //generate bp based on cc request - if we send 1 segment, generate bp for that segment
      if (flight.flightIdentifier.uniqueIdentifier === uniqueIdentifier) {
        coupon.boardingPass = qrDataToCcBp(qrCoupon, flight);
      }
    })
  }
  else if (isCheckedIn) {
    coupon.boardingPass = qrDataToCcBp(qrCoupon, flight);
  }

  return coupon;
}

function qrDataToCcBp(qrCoupon, qrFlight) {
  return {
    barcodeData: dlv(qrCoupon, ['checkInInfo', 'barCode'].join('.')) || '',
    qrCodeData: '',
    seatNumber: dlv(qrCoupon, ['seatPreference', 'assignedSeat'].join('.')),
    passengerClass: qrCoupon.travelCabinClass,
    boardingTime: dateUtil.toCcDateTime(new Date(qrFlight.boardingOpenTime)),
    eTicketNumber: dlv(qrCoupon, ['couponDetail', 'eticketNumber'].join('.')),
    frequentFlierNumber: '',
    sequenceNumber: '',
    iOSPassbookFile: '',
    gate: '',
    terminal: '',
    securityNumber: dlv(qrCoupon, ['checkInInfo', 'securityNumber'].join('.')),
    boardingGroup: '',
    allowTSA: '',
    allowFastTrack: '',
  };
}

// EXTRACT
function extractFlights(trip) {
  return trip.journeys.reduce((source, j) => {
    j.flightList.forEach((f) => {
      // save the source because it's used later for coupons
      source[f.flightIdentifier.uniqueIdentifier] = f;
    });
    return source;
  }, {});
}

function extractPaxs(trip) {
  return trip.passengers.reduce((source, pax) => {
    source[dlv(pax, paths.PAX_ID)] = pax;
    return source;
  }, {});
}

function extractPaxCoupons(trip, paxId) {
  return trip.passengerFlightMapping.filter((mapping) => {
    return dlv(mapping, paths.FLIGHT_PAX_ID) === paxId;
  });
}
