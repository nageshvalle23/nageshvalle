const {
  DynamoDBClient,
  PutItemCommand,
  GetItemCommand,
  UpdateItemCommand,
  DeleteItemCommand
} = require("@aws-sdk/client-dynamodb");
const dynamoDBClient = new DynamoDBClient({ region: process.env.AWS_REGION });

const { unmarshall, marshall } = require("@aws-sdk/util-dynamodb");
require('dotenv').config();
const STAGE = process.env.stage || "stage";
const ttl = process.env.QR_CACHE_EXPIRY || 10;

exports.insertPnr = async (id, session, passengers = []) => {
  const { conversationToken, authorization } = session;

  const item = {
    PNR: id,
    Session: {
      conversationToken,
      authorization,
      passengers: passengers.map((passenger) => ({
        familyName: passenger.familyName,
        givenName: passenger.givenName,
        eTicketNumber: passenger.eTicketNumber,
      })),
    },
    record_life: Math.floor(Date.now() / 1000) + (ttl * 60), // 5 minutes in seconds
  };

  const params = {
    TableName: `qr-token-cache-${STAGE}`,
    Item: marshall(item),
  };

  try {
    const data = await dynamoDBClient.send(new PutItemCommand(params));
    console.log('Inserted to DB');
    console.log(JSON.stringify(data, null, 2));
  } catch (e) {
    console.log('Error while inserting the pnr: ', e);
  }
};

exports.getPnr = async (id) => {
  const params = {
    TableName: `qr-token-cache-${STAGE}`,
    Key: marshall({
      PNR: id,
    }),
  };

  try {
    const data = await dynamoDBClient.send(new GetItemCommand(params));

    if ( data.Item ) {
      const resp = unmarshall( data.Item );
      const curTime = Math.floor( Date.now() / 1000 )

      /* delete the expired records */
      if ( curTime >= resp.record_life ) {
          const command2 = new DeleteItemCommand( {
              TableName: `qr-token-cache-${ STAGE }`,
              Key: marshall({
                PNR: id,
              }),
          } );

          await dynamoDBClient.send( command2 );
          console.log('----DELETED EXPIRED RECORD----: ',id,resp.record_life)
      } else {
        console.log('Item returned from DB');
        console.log(JSON.stringify(resp, null, 2))
        return resp;
      }
    }
    return null
  } catch (e) {
    console.log("Error while retrieving item from Cache", e);
  }
};

exports.updatePassengers = async (id, paxs) => {
  if (!Array.isArray(paxs)) {
    console.error("paxs is not an array or is undefined");
    return;
  }

  const params = {
    TableName: `qr-token-cache-${STAGE}`,
    Key: marshall({
      PNR: id,
    }),
    UpdateExpression: 'SET #sessionAttr.#passengersAttr = :newPax, record_life = :ttlTime',
    ExpressionAttributeNames: {
      '#sessionAttr': 'Session',
      '#passengersAttr': 'passengers',
    },
    ExpressionAttributeValues: marshall({
      ':newPax': paxs,
      ':ttlTime': Math.floor(Date.now() / 1000) + (ttl * 60), //5 minutes
    }),
    ReturnValues: "ALL_NEW",
  };

  try {
    const data = await dynamoDBClient.send(new UpdateItemCommand(params));
    console.log('Updating passengers into the Cache');
    console.log(JSON.stringify(unmarshall(data.Attributes), null, 2))
  } catch (e) {
    console.error('Error while Updating passengers into Cache: ', e);
  }
};