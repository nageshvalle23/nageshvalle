const flifo = require('./api');
const converter = require('./converter')
const run = async () => {
  try {
    const res  = await flifo('2019-12-03', '773')
    console.log(JSON.stringify(res, null, '  '), '<<<<<<\n\n\n\n\n\n')
    console.log(JSON.stringify(converter(res), null, '  '))
  } catch (err) {
    console.log(err)
  }
}

run()
