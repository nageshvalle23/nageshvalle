const QR_DATE_FORMAT = 'EEE MMM d yyyy H:m'; // Wed Jul 17 2019 15:55

const {
  DateTimeFormatter,
  ZonedDateTime,
  LocalDateTime,
  ZoneId,
  ZoneOffset
} = require('@js-joda/core');
require('@js-joda/timezone');

const statusMap = {
  ARRIVED: 'ARRIVED',
  SCHEDULED: 'SCHEDULED',
  INFLIGHT: 'DEPARTED',
  DEPARTED: 'DEPARTED',
  LANDED: 'LANDED',
  DELAYED: 'DELAYED',
  CANCELLED: 'CANCELLED',
  REROUTED: 'REROUTED',
  RESCHEDULED: 'RESCHEDULED',
  DIVERTED: 'DIVERTED'
}

const monthMap = {
  Jan: 1,
  Feb: 2,
  Mar: 3,
  Apr: 4,
  May: 5,
  Jun: 6,
  Jul: 7,
  Aug: 8,
  Sep: 9,
  Oct: 10,
  Nov: 11,
  Dec: 12
}

// const makeDateString = (qrDate, utcOffset) => {
//   if (typeof qrDate === 'undefined') {
//     return null;
//   }

//   const dateSegs = qrDate.split(' ');
//   const year = dateSegs[3];
//   const month = monthMap[dateSegs[1]];
//   const day = dateSegs[2];

//   const timeSegs = dateSegs[4].split(':');
//   const hour = timeSegs[0];
//   const min = timeSegs[1];

//   const display = LocalDateTime.of(year, month, day, hour, min).toString();
//   return utcOffset ? display + utcOffset : display + 'Z';
// }

const makeDateString = (qrDate, utcOffset) => {
  if (typeof qrDate === 'undefined') {
    return null;
  }

  const dateSegs = qrDate.split(' ');
  const year = dateSegs[3];
  const month = monthMap[dateSegs[1]];
  const day = dateSegs[2];

  const timeSegs = dateSegs[4].split(':');
  const hour = timeSegs[0];
  const min = timeSegs[1];
  const sec = timeSegs[2];

  const display = LocalDateTime.of(year, month, day, hour, min, sec).toString();
  return utcOffset ? display + utcOffset : display + 'Z';
}

const makeUTCDateString = (qrDate) => makeDateString(qrDate);

module.exports = function (qrFlifo) {
  if (typeof qrFlifo.flights === 'undefined') {
    return [];
  }

  const flight = makeFlight();

  qrFlifo.flights.forEach((s, i) => {
    const sector = makeSector();

    flight.flightNumber = s.flightNumber;
    flight.carrierCode = s.carrier.carrier;

    sector.sourceStatus = s.flightStatus;
    sector.status = statusMap[s.flightStatus];

    const arrivalStation = qrFlifo.stationList.find(
      station => station.iataCode === s.arrivalStation.airportCode)

    const departureStation = qrFlifo.stationList.find(
      station => station.iataCode === s.departureStation.airportCode)

    sector.departure.terminal = departureStation.terminal || null;
    sector.departure.gate = departureStation.gate || null;
    sector.departure.airportCode = s.departureStation.airportCode;
    sector.departure.airportName = departureStation.airport;
    sector.departure.cityName = departureStation.city;
    sector.departure.countryId = departureStation.countryCode;

    sector.arrival.terminal = arrivalStation.terminal || null;
    sector.arrival.gate = arrivalStation.gate || null;
    sector.arrival.airportCode = s.arrivalStation.airportCode;
    sector.arrival.airportName = arrivalStation.airport;
    sector.arrival.cityName = arrivalStation.city;
    sector.arrival.countryId = arrivalStation.countryCode;

    sector.arrival = Object.assign(sector.arrival, makeArrivalDateTimes(s))
    sector.departure = Object.assign(sector.departure, makeDepartureDateTimes(s))


    flight.sectors.push(sector);
  })

  flight.summary = makeSummary(flight.sectors);

  return flight;
}

const makeSummary = (sectors) => {
  const summary = {
    departure: {
      at: {
        utc: null,
        local: null,
        type: null // estimated, or actual
      }
    },
    arrival: {
      at: {
        utc: null,
        local: null,
        type: null // estimated, or actual
      }
    },
    notice: false
  }

  sectors.forEach(s => {
    if (['DIVERTED', 'CANCELLED', 'REROUTED', 'RESCHEDULED'].indexOf(s.flightStatus) !== -1) {
      flight.summary.notice = true;
    }

    if (s.departure.actual.local !== null) {
      summary.departure.at.local = s.departure.actual.local;
      summary.departure.at.utc = s.departure.actual.utc;
      summary.departure.at.type = 'actual';
    } else if (s.departure.estimated.local !== null) {
      summary.departure.at.local = s.departure.estimated.local;
      summary.departure.at.utc = s.departure.estimated.utc;
      summary.departure.at.type = 'estimated';
    } else if (s.departure.scheduled.local !== null) {
      summary.departure.at.local = s.departure.scheduled.local;
      summary.departure.at.utc = s.departure.scheduled.utc;
      summary.departure.at.type = 'scheduled';
    }

    if (s.arrival.actual.local !== null) {
      summary.arrival.at.local = s.arrival.actual.local;
      summary.arrival.at.utc = s.arrival.actual.utc;
      summary.arrival.at.type = 'actual';
    } else if (s.arrival.estimated.local !== null) {
      summary.arrival.at.local = s.arrival.estimated.local;
      summary.arrival.at.utc = s.arrival.estimated.utc;
      summary.arrival.at.type = 'estimated';
    } else if (s.arrival.scheduled.local !== null) {
      summary.arrival.at.local = s.arrival.scheduled.local;
      summary.arrival.at.utc = s.arrival.scheduled.utc;
      summary.arrival.at.type = 'scheduled';
    }
  });

  return summary;
}

const makeDepartureDateTimes = (qrFlight) => makeDateTimes('departure', qrFlight);
const makeArrivalDateTimes = (qrFlight) => makeDateTimes('arrival', qrFlight);

const makeDateTimes = (phaseName, qrFlight) => {
  const phaseDateTimes = {
    scheduled: {
      local: null,
      utc: null,
      source: null
    },
    estimated: {
      local: null,
      utc: null,
      source: null
    },
    actual: {
      local: null,
      utc: null,
      source: null
    }
  };

  // scheduled
  const scheduledLocal = qrFlight[phaseName + 'DateScheduled'];
  const scheduledUTC = qrFlight[phaseName + 'DateScheduledUTC'];

  phaseDateTimes.scheduled.local = makeDateString(scheduledLocal, calculateTzOffset(scheduledLocal, scheduledUTC));
  phaseDateTimes.scheduled.utc = makeUTCDateString(scheduledUTC);
  phaseDateTimes.scheduled.source = 'QR';

  // estimated
  const estimatedLocal = qrFlight[phaseName + 'DateEstimated'];
  const estimatedUTC = qrFlight[phaseName + 'DateEstimatedUTC'];

  phaseDateTimes.estimated.local = makeDateString(estimatedLocal, calculateTzOffset(estimatedLocal, estimatedUTC));
  phaseDateTimes.estimated.utc = makeUTCDateString(estimatedUTC);
  phaseDateTimes.estimated.source = 'QR';

  // actual
  const actualLocal = qrFlight[phaseName + 'DateActual']
  const actualUTC = qrFlight[phaseName + 'DateActualUTC']

  phaseDateTimes.actual.local = makeDateString(actualLocal, calculateTzOffset(actualLocal, actualUTC));
  phaseDateTimes.actual.utc = makeUTCDateString(actualUTC);
  phaseDateTimes.actual.source = 'QR';

  return phaseDateTimes;
}

const calculateTzOffset = (local, utc) => {
  const localDate = new Date(local);
  const utcDate = new Date(utc);

  let diff = localDate.getTime() - utcDate.getTime();
  diff /= 1000; // ms -> seconds

  let hours = diff / (60 * 60) // sec -> hr (60 sec/min * 60 min/hr)
  hours = (hours >= 0) ? Math.floor(hours) : Math.ceil(hours);
  hours = (hours > 0) ? `+${hours.toString().padStart(2, '0')}` : `-${Math.abs(hours).toString().padStart(2, '0')}`;

  const minutes = Math.abs((diff / 60) % 60).toString().padStart(2, '0')

  const offset = `${hours.toString().padStart(2, '0')}:${minutes}`;
  return (offset !== '-00:00') ? offset : '+00:00';
}

const makeFlight = () => (
  {
    flightNumber: null,
    carrierCode: null,
    sectors: [],
    summary: {
      departure: {
        at: {
          utc: null,
          local: null,
          type: null // estimated, or actual
        }
      },
      arrival: {
        at: {
          utc: null,
          local: null,
          type: null // estimated, or actual
        }
      },
      notice: false
    }
  });

const makeSector = () => ({
  codeShares: [],
  status: 'UNKNOWN',
  sourceStatus: null,
  departure: {
    airportCode: null,
    airportName: null,
    cityName: null,
    countryId: null,
    terminal: null,
    gate: null,

    scheduled: {
      local: null,
      utc: null,
      source: null
    },
    estimated: {
      local: null,
      utc: null,
      source: null
    },
    actual: {
      local: null,
      utc: null,
      source: null
    }
  },
  arrival: {
    airportCode: null,
    airportName: null,
    cityName: null,
    countryId: null,
    terminal: null,
    gate: null,
    scheduled: {
      local: null,
      utc: null,
      source: null
    },
    estimated: {
      local: null,
      utc: null,
      source: null
    },
    actual: {
      local: null,
      utc: null,
      source: null
    }
  }
});
