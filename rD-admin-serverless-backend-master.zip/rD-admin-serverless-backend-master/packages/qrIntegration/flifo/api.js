const QR_FLIFO_API_URL = process.env.QR_FLIFO_API_URL || 'https://qoresit.qatarairways.com.qa/fltstatus-services/flight/getStatus';
const rp = require('request-promise-native');

module.exports = function (date, flightNumber) {
  // Flight request format:
  const flifoReq = {
    scheduledDate: date,
    flightNumber: flightNumber.padStart(3, '0')
  }

  return _gatherAndReportErrors(rp.post({
    url: QR_FLIFO_API_URL,
    body: flifoReq,
    headers: {
      'Content-Type': 'application/json'
    },
    json: true
  }));
}

async function _gatherAndReportErrors(promisedApiCall) {
  const res = await promisedApiCall;

  const body = res.body || res; // api call does not always resolve with full response

  const errors = body.errors;

  if (Array.isArray(errors) && errors.length > 0) {
    console.error(`Error calling ${promisedApiCall.path}: ${JSON.stringify(errors, null, 2)}`);
    const qrError = errors[0];

    const err = new Error('QR Error');
    err.CARRIER_ERROR_CODE = qrError.errorCode;
    err.CARRIER_ERROR_MESSAGE = qrError.type;
    throw err;
  }

  if (body.result && body.result.length === 0) {
    throw new Error('No Flights');
  }

  return res;
}

