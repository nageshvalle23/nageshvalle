const uuid = require('uuid/v1');
require('dotenv').config()
const { response, body, params } = require('@oneworld-digital/integration-utils').request;
const {
  isV2Request,
  convertToV1Body,
  convertToV1Params,
  v1RecordToV2Record
} = require("@oneworld-digital/integration-utils").versionConverter;
const {convertToV2Body, convertToV2Params} =  require("./utility");
const api = require('./api');
const db = require('./db');

exports.getPnrs = async (event, context, cb) => {
  try {
    cb(null, response(200, await api.getPnrs()));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.createPnr = async (event, context, cb) => {
  try {
    const { numPax, targetCarrier, docs } = body(event);

    const pnr = await api.createPnr(targetCarrier, numPax, docs);

    cb(null, response(200, pnr));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.getPnr = async (event, context, cb) => {
  try {
    const {rloc} = event.pathParameters;
    cb(null, response(200, await api.getPnr(rloc)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.resetPnr = async (event, context, cb) => {
  try {
    const {rloc} = event.pathParameters;
    cb(null, response(200, await api.resetPnr(rloc)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.deletePnr = async (event, context, cb) => {
  try {
    const {rloc} = event.pathParameters;
    cb(null, response(200, await api.deletePnr(rloc)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

// exports.record = async (event, context, cb) => {
//   try {
//     const isV2 = isV2Request(event);

//     const { familyName, givenName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);
    

//     const record = await api.getRecord(rloc, familyName, givenName);

//     cb(null, response(200, isV2 ? v1RecordToV2Record(record) : record));
//   } 
//   catch (err) {
//     return _handleErrors(err, cb);
//   }
// };

exports.record = async (event, context, cb) => {
  const docs = ['PASSPORT', 'VISA', 'DESINATION_ADDRESS', 'RESIDENT_ADDRESS'];

  try {
    const isV2 = isV2Request(event);

    const { familyName, givenName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);
    
    const clientCarrier = event.headers["x-client-carrier"];
    console.log('Client carrier: ', clientCarrier);

    // const clientCarrier = 'MH';
    const auth_token = event.headers['x-api-key'];

    let record;

    if (clientCarrier === 'MH') {
      const pnr = await db.getPnr(rloc);

      if (pnr) {
        console.log('PNR from DB: ', JSON.stringify(pnr));
        record = {pnr: pnr.info}
      }
      else {
        record = await api.get1ARecord(rloc, familyName, givenName, clientCarrier, auth_token);

        const pnr = record.pnr
    
        // const updatedPax = pnr.passengers.map((pax) => {
        //   pax['givenName'] = pax['firstName']
        //   pax['familyName'] = pax['lastName']
        //   delete pax['firstName']
        //   delete pax['lastName']
        //   return pax
        // })
        // pnr.passengers = updatedPax;
    
        const props = {
          requirements: pnr.passengers
                           .map(p =>
                             docs
                               .reduce((acc, doc) =>
                                 Object.assign(acc,
                                               {[doc]: false}),
                                       {}))
        };
        
  
        await db.createPnr(pnr.rloc, pnr, props);
        console.log('After createPnr - Added PNR to db');
  
        record.pnr.flights = record.pnr.flights.map((flight) => {
          flight['carrier'] = flight.carrierCode;
          delete flight['carrierCode']
          return flight
        })
        
        record.pnr.passengers.map((pax) => {
          return pax.coupons.map((coupon) => {
            coupon['carrier'] = coupon.carrierCode;
            delete coupon['carrierCode'];
            return coupon
          })
        })
        
        console.log('Updated Record: ', JSON.stringify(record));
      }
    }
    else {
      record = await api.getRecord(rloc, familyName, givenName);
    }

    cb(null, response(200, isV2 ? v1RecordToV2Record(record) : record));
  } 
  catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.eligibility = async (event, context, cb) => {
  try {
    const { recordRequest, passengerRequest } = body(event);
    cb(null,
       response(200,
                await api.getPaxEligibility(recordRequest, passengerRequest)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.multieligibility = async (event, context, cb) => {
  try {
    const { recordRequest, passengerRequests } = body(event);
    let isMultiEligibility = true;
    let multiEligibilityResponse = [];

    for (let eachPax of passengerRequests) {
      const paxEligibilityResponse = await api.getPaxEligibility(
        recordRequest,
        eachPax,
        isMultiEligibility
      );
      multiEligibilityResponse.push(paxEligibilityResponse);
    }

    cb(null, response(200, multiEligibilityResponse));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.checkin = async (event, context, cb) => {
  try {
    const isV2 = isV2Request(event);

    const { familyName, givenName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    const { flightLookups, passengerLookups, requirements, checkIn } = isV2 ?
      convertToV1Body(body(event)) : body(event);

    const record = await api.checkinRecord(
      { rloc, familyName, givenName },
      passengerLookups,
      flightLookups,
      requirements,
      checkIn
    );

    cb(null, response(200, isV2 ? v1RecordToV2Record(record) : record));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.multicheckin = async (event, context, cb) => {
  try {

    const { familyName, givenName, rloc } = convertToV2Params(body(event))

    const { flightLookups, passengerLookups, requirements, checkIn } = convertToV2Body(body(event));

    const record = await api.checkinRecord(
      { rloc, familyName, givenName },
      passengerLookups,
      flightLookups,
      requirements,
      checkIn
    );

    cb(null, response(200, v1RecordToV2Record(record)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.update = async (event, context, cb) => {
  try {
    const { recordRequest, passengerRequest, flightsRequest, document } = body(event);

    cb(null, response(200,
                      await api.updatePax(recordRequest,
                                          passengerRequest,
                                          document)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};


exports.boardingpass = async (event, context, cb) => {
  try {
    const isV2 = isV2Request(event);
    const { familyName, givenName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    const { flightLookups, passengerLookups } = isV2 ?
      convertToV1Body(body(event)) : body(event);

    const record = await api.getBoardingPasses({ rloc, familyName, givenName }, passengerLookups, flightLookups);

    cb(null, response(200, isV2 ? v1RecordToV2Record(record) : record));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.multiboardingpass = async (event, context, cb) => {
  try {
    const { familyName, givenName, rloc } = convertToV2Params(body(event))
    const { flightLookups, passengerLookups } = convertToV2Body(body(event));

    const record = await api.getBoardingPasses({ rloc, familyName, givenName }, passengerLookups, flightLookups);

    cb(null, response(200, v1RecordToV2Record(record)));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

function _handleErrors(err, cb) {
  console.log(err);
  const body = {
    id: uuid(),
    message: err.message,
    type : 'Internal',
    code: '500',
  };

  let responseCode;

  // handling all OG errors as Internal - as opposed to Carrier Errors
  responseCode = 500;

  console.log(`Could not satisfy request ${JSON.stringify(body, null, 2)}`);
  return cb(null, response(responseCode, body));
}
