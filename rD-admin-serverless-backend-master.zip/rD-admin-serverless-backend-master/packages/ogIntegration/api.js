const { date } = require("@oneworld-digital/integration-utils");
const {
  getPaxsByPaxLookups,
  getFlightsByFlightLookups,
  isPaxMatch,
  findPax,
  findPaxIndex,
  findCoupon,
} = require('./helpers');

const { getPnr, getPnrs, createPnr, deletePnr, setPnrProps, setPnrInfo, setPnrBp, getPnrBp } = require('./db');

const { genBp, genPnr } = require('./generator');
const axios = require('axios');

exports.getRecord = async function getRecord(rloc, familyName, givenName) {
  if (!rloc || !familyName || !givenName) {
    throw new Error('GetRecord: Missing required params');
  }
  const pnr = (await getPnr(rloc)).info;

  if (!pnr) {
    throw new Error('GetRecord: No record found with provided lookup');
  }

  if (isPaxMatch(pnr.passengers, familyName, givenName)) {
    return {
      pnr,
      lookup: {
        rloc,
        familyName,
        givenName,
        targetAirlineCode: 'OG',
      },
    };
  } else {
    throw new Error('GetRecord: No record found with provided lookup');
  }
};

exports.get1ARecord = async function get1ARecord(rloc, familyName, givenName, carrier, token) {
  const url = 'https://stage.rd-cc-api.carrierconnect.co/1a/v2/record';
  const body = {
    recordRequest: {
      familyName,
      givenName,
      rloc,
      carrierCode: carrier
    }
  };

  try{
    const response = await axios.post(url, body, {
      headers: {
        'x-api-key': `${token}`
        // Authorization: `Bearer ${process.env.MH_AUTH_TOKEN}`
      }
    });

    // Handle the response here
    console.log('MH Record response: ', JSON.stringify(response.data)); 
    return response.data 
  }
  catch(err) {
    console.log('Iam at Error: ', err);
    throw err;
  }
}

exports.getPnr = async function (rloc) {
  return getPnr(rloc);
};


exports.getPnrs = async function () {
  return getPnrs();
};

exports.createPnr = async function (targetCarrier, numPax, docs) {
  const pnr = genPnr(targetCarrier, numPax);

  const props = {
    requirements: pnr.passengers
                     .map(p =>
                       docs
                         .reduce((acc, doc) =>
                           Object.assign(acc,
                                         {[doc]: false}),
                                 {}))
  };

  await createPnr(pnr.rloc, pnr, props);

  return getPnr(pnr.rloc, false);
};

exports.resetPnr = async function (rloc) {
  const pnr = await getPnr(rloc);

  pnr.props.requirements = pnr.props.requirements
    .map(p => Object.keys(p)
         .reduce((acc, k) => {
           return Object.assign(acc, {[k]: false});
         }, {}));

  pnr.info.passengers = pnr.info.passengers.map(pax => {
    pax.coupons = pax.coupons.map(c => {
      return Object.assign(c, {isCheckedIn: false});
    });
    return pax;
  });

  await setPnrInfo(rloc, pnr.info);
  await setPnrProps(rloc, pnr.props);

  return true;
};

exports.deletePnr = async function (rloc) {
  await deletePnr(rloc);
  return true;
};


exports.updatePax = async function(recordRequest, passengerRequest, update) {
  // Updates required documents list, does not retain actual data just existence of update
  // TODO: could store country of residence to determine further rules validations
  const { props, info: pnr } = await getPnr(recordRequest.rloc, false);

  const paxIndex = findPaxIndex(pnr.passengers, passengerRequest.familyName, passengerRequest.givenName);
  const requiredDocs = await getRequiredDocs(pnr.flights);

  let requirements = {};
  requiredDocs.forEach(req => requirements[req] = props.requirements[paxIndex][req] || false);

  // TODO: should this throw an error if false?
  for (let document of update) {
    if (requiredDocs.includes(document.type)) {
      requirements[document.type] = true;
    };
  }

  // set updated requirements to PNR
  props.requirements[paxIndex] = requirements;
  await setPnrProps(recordRequest.rloc, props)

  return { 
    requiredDocuments: Object.keys(props.requirements[paxIndex])
    .filter(r => !props.requirements[paxIndex][r]),
    populatedDocuments: Object.keys(props.requirements[paxIndex])
    .filter(r => props.requirements[paxIndex][r])
  };

};

const getRequiredDocs = async function (flights) {
  // this is essentially a stub
  // TODO: use api to look up destination countries by airport code
  // TODO: use db to dynamically assign country rules


  const airportCodes = {
    'MAD': ["PASSPORT", "VISA"],
    'KUL': ["PASSPORT", "DESTINATION_ADDRESS", "RESIDENT_ADDRESS", "VISA"],
    'JFK': ["PASSPORT", "DESTINATION_ADDRESS", "RESIDENT_ADDRESS"],
    'LHR': ["PASSPORT", "RESIDENT_ADDRESS"]
  }

  const requiredDocs = [
    [],
    ["PASSPORT", "VISA"],
    ["PASSPORT", "VISA", "EMERGENCY_CONTACT"],
    ["PASSPORT", "DESTINATION_ADDRESS", "RESIDENT_ADDRESS"],
    ["PASSPORT", "DESTINATION_ADDRESS", "RESIDENT_ADDRESS", "EMERGENCY_CONTACT"]

  ];

  const destination = flights[flights.length - 1].destination.toUpperCase();

  if (Object.keys(airportCodes).includes(destination)) {
    console.log('Required docs are:', airportCodes[destination]);
    return airportCodes[destination];
  }
  else {
  // arbitrarily selecting one of three possible types
  const reqType = destination.charCodeAt(0) % 3;
  return requiredDocs[reqType];
  }

};

exports.getPaxEligibility = async (
  recordRequest,
  passengerRequest,
  isMultiEligibility
) => {
  const { props, info: pnr } = await getPnr(recordRequest.rloc, false);
  // console.log('MH record response from DB: ', JSON.stringify(pnr));
  
  const requiredDocs = await getRequiredDocs(pnr.flights);

  const paxIndex = findPaxIndex(
    pnr.passengers,
    passengerRequest.familyName,
    passengerRequest.givenName
  );

  let requirements = {};
  requiredDocs.forEach(req => requirements[req] = props.requirements[paxIndex][req] || false);
  // set updated requirements to PNR
  props.requirements[paxIndex] = requirements;
  await setPnrProps(recordRequest.rloc, props)

  let responseObj = {
    requiredDocuments: Object.keys(props.requirements[paxIndex]).filter(
      (r) => !props.requirements[paxIndex][r]
    ),
    populatedDocuments: Object.keys(props.requirements[paxIndex]).filter(
      (r) => props.requirements[paxIndex][r]
    ),
  };

  if (isMultiEligibility) {
    responseObj.familyName = passengerRequest.familyName,
    responseObj.givenName = passengerRequest.givenName,
    responseObj.eTicketNumber = passengerRequest.eTicketNumber
  }

  return responseObj;
  // return {
  //   familyName: passengerRequest.familyName,
  //   givenName: passengerRequest.givenName,
  //   eTicketNumber: passengerRequest.eTicketNumber,
  // };
};

exports.checkinRecord = async function(lookup, paxLookups, flightLookups, reqs, checkInFlag) {
  const { rloc, familyName, givenName } = lookup;

  if (!rloc || !familyName || !givenName || paxLookups.length == 0 || flightLookups.length == 0) {
    throw new Error('CheckInRecord: Missing required params');
  }

  const pnr = await getPnr(rloc);

  if (!pnr.info) {
    throw new Error('CheckInRecord: No record found with provided lookup');
  }

  const paxs = getPaxsByPaxLookups(pnr.info, paxLookups);
  const flights = getFlightsByFlightLookups(pnr.info, flightLookups);

  if (!reqs.acknowledgeDGTerms) {
    throw new Error('CheckInRecord: Must accept DG terms');
  }

  // Validating eligibility requirements
  // This is V2 functionality so only referencing first passenger in request

  for (let paxLookup of paxLookups) {
    const paxIndex = pnr.info.passengers.findIndex(
      p =>
        p.familyName.toUpperCase() === paxLookup.familyName.toUpperCase() &&
        p.givenName.toUpperCase() === paxLookup.givenName.toUpperCase()
    );
    const paxReqs = pnr.props && pnr.props.requirements[paxIndex] ? pnr.props.requirements[paxIndex] : {};
    if (Object.values(paxReqs).some(r => r === false)) {
      throw new Error('CheckInRecord: All required passenger documents must be present.');
    };

  }
  
  paxs.forEach(pax => {
    changePaxFlightStatus(pnr.info, pax, flights, checkInFlag);
  });

  await setPnrInfo(rloc, pnr.info);
  const newPnr = await getPnr(rloc);

  // retrieve boardingpass
  // TODO  delete BP for uncheck in?
  // TODO: now I understand what amy was talking about re: deleting bp on uncheckin
  // this is manipulating the underlying object passed by reference
  // if (checkInFlag) {
  //   const bpResult = await boardingPassProcessing(rloc, paxs, false);
  // }

  return {
    pnr: newPnr.info,
    lookup: {
      rloc,
      familyName,
      givenName,
      targetAirlineCode: 'OG',
    },
  };
};

exports.getBoardingPasses = async function (lookup, paxLookups, flightLookups) {
  const { rloc, familyName, givenName } = lookup;

  if (!rloc || !familyName || !givenName || paxLookups.length == 0 || flightLookups.length == 0) {
    throw new Error('GetBoardingPass: Missing required params');
  }

  const pnr = (await getPnr(rloc)).info;

  if (!pnr) {
    throw new Error("GetBoardingPass: No record found with provided lookup");
  }

  const paxs = getPaxsByPaxLookups(pnr, paxLookups);
  const flights = getFlightsByFlightLookups(pnr, flightLookups);

  // verify coupon checked in before issue BP
  paxs.forEach(p => {
    flights.forEach(f => {
      const coupon = findCoupon(p.coupons, f.carrier, f.flightNumber, f.date, f.origin, f.destination);

      if (!coupon.isCheckedIn) {
        throw new Error(
          'GetBoardingPass: Cannot issue boarding pass - passenger is not checked in ' + rloc + ' ' + f.flightNumber
        );
      }
    });
  });

  // retrieve or create BP
  await boardingPassProcessing(rloc, paxs, true, flights);

  return {
    pnr: Object.assign({}, pnr, {
      passengers: paxs,
      flights
    }),
    lookup: {
      rloc,
      familyName,
      givenName,
      targetAirlineCode: 'OG',
    },
  };
};

async function boardingPassProcessing(rloc, paxs, doCreateBp, flights) {
  await Promise.all(
    paxs.map(async p => {
      p.coupons = await Promise.all(
        p.coupons.map(async c => {

          const validateCouponWithCCFlight = flights.some((flight) => {
            return (
              flight.carrier === c.carrier &&
              flight.date === c.departureDateTime.split(" ")[0] &&
              flight.flightNumber === c.flightNumber &&
              flight.origin === c.origin &&
              flight.destination === c.destination
            )
          })
          
          if (c.isCheckedIn && validateCouponWithCCFlight) {
            const bpKey =
              p.eTicketNumber + c.flightNumber + c.carrier + date.toLookupDate(new Date(c.departureDateTime));

            c.boardingPass = await getPnrBp(rloc, bpKey, c);
            if (doCreateBp == true && c.boardingPass == undefined) {
              c.boardingPass = await setPnrBp(rloc, bpKey, genBp(c));
            }
          }
          return c;
        })
      );

      return p;
    })
  );
  return paxs;
}

function changePaxFlightStatus(pnr, pax, flights, checkInFag) {
  var pnrPax = findPax(pnr.passengers, pax.familyName, pax.givenName, pax.ticketNumber);

  // find my coupon.
  flights.forEach(flight => {
    var pnrCoupon = findCoupon(
      pnrPax.coupons,
      flight.carrier,
      flight.flightNumber,
      flight.date,
      flight.origin,
      flight.destination
    );

    if (!pnrCoupon.isCheckInInhibited) {
      pnrCoupon.isCheckedIn = checkInFag;
    }
  });
}
