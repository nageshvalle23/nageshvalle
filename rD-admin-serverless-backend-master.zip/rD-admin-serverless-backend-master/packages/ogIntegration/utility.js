
function convertToV2Params({ recordRequest }) {
    const { rloc, familyName, givenName } = recordRequest;
    return {
      rloc,
      familyName,
      givenName,
    };
  }

function convertToV2Body({flightRequests,passengerRequests,requirements,}) {
    const v2Body = {
      flightLookups: flightRequests.map(_flightRequestToLookup),
      passengerLookups: passengerRequests,
    };

    if (typeof requirements === "object") {
      v2Body.requirements = {
        acknowledgeDGTerms: requirements.acknowledgeDGTerms,
      };
      v2Body.checkIn = requirements.acceptance;
    }
    return v2Body;
  }

function _flightRequestToLookup({ date, flightNumber, carrierCode, origin, destination }) {
    return {
        carrier: carrierCode,
        date, flightNumber, origin, destination,
    };
}

module.exports = {
  convertToV2Params,
  convertToV2Body
}
