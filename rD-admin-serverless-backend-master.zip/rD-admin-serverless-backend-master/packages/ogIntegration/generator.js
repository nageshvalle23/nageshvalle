const Chance = require('chance');
const chance = new Chance();
const {DateTime} = require('luxon');

exports.genPnr = (targetAirlineCode, numPax = 3) => {
  const rloc = chance.word({length: 6}).toUpperCase();
  const route = genRoute(targetAirlineCode);

  // the flights only show the date of the flight for lookup purposes
  const flights = route.map(r => genFlight(r));

  const passengers = Array.from(Array(numPax)
    .keys()).map(_ => genPax(route));

  return {
    rloc, passengers, flights
  }
}

exports.genBp = (coupon) => {
  return {
    barcodeData: 'M1SMITH/JOHN EUKFCGM TPEHKGCX 0531 319Y042G0001 163>6320WW7318BCX 2A1258761858269 1CX 20KN8',
    qrCodeData: '2qrcodestring',
    seatNumber: '3A',
    passengerClass: '4st',
    eTicketNumber: coupon.eTicketNumber,
    frequentFlierNumber: '123-456',
    iOSPassbookFile: '7iOSPassbookFile',
    gate: '19',
    terminal: 'A',
    securityNumber: '12345',
    boardingGroup: '1',
    allowTSA: true,
    mobilewalletURL_ios: chance.url({ protocol:'https', tld: 'com', path: 'iOSpkPass', domain_prefix: 'og' }), //ex. https://og.vurece.com/iOSpkPass
    mobilewalletURL_android: chance.url({ protocol:'https', tld: 'com', path: 'androidpkPass', domain_prefix: 'og' }), //ex. https://og.vadutpet.com/androidpkPass
    allowFastTrack: false
  }
}

function genFlight (flight) {
  return Object.assign({
    carrierCode: flight.carrierCode,
    flightNumber: flight.flightNumber,
    origin: flight.origin,
    destination: flight.destination
  }, {
    date: DateTime.fromISO(flight.departure).toISODate()
  })
}

function genPax (route) {
  const gender = chance.bool() ? 'male' : 'female';

  const eTicketNumber = chance.string({
    pool: '0123456789',
    length: 14
  });

  return {
    familyName: chance.last(),
    givenName: chance.first({gender}),
    ageCategory: 'ADULT',
    title: chance.prefix({gender}),
    coupons: route.map(r => ({
      flightNumber: r.flightNumber,
      carrierCode: r.carrierCode,
      origin: r.origin,
      destination: r.destination,
      isCheckedIn: false,
      isCheckInInhibited: false,
      eTicketNumber,
      departureDateTime: DateTime.fromISO(r.departure).toFormat('yyyy-MM-dd HH:mm')
    }))
  }
}

// This is the prototype for creating flights array and pax coupons
function genRoute (targetCarrierCode) {
  const origin = chance.string({ length: 3, casing: 'upper', alpha: true });
  const layover = chance.string({ length: 3, casing: 'upper', alpha: true });
  const destination = chance.string({ length: 3, casing: 'upper', alpha: true });

  const originDeparture = DateTime
    .local().plus({
      days: 1, // at least one day in the future
      minutes: chance.integer({ min: 0, max: 1440 }) // at some point during that day (to the minute)
    }).toISO();

  const layoverDeparture = DateTime
    .fromISO(originDeparture)
    .plus({ minutes: chance.integer({ min: 180, max: 720 }) }).toISO()

  return [
    {
      carrierCode: 'OG',
      flightNumber: chance.integer({ min: 1, max: 999 }) + '',
      origin,
      destination: layover,
      departure: originDeparture
    },

    {
      carrierCode: targetCarrierCode,
      flightNumber: chance.integer({ min: 1, max: 999 }) + '',
      origin: layover,
      destination,
      departure: layoverDeparture,
    }
  ]
}
