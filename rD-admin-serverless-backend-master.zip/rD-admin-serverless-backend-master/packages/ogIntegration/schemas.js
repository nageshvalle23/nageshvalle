const Joi = require('joi');

const RECORD_REQUEST = Joi.object().keys({
  rloc: Joi.string().required(),
  carrierCode: Joi.string().length(2).required(),
  givenName: Joi.string().required(),
  familyName: Joi.string().required(),
});

const PASSENGER_REQUEST = Joi.object({
  familyName: Joi.string().required(),
  givenName: Joi.string().required(),
  eTicketNumber: Joi.string(),
});

const FLIGHTS_REQUEST = Joi.array().min(1).items({
  date: Joi.date().iso().required(),
  flightNumber: Joi.string().required(),
  carrierCode: Joi.string().length(2).required(),
  origin: Joi.string().length(3).required(),
  destination: Joi.string().length(3).required(),
});

const EMERGENCY_CONTACT = Joi.object({
  payload: Joi.object({
    phone: Joi.string().regex(/\+[0-9]{9,11}/),
    email: Joi.string().email(),
  }),
  type: Joi.string().valid('EMERGENCY_CONTACT').required()
});

const ADDRESS = Joi.object({
  payload: Joi.object({
    street: Joi.string().required(),
    city: Joi.string().required(),
    state: Joi.string(),
    zipCode: Joi.string().required(),
    country: Joi.string().required(),
    type: Joi.string().valid('DESTINATION', 'HOME').required() // DESTINATION, HOME
  }),
  type: Joi.string().valid('ADDRESS').required()
});

const REGULATORY_INFORMATION = Joi.object({
  payload: Joi.object({
    gender: Joi.string().valid('FEMALE', 'MALE', 'X', 'U'),
    dateOfBirth: Joi.date().iso(),
    nationality: Joi.string(),
    countryOfResidence: Joi.string().max(3),
    travelDoc: Joi.object({
      regulatoryGivenName: Joi.string(),
      regulatoryMiddleName: Joi.string(),
      regulatoryFamilyName: Joi.string(),
      documentType: Joi.string().valid('PASSPORT', 'VISA', 'NATIONAL_ID').required(), // PASSPORT, VISA
      documentNumber: Joi.string(),
      expiryDate: Joi.date().iso(),
      issueDate: Joi.date().iso(),
      countryOfIssue: Joi.string(),
    })
  }),
  type: Joi.string().valid('REGULATORY_INFORMATION').required()
})

const PAX_UPDATE = Joi.alternatives().try(EMERGENCY_CONTACT, ADDRESS, REGULATORY_INFORMATION);

module.exports = {
  RECORD_REQUEST, PASSENGER_REQUEST, FLIGHTS_REQUEST,

  PAX_UPDATE
}
