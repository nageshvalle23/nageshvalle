const chai = require('chai');
const assert = chai.assert;


// TODO - i want to test...what would happen if 1 of 2 pax does not exist on pnr
describe('Helpers for searching and translating data', () => {
  const m = require('../helpers')
  const pnrListing = require('../data/pnr.json')

  describe('getPaxsByPaxLookups', () => {

    it('Should find the pax with the given lookup', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      const pax = {
        givenName: 'JESSE',
        familyName: 'JAMES',
        eTicketNumber: '0012173934336'
      }

      const paxResult = m.getPaxsByPaxLookups(pnr, [pax])[0]
      assert.equal(paxResult.eTicketNumber, '0012173934336')
    })


    it('Should find all pax with the given lookups', () => {
      const pnr = pnrListing['QFWKIU']
       if (!pnr) {
         throw new Error('No record found with provided lookup')
       }

       const pax = [
         {
           givenName: 'JESSE',
           familyName: 'JAMES',
           eTicketNumber: '0012173934336'
         },
         {
           givenName: 'JEN',
           familyName: 'JAMES',
           eTicketNumber: '0012173934337'
         }
       ]

       const paxResults = m.getPaxsByPaxLookups(pnr, pax)

       // getPax function will confirm requesting list size is = to result size
       assert.notEqual(paxResults.find(p => p.familyName.toUpperCase() == 'JAMES'.toUpperCase() && p.givenName.toUpperCase() == 'JESSE'.toUpperCase() && p.eTicketNumber == '0012173934336'),undefined)
       assert.notEqual(paxResults.find(p => p.familyName.toUpperCase() == 'JAMES'.toUpperCase() && p.givenName.toUpperCase() == 'JEN'.toUpperCase() && p.eTicketNumber == '0012173934337'),undefined)

     })

    it('Should throw error when first name, last name or ticket number does not match', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      assert.throws( ()=> m.getPaxsByPaxLookups(pnr, [{
        givenName: 'jesse',
        familyName: 'foo',
        eicketNumber: '0012173934346'
      }]), "Bad lookup information")

      assert.throws( ()=> m.getPaxsByPaxLookups(pnr, [{
        givenName: 'foo',
        familyName: 'james',
        eicketNumber: '0012173934346'
      }]), "Bad lookup information")

       assert.throws( ()=> m.getPaxsByPaxLookups(pnr, [{
         givenName: 'jesse',
         familyName: 'james',
         eicketNumber: 'foo'
       }]), "Bad lookup information")

    })

    it('Should throw error if any of the lookup properties are missing', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      assert.throws( ()=> m.getPaxsByPaxLookups(pnr, [{
          familyName: 'JAMES',
          eTicketNumber: '0012173934436'
        }]), Error)

      assert.throws( ()=> m.getPaxsByPaxLookups(pnr, [{
          givenName: 'JESSE',
          eTicketNumber: '0012173934436'
        }]), Error)

      assert.throws( ()=>  m.getPaxsByPaxLookups(pnr, [{
           givenName: 'JESSE',
           familyName: 'JAMES'
         }]), Error)
    })
  })

  describe('getFlightsByFlightLookups', () => {
    it('Should find the flight with the given lookup', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      const flight = [{
        flightNumber: '0729',
        date: '2018-06-28',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'DFW'
      }]

      const result = m.getFlightsByFlightLookups(pnr, flight)[0]

      assert.equal(result.flightNumber, '0729')
    })

    it('Should find all flights with the given lookups', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      const flights = [{
        flightNumber: '0729',
        date: '2018-06-28',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'DFW'
      },{
        flightNumber: '1408',
        date: '2018-06-28',
        carrier: 'AA',
        origin: 'DFW',
        destination: 'LAX'
      }]

      const results = m.getFlightsByFlightLookups(pnr, flights)

      assert.notEqual(results.find(f => f.flightNumber == '0729' && f.date == '2018-06-28' && f.carrier == 'QR' && f.origin == 'DOH' && f.destination == 'DFW' ),undefined)
      assert.notEqual(results.find(f => f.flightNumber == '1408' && f.date == '2018-06-28' && f.carrier == 'AA' && f.origin == 'DFW' && f.destination == 'LAX' ),undefined)
    })

    it('Should gracefully handle an unexpected date format', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      const flight = [{
        flightNumber: '0729',
        date: '06-28-2018',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'DFW'
      }]

      const result = m.getFlightsByFlightLookups(pnr, flight)[0]

      assert.equal(result.flightNumber, '0729')
    })

    it('Should gracefully handle an invalid date ', () => {
      const pnr = pnrListing['QFWKIU']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      const flight = [{
        flightNumber: '0729',
        date: '76-28-2018',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'DFW'
      }]

      try {
        const result = m.getFlightsByFlightLookups(pnr, flight)[0]

        assert.equal(true, false)
      } catch (e) {
        assert.equal(true, true)
      }
    })
  })


  describe('findCoupon', () => {
    it('Should find the coupon', () => {
      const pnr = pnrListing['RO4I5R']
      if (!pnr) {
        throw new Error('No record found with provided lookup')
      }

      const result = m.findCoupon(pnr.passengers[0].coupons, 'CX', '0470', '2018-07-04 17:45', 'HKG', 'TPE')

      assert.equal(result.flightNumber, '0470')
    })

  })



})
