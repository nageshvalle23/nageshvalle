const _ = require("lodash");
const proxyquire = require("proxyquire");
const sinon = require("sinon");

const chai = require("chai");
const assert = chai.assert;
const chaiAsPromised = require("chai-as-promised");

chai.use(chaiAsPromised);

const moduleName = "../index";

const placeholderStub = (fnName) => () => {
  throw new Error("Please stub this function call: " + fnName);
};

const createStubs = (customStubs) =>
  _.defaults({}, customStubs, {
    ["@oneworld-digital/integration-utils"]: {
      request: {
        params: placeholderStub("params"),
        body: placeholderStub("body"),
        response: placeholderStub("response"),
      },
    },

    ["./api"]: {
      get1ARecord: placeholderStub("get1ARecord"),
      checkinRecord: placeholderStub("checkinRecord"),
      getBoardingPasses: placeholderStub("getBoardingPasses"),
    },
    ["./db"]: {
      createPnr: placeholderStub("createPnr"),
      getPnr: placeholderStub("getPnr"),
    }
  });

describe("CC API interface to OG REST services", () => {
  const params = sinon.stub();
  const body = sinon.stub();
  const response = sinon.stub();

  const createPnr = sinon.stub();
  const getPnr = sinon.stub();

  const get1ARecord = sinon.stub();
  const checkinRecord = sinon.stub();
  const getBoardingPasses = sinon.stub();

  const m = proxyquire(
    moduleName,
    createStubs({
      ["./api"]: {
        get1ARecord,
        checkinRecord,
        getBoardingPasses,
      },
      ["./db"]: {
        createPnr,
        getPnr,
      },
      ["@oneworld-digital/integration-utils"]: {
        request: {
          params,
          body,
          response,
        },
      },
    })
  );

  describe("GET a record", () => {
    beforeEach(() => {
      get1ARecord.reset(), params.reset(), body.reset(), response.reset();
    });

    it("should return 500 if rloc is missing", () => {
      const qs = {
        familyName: "foo",
      };

      params.returns(qs);

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();

      get1ARecord.throws(new Error("unknown rloc"));

      m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it("should return 500 if familyName is missing", () => {
      const qs = {
        rloc: "foo",
      };

      params.returns(qs);

      const event = {
        queryStringParameters: qs,
      };

      const cb = sinon.spy();

      get1ARecord.throws(new Error("family name missing"));

      m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it("should send an OK res", async () => {
      get1ARecord.returns(require("./1a_pnr.json"));

      const qs = {
        rLoc: "bar123",
        familyName: "foo",
      };

      params.returns(qs);

      const event = {
        queryStringParameters: qs,
        headers: {
          "x-client-carrier": "MH",
        },
      };

      const cb = sinon.spy();
      getPnr.returns({})
      createPnr.returns({})
      await m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  });

  describe("checkin", () => {
    before(() => {
      body.reset();
      params.reset();
      response.reset();
      checkinRecord.reset();
    });

    it("should send a bad res if any api call throws an error", async () => {
      const qs = {
        familyName: "foo",
      };

      params.returns(qs);
      body.returns({ foo: "bar" });

      const cb = sinon.spy();

      checkinRecord.throws(new Error("error occurred"));

      await m.checkin({}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it("should return a happy response if all the api calls succeed", async () => {
      const lookup = {
        rloc: "ISOFIG",
        familyName: "Callie",
        givenName: "Miceli",
      };

      const recordRequest = {
        rloc: "ISOFIG",
        familyName: "Callie",
        givenName: "Miceli",
        carrierCode: "OG",
      };

      const passengerRequest = {
        familyName: "Miceli",
        givenName: "Callie",
        eTicketNumber: "32121157229992",
      };

      const flightRequests = [
        {
          destination: "OCD",
          date: "2023-04-06",
          flightNumber: "256",
          origin: "YAN",
          carrierCode: "OG",
        },
        {
          destination: "MLE",
          date: "2023-04-06",
          flightNumber: "937",
          origin: "OCD",
          carrierCode: "OG",
        },
      ];

      const cb = sinon.spy();

      checkinRecord.returns({});
      const event = {
        queryStringParameters: lookup,
        body: JSON.stringify({
          recordRequest,
          flightRequests,
          passengerRequest,
          value: false,
          requirements: {
            acknowledgeDGTerms: true,
          },
        }),
      };
      await m.checkin({}, {}, cb);
      console.log("Response: ", response);

      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  });

  describe("boarding pass", () => {
    before(() => {
      body.reset();
      params.reset();
      response.reset();
      getBoardingPasses.reset();
    });

    it("should send a bad res if any api call throws an error", async () => {
      const qs = {
        familyName: "foo",
      };

      params.returns(qs);
      body.returns({ foo: "bar" });

      const cb = sinon.spy();

      getBoardingPasses.throws(new Error("error occurred"));

      await m.boardingpass({}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it("should return a happy response if all the api calls succeed", async () => {
      const cb = sinon.spy();

      body.returns({});
      getBoardingPasses.returns({});

      await m.boardingpass({}, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  });
});
