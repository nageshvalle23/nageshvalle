const chai = require('chai');
const assert = chai.assert;
const expect = chai.expect
const chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);

const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');


const moduleName = '../api'

const placeholderStub = fnName => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = customStubs => _.defaults({}, customStubs, {

  ['./db']: {
    getPnr: placeholderStub('getPnr'),
    setPnrInfo: placeholderStub('setPnrInfo'),
    getPnrBp: placeholderStub('getPnrBp'),
    setPnrProps: placeholderStub('setPnrProps'),
  }

});



describe('Testing OG API functionality', () => {

  const getPnr = sinon.stub();
  const setPnrInfo = sinon.stub();
  const getPnrBp = sinon.stub();
  const setPnrProps = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    ['./db']: {
      getPnr,
      setPnrInfo,
      getPnrBp,
      setPnrProps,
    },
  }))


  describe('getRecord', () => {

    beforeEach(() => {
      getPnr.reset()
    });

    it('Should find the record with the given rloc', async () => {

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"ticketNumber":"2301DB0700003763","title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","isCheckedIn":true,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","isCheckedIn":true,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})

      const result = await m.getRecord('RO4I5R', 'connect', 'carrier')
      assert.deepEqual(result.pnr.rloc, 'RO4I5R')
    })

    it('Should throw an error if a parameter does not match', async () => {

      getPnr.returns(undefined)
      await assert.isRejected(m.getRecord('foo', 'connect', 'carrier'), Error)
      await assert.isRejected(m.getRecord('RO4I5R', 'foo', 'carrier'), Error)
      await assert.isRejected(m.getRecord('RO4I5R', 'connect', 'foo'), Error)
    })

    it('Should throw an error if pnr does not exist', async () => {

      getPnr.returns(undefined)
      await assert.isRejected(m.getRecord('ABCDEF', 'connect', 'carrier'), Error)

    })
  })

  describe('getEligibility', () => {

    it('Should returns the eligility response', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequest = {
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '2301DB0700003763'
      }

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 00:55","carrier":"QR","flightNumber":"0818","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({ props: { requirements: [] } ,info: JSON.parse(pnr)})
      setPnrProps.returns();

      const result = await m.getPaxEligibility(recordRequest,passengerRequest)
      expect(result).to.have.property('requiredDocuments').that.is.an('array');
      expect(result).to.have.property('populatedDocuments').that.is.an('array');
    })

    it('Should throw an error if a request does not match', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequest = {
        givenName: 'carrier',
        familyName: 'connect',
      }

      getPnr.returns(undefined)
      await assert.isRejected(m.getPaxEligibility(recordRequest, passengerRequest), Error)
    })

    it('Should throw an error when rloc is invalid', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequest = {
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'
      }

      getPnr.returns(undefined)

      // blank rloc
      recordRequest.rloc = ''
      await assert.isRejected(m.getPaxEligibility(recordRequest,passengerRequest), Error)

      // rloc incorrect length
      recordRequest.rloc = 'abc'
      await assert.isRejected(m.getPaxEligibility(recordRequest,passengerRequest), Error)

      // unknown rloc
      recordRequest.rloc = 'qwerty'
      await assert.isRejected(m.getPaxEligibility(recordRequest,passengerRequest), Error)

    })

  })

  describe('multiEligibility', () => {
    it('Should returns the multi eligility response', async () => {
      const isMultiEligibility = true;

      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequests = [
        {
          givenName: 'carrier',
          familyName: 'connect',
          eTicketNumber: '2301DB0700003763'
        }

    ]

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 00:55","carrier":"QR","flightNumber":"0818","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({ props: { requirements: [] } ,info: JSON.parse(pnr)})
      setPnrProps.returns();

      passengerRequests.forEach(async (eachPax) => {
        const result = await m.getPaxEligibility(recordRequest,eachPax, isMultiEligibility);
        expect(result).to.have.property('requiredDocuments').that.is.an('array');
        expect(result).to.have.property('populatedDocuments').that.is.an('array');
        expect(result).to.have.property('familyName').that.is.an('string');
        expect(result).to.have.property('givenName').that.is.an('string');
        expect(result).to.have.property('eTicketNumber').that.is.an('string');
      })
    })

    it('Should throw an error if a request does not match', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequests = [
        {
          givenName: 'carrier',
          familyName: 'connect',
          eTicketNumber: '2301DB0700003763'
        }

    ]

      getPnr.returns(undefined)
      passengerRequests.forEach(async (eachPax) => {
        await assert.isRejected(m.getPaxEligibility(recordRequest, eachPax), Error)
      })
    })
  })

  describe('documentUpdate', () => {

    it('Should returns the document response', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequest = {
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '2301DB0700003763'
      }
      const document = [{
        "type": "DESTINATION_ADDRESS",
        "payload": {
            "street": "TEST1234",
            "city": "ABC123",
            "stateProv": "CA",
            "postalCode": "122345",
            "country": "USA"
        }
    }]

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 00:55","carrier":"QR","flightNumber":"0818","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({ props: { requirements: [] } ,info: JSON.parse(pnr)})
      setPnrProps.returns();

      const result = await m.updatePax(recordRequest,passengerRequest, document)
      expect(result).to.have.property('requiredDocuments').that.is.an('array');
      expect(result).to.have.property('populatedDocuments').that.is.an('array');
    })

    it('Should throw an error if a request does not match', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequest = {
        givenName: 'carrier',
        familyName: 'connect',
      }
      const document = {
        "type": "DESTINATION_ADDRESS",
        "payload": {
            "street": "TEST1234",
            "city": "ABC123",
            "stateProv": "CA",
            "postalCode": "122345",
            "country": "USA"
        }
    }
      getPnr.returns(undefined)
      await assert.isRejected(m.updatePax(recordRequest, passengerRequest, document), Error)
    })

    it('Should throw an error when rloc is invalid', async () => {
      const recordRequest = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier',
        carrierCode: "OG"
      }
      const passengerRequest = {
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'
      }
      const document = {
        "type": "DESTINATION_ADDRESS",
        "payload": {
            "street": "TEST1234",
            "city": "ABC123",
            "stateProv": "CA",
            "postalCode": "122345",
            "country": "USA"
        }
    }
      getPnr.returns(undefined)

      // blank rloc
      recordRequest.rloc = ''
      await assert.isRejected(m.updatePax(recordRequest,passengerRequest, document), Error)

      // rloc incorrect length
      recordRequest.rloc = 'abc'
      await assert.isRejected(m.updatePax(recordRequest,passengerRequest, document), Error)

      // unknown rloc
      recordRequest.rloc = 'qwerty'
      await assert.isRejected(m.updatePax(recordRequest,passengerRequest, document), Error)

    })
  })

  describe('checkinRecord', () => {

    it('Should check-in single passenger with single flight on the given rloc', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]
      const reqs = {acknowledgeDGTerms: true}
      const checkInFlag = true

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 00:55","carrier":"QR","flightNumber":"0818","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})
      setPnrInfo.returns(undefined)
      getPnrBp.returns(undefined)

      const result = await m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag)

      assert.equal(result.pnr.rloc, 'RO4I5R')
      assert.isTrue(result.pnr.passengers[0].coupons.find(
          f => (f.flightNumber === '0818' &&
                f.origin == 'DOH' &&
                f.carrier == 'QR' &&
                f.destination == 'HKG' )).isCheckedIn)
    })

    it('Should check-in single passenger with 2 flights on the given rloc', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      },{
        flightNumber: '0470',
        date: '2018-07-04',
        origin: 'HKG',
        destination: 'TPE',
        carrier: 'CX'
      }]
      const reqs = {acknowledgeDGTerms: true}
      const checkInFlag = true

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})
      setPnrInfo.returns(undefined)
      getPnrBp.returns(undefined)

      const result = await m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag)
      assert.equal(result.pnr.rloc, 'RO4I5R')
      assert.isTrue(result.pnr.passengers[0].coupons.find(
        f => (f.flightNumber === '0818' &&
              f.origin == 'DOH' &&
              f.carrier == 'QR' &&
              f.destination == 'HKG' )).isCheckedIn)
      assert.isTrue(result.pnr.passengers[0].coupons.find(
        f => (f.flightNumber === '0470' &&
              f.origin == 'HKG' &&
              f.carrier == 'CX' &&
              f.destination == 'TPE' )).isCheckedIn)

    })



    it('Should fail since already checked in', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]
      const reqs = {acknowledgeDGTerms: false}
      const checkInFlag = true

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"ticketNumber":"2301DB0700003763","title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","isCheckedIn":true,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","isCheckedIn":true,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})

      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

    })

    it('Should fail since checkIn is inhibited', async () => {
      const lookup = {
        rloc: 'INHIBT',
        familyName: 'PUTTER',
        givenName: 'ROB'}
      const paxLookups = [{
        givenName: 'ROB',
        familyName: 'Putter',
        ticketNumber: '1111371378156'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-10-20',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]

      const reqs = {acknowledgeDGTerms: false}
      const checkInFlag = true

      const pnr = '{"rloc": "INHIBT",         "passengers": [             {                 "familyName": "PUTTER",                 "givenName": "ROB",                 "title": "MR",                 "ageCategory": "ADULT",                 "ticketNumber": "1111371378156",                 "coupons": [                     {                         "flightNumber": "0818",                         "departureDateTime": "2018-10-20 03:25",                         "carrier": "QR",                         "origin": "DOH",                         "destination": "HKG",                         "isCheckedIn": false,                         "isCheckInInhibited": true,                         "boardingPass": null                     },                     {                         "flightNumber": "0470",                         "departureDateTime": "2018-10-20 17:45",                         "carrier": "CX",                         "origin": "HKG",                         "destination": "TPE",                         "isCheckedIn": false,                         "isCheckInInhibited": true,                         "boardingPass": null                     }                 ]             }         ],         "flights": [             {                 "flightNumber": "0818",                 "date": "2018-10-20",                 "carrier": "QR",                 "origin": "DOH",                 "destination": "HKG"             },             {                 "flightNumber": "0470",                 "date": "2018-10-20",                 "carrier": "CX",                 "origin": "HKG",                 "destination": "TPE"             }         ]     }'
      getPnr.returns({info: JSON.parse(pnr)})

      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

    })

    it('Should fail since DG is not set', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]
      const reqs = {acknowledgeDGTerms: false}
      const checkInFlag = true

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"ticketNumber":"2301DB0700003763","title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})

      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

    })

    it('Should throw an error when rloc is invalid', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]
      const reqs = {acknowledgeDGTerms: true}
      const checkInFlag = true
      getPnr.returns(undefined)

      // blank rloc
      lookup.rloc = ''
      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

      // rloc incorrect length
      lookup.rloc = 'abc'
      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

      // unknown rloc
      lookup.rloc = 'qwerty'
      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

    })

    it('Should throw an error when request data does not match pnr', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]
      const reqs = {acknowledgeDGTerms: true}
      const checkInFlag = true
      getPnr.returns(undefined)


      lookup.familyName = 'foo'
      paxLookups[0].familyName = 'foo'
      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

      lookup.familyName = 'connect'
      paxLookups.familyName = 'connect'
      flightLookups[0].flightNumber = '0000'
      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

      flightLookups[0].flightNumber = '0818'
      lookup.givenName = 'foo'
      paxLookups[0].givenName = 'foo'
      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

    })

  })

  describe('multiCheckinRecord', () => {
    it('Should check-in single passenger with 2 flights on the given rloc', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        eTicketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      },{
        flightNumber: '0470',
        date: '2018-07-04',
        origin: 'HKG',
        destination: 'TPE',
        carrier: 'CX'
      }]
      const reqs = {acknowledgeDGTerms: true}
      const checkInFlag = true

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","eTicketNumber":"2301DB0700003763","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})
      setPnrInfo.returns(undefined)
      getPnrBp.returns(undefined)

      const result = await m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag)
      assert.equal(result.pnr.rloc, 'RO4I5R')
      assert.isTrue(result.pnr.passengers[0].coupons.find(
        f => (f.flightNumber === '0818' &&
              f.origin == 'DOH' &&
              f.carrier == 'QR' &&
              f.destination == 'HKG' )).isCheckedIn)
      assert.isTrue(result.pnr.passengers[0].coupons.find(
        f => (f.flightNumber === '0470' &&
              f.origin == 'HKG' &&
              f.carrier == 'CX' &&
              f.destination == 'TPE' )).isCheckedIn)
      assert.equal(result.pnr.passengers.length, paxLookups.length)

    })

    it('Should fail since DG is not set', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]
      const reqs = {acknowledgeDGTerms: false}
      const checkInFlag = true

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"ticketNumber":"2301DB0700003763","title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})

      await assert.isRejected(m.checkinRecord(lookup, paxLookups, flightLookups, reqs, checkInFlag), Error)

    })
  })
  describe('getBoardingPasses', () => {

    it('Should fail since pax is not checked in', async () => {
      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"ticketNumber":"2301DB0700003763","title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","isCheckedIn":false,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","isCheckedIn":false,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})

      await assert.isRejected(m.getBoardingPasses(lookup, paxLookups, flightLookups), Error)

    })

    // TODO how would you stub retrieveboardingpass being called twice -- with diff data each time?
    it('Should produce BP for single passenger with 1 flight ', async () => {

      const lookup = {
        rloc: 'RO4I5R',
        familyName: 'connect',
        givenName: 'carrier'}
      const paxLookups = [{
        givenName: 'carrier',
        familyName: 'connect',
        ticketNumber: '2301DB0700003763'}]
      const flightLookups = [{
        flightNumber: '0818',
        date: '2018-07-04',
        carrier: 'QR',
        origin: 'DOH',
        destination: 'HKG'
      }]

      const pnr = '{"flights":[{"date":"2018-07-04","destination":"HKG","carrier":"QR","flightNumber":"0818","origin":"DOH"},{"date":"2018-07-04","destination":"TPE","carrier":"CX","flightNumber":"0470","origin":"HKG"}],"passengers":[{"ticketNumber":"2301DB0700003763","title":"MR","ageCategory":"ADULT","coupons":[{"destination":"HKG","departureDateTime":"2018-07-04 02:55","carrier":"QR","flightNumber":"0818","isCheckedIn":true,"isCheckInInhibited":false,"origin":"DOH"},{"destination":"TPE","departureDateTime":"2018-07-04 17:45","carrier":"CX","flightNumber":"0470","isCheckedIn":true,"isCheckInInhibited":false,"origin":"HKG"}],"givenName":"CARRIER","familyName":"CONNECT"}],"rloc":"RO4I5R"}'
      getPnr.returns({info: JSON.parse(pnr)})
      const bp0818 = '{"securityNumber":"12345","qrCodeData":"2qrcodestring","allowTSA":"true","eTicketNumber":"555555","iOSPassbookFile":"7iOSPassbookFile","terminal":"A","passengerClass":"4st","frequentFlierNumber":"123-456","allowFastTrack":"false","seatNumber":"3A","boardingGroup":"1","gate":"19","barcodeData":"1barcodestring"}'
      getPnrBp.returns(bp0818)

      const result = await m.getBoardingPasses(lookup, paxLookups, flightLookups)
      const boardingPass0818 = result.pnr.passengers[0].coupons.find(
        f => (f.flightNumber === '0818' &&
        f.origin == 'DOH' &&
        f.carrier == 'QR' &&
        f.destination == 'HKG'  )).boardingPass

      assert.equal(result.pnr.rloc, 'RO4I5R')
      assert.isTrue(result.pnr.passengers[0].coupons.find(
        f => (f.flightNumber === '0818' &&
        f.origin == 'DOH' &&
        f.carrier == 'QR' &&
        f.destination == 'HKG' )).isCheckedIn)
      assert.isTrue(typeof boardingPass0818 !== 'undefined' && boardingPass0818 !== null)

    })

    it('Should throw an error if rloc does not exist', async () => {
      getPnr.returns(undefined)
      await assert.isRejected(m.getBoardingPasses('ABCDEF', 'connect', 'carrier'), Error)
    })

   })

})
