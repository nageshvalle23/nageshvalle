const STAGE = process.env.STAGE;
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();
AWS.config.update({region: process.env.AWS_REGION});

exports.getPnr = getPnr;
async function getPnr(rloc, shouldConvertToV1 = true) {
  const record = await dynamo
    .get({
      Key: {
        rloc,
      },
      TableName: 'rd-pangaea-pnr-' + STAGE,
    })
    .promise();

  const pnr = !record || !record.Item ? undefined : record.Item;

  if (shouldConvertToV1 && pnr !== undefined) {
    pnr.info = convertToV1Pnr(pnr.info);
  }

  return pnr;
}

exports.getPnrs = async function() {
  const params = {
    TableName: 'rd-pangaea-pnr-' + STAGE,
  };

  const { Items } = await dynamo.scan(params).promise();

  return Items;
};

exports.createPnr = async function (rloc, info, props) {
  const params = {
    TableName: 'rd-pangaea-pnr-' + STAGE,
    Item: {
      rloc,
      info,
      props,
    },
  };
  return await dynamo.put(params).promise();
}

exports.deletePnr = async function(rloc) {
  const params = {
    TableName: 'rd-pangaea-pnr-' + STAGE,
    Key: { rloc },
  };

  return dynamo.delete(params).promise();
};

exports.setPnrProps = async function(rloc, props) {
  const params = {
    TableName: 'rd-pangaea-pnr-' + STAGE,
    Key: { rloc },
    UpdateExpression: 'set props = :props',
    ExpressionAttributeValues: {
      ':props': props,
    },
    ReturnValues: 'UPDATED_NEW',
  };

  return dynamo.update(params).promise();
};

exports.setPnrInfo = async function(rloc, info) {
  const params = {
    TableName: 'rd-pangaea-pnr-' + STAGE,
    Key: { rloc },
    UpdateExpression: 'set info = :info',
    ExpressionAttributeValues: {
      ':info': convertToV2Pnr(info),
    },
    ReturnValues: 'UPDATED_NEW',
  };

  return dynamo.update(params).promise();
};

exports.setPnrBp = async function(rloc, bpKey, bp) {
  const pnr = await getPnr(rloc);

  pnr.bp = Object.assign(pnr.bp || {}, { [bpKey]: bp });

  const params = {
    TableName: 'rd-pangaea-pnr-' + STAGE,
    Key: { rloc },
    UpdateExpression: 'set bp = :bp',
    ExpressionAttributeValues: {
      ':bp': pnr.bp,
    },
    ReturnValues: 'UPDATED_NEW',
  };

  await dynamo.update(params).promise();

  return bp;
};

exports.getPnrBp = async function(rloc, bpKey, coupon) {
  const pnr = await getPnr(rloc);
  
  if (pnr.bp && pnr.bp[bpKey]) {
    // Modify the eTicketNumber
    pnr.bp[bpKey].eTicketNumber = coupon.eTicketNumber;
  }
  return pnr.bp && pnr.bp[bpKey];
};

function convertToV2Pnr(pnr) {
  const v2 = Object.assign({}, pnr);

  v2.passengers = pnr.passengers.map(pax => {
    pax.coupons = pax.coupons.map(c => {
      const coupon = Object.assign({}, c, { carrierCode: c.carrier });
      delete coupon.carrier;
      return coupon;
    });

    return pax;
  });

  v2.flights = pnr.flights.map(f => {
    const flight = Object.assign({}, f, { carrierCode: f.carrier });
    delete flight.carrier;
    return flight;
  });

  return v2;
}

function convertToV1Pnr(pnr) {
  const v1 = Object.assign({}, pnr);

  v1.passengers = pnr.passengers.map(pax => {
    pax.coupons = pax.coupons.map(c => {
      const coupon = Object.assign({}, c, { carrier: c.carrierCode || c.carrier });
      delete coupon.carrierCode;
      return coupon;
    });

    return pax;
  });

  v1.flights = pnr.flights.map(f => {
    const flight = Object.assign({}, f, { carrier: f.carrierCode || f.carrier });
    delete flight.carrierCode;
    return flight;
  });

  return v1;
}
