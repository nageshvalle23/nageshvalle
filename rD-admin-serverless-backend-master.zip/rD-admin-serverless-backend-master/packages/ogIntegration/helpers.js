const { date } = require('@oneworld-digital/integration-utils');

function getPaxsByPaxLookups(pnr, paxs) {
  const selectedPaxs = pnr.passengers.filter(p => isPaxMatch(paxs, p.familyName, p.givenName, p.eTicketNumber));

  if (selectedPaxs.length !== paxs.length) {
    throw new Error('Bad lookup information');
  }

  return selectedPaxs;
}

function getFlightsByFlightLookups(pnr, flights) {
  const selectedFlights = pnr.flights.filter(f => {
    return isFlightMatch(flights, f.carrier, f.flightNumber, f.date, f.origin, f.destination);
  });

  if (selectedFlights.length !== flights.length) {
    throw new Error('Bad lookup information');
  }

  return selectedFlights;
}

function findPax(paxs, familyName, givenName, ticketNumber) {
  // ticket number is not available in all uses of this function.
  return paxs[findPaxIndex(paxs, familyName, givenName, ticketNumber)];
}

const findPaxIndex = function (paxs, familyName, givenName, ticketNumber) {
  // ticket number is not available in all uses of this function.
  const match = paxs.findIndex(
    p =>
      p.familyName.toUpperCase() === familyName.toUpperCase() &&
      p.givenName.toUpperCase() === givenName.toUpperCase() &&
      (ticketNumber == undefined || p.eTicketNumber == ticketNumber)
  );

  return match;
}

function findFlight(flights, carrier, flightNumber, flightDate, origin, dest) {
  return flights.find(
    f =>
      f.carrier.toUpperCase() === carrier.toUpperCase() &&
      f.flightNumber === flightNumber &&
      // This is kindof a hack to make this function work with coupons in addition to flights
      date.toLookupDate(new Date(f.date)) === flightDate &&
      f.origin.toUpperCase() === origin.toUpperCase() &&
      f.destination.toUpperCase() === dest.toUpperCase()
  );
}

function findCoupon(coupons, carrier, flightNumber, flightDate, origin, dest) {
  return coupons.find(
    f => {
      return (
        f.carrier.toUpperCase() === carrier.toUpperCase() &&
        f.flightNumber === flightNumber &&
        // This is kindof a hack to make this function work with coupons in addition to flights
        date.toLookupDate(new Date(f.departureDateTime)) === date.toLookupDate(new Date(flightDate)) &&
        f.origin.toUpperCase() === origin.toUpperCase() &&
        f.destination.toUpperCase() === dest.toUpperCase()
      )
    }
  );
}

const isPaxMatch = function() {
  return !!findPax(...arguments);
};

const isFlightMatch = function() {
  return !!findFlight(...arguments);
};

module.exports = {
  getPaxsByPaxLookups,
  getFlightsByFlightLookups,
  findPax,
  findFlight,
  findCoupon,
  isPaxMatch,
  isFlightMatch,
  findPaxIndex
};
