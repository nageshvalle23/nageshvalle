const index = require("./index");

const lookup = { rloc: "ISOFIG", familyName: "Callie", givenName: "Miceli" };

const recordRequest = {
  rloc: "ISOFIG",
  familyName: "Callie",
  givenName: "Miceli",
  carrierCode: "OG"
};

const passengerRequests = [
  {
    familyName: "Miceli",
    givenName: "Callie",
    eTicketNumber: "32121157229992",
  },
  {
    familyName: "Bourgeois",
    givenName: "Gary",
    eTicketNumber: "76044669308611",
  },
];

const passengerRequest = {
  familyName: "Miceli",
  givenName: "Callie",
  eTicketNumber: "32121157229992",
};

const flightRequests = [
  {
    destination: "OCD",
    date: "2023-04-06",
    flightNumber: "256",
    origin: "YAN",
    carrier: "OG",
  },
  {
    destination: "MLE",
    date: "2023-04-06",
    flightNumber: "937",
    origin: "OCD",
    carrier: "OG",
  },
];

// index.eligibility(
//   {
//     queryStringParameters: lookup,
//     body: JSON.stringify({ recordRequest, passengerRequest, flightRequests }),
//   },
//   null,
//   (err, res) => {
//     console.log(
//       JSON.stringify(JSON.parse(res.body), null, "  "),
//       "<<<<<<<<<<<<<"
//     );
//   }
// );

// index.multieligibility(
//   {
//     queryStringParameters: lookup,
//     body: JSON.stringify({ recordRequest, passengerRequests }),
//   },
//   null,
//   (err, res) => {
//     console.log(
//       JSON.stringify(JSON.parse(res.body), null, "  "),
//       "<<<<<<<<<<<<<"
//     );
//   }
// );

index.checkin(
  {
    queryStringParameters: lookup,
    body: JSON.stringify({
      recordRequest,
      flightRequests,
      passengerRequest,
      value: false,
      requirements: {
        acknowledgeDGTerms: true,
      },
    }),
  },
  null,
  (err, res) => {
    console.log(
      JSON.stringify(JSON.parse(res.body), null, "  "),
      "<<<<<<<<<<<<<"
    );
  }
);

// index.boardingpass({
//   queryStringParameters: lookup,
//   body: JSON.stringify({flightLookups,
//                         passengerLookups,
//                         value: true,
//                         requirements: {
//                           acknowledgeDGTerms: true
//                         }})
// }, null, (err, res) => {
//     console.log(JSON.stringify(JSON.parse(res.body), null, '  '), '<<<<<<<<<<<<<')
//   })

// index.record(
//   {
//     queryStringParameters: {
//       familyName: 'Miceli',
//       givenName: 'Callie',
//       rloc: 'ISOFIG'
//     }
//   },
//   null,
//   (err, response) => {
//     console.log(JSON.stringify(JSON.parse(response.body), null, '  '))
//   });