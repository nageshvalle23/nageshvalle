const api = require('./index.js')

const flightLookups =
  {
    origin: '',
    destination: '',
    flightNumber: '181', // Needs to be padded as 0181 for MH api
    carrier: 'MH',
    date: '2020-09-30'
  };

api.flifo({
  body: JSON.stringify(flightLookups)
}, null, (err, res) => {
  console.log(JSON.stringify(JSON.parse(res.body), null, 2));
});
