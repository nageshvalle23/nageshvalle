const { get } = require('axios');

// 'https://sandbox-api.malaysiaairlines.com/api/rest/carrierconnect/flight/status';
const MH_FLIFO_API = process.env.MH_FLIFO_API;
const MH_FLIFO_KEY = process.env.MH_FLIFO_KEY;

async function getFlights({ flightNumber, date }) {
  try {
    return (await get(MH_FLIFO_API, {
      timeout: 5000,
      params: {
        flightNumber: flightNumber.padStart(4, '0'),
        departureDate: date,
        searchType: 'departure'
      },
      headers: {
        "Ocp-Apim-Subscription-Key": MH_FLIFO_KEY
      }
    })).data
  } catch(err) {
    err.OA = true
    throw err;
  }
}

module.exports = { getFlights };
