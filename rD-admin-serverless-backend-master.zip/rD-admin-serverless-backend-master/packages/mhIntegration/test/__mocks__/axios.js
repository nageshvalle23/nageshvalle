const flights = require('./flights/index.js');

module.exports = {
  get: async (url, options) => {
    const flightNumber = options.params.flightNumber;
    if (flights[flightNumber]) {
      return { data: flights[flightNumber].data.source };
    } else {
      throw new Error('Mock Axios Error');
    }
  }
}
