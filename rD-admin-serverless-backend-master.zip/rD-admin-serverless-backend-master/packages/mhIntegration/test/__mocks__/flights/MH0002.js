module.exports.source = [
  {
    "latestEtdLocal": "2020-02-04 23:30:00.0",
    "aircraftDescription": "AIRBUS INDUSTRIE A350-900   ",
    "flightStdLocal": "2020-02-04 23:30:00.0",
    "flightEtaLocal": "2020-02-05 05:35:00.0",
    "flightStaLocal": "2020-02-05 05:35:00.0",
    "flightStatus": "NOR",
    "latestEtd": "2020-02-04 15:30:00.0",
    "flightSta": "2020-02-05 05:35:00.0",
    "flightEta": "2020-02-05 05:35:00.0",
    "blockOffTime": null,
    "takeOffTime": null,
    "blockOnTime": null,
    "depGate": null,
    "arrGate": null,
    "legStatus": "SCH",
    "depDelay": null,
    "arrDelay": null,
    "localRemarks": null,
    "landingTime": null,
    "globalRemarks": null,
    "arrAirport": "LHR",
    "airlineCode": "MH",
    "aircraftType": "359",
    "flightStd": "2020-02-04 15:30:00.0",
    "aircraftRegNo": "9MMAG",
    "mvtStatusCode": null,
    "flightDateUtc": "2020-02-04 00:00:00.0",
    "searchType": "departure",
    "depAirport": "KUL",
    "flightNumber": "0002",
    "opSuffix": null,
    "legNumber": "1",
    "latestDepAirportCode": "KUL",
    "latestArrAirportCode": "LHR",
    "landingTimeLocal": null,
    "takeOffTimeLocal": null,
    "blockOnTimeLocal": null,
    "blockOffTimeLocal": null
  }
]

module.exports.expected = {
  "flightNumber": "0002",
  "carrierCode": "MH",
  "sectors": [
    {
      "codeShares": [],
      "status": "SCHEDULED",
      "sourceStatus": "SCH",
      "departure": {
        "airportCode": "KUL",
        "terminal": null,
        "gate": null,
        "scheduled": {
          "local": "2020-02-04T23:30:00+08:00",
          "utc": "2020-02-04T15:30:00Z",
          "source": "MH"
        },
        "estimated": {
          "local": null,
          "utc": null,
          "source": "MH"
        },
        "actual": {
          "local": null,
          "utc": null,
          "source": "MH"
        }
      },
      "arrival": {
        "airportCode": "LHR",
        "terminal": null,
        "gate": null,
        "scheduled": {
          "local": "2020-02-05T05:35:00Z",
          "utc": "2020-02-05T05:35:00Z",
          "source": "MH"
        },
        "estimated": {
          "local": "2020-02-05T05:35:00Z",
          "utc": "2020-02-05T05:35:00Z",
          "source": "MH"
        },
        "actual": {
          "local": null,
          "utc": null,
          "source": "MH"
        }
      }
    }
  ],
  "summary": {
    "notice": false,
    "departure": {
      "at": {
        "local": "2020-02-04T23:30:00+08:00",
        "utc": "2020-02-04T15:30:00Z",
        "type": "SCHEDULED"
      }
    },
    "arrival": {
      "at": {
        "local": "2020-02-05T05:35:00Z",
        "utc": "2020-02-05T05:35:00Z",
        "type": "ESTIMATED"
      }
    }
  }
}
