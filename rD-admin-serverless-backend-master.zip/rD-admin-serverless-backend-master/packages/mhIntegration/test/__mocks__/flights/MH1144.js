module.exports.source = [
  {
    "latestEtdLocal": "2020-02-03 22:15:00.0",
    "aircraftDescription": "A330-300",
    "flightStdLocal": "2020-02-03 22:15:00.0",
    "flightEtaLocal": "2020-02-04 04:04:00.0",
    "flightStaLocal": "2020-02-04 03:50:00.0",
    "flightStatus": "NOR",
    "latestEtd": "2020-02-03 11:15:00.0",
    "flightSta": "2020-02-03 19:50:00.0",
    "flightEta": "2020-02-03 20:04:00.0",
    "blockOffTime": "2020-02-03 11:14:00.0",
    "takeOffTime": "2020-02-03 11:34:00.0",
    "blockOnTime": null,
    "depGate": null,
    "arrGate": null,
    "legStatus": "Gibberish", // UNKNOWN STATUS
    "depDelay": null,
    "arrDelay": null,
    "localRemarks": "WW0072\nDUE TO MTK TECH AILERON SERVO FAULT\nMH318/319 KUL/PKX VV ACFT SWAP TO APPLY",
    "landingTime": null,
    "globalRemarks": null,
    "arrAirport": "KUL",
    "airlineCode": "MH",
    "aircraftType": "333",
    "flightStd": "2020-02-03 11:15:00.0",
    "aircraftRegNo": "9MMTF",
    "mvtStatusCode": "OFF",
    "flightDateUtc": "2020-02-03 00:00:00.0",
    "searchType": "departure",
    "depAirport": "SYD",
    "flightNumber": "1144",
    "opSuffix": null,
    "legNumber": "1",
    "latestDepAirportCode": "SYD",
    "latestArrAirportCode": "KUL",
    "landingTimeLocal": null,
    "takeOffTimeLocal": "2020-02-03 22:34:00.0",
    "blockOnTimeLocal": null,
    "blockOffTimeLocal": "2020-02-03 22:14:00.0"
  }
]

module.exports.expected = {
  "flightNumber": "1144",
  "carrierCode": "MH",
  "sectors": [
    {
      "codeShares": [],
      "status": "UNKNOWN",
      "sourceStatus": "Gibberish",
      "departure": {
        "airportCode": "SYD",
        "terminal": null,
        "gate": null,
        "scheduled": {
          "local": "2020-02-03T22:15:00+11:00",
          "utc": "2020-02-03T11:15:00Z",
          "source": "MH"
        },
        "estimated": {
          "local": null,
          "utc": null,
          "source": "MH"
        },
        "actual": {
          "local": "2020-02-03T22:34:00+11:00",
          "utc": "2020-02-03T11:34:00Z",
          "source": "MH"
        }
      },
      "arrival": {
        "airportCode": "KUL",
        "terminal": null,
        "gate": null,
        "scheduled": {
          "local": "2020-02-04T03:50:00+08:00",
          "utc": "2020-02-03T19:50:00Z",
          "source": "MH"
        },
        "estimated": {
          "local": "2020-02-04T04:04:00+08:00",
          "utc": "2020-02-03T20:04:00Z",
          "source": "MH"
        },
        "actual": {
          "local": null,
          "utc": null,
          "source": "MH"
        }
      }
    }
  ],
  "summary": {
    "notice": false,
    "departure": {
      "at": {
        "local": "2020-02-03T22:34:00+11:00",
        "utc": "2020-02-03T11:34:00Z",
        "type": "ACTUAL"
      }
    },
    "arrival": {
      "at": {
        "local": "2020-02-04T04:04:00+08:00",
        "utc": "2020-02-03T20:04:00Z",
        "type": "ESTIMATED"
      }
    }
  }
}
