module.exports.source = {
  "Message": "No data available for this search"
}

module.exports.expected = [];
