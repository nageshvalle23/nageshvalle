module.exports.source = [
 {
     "flightNumber":"0074",
     "flightDateUtc":"2017-05-09 00:00:00.0",
     "searchType":"departure",
     "opSuffix":"",
     "depAirport":"HKG",
     "arrAirport":"KUL",
     "latestDepAirportCode":"HKG",
     "latestArrAirportCode":"KUL",
     "airlineCode":"MH",
     "aircraftType":"333",
     "aircraftRegNo":"9MMTN",
     "aircraftDescription":"A330-300",
     "flightStd":"2017-05-09 06:45:00.0",
     "latestEtd":"2017-05-09 06:45:00.0",
     "flightSta":"2017-05-09 10:25:00.0",
     "flightEta":"2017-05-09 10:43:00.0",
     "blockOffTime":"2017-05-09 06:54:00.0",
     "takeOffTime":"2017-05-09 07:14:00.0",
     "landingTime":"2017-05-09 10:38:00.0",
     "blockOnTime":"2017-05-09 10:46:00.0",
     "flightStdLocal":"2017-05-09 14:45:00.0",
     "latestEtdLocal":"2017-05-09 14:45:00.0",
     "flightStaLocal":"2017-05-09 18:25:00.0",
     "flightEtaLocal":"2017-05-09 18:43:00.0",
     "blockOffTimeLocal":"2017-05-09 14:54:00.0",
     "takeOffTimeLocal":"2017-05-09 15:14:00.0",
     "landingTimeLocal":"2017-05-09 18:38:00.0",
     "blockOnTimeLocal":"2017-05-09 18:46:00.0",
     "depGate":"",
     "arrGate":"T1",
     "legNumber":"1",
     "legStatus":"ON",
     "flightStatus":"NOR",
     "mvtStatusCode":"IN",
     "depDelay":"9",
     "arrDelay":"21",
     "localRemarks":"remark1",
     "globalRemarks":"ATC",
 }
]

module.exports.expected = {
  "flightNumber": "0074",
  "carrierCode": "MH",
  "sectors": [
    {
      "codeShares": [],
      "status": "LANDED",
      "sourceStatus": "ON",
      "departure": {
        "airportCode": "HKG",
        "terminal": null,
        "gate": "",
        "scheduled": {
          "local": "2017-05-09T14:45:00+08:00",
          "utc": "2017-05-09T06:45:00Z",
          "source": "MH"
        },
        "estimated": {
          "local": null,
          "utc": null,
          "source": "MH"
        },
        "actual": {
          "local": "2017-05-09T15:14:00+08:00",
          "utc": "2017-05-09T07:14:00Z",
          "source": "MH"
        }
      },
      "arrival": {
        "airportCode": "KUL",
        "terminal": null,
        "gate": "T1",
        "scheduled": {
          "local": "2017-05-09T18:25:00+08:00",
          "utc": "2017-05-09T10:25:00Z",
          "source": "MH"
        },
        "estimated": {
          "local": "2017-05-09T18:43:00+08:00",
          "utc": "2017-05-09T10:43:00Z",
          "source": "MH"
        },
        "actual": {
          "local": "2017-05-09T18:38:00+08:00",
          "utc": "2017-05-09T10:38:00Z",
          "source": "MH"
        }
      }
    }
  ],
  "summary": {
    "notice": false,
    "departure": {
      "at": {
        "local": "2017-05-09T15:14:00+08:00",
        "utc": "2017-05-09T07:14:00Z",
        "type": "ACTUAL"
      }
    },
    "arrival": {
      "at": {
        "local": "2017-05-09T18:38:00+08:00",
        "utc": "2017-05-09T10:38:00Z",
        "type": "ACTUAL"
      }
    }
  }
}
