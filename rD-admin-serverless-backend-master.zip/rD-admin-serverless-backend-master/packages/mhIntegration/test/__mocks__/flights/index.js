module.exports = {
  '0002': { data: require('./MH0002'), description: 'Scheduled' },
  '0004': { data: require('./MH0004'), description: 'Delayed' },
  '0005': { data: require('./MH0005'), description: 'Not found' },
  '0073': { data: require('./MH0073'), description: 'Arrived  (Movement In)' },
  '0074': { data: require('./MH0074'), description: 'Landed   (Movement: On)' },
  '0140': { data: require('./MH0140'), description: 'Departed (Movement: Off)' },
  '0141': { data: require('./MH0141'), description: 'Departed (Movement: Out)' },
  '1141': { data: require('./MH1141'), description: 'Diverted' },
  '1142': { data: require('./MH1142'), description: 'Return to base' },
  '1143': { data: require('./MH1143'), description: 'Cancelled' },
  '1144': { data: require('./MH1144'), description: 'Unknown' },
}
