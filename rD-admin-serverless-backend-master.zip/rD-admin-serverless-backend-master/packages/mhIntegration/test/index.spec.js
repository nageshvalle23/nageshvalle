const index = require('../index');
const flights = require('./__mocks__/flights');

jest.mock('axios');

for (let flightNo of Object.keys(flights)) {
  const flight = flights[flightNo];
  test(`Returns CC formatted flifo data for scenario: ${flight.description}`, async () => {
    let lookup = { flightNumber: flightNo, date: '2020-02-02' }
    await index.flifo({body: JSON.stringify(lookup)}, null, (err, res) => {
      expect(res.statusCode).toEqual(200)
      expect(JSON.parse(res.body)).toEqual(flights[flightNo].data.expected);
    });
  });
}

test('Reports errors from the MH flifo api', async () => {
  const lookup = { flightNumber: '123', date: '2020-02-02' }; // Flight not found
  await index.flifo({body: JSON.stringify(lookup)}, null, (err, res) => {
    const body = JSON.parse(res.body);
    expect(res.statusCode).toEqual(502)
    expect(body.code).toEqual(502);
    expect(body.type).toEqual('OA');
  });
});

test('Does not report internal errors as OA', async () => {
  await index.flifo({}, null, (err, res) => { //  Body doesn't match interace (lookups)
    const body = JSON.parse(res.body);
    expect(res.statusCode).toEqual(500)
    expect(body.code).toEqual(500);
    expect(body.type).toEqual('Internal');
  });
});
