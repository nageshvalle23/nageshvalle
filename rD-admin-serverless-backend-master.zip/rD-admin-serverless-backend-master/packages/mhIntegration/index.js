const uuid = require('uuid/v1');
const { response, body } = require('@oneworld-digital/integration-utils').request;
const { convertFlights } = require('./converter');
const { getFlights } = require('./api');

exports.flifo = async (event, context, cb) => {
  try {
    const lookup = body(event);
    const flights = convertFlights(await getFlights(lookup));
    cb(null, response(200, flights));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

function _handleErrors(err, cb) {
  console.error(err)

  const body = {
    id: uuid(),
    message: 'Failed to retrieve flight.',
    type: (err.OA) ? 'OA' : 'Internal',
    code: (err.OA) ? 502 : 500,
  };

  console.error(`Request failed with status ${body.code} and body ${JSON.stringify(body, null, 2)}`);

  return cb(null, response(body.code, body));
}
