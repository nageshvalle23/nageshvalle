
const { DateTime } = require('luxon');

const MH_DATE_FORMAT = 'yyyy-MM-dd TT.0';

const utcDateTime = ts => {
  if (!ts) {
    return null;
  }
  return DateTime.fromFormat(ts, MH_DATE_FORMAT, { zone: 'UTC' }).toISO({ suppressMilliseconds: true });
};

const localDateTime = (local_ts, utc_ts) => {
  if (!local_ts || !utc_ts) {
    return null;
  }

  const local = DateTime.fromFormat(local_ts, MH_DATE_FORMAT);
  const utc = DateTime.fromFormat(utc_ts, MH_DATE_FORMAT);

  const {hours, minutes} = local.diff(utc, ['hours', 'minutes']).toObject();
  const isPositiveOffset = local.diff(utc, ['minutes']).toObject().minutes > 0;

  const offsetString = `UTC${isPositiveOffset ? '+' : '-'}${('' + hours).padStart(2, '0')}:${('' + minutes).padStart(2, '0')}`;

  return local.setZone(offsetString, { keepLocalTime: true }).toISO({ suppressMilliseconds: true })
};

// TODO: How do MH handle multiple flights with same number in air on same day
module.exports.convertFlights = function(mhFlights) {
  if (!Array.isArray(mhFlights) || mhFlights.length < 1) {
    return [];
  }

  const flight = {
    flightNumber: mhFlights[0].flightNumber,
    carrierCode: mhFlights[0].airlineCode,
    sectors: [],
    summary: {
      notice: false,
    },
  }

  flight.sectors = mhFlights.map((f) => {
    let sector = {
      codeShares: [],
      status: _status(f),
      sourceStatus: (f.flightStatus === 'NOR') ? f.legStatus : f.flightStatus,
      departure: {
        airportCode: f.depAirport,
        terminal: null,
        gate: f.depGate,
        scheduled: {
          local: localDateTime(f.flightStdLocal, f.flightStd),
          utc: utcDateTime(f.flightStd),
          source: 'MH',
        },
        estimated: {
          local: localDateTime(f.flightLatestEtdLocal, f.flightLatestEtd),
          utc: utcDateTime(f.flightLatestEtd),
          source: 'MH',
        },
        actual: {
          local: localDateTime(f.takeOffTimeLocal, f.takeOffTime),
          utc: utcDateTime(f.takeOffTime),
          source: 'MH',
        },
      },
      arrival: {
        airportCode: f.arrAirport,
        terminal: null,
        gate: f.arrGate,
        scheduled: {
          local: localDateTime(f.flightStaLocal, f.flightSta),
          utc: utcDateTime(f.flightSta),
          source: 'MH',
        },
        estimated: {
          local: localDateTime(f.flightEtaLocal, f.flightEta),
          utc: utcDateTime(f.flightEta),
          source: 'MH',
        },
        actual: {
          local: localDateTime(f.landingTimeLocal, f.landingTime),
          utc: utcDateTime(f.landingTime),
          source: 'MH',
        },
      },
    };

    if (sector.status === 'DIVERTED' || sector.status === 'CANCELLED' || sector.status === 'DELAYED') {
      flight.summary.notice = true;
    }

    return sector;
  })

  flight.summary.departure = { at: _summary(flight.sectors[0], 'departure') };
  flight.summary.arrival = { at: _summary(flight.sectors[flight.sectors.length - 1], 'arrival') };

  return flight
}

/**
 * Get sector summary for type: arrival/departure
 */
function _summary(sector, type) {
  if (sector[type].actual.local && sector[type].actual.utc) {
    return {
      local: sector[type].actual.local,
      utc: sector[type].actual.utc,
      type: 'ACTUAL'
    };
  } else if (sector[type].estimated.local && sector[type].estimated.utc) {
    return {
      local: sector[type].estimated.local,
      utc: sector[type].estimated.utc,
      type: 'ESTIMATED'
    };

  } else {
    return {
      local: sector[type].scheduled.local,
      utc: sector[type].scheduled.utc,
      type: 'SCHEDULED'
    }
  }
}

// TODO: What do we do for delayed flights in air? I think we just show as DEPARTED right now
function _status({flightStatus, legStatus, depDelay, arrDelay}) {
  // Diversion/Return to base
  if (flightStatus === 'DIV' || flightStatus === 'RTB')  {
    return 'DIVERTED';
  }

  // Check for delays (Apply this if flight hasn't taken off yet)
  let delay = parseInt(depDelay) > 0 || parseInt(arrDelay) > 0

  // Leg status to make a decision
  switch (legStatus) {
    case 'CNL':
      return 'CANCELLED';
    case 'SCH':
      return delay ? 'DELAYED' : 'SCHEDULED';
    case 'OUT':
    case 'OFF':
      return 'DEPARTED';
    case 'ON':
      return 'LANDED';
    case 'IN':
      return 'ARRIVED';
    default:
      return 'UNKNOWN';
  }
}
