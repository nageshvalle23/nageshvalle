/**
 * helpers
 *  helper functions for sita integration
 */

exports.filterBagByPax = (bags, passengers) => {
  if (!Array.isArray(passengers) || passengers.length === 0) {
    return bags;
  }

  return bags.filter(bag => {
    return passengers.find(({ givenName, familyName }) => {
      return (
        bag.givenName.toLowerCase() === givenName.toLowerCase() &&
        bag.familyName.toLowerCase() === familyName.toLowerCase()
      );
    });
  });
};
