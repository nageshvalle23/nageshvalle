/**
 * converter.js
 *  Convert bags from SITA to CarrierConnect format
 */

exports.convertToCCBags = function(sitaBags) {
  return sitaBags.map(_convertBag);
};

function _convertBag(sitaBag) {
  return {
    bagtag: sitaBag.bagtag,
    givenName: sitaBag.passenger_first_name,
    familyName: sitaBag.passenger_last_name,
    rushIndicator: sitaBag.rush_bag_indicator,
    rushTag: sitaBag.rushtag,
    events: sitaBag.events.map(_eventMapper),
  };
}

function _eventMapper(event) {
  return {
    location: event.airport,
    time: event.utc_date_time,
    code: event.event_code,
    description: event.event_desc,
  };
}
