/* eslint-env mocha */
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);
const assert = chai.assert;

describe('Helper functions for SITA bag integrations', () => {
  const module = require('../helpers');

  describe('Filter results by passenger', () => {
    beforeEach(() => {});

    const sampleBags = [
      { bagTag: '12345', givenName: 'Carrier', familyName: 'Connect' },
      { bagTag: '12346', givenName: 'Bus', familyName: 'Connect' },
      { bagTag: '12347', givenName: 'Train', familyName: 'Connect' },
      { bagTag: '12348', givenName: 'Carrier', familyName: 'Connect' },
      { bagTag: '12349', givenName: 'Boat', familyName: 'Connect' },
    ];

    it('should return a filtered array of bags', done => {
      // Weird caps to check name comparison
      const passengers = [
        { givenName: 'Carrier', familyName: 'COnnect' },
        { givenName: 'BUS', familyName: 'Connect' },
      ];

      const expectedBags = [
        { bagTag: '12345', givenName: 'Carrier', familyName: 'Connect' },
        { bagTag: '12346', givenName: 'Bus', familyName: 'Connect' },
        { bagTag: '12348', givenName: 'Carrier', familyName: 'Connect' },
      ];

      const filteredBags = module.filterBagByPax(sampleBags, passengers);

      assert.deepEqual(expectedBags, filteredBags);
      return done();
    });

    it('should return all bags if no filter pax specificed', done => {
      // filter null
      let passengers;
      const filteredBagsNull = module.filterBagByPax(sampleBags, passengers);
      assert.deepEqual(sampleBags, filteredBagsNull);

      // empty filter
      passengers = [];
      const filteredBagsEmpty = module.filterBagByPax(sampleBags, passengers);
      assert.deepEqual(sampleBags, filteredBagsEmpty);

      return done();
    });
  });
});
