/* eslint-env mocha */
const proxyquire = require('proxyquire');
const sinon = require('sinon');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);
const assert = chai.assert;

const moduleName = '../index';

describe('CC API interface to SITA REST services', () => {
  const getBagInfo = sinon.stub();
  const filterBagsByPax = sinon.stub();
  const convertToCCBags = sinon.stub();

  const sampleEvent = {
    queryStringParameters: { rloc: 'XYZDEF' },
    body: JSON.stringify({
      flights: [{ date: '2018-06-28' }],
      passengers: [{ givenName: 'Carrier', familyName: 'Connect' }],
    }),
  };

  const module = proxyquire(moduleName, {
    ['./api']: {
      getBagInfo,
    },
    ['./helpers']: {
      filterBagsByPax,
    },
    ['./converter']: {
      convertToCCBags,
    },
  });

  describe('GET bags', () => {
    beforeEach(() => {
      getBagInfo.reset();
      filterBagsByPax.reset();
      convertToCCBags.reset();
    });

    it('should return 400 if request params are missing', async () => {
      // No rloc
      let event = {
        queryStringParameters: {},
        body: JSON.stringify({
          flights: [{ date: '2018-06-28' }],
          passengers: [{ givenName: 'Carrier', familyName: 'Connect' }],
        }),
      };

      const res1 = await module.bags(event);
      assert.equal(res1.statusCode, 400);

      // No pax lookup
      event = {
        queryStringParameters: { rloc: 'XYZDEF' },
        body: JSON.stringify({
          flights: [{ date: '2018-06-28' }],
        }),
      };

      const res2 = await module.bags(event);
      assert.equal(res2.statusCode, 400);

      // No flight lookup
      event = {
        queryStringParameters: { rloc: 'XYZDEF' },
        body: JSON.stringify({
          passengers: [{ givenName: 'Carrier', familyName: 'Connect' }],
        }),
      };

      const res3 = await module.bags(event);
      assert.equal(res3.statusCode, 400);
    });

    it('should return 503 if there is a problem with the sita services', async () => {
      let event = Object.assign({}, sampleEvent);
      getBagInfo.throws('Gateway timeout');

      const res = await module.bags(event);
      assert.equal(res.statusCode, 500);
    });

    it('should use the most recent departure date to get bag data', async () => {
      let event = Object.assign({}, sampleEvent);
      filterBagsByPax.returns({ bags: [] });

      const res = await module.bags(event);
      assert.equal(res.statusCode, 200);
      assert.equal(res.body, JSON.stringify({ bags: [] }));
    });

    it('should return bag tracking data', async () => {
      let event = {
        queryStringParameters: { rloc: 'XYZDEF' },
        body: JSON.stringify({
          flights: [{ date: '2018-06-29' }, { date: '2018-06-28' }],
          passengers: [{ givenName: 'Carrier', familyName: 'Connect' }],
        }),
      };

      const res = await module.bags(event);

      assert.isTrue(getBagInfo.calledWith('XYZDEF', '2018-06-29'));
    });
  });
});
