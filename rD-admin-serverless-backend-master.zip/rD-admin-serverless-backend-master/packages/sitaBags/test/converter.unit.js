/* eslint-env mocha */
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);
const assert = chai.assert;

describe('Convert SITA bags to CC format', () => {
  const module = require('../converter');

  describe('Convert', () => {
    beforeEach(() => {});

    const sitaBags = [
      {
        bagtag: '123456',
        passenger_first_name: 'HEATH',
        passenger_last_name: 'DAVIS',
        rush_bag_indicator: 'N',
        rushtag: 'Y',
        events: [
          {
            airport: 'MXP',
            utc_date_time: '2013-08-22T13:00:00Z',
            event_code: 'EXPECTED',
            event_desc: 'Bag Expected',
          },
        ],
      },
      {
        bagtag: '123457',
        passenger_first_name: 'HEATH',
        passenger_last_name: 'DAVIS',
        rush_bag_indicator: 'N',
        rushtag: 'Y',
        events: [
          {
            airport: 'MXP',
            utc_date_time: '2013-08-22T13:00:00Z',
            event_code: 'EXPECTED',
            event_desc: 'Bag Expected',
          },
        ],
      },
    ];

    const expectedConvertedBags = [
      {
        bagtag: '123456',
        givenName: 'HEATH',
        familyName: 'DAVIS',
        rushIndicator: 'N',
        rushTag: 'Y',
        events: [
          {
            location: 'MXP',
            time: '2013-08-22T13:00:00Z',
            code: 'EXPECTED',
            description: 'Bag Expected',
          },
        ],
      },
      {
        bagtag: '123457',
        givenName: 'HEATH',
        familyName: 'DAVIS',
        rushIndicator: 'N',
        rushTag: 'Y',
        events: [
          {
            location: 'MXP',
            time: '2013-08-22T13:00:00Z',
            code: 'EXPECTED',
            description: 'Bag Expected',
          },
        ],
      },
    ];

    it('should conver SITA bags to CC bag format', done => {
      const convertedBags = module.convertToCCBags(sitaBags);
      assert.deepEqual(convertedBags, expectedConvertedBags);
      done();
    });
  });
});
