/* eslint-env mocha */
const proxyquire = require('proxyquire');
const sinon = require('sinon');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);
const assert = chai.assert;

const moduleName = '../api';

describe('Service for interacting with SITA API', () => {
  const axios = sinon.stub();

  const module = proxyquire(moduleName, {
    ['axios']: axios,
  });

  describe('Get Bag Data', () => {
    beforeEach(() => {
      axios.reset();
    });

    it('should return bag tags with events', async () => {
      const expectedBags = [
        {
          bagTag: '12345',
          events: [],
        },
      ];
      axios
        .onFirstCall()
        .returns({ success: true, bags: [{ bagTag: '12345' }] });
      axios
        .onSecondCall()
        .returns({ success: true, events: [] });

      const bags = await module.getBagInfo('12345', '2019-06-25');

      assert.deepEqual(bags, expectedBags);
    });

    it('should throw an error if SITA api call fails', async () => {
      axios.throws('Internal Server Error');
      await assert.isRejected(
        module.getBagInfo('12345', '2018-06-24'),
        'Sita Error'
      );
    });

    it('should throw an error if bag retrieval fails or has errors', async () => {
      // failures to retrieve bags
      axios
        .onFirstCall()
        .returns({success: false, bags: [], });
      await assert.isRejected(
        module.getBagInfo('12345', '2018-06-24'),
        'Sita Error'
      );

      axios.reset();

      // partial success
      axios
        .onFirstCall()
        .returns({success: true, errors: [{error: 'partial failure'}], bags: [], });
      await assert.isRejected(
        module.getBagInfo('12345', '2018-06-24'),
        'Sita Error'
      );
    });

    it('should throw an error if bag history fails or has errors', async () => {
      axios
        .onFirstCall()
        .returns({ success: true, bags: [{ bagTag: '12345' }] });
      axios
        .onSecondCall()
        .returns({ success: false, events: [] });
      await assert.isRejected(
        module.getBagInfo('12345', '2018-06-24'),
        'Sita Error'
      );

      axios.reset();

      // partial success
      axios
        .onFirstCall()
        .returns({ success: true, bags: [{ bagTag: '12345' }] });
      axios
        .onSecondCall()
        .returns({
          success: true,
          errors: [{ error: 'partial failure' }],
          events: [],
        });
      await assert.isRejected(
        module.getBagInfo('12345', '2018-06-24'),
        'Sita Error'
      );
    });
  });
});
