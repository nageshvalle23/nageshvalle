/**
 * SITA Bag tracking api integration
 */
const { response, params, body } = require('@oneworld-digital/integration-utils').request;
const { getBagInfo } = require('./api');
const { filterBagsByPax } = require('./helpers');
const { convertToCCBags } = require('./converter');

exports.bags = async event => {
  try {
    // Parse lookup data from request
    const { rloc } = params(event);
    const { passengers, flights } = body(event);

    if (
      typeof rloc !== 'string' ||
      !_checkFlights(flights) ||
      !_checkPax(passengers)
    ) {
      return response(400, 'Missing request parameters');
    }

    const allBags = convertToCCBags(
      await getBagInfo(rloc, _mostRecentDeparture(flights))
    );

    const paxBags = filterBagsByPax(allBags, passengers);

    return response(200, paxBags);
  } catch (err) {
    return response(500);
  }
};

function _checkFlights(flights) {
  return (
    Array.isArray(flights) &&
    flights.length > 0 &&
    flights.every(f => typeof f.date === 'string')
  );
}

function _checkPax(passengers) {
  return (
    Array.isArray(passengers) &&
    passengers.every(pax => {
      return (
        typeof pax.givenName === 'string' && typeof pax.familyName === 'string'
      );
    })
  );
}

function _mostRecentDeparture(flights) {
  const sortedFlights = flights.sort(
    (f1, f2) => new Date(f1.date) - new Date(f2.date)
  );

  return sortedFlights[sortedFlights.length - 1].date;
}
