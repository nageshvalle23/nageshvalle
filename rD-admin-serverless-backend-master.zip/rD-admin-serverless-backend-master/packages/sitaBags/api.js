/**
 * api.js
 */
const axios = require('axios');

const SITA_API_URL = process.env.SITA_URL || '';
const SITA_API_KEY = process.env.SITA_KEY || '';

exports.getBagInfo = async (rloc, flightDate) => {
  try {
    const bags = await _getBagTags(rloc, flightDate);
    return await Promise.all(bags.map(b => _getBagHistory(b, flightDate)));
  } catch (err) {
    throw new Error('Sita Error');
  }
};

async function _getBagTags(rloc, flightDate) {
  const res = await axios({
    method: 'GET',
    url:
      SITA_API_URL +
      `/bagsforpassenger/v1.0/pnr/${rloc}/dep_flight_date/${flightDate}`,
    headers: {
      api_key: SITA_API_KEY,
    },
  });

  if (!res.success || (Array.isArray(res.errors) && res.errors.length)) {
    console.error(`Problem retrieving bags from sita: ${res.errors}`);
    throw new Error('Sita Error');
  }

  return res.bags;
}

async function _getBagHistory(bag, flightDate) {
  let res = await axios({
    method: 'GET',
    url:
      SITA_API_URL + `/history/v1.0/tag/${bag.bagTag}/flightdate/${flightDate}`,
    headers: {
      api_key: SITA_API_KEY,
    },
  });

  if (!res.success || (Array.isArray(res.errors) && res.errors.length)) {
    console.error(`Problem retrieving bags from sita: ${res.errors}`);
    throw new Error('Sita Error');
  }

  return Object.assign(bag, { events: res.events });
}
