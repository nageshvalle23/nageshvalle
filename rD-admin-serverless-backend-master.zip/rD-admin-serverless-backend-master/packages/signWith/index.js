const AWS = require('aws-sdk');
const kms = new AWS.KMS();
const dlv = require('dlv');

exports.handler = async (event, context, callback) => {
  const body = JSON.parse(event.body);

  const blob = body.blob;

  if (!(blob && /.+/.test(blob))) {
    return callback(null, {
      statusCode: 403
    })
  }
  try {
    const plainText = await decryptBlob(blob);
    return callback(null, {
      statusCode: 200,
      body: JSON.stringify({
        key: plainText
      }),
      headers: {
        'Content-Type':'application/json'
      }
    });
  } catch (err) {
    return callback(null, {statusCode: 403})
  }
};

async function decryptBlob (blob) {
  /* blob comes in base64 encoded */
  const data = await kms.decrypt({
    CiphertextBlob: Buffer.from(blob, 'base64')
  }).promise();

  return data.Plaintext.toString('base64');
}
