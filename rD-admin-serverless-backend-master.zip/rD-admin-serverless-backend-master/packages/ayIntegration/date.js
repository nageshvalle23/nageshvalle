function getDateParts (d) {
  const pad = n => n < 10 ? '0' + n : n + ''

  const year = d.getFullYear() + ''
  const month = pad(d.getMonth() + 1)
  const date = pad(d.getDate())
  const hours = pad(d.getHours())
  const mins = pad(d.getMinutes())

  return [year, month, date, hours, mins]
}

exports.toSimpleDate = function (d) {
  return getDateParts(d).slice(0, 3).join('')
}

exports.toLookupDate = function (d) {
  if (d) {
    return getDateParts(d).slice(0, 3).join('-')
  }
}

exports.toCcDateTime = function (d) {
  if (d) {
  const dateParts = getDateParts(d);
  return dateParts.slice(0, 3).join('-') + ' ' +
         dateParts.slice(3, 5).join(':')
  }
}
