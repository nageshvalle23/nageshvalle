const _ = require('lodash');
const proxyquire = require('proxyquire').noPreserveCache();
const sinon = require('sinon');

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const assert = chai.assert;

const moduleName = '../api'

const placeholderStub = fnName => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = customStubs => _.defaults({}, customStubs, {
  ['axios']: placeholderStub('params')
});

describe('API for AY DCS integration', () => {
  const axios = sinon.stub();

  describe('getBooking', () => {
    beforeEach(() => {
      axios.reset();
    });

    it('should return a properly formatted booking object', async () => {
      process.env.API_URL = 'http://foo.bar'
      process.env.KEY_ID = 'foobar'

      const m = proxyquire(moduleName, createStubs({
        ['axios']: axios
      }))

      const res = {
        data: {
          recLoc: 'abc123'
        }
      }

      axios.returns(res)

      const booking = await m.getBooking('abc123', 'smith')

      assert(axios.calledOnce)

      assert.deepEqual(booking, {recLoc: 'abc123'})
    });

    it('should throw an error if the env vars are not set', async () => {
      process.env.API_URL = ''
      process.env.KEY_ID = ''
      const m = proxyquire(moduleName, createStubs({
        ['axios']: axios
      }))
      assert.isRejected(m.getBooking('abc123', 'smith'))
    });

    it('should throw an error if any params are missing', async () => {
      process.env.API_URL = 'http://foo.bar'
      process.env.KEY_ID = 'foobar'
      const m = proxyquire(moduleName, createStubs({
        ['axios']: axios
      }))
      assert.isRejected(m.getBooking('abc123'))
    });
  })
})
