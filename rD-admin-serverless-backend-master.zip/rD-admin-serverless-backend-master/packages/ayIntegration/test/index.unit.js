const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const assert = chai.assert;
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const moduleName = '../index'

const placeholderStub = fnName => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = customStubs => _.defaults({}, customStubs, {
  ['@oneworld-digital/integration-utils']: {
    request: {
      params: placeholderStub('params'),
      response: placeholderStub('response')
    }
  },

  ['./converter']: {
    execute: placeholderStub('execute')
  },

  ['./api']: {
    getBooking: placeholderStub('getBooking')
  }
});

describe('CC API interface to AY REST services', () => {
  const params = sinon.stub();
  const response = sinon.stub();
  const getBooking = sinon.stub();

  const bookingConverter = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    ['./api']: {
      getBooking
    },
    ['@oneworld-digital/integration-utils']: {
      request: {
        params,
        response
      }
    },
    ['./converter']: {
      execute: bookingConverter
    }
  }))

  describe('GET a record', () => {

    beforeEach(() => {
      params.reset()
      response.reset()
      bookingConverter.reset()
    });

    it('should return 500 if getBooking fails', async () => {
      const qs = {
        rLoc: 'bar123',
        familyName: 'foo'
      }

      params.returns(qs);

      getBooking.throws(new Error('AY error'))

      const event = {
        queryStringParameters: qs
      };

      const cb = sinon.spy();
      await m.record(event, {}, cb)

      assert(cb.calledOnce)
      assert(response.calledWith(500))
    });

    it('should return 500 if the convererter fails', async () => {
      const qs = {
        rLoc: 'bar123',
        familyName: 'foo'
      }

      params.returns(qs);

      bookingConverter.throws(new Error())

      const event = {
        queryStringParameters: qs
      };

      const cb = sinon.spy();
      await m.record(event, {}, cb)

      assert(cb.calledOnce)
      assert(response.calledWith(500))
    });


    it('should send an OK res', async () => {
      getBooking.returns(require('./mocks/valid-bp'))

      const qs = {
        rLoc: 'bar123',
        familyName: 'foo'
      }

      params.returns(qs);

      const event = {
        queryStringParameters: qs
      };

      const cb = sinon.spy();
      await m.record(event, {}, cb)
      bookingConverter.returns({})

      assert(cb.calledOnce)
      assert(response.calledWith(200))
    });
  });

  describe('checkin', () => {
    beforeEach(() => {
      response.reset()
    });

    it('should return 500 no matter what', async () => {
      const cb = sinon.spy();
      await m.checkin({}, {}, cb)

      assert(cb.calledOnce)
      assert(response.calledWith(500))
    });

  })

  describe('boardingpass', () => {
    beforeEach(() => {
      response.reset()
    });

    it('should return 500 no matter what', async () => {
      const cb = sinon.spy();
      await m.boardingpass({}, {}, cb)

      assert(cb.calledOnce)
      assert(response.calledWith(500))
    });

  })
})
