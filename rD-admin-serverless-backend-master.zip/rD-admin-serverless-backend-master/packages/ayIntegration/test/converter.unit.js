const chai = require('chai');
const assert = chai.assert;

describe('Data conversion functions', () => {
  const m = require('../converter')

  describe('execute', () => {
    it('Should produce a traveler record', () => {
      const booking = require('./mocks/valid-bp')
      const rec = m.execute(booking);

      assert.equal(rec.pnr.rloc, 'OE5XRB')
      assert.equal(rec.pnr.passengers.length, 2)
      assert.equal(rec.pnr.flights.length, 2)
    })

    it('Should throw an error if the booking comes back malformed', () => {
      const booking = {}
      assert.throws(() => m.execute({
        passengers: [],
        journeys: []
      }))
    })
  })
});
