const utils = require('integration-utils');
const svc = require('./index');

svc.record(
  {
    queryStringParameters: {
      familyName: 'mylastname',
      rloc: 'PSHKIQ'
    }
  },
  null,
  (err, response) => {
    console.log(JSON.stringify(JSON.parse(response.body), null, '  '))
  });
