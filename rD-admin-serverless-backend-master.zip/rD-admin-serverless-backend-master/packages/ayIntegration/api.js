const axios = require('axios')

const KEY_ID = process.env.KEY_ID // TODO: <<<<<<<<<< set this via env var
const API_URL = process.env.API_URL // 'https://api-preprod.finnair.com/a/booking-service/api/booking'

// '/OGBBDZ/JAMES?includePassbooks=true'

exports.getBooking = async (rloc, familyName) => {
  if (!KEY_ID || !API_URL) {
    throw new Error('api not configured properly')
  }

  if (!rloc || !familyName) {
    throw new Error('Missing required params')
  }

  const res = await _gatherAndReportErrors(axios({
    method: 'get',
    url: API_URL + '/' + rloc + '/' + familyName,
    headers: {
      accept: 'application/json',
      'x-api-key': KEY_ID
    },
    params: {
      includePassbooks: true
    }
  }))

  return res.data
}


async function _gatherAndReportErrors(promisedApiCall) {
  var err = new Error('AY error');
  var res;
  
  try {
    res = await promisedApiCall;

    // TODO: do we ever get more than one of these back?
    if (res.data && res.data.errorObject && Array.isArray(res.data.errorObject)) {
      err.CARRIER_ERROR_MESSAGE = res.data.errorObject[0].errorDescription;
      err.CARRIER_ERROR_CODE = res.data.errorObject[0].errorName;
    }
  } catch (axiosError) {
    err.CARRIER_ERROR_MESSAGE = axiosError.response.data.error;
    err.CARRIER_ERROR_CODE = axiosError.response.status;
  }

  if (!res) {
    console.error('Error occured with carrier', err);
    throw err;
  }
  return res;
}

