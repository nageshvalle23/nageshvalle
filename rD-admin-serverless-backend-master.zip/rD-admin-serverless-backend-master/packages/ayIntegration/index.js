const uuid = require('uuid/v1');
const converter = require('./converter')
const api = require('./api')

const {response, params} = require('@oneworld-digital/integration-utils').request;

exports.record = async (event, context, cb) => {
  try {
    const {familyName, rloc} = params(event)

    const booking = await api.getBooking(rloc, familyName)

    const travelerRecord = converter.execute(booking)

    cb(null, response(200, travelerRecord))
  } catch (err) {
    return _handleErrors(err, cb);
  }
}

exports.boardingpass = async (event, context, cb) => {
  return _handleErrors(new Error('Boarding Pass - Not Implemented'), cb);
}

exports.checkin = async (event, context, cb) => {
  return _handleErrors(new Error('CheckIn - Not Implemented'), cb);
}

function _handleErrors(err, cb) {
  const body = {
    id: uuid(),
    message: err.CARRIER_ERROR_MESSAGE || err.message,
    type: err.CARRIER_ERROR_CODE ? 'OA' : 'Internal',
    code: err.CARRIER_ERROR_CODE || '500',
  };

  let responseCode;
  if (err.CARRIER_ERROR_MESSAGE && err.CARRIER_ERROR_CODE) {
    responseCode = 502;
  } else {
    responseCode = 500;
  }

  console.error(`Request failed with status ${responseCode} and body ${JSON.stringify(body, null, 2)}`);
  return cb(null, response(responseCode, body));
}
