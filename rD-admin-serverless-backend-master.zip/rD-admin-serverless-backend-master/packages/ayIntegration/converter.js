const dlv = require('dlv');
const dateUtil = require('./date')
const joda = require("js-joda");

exports.execute = function (booking) {
  const flights = extractFlights(booking)
  const paxs = extractPaxs(booking)

  let record = {
    pnr: {
      rloc: booking.recLoc,
      flights: Object.keys(flights).map(k => ayDataToCcFlight(flights[k])),
      passengers: Object.keys(paxs).map(k => ayDataToCcPax(paxs[k], flights))
    }
  }

  const {pnr} = record

  if (!pnr.rloc || !pnr.passengers.length || !pnr.flights.length) {
    throw new Error('Failed to produce a valid record')
  }

  return record
}

function ayDataToCcFlight (ayFlight) {
  console.error('ayDataToCcFlight ayFlight.departure.scheduledDateTime' + ayFlight.departure.scheduledDateTime);
  const parsedLocalTime = convertZonedDateTimeToLocal(ayFlight.departure.scheduledDateTime);
  console.error(' lookup date', dateUtil.toLookupDate(parsedLocalTime))

  return {
    origin: ayFlight.departure.airport,
    destination: ayFlight.arrival.airport,
    flightNumber: ayFlight.flightNumber,
    carrier: ayFlight.marketingAirline,
    date: dateUtil.toLookupDate(parsedLocalTime)
  }
}

function ayDataToCcPax (ayPax, ayFlights) {
  const ticketNumber = ayPax.passengerFlightInfos[0].ticketNumber
  return {
    familyName: ayPax.lastName,
    givenName: ayPax.firstName,
    title: '',
    ageCategory: '',
    coupons: ayPax.passengerFlightInfos.map(c => ayDataToCcCoupon(c, ayFlights, ticketNumber))
  }
}

function ayDataToCcCoupon (ayCoupon, ayFlights, ticketNumber) {
  const flight = ayFlights[ayCoupon.flightUniqueId]
  const checkedIn = isCheckedIn(ayCoupon)

  console.error('ayDataToCcCoupon flight.departure.scheduledDateTime' + flight.departure.scheduledDateTime);
  const parsedLocalTime = convertZonedDateTimeToLocal(flight.departure.scheduledDateTime);
  console.error(' cc date time', dateUtil.toCcDateTime(parsedLocalTime))

  const coupon = {
    origin: flight.departure.airport,
    destination: flight.arrival.airport,
    flightNumber: flight.flightNumber,
    eTicketNumber: ticketNumber,
    carrier: flight.marketingAirline,
    isCheckedIn: checkedIn,                   // TODO: what is the default checkin status?
    isCheckInInhibited: false,                       // TODO: is this data point in AY PNR?
    departureDateTime: dateUtil.toCcDateTime(parsedLocalTime)
  }

  if (checkedIn) {
    coupon.boardingPass = ayDataToCcBp(ayCoupon, flight)
  }

  return coupon
}

function ayDataToCcBp (ayCoupon, ayFlight) {
  console.error("ayDataToCcBp ayFlight.departure.boardingTime" + ayFlight.boarding.boardingDateTime);
  const parsedLocalTime = convertZonedDateTimeToLocal(ayFlight.boarding.boardingDateTime);
  console.error('cc date time ', dateUtil.toCcDateTime(parsedLocalTime))

  return {
    barcodeData:
    dlv(ayCoupon, ['boardingPass', 'boardingBarCode'].join('.')),

    // TODO:
    qrCodeData: '',

    seatNumber:
    dlv(ayCoupon, ['seat', 'row'].join('.')) + dlv(ayCoupon, ['seat', 'col'].join('.')),

    passengerClass: ayCoupon.fareClass,

    boardingTime:
    dateUtil.toCcDateTime(parsedLocalTime),

    eTicketNumber:
    dlv(ayCoupon, ['boardingPass', 'eTicketNumber'].join('.')),

    // TODO:
    frequentFlierNumber: '',

    sequenceNumber:
    dlv(ayCoupon, ['boardingPass', 'checkinSequenceNumber'].join('.')),

    // TODO:
    iOSPassbookFile: '',

    gate:
    dlv(ayFlight, ['boarding', 'gate']),

    terminal:
    dlv(ayFlight, ['departure', 'terminal']),

    securityNumber:
    dlv(ayCoupon, ['checkInInfo', 'securityNumber'].join('.')),

    boardingGroup:
    dlv(ayCoupon, ['boardingPass', 'boardingGroup'].join('.')),

    // TODO:
    allowTSA: '',
    allowFastTrack: ''
  }
}

function isCheckedIn (ayCoupon) {
  // TODO : is this valid? what are actual values for checkinStatus field?
  return ayCoupon.checkinStatus === 'CHECKED_IN'
}

function extractFlights (booking) {
  return booking.journeys.reduce((source, j) => {
    j.flights.forEach(f => {
      // save the source because it's used later for coupons
      source[f.uniqueId] = f
    })
    return source
  }, {})
}

function extractPaxs (booking) {
  return booking.passengers.reduce((source, pax) => {
    source[pax.passengerNum] = pax
    return source
  }, {})
}

function convertZonedDateTimeToLocal (dateTime) {
  if (dateTime) {
    const flightDateTime = joda.ZonedDateTime.parse(dateTime);
    const parsedLocalTime = flightDateTime.toLocalDateTime().toString();
    console.error('parsed ', new Date(parsedLocalTime))
    return new Date(parsedLocalTime);
  } 
}