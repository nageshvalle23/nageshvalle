const api = require('./index');

const rloc = process.argv[2];
const family  = process.argv[3];
const given = process.argv[4];
const checkinVal = process.argv[5] === 'true'
const lookup = {
  rloc: rloc || 'S3M4IL',
  givenName: given || 'CARRIER',
  familyName: family || 'CONNECT',
  targetAirlineCode: 'CX',
  requestingCarrier: 'QR'
}

console.log(`Getting record for lookup: ${JSON.stringify(lookup, null, 2)}`)
const event = {
  queryStringParameters: lookup,
  body: null
}


const res = api.record(event, {}, (err, res) => {
  const body = JSON.parse(res.body);
  console.log(JSON.stringify(body, null, 2));

  const flightLookups = body.pnr.flights;
  const passengerLookups = body.pnr.passengers.map((pax) => {
    return {
      familyName: pax.familyName,
      givenName: pax.givenName,
      ticketNumber: 'null'
    }
  })

  const requirements = {acknowledgeDGTerms: true};
  const checkIn = checkinVal;
  event.body = JSON.stringify({ passengerLookups, flightLookups, requirements, checkIn }, null, 2);

  console.log('>>>>>>>>>>>>>>>>>>>>>>>')
  console.log('')
  console.log('')
  console.log('')
  console.log('')
  console.log(`Trying to check in lookup: ${event.body}`);

  api.checkin(event, {}, (err, res2) => {
    console.log(JSON.stringify(JSON.parse(res2.body), null, 2));
  }).then(() => {});

}).then(() => {})
