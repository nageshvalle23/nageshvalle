const uuid = require('uuid/v1');
const api = require('./api');
const flifoApi = require('./flifo/api');
const convertToFlight = require('./flifo/converter')
const {convertToRecord} = require('./converter');
const warmer = require("lambda-warmer");

const {params, body, response} = require('@oneworld-digital/integration-utils').request;
const {isV2Request, convertToV1Params, convertToV1Body, v1RecordToV2Record}= require('@oneworld-digital/integration-utils').versionConverter;

exports.record = async (event, context, cb) => {
  try {
    const isV2 = isV2Request(event);

    // Parse lookup data from request
    let {givenName, familyName, rloc, targetAirlineCode, requestingCarrier} = isV2 ? convertToV1Params(body(event)) : params(event);

    const lookup = {givenName, familyName, rloc, targetAirlineCode};

    if (!requestingCarrier) {
      requestingCarrier = event.headers['x-client-carrier'];
    }

    // Login and get journey information
    const {journeys} = await api.login(lookup, requestingCarrier);

    // Transform journey to Record
    let record = convertToRecord(journeys, lookup);

    if (isV2) {
      record = v1RecordToV2Record(record);
    }

    // Send back the journey!
    return cb(null, response(200, record));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.checkin = async (event, context, cb) => {
  try {
    const isV2 = isV2Request(event);

    // Parse lookup + checkin data from request
    let {givenName, familyName, rloc, targetAirlineCode, requestingCarrier} = isV2 ? convertToV1Params(body(event)) : params(event);
    const checkin = isV2 ? convertToV1Body(body(event)) : body(event);

    if (!requestingCarrier) {
      requestingCarrier = event.headers['x-client-carrier'];
    }

    const lookup = {givenName, familyName, rloc, targetAirlineCode};

    // Login and get journey information
    const {journey} = await api.checkIn(lookup, checkin, requestingCarrier);

    // Transform journey to Record
    let record = convertToRecord([journey], lookup);

    if (isV2) {
      record = v1RecordToV2Record(record);
    }

    // Send back the journey!
    return cb(null, response(200, record));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.boardingpass = async (event, context, cb) => {
  try {
    const isV2 = isV2Request(event);

    // Parse request data
    let {givenName, familyName, rloc, targetAirlineCode, requestingCarrier} = isV2 ? convertToV1Params(body(event)) : params(event);

    const boardingpassLookup = isV2 ? convertToV1Body(body(event)) : body(event);

    if (!requestingCarrier) {
      requestingCarrier = event.headers['x-client-carrier'];
    }

    const lookup = {givenName, familyName, rloc, targetAirlineCode};

    const {journey} = await api.boardingPass(lookup, boardingpassLookup, requestingCarrier);

    let record = convertToRecord([journey], lookup);

    if (isV2) {
      record = v1RecordToV2Record(record);
    }

    return cb(null, response(200, record));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

exports.flifo = async (event, context, cb) => {
  try {
    if (await warmer(event)) return "warmed";
    // Parse request data
    const {flightNumber, carrierCode, date, origin, destination} = body(event);

    if (!date || !carrierCode || !flightNumber) {
      const err = new Error()
      err.message = 'Must provide date, carrier and flightNumber in lookup.'

      throw err;
    }

    const { result } = await flifoApi(date, carrierCode, flightNumber)

    let flifoResponse = [];
    if (result.length > 1 && !origin && !destination) {
      flifoResponse = result.map(convertToFlight);
    } else if (result.length > 0) {
      flifoResponse = convertToFlight(result[0]);
    }

    return cb(null, response(200, flifoResponse));
  } catch (err) {
    return _handleErrors(err, cb);
  }
};

function _handleErrors(err, cb) {
  const body = {
    id: uuid(),
    message: (err.CARRIER_ERROR_MESSAGE) ? `Type: ${err.CARRIER_ERROR_MESSAGE}` : err.message,
    type: (err.CARRIER_ERROR_CODE || err.statusCode) ? 'OA' : 'Internal',
    code: err.CARRIER_ERROR_CODE || '500',
  };

  let responseCode;

  // TODO: 502 vs 500 may not be sufficient. Do we need to support 400 and others?
  if (err.CARRIER_ERROR_MSG || err.CARRIER_ERROR_CODE) {
    responseCode = 502;
  } else {
    responseCode = 500;
  }

  console.error(`Could not satisfy request ${JSON.stringify(body, null, 2)}`);
  return cb(null, response(responseCode, body));
}
