const moment = require('moment');

/*
 * cx checkin requests require a journey object for pax/flights to be checked in
 */
exports.formatCheckinRequest = (journeys, checkin) => {
  const journey = findJourneyForLookup(journeys, checkin);

  if (checkin.checkIn === true) {
    return {
      journeyId: journey.journeyId,
      passengers: journey.passengers.map((pax) => (
        {
          uniqueCustomerId: pax.uniqueCustomerId,
          flights: pax.flights.map((flight) => ({
            productIdentifierDID: flight.productIdentifierDID,
            productIdentifierJID: flight.productIdentifierJID,
            exitSeat: flight.seat ? flight.seat.exitSeat : null,
            extraLegRoomSeat: flight.seat ? flight.seat.extraLegRoomSeat : null,
            seatPreference: flight.seatPreference,
          })),
        }
      )),
    };
  }

  return {
    journeyId: journey.journeyId,
    uniqueCustomerIds: journey.passengers.map((pax) => pax.uniqueCustomerId),
  };
};

exports.formatBoardingPassRequest = (journeys, bpLookup) => {
  const journey = findJourneyForLookup(journeys, bpLookup);

  return {
    journeyId: journey.journeyId,
    passengersUniqueCustomerId: journey.passengers.map((pax) => pax.uniqueCustomerId),
  };
};

function findJourneyForLookup(journeys, {passengerLookups, flightLookups}) {
  const matchingJourney = findCxJourneyByFlightLookups(journeys, flightLookups);

  if (!matchingJourney) {
    throw new Error('Could not match specified flight lookups to journey');
  }

  // Filter down to passengers that are in the bpLookup object
  matchingJourney.passengers = matchingJourney.passengers.filter((pax) => {
    return passengerLookups.reduce((match, p) => {
      return match
          || ((p.familyName.toLowerCase()) === pax.familyName.toLowerCase())
          && (p.givenName.toLowerCase() === pax.givenName.toLowerCase());
    }, false);
  });

  return matchingJourney;
}

exports.findJourneyForLookup = findJourneyForLookup;


exports.backfillBpJourney = function (baseJourney, bpJourney) {
  // I'm taking fields missing on bpJourney and filling from the originally returned journey
  const journey = { ...bpJourney }
  journey.passengers = journey.passengers.map((pax, i) => {
    pax.type = baseJourney.passengers[i].type;
    pax.flights = pax.flights.map((flight, j) => {
      flight.assocETicketNumber = baseJourney.passengers[i].flights[j].assocETicketNumber;
      flight.conjunctionETicketNumber = baseJourney.passengers[i].flights[j].conjunctionETicketNumber;
      flight.checkInAccepted = baseJourney.passengers[i].flights[j].checkInAccepted;
      flight.applePassNumber = baseJourney.passengers[i].flights[j].applePassNumber;
      return flight;
    });

    return pax;
  })

  return journey
}

function findCxJourneyByFlightLookups(journeys, flightLookups) {
  for (let journey of journeys) {
    for (let pax of journey.passengers) {
      if (matchLookupToFlights(flightLookups, pax.flights)) {
        return journey;
      }
    }
  }

  return null;
}

function matchLookupToFlights(flightLookups, flights) {
  if (!flightLookups.length) { // edge case: no flight lookups provided
    return false;
  }

  // All flight lookups must match a flight
  return flightLookups.reduce((match, ccFlight) => (
    match && flights.find((cxFlight) => flightLookupMatchesFlight(cxFlight, ccFlight))
  ), true /* initial value for match */);
}

function flightLookupMatchesFlight(cxFlight, ccFlight) {
  return (getFormatedDate(cxFlight.departureTime.cprScheduledTime) === getFormatedDate(ccFlight.date))
    && (cxFlight.operateFlightNumber.toLowerCase() === ccFlight.flightNumber.toLowerCase());
}

function getFormatedDate(time) {
  return moment(time).format('YYYYMMDD');
}

exports.validateLookup = function({familyName, givenName, rloc, targetAirlineCode}) {
  if ((!rloc || !/.+/.test(rloc))
    || (!familyName || !/.+/.test(familyName))
    || (!givenName || !/.+/.test(givenName))) {
    throw new Error('Missing parameters');
  }
};
