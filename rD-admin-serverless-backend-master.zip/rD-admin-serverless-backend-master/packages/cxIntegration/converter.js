const moment = require('moment');
const {validateLookup} = require('./helpers');

exports.convertToRecord = (journeys, lookup) => {
  validateLookup(lookup);

  const flights = extractFlights(journeys);
  const passengers = extractPassengers(journeys);

  const record = {
    lookup: lookup,
    pnr: {
      rloc: lookup.rloc,
      flights: flights,
      passengers: passengers,
    },
    errors: null,
  };

  return record;
};

function extractFlights(journeys) {
  let flights = {};

  for (let journey of journeys) {
    const flightsInJourney = journey.passengers.reduce((flights, pax) => {
      for (let flight of pax.flights) {
        const flightKey = flight.originPort
          + flight.destPort
          + (flight.departureTime.cprScheduledTime || flight.departureTime)
          + flight.operateFlightNumber;
        flights[flightKey] = cxDataToCcFlight(flight);
      }
      return flights;
    }, {});

    flights = Object.assign(flights, flightsInJourney);
  }

  return Object.values(flights);
}

function extractPassengers(journeys) {
  const passengers = {};

  for (let journey of journeys) {
    for (let pax of journey.passengers) {
      const coupons = pax.flights.map(cxFlightToCcCoupon);

      if (!passengers[pax.uniqueCustomerId]) {
        passengers[pax.uniqueCustomerId] = {
          familyName: pax.familyName,
          givenName: pax.givenName,
          title: pax.title,
          ageCategory: pax.type || null,
          coupons: coupons,
        };
      } else {
        passengers[pax.uniqueCustomerId].coupons = passengers[pax.uniqueCustomerId].coupons.concat(coupons);
      }
    }
  }

  return Object.values(passengers);
}

function cxFlightToCcCoupon(cxFlight) {
  const {origin, destination, carrier, flightNumber} = cxDataToCcFlight(cxFlight);
  return {
    isCheckedIn: cxFlight.checkInAccepted,
    isCheckInInhibited: false,
    boardingPass: formatBoardingPass(cxFlight),
    departureDateTime: cxFlight.departureTime.cprScheduledTime || cxFlight.departureTime,
    origin, destination, carrier, flightNumber,
    eTicketNumber: cxFlight.conjunctionETicketNumber || cxFlight.assocETicketNumber,
  };
}

function formatBoardingPass(cxFlight) {
  if (cxFlight.qrCodeString) {
    return {
      barcodeData: cxFlight.barCodeString,
      qrCodeData: cxFlight.qrCodeString,
      seatNumber: cxFlight.seatNum,
      passengerClass: cxFlight.cabinClass,
      boardingTime: cxFlight.boardingTime,
      eTicketNumber: cxFlight.conjunctionETicketNumber || cxFlight.assocETicketNumber,
      frequentFlierNumber: cxFlight.ffpNumber,
      sequenceNumber: '',
      iOSPassbookFile: cxFlight.applePassNumber,
      gate: cxFlight.boardingGate,
      terminal: '',
      securityNumber: cxFlight.securityNumber,
      boardingGroup: '',
      allowTSA: cxFlight.allowTSA,
      allowFastTrack: cxFlight.allowFastTrack,
    };
  }

  return null;
}

function cxDataToCcFlight(cxFlight) {
  const {
    originPort: origin,
    destPort: destination,
    operateCompany: carrier,
    operateFlightNumber: flightNumber,
  } = cxFlight;

  const date = moment(cxFlight.departureTime.cprScheduledTime || cxFlight.departureTime).format('YYYY-MM-DD');

  return {origin, destination, carrier, flightNumber, date};
}
