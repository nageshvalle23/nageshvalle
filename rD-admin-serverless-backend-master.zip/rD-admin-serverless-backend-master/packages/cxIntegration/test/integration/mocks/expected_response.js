module.exports.EXPECTED_RES ={
  statusCode: 200,
  body:
  '{"lookup":{"givenName":"two","familyName":"carrier","rloc":"TTING2","targetAirlineCode":"CX"},"pnr":{"rloc":"TTING2","flights":[{"origin":"HKG","destination":"TPE","carrier":"CX","flightNumber":"474","date":"2017-10-20"}],"passengers":[{"familyName":"test","givenName":"test","title":null,"ageCategory":"A","ticketNumber":null,"coupons":[{"isCheckedIn":true,"isCheckInInhibited":false,boardingPass":null,"departureDateTime":"2017-10-20 08:10","origin":"HKG","destination":"TPE","carrier":"CX","flightNumber":"474"}]}]},"errors":null}',
  headers: { 'Content-Type': 'application/json' }
};

module.exports.EXPECTED_RES_WITH_BP ={
  statusCode: 200,
  body:
  '{"lookup":{"givenName":"two","familyName":"carrier","rloc":"TTING2","targetAirlineCode":"CX"},"pnr":{"rloc":"TTING2","flights":[{"origin":"HKG","destination":"TPE","carrier":"CX","flightNumber":"474","date":"2018-08-29"}],"passengers":[{"familyName":"test","givenName":"test","title":null,"ticketNumber":null,"coupons":[{"isCheckedIn":true,"isCheckInInhibited":false,"boardingPass":{"qrCodeData":"M1TEST/TEST           ETTING2 HKGTPECX 0474 293Y042H0002 163>6320WW7292BCX                                        2A1602359567302 1CX                     20KN8","seatNumber":"42H","passengerClass":"Y","boardingTime":"2017-10-20 07:30","eTicketNumber":0,"frequentFlierNumber":null,"sequenceNumber":"","iOSPassbookFile":null,"gate":null,"terminal":"","securityNumber":"2","boardingGroup":"","allowTSA":false,"allowFastTrack":false},"origin":"HKG","destination":"TPE","carrier":"CX","flightNumber":"474"}]}]},"errors":null}',
  headers: { 'Content-Type': 'application/json' }
};
