module.exports.loginResponse = {"errors":null,"journeys":[{"errors":null,"journeyId":"0","rloc":"TTING2","passengers":[{"errors":null,"uniqueCustomerId":"2301DA05000005F0","title":null,"familyName":"test","givenName":"test","gender":"M","type":"A","age":0,"rloc":"TTING2","loginPax":true,"flights":[{"errors":null,"cabinClass":"Y","subClass":"Y","operateFlightNumber":"474","marketFlightNumber":null,"operateCompany":"CX","marketingCompany":null,"provisional":false,"departureTime":{"cprScheduledTime":"2017-10-20 08:10","cprEstimatedTime":null,"rtfsScheduledTime":"2017-10-20 08:10","rtfsEstimatedTime":"2017-10-20 08:10"},"originPort":"HKG","arrivalTime":{"cprScheduledTime":"2017-10-20 10:00","cprEstimatedTime":null,"rtfsScheduledTime":"2017-10-20 10:00","rtfsEstimatedTime":"2017-10-20 10:00"},"destPort":"TPE","productIdentifierDID":"2301CA040003F32B","productIdentifierJID":null,"seat":{"seatNum":"42H","exitSeat":false,"extraLegRoomSeat":false},"seatPreference":null,"tempSeat":null,"tempSeatPreference":null,"hasPaidSeat":false,"canChangeSeat":true,"hasFOCChargeableSeatRequest":false,"displayOnly":false,"inhibited":false,"travelDoc":{"type":"P","number":"****2321","expiryDate":{"year":"****","month":"01","day":"**","date":"****-01-**"},"issueCountry":"HKG","nationality":"HND","regulatorySurname":"TEST","regulatoryFirstName":"TEST","regulatoryGender":"TVL"},"secTravelDoc":null,"ktnTravelDoc":null,"travelDocVersion":1,"travelDocGroupList":[{"name":"EC","mandatory":false},{"name":"PI","mandatory":true},{"name":"PT","mandatory":true},{"name":"ST","mandatory":false}],"travelDocTypeMap":{"ST":["A","C","V"],"PT":["CD","CT","P"]},"memberTier":null,"fqtvProgram":null,"fqtvNumber":null,"standBy":false,"securityNumber":"HKG-002","checkInAccepted":true,"operatorKey":null,"boardingPassCode":"2C1OjG00_Cu","applePassNumber":"jKa4kHOF0lQTNf_Eoon3pl2QY2Rpo_n8","ferryFlight":false}],"dateOfBirth":{"year":"****","month":"01","day":"**","date":"****-01-**"},"residenceCountry":"HKG","destinationAddress":null,"transit":false,"contacts":{"emailAddress":"TEST@**********","mobileNumber":"2121****","mobileCountryNumber":"852","emergencyContactPerson":null,"emergencyContactNumber":null,"emergencyContactCountryNumber":null},"unlock":false,"clearAll":null,"canChooseExitSeat":true,"travelDocGroupList":[{"name":"EC","mandatory":false},{"name":"PI","mandatory":true},{"name":"PT","mandatory":true},{"name":"ST","mandatory":false}],"staffBooking":false,"inhibitCancelCheckIn":false,"inhibitBP":false,"inhibitChangeSeat":false,"inhibitFFP":false,"displayOnly":false,"boarded":false,"checkInAccepted":true,"standBy":false,"memberProgram":null,"memberTier":null,"isMiceBooking":false,"miceSeatAvailable":false}],"allowSPBP":true,"allowMBP":true,"inhibitUSBP":null,"displayOnly":false,"betweenChekinFlightCloseTime":false}]};

module.exports.checkinResponse = {
    "errors": null,
    "journey": {
        "errors": null,
        "journeyId": "0",
        "rloc": "TTING2",
        "passengers": [
            {
                "errors": null,
                "uniqueCustomerId": "2301DA05000005F0",
                "title": null,
                "familyName": "test",
                "givenName": "test",
                "gender": "M",
                "type": "A",
                "age": 0,
                "dateOfBirth": {
                    "year": "****",
                    "month": "01",
                    "day": "**",
                    "date": "****-01-**"
                },
                "residenceCountry": "HKG",
                "destinationAddress": null,
                "transit": false,
                "rloc": "TTING2",
                "uma": null,
                "ema": null,
                "loginPax": true,
                "flights": [
                    {
                        "errors": [
                            {
                                "errorCode": "W13Z00115",
                                "type": "W",
                                "fieldName": null
                            }
                        ],
                        "cabinClass": "Y",
                        "subClass": "Y",
                        "operateFlightNumber": "474",
                        "marketFlightNumber": null,
                        "operateCompany": "CX",
                        "marketingCompany": null,
                        "provisional": false,
                        "departureTime": {
                            "cprScheduledTime": "2017-10-20 08:10",
                            "cprEstimatedTime": null,
                            "rtfsScheduledTime": "2017-10-20 08:10",
                            "rtfsEstimatedTime": "2017-10-20 08:10"
                        },
                        "originPort": "HKG",
                        "arrivalTime": {
                            "cprScheduledTime": "2017-10-20 10:00",
                            "cprEstimatedTime": null,
                            "rtfsScheduledTime": "2017-10-20 10:00",
                            "rtfsEstimatedTime": "2017-10-20 10:00"
                        },
                        "destPort": "TPE",
                        "seat": {
                            "seatNum": "42H",
                            "requestSeatNum": "41G",
                            "exitSeat": false,
                            "extraLegRoomSeat": false
                        },
                        "seatPreference": null,
                        "tempSeat": {
                            "seatNum": null,
                            "requestSeatNum": null,
                            "exitSeat": false,
                            "extraLegRoomSeat": false
                        },
                        "tempSeatPreference": null,
                        "productIdentifierDID": "2301CA040003F32B",
                        "productIdentifierJID": null,
                        "travelDoc": {
                            "type": "P",
                            "number": "****2321",
                            "expiryDate": {
                                "year": "****",
                                "month": "01",
                                "day": "**",
                                "date": "****-01-**"
                            },
                            "issueCountry": "HKG",
                            "nationality": "HND",
                            "regulatorySurname": "TEST",
                            "regulatoryFirstName": "TEST",
                            "regulatoryGender": "TVL"
                        },
                        "secTravelDoc": null,
                        "ktnTravelDoc": null,
                        "travelDocVersion": 1,
                        "travelDocGroupList": [
                            {
                                "name": "EC",
                                "mandatory": false
                            },
                            {
                                "name": "PI",
                                "mandatory": true
                            },
                            {
                                "name": "PT",
                                "mandatory": true
                            },
                            {
                                "name": "ST",
                                "mandatory": false
                            }
                        ],
                        "travelDocTypeMap": {
                            "ST": [
                                "A",
                                "C",
                                "V"
                            ],
                            "PT": [
                                "CD",
                                "CT",
                                "P"
                            ]
                        },
                        "memberTier": null,
                        "fqtvProgram": null,
                        "fqtvNumber": null,
                        "hasPaidSeat": false,
                        "canChangeSeat": true,
                        "hasFOCChargeableSeatRequest": false,
                        "displayOnly": false,
                        "inhibited": false,
                        "checkInAccepted": true,
                        "standBy": false,
                        "securityNumber": "HKG-002",
                        "operatorKey": null,
                        "boardingPassCode": "2C1OjG00_Cu",
                        "applePassNumber": "jKa4kHOF0lQTNf_Eoon3pl2QY2Rpo_n8",
                        "ferryFlight": false
                    }
                ],
                "staffBooking": false,
                "contacts": {
                    "emailAddress": "TEST@**********",
                    "mobileNumber": "2121****",
                    "mobileCountryNumber": "852",
                    "emergencyContactPerson": null,
                    "emergencyContactNumber": null,
                    "emergencyContactCountryNumber": null
                },
                "unlock": false,
                "travelDoc": null,
                "secTravelDoc": null,
                "clearAll": null,
                "canChooseExitSeat": true,
                "travelDocGroupList": [
                    {
                        "name": "EC",
                        "mandatory": false
                    },
                    {
                        "name": "PI",
                        "mandatory": true
                    },
                    {
                        "name": "PT",
                        "mandatory": true
                    },
                    {
                        "name": "ST",
                        "mandatory": false
                    }
                ],
                "inhibitCancelCheckIn": false,
                "inhibitBP": false,
                "inhibitChangeSeat": false,
                "inhibitFFP": false,
                "displayOnly": false,
                "boarded": false,
                "checkInAccepted": true,
                "standBy": false,
                "memberProgram": null,
                "memberTier": null,
                "isMiceBooking": false,
                "miceSeatAvailable": false,
                "boardingPassSent": true
            }
        ],
        "allowSPBP": true,
        "allowMBP": true,
        "inhibitUSBP": null,
        "displayOnly": false,
        "betweenChekinFlightCloseTime": false
    },
    "hasAcceptedSectorOfRequest": true
};

module.exports.boardingpassResponse = {
    "errors": null,
    "journey": {
        "journeyId": "0",
        "rloc": "KDZSCO",
        "passengers": [
            {
                "uniqueCustomerId": "2301CA8A0000D2F3",
                "title": null,
                "familyName": "test",
                "givenName": "one",
                "loginPax": true,
                "flights": [
                    {
                        "cabinClass": "Y",
                            "operateFlightNumber": "562",
                        "marketFlightNumber": null,
                        "operateCompany": "CX",
                        "marketingCompany": null,
                        "cprScheduledTime": "2018-03-02 08:00",
                        "originPort": "HKG",
                        "destPort": "KIX",
                        "seatNum": "42H",
                        "cprScheduledTime": "2018-03-02 07:30",
                        "boardingGate": null,
                        "securityNumber": "2",
                        "ffpCarrier": null,
                        "ffpNumber": null,
                        "number": 0,
                        "ffpTierLevel": null,
                        "ffpPriorityCode": null,
                        "ffpDisplayTier": null,
                        "qrCodeString": "M1TEST/TEST           ETTING2 HKGTPECX 0474 293Y042H0002 163>6320WW7292BCX                                        2A1602359567302 1CX                     20KN8",
                        "barCodeString": "M1TEST/TEST           ETTING2 HKGTPECX 0474 293Y042H0002 163>6320WW7292BCX                                        2A1602359567302 1CX                     20KN8",
                        "loungeName": null,
                        "operatorKey": null,
                        "applePassNumber": null,
                        "allowTSA": false,
                        "allowFastTrack": false,
                        "ferryFlight": false
                    }
                ]
            }
        ]
    },
    "generatedGMTTime": "2017-10-19 14:45"
};
