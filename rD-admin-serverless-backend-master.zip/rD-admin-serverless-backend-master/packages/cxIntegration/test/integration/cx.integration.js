const chai = require('chai');
const nock = require('nock');
const _ = require('lodash');
var url = require('url');
const assert = chai.assert;


// TODO: pull this out from api so its shared here
const CX_LOGIN_URL = process.env.CX_LOGIN_URL ||
  'https://f1c2d454-00c5-43bc-aa91-4c10b47f8c2b.mock.pstmn.io/olcilogin/v1/bookings';
const CX_CHECKIN_URL = process.env.CX_CHECKIN_URL ||
  'https://f1c2d454-00c5-43bc-aa91-4c10b47f8c2b.mock.pstmn.io/olcicheckin/v1/acceptance';
const {loginResponse, checkinResponse, boardingpassResponse, interlineBpResponse, interlineCkinResponse} = require('./mocks/cx-responses');
const {EXPECTED_RES, EXPECTED_RES_WITH_BP} = require('./mocks/expected_response');

describe('Integration tests for CC interface to CX', () => {
  beforeEach(() => {
    const loginUrl = url.parse(CX_LOGIN_URL);
    nock(loginUrl.host)
      .get(loginUrl.pathname)
      .query({
        txtFamilyName: 'carrier',
        txtGivenName: 'two',
        txtBookingRef: 'TTING2',
        requestingCarrier: 'QR',
        targetAirlineCode: 'CX'
      })
      .reply(200, loginResponse);

    const checkinUrl = url.parse(CX_CHECKIN_URL)
    nock(checkinUrl.host)
      .filteringRequestBody(function(body) {
        return '*';
      })
      .put(checkinUrl.pathname, '*')
      .reply(200, checkinResponse);
  })

  const module = require('../../index');

  const qs = {
    rloc: 'TTING2',
    givenName: 'two',
    familyName: 'carrier',
    requestingCarrier: 'QR',
    targetAirlineCode: 'CX'
  };

  const flightLookups = [
    {
        "origin": "HKG",
        "destination": "TPE",
        "carrier": "CX",
        "flightNumber": "474",
        "date": "2017-10-20"
    }
  ];

  const passengerLookups = [
    {
        "rloc": "TTING2",
        "givenName": "TEST",
        "familyName": "TEST"
    }
  ];

  describe('record', () => {
    it('should respond with a Record object', async () => {
      await module.record({queryStringParameters: qs}, {}, (err, res) => {
        assert.deepEqual(res, EXPECTED_RES);
      });
    });
  });

  describe('checkin', () => {
    it('should respond with a Record object', async () => {
      await module.checkin({queryStringParameters: qs, body: JSON.stringify({flightLookups, passengerLookups})}, {}, (err, res) => {
        assert.deepEqual(res, EXPECTED_RES);
      });
    })
  });

  describe('boardingpass', () => {
    it('should respond with a Record object', async () => {
      await module.boardingpass({queryStringParameters: qs, body: JSON.stringify({flightLookups, passengerLookups})}, {}, (err, res) => {
        assert.deepEqual(res, EXPECTED_RES_WITH_BP);
      });
    })
  });
});
