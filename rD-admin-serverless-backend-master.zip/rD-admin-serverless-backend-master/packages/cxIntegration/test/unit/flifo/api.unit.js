const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const assert = chai.assert;
const expect = chai.expect;

const moduleName = '../../../flifo/api';

const placeholderStub = (fnName) => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = (customStubs) => _.defaults({}, customStubs, {
  ['request-promise']: {
    defaults: placeholderStub('request-promise-defaults'),
  }
});


describe('API for CX Flifo integration', () => {
  const post = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    'request-promise-native': {
      post: post
    }
  }));

  describe('flifo', () => {
    it('should return an empty array for lookups that return no matching flight', async () => {
      post.resolves({result: []});
      await expect(m('foo', 'bar', 'baz'))
        .to.be.eventually
        .eql({result: []})
    })

    it('should reject if post fails for any reason', async () => {
      post.rejects('WHATEVER');
      await expect(m('foo', 'bar', 'baz'))
        .to.be.eventually
        .rejectedWith()
        .and.be.instanceOf(Error);
    })

    it('should reject if response contains errors', async () => {
      post.resolves({errors: ['foo']});
      await expect(m('foo', 'bar', 'baz'))
        .to.be.eventually
        .rejectedWith()
        .and.be.instanceOf(Error);
    })

    it('should return the response object', async () => {
      post.resolves({result: ['foo']});
      await expect(m('foo', 'bar', 'baz'))
        .to.be.eventually
        .eql({result: ['foo']})
        //.and.be.instanceOf(Error);
    })
  })
});
