const chai = require('chai');

const assert = chai.assert;
const expect = chai.expect;

const moduleName = '../../../flifo/converter';

const m = require(moduleName);

describe('Converter for CX Flifo integration', () => {
  describe('converter multi-sector', () => {
    const res = require('./mocks/res-a.json');

    it('Should contain three sectors', async () => {
      const flight = m(res.result[0]);
      expect(flight.sectors.length).to.be.equal(3)
    })

    it('Should contain a valid summary regardless of available dates', async () => {
      const alt = require('./mocks/res-b.json');
      const flight = m(alt.result[0]);

      expect(flight.summary.departure.at.utc).to.not.equal(null)
      expect(flight.summary.arrival.at.utc).to.not.equal(null)
    })
  })
})
