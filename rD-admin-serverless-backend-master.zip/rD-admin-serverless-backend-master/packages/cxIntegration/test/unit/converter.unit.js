const sinon = require('sinon');
const chai = require('chai');
const assert = chai.assert;


const TEST_JOURNEY = require('./mocks/journey_KDZSCO.json');
const EXPECTED_REC = require('./mocks/record_KDZSCO.js');

describe('Convert CX Journeys object to CC Record', () => {

  const lookup = {givenName: 'one', familyName: 'test', rloc: 'KDZSCO', targetAirlineCode: 'CX'};

  const m = require('../../converter');

  describe('convert', () => {
    it('should convert an array of journeys to a valid record', () => {
      const record = m.convertToRecord(TEST_JOURNEY.journeys, lookup);
      assert.deepEqual(record, EXPECTED_REC);
    });

    it('should throw an error if there is a problem with a journey', () => {
      assert.throws(() => {
        const r = m.convertToRecord([{pnr: '123', passengers: [], flights: []}, {}], lookup);
      });
    });

    it('should throw an error if there is a problem with the lookup', () => {
      assert.throws(() => {
        m.convertToRecord(TEST_JOURNEY.journeys, {});
      }, Error, /Missing parameters/);
    });

  });

});
