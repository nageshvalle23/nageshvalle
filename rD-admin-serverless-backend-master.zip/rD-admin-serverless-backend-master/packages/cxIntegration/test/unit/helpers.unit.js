const chai = require('chai');
const assert = chai.assert;

const TEST_JOURNEYS = require('./mocks/journey_KDZSCO.json').journeys;
const EXPECTED_CHECKIN_REQ = require('./mocks/checkin_KDZSCO.json');
const EXPECTED_CANCEL_CHECKIN_REQ = require('./mocks/cancel_checkin_KDZSCO.json');
const EXPECTED_BOARDINGPASS_REQ = require('./mocks/boardingpass_req_KDZSCO.json');

describe('Helper functions for CC -> CX integration', () => {

  const m = require('../../helpers');

  describe('formatCheckinRequest', () => {

    it('should filter a journey by flight/pax lookup', () => {
      const passengerLookups = [{
        rloc: 'KDZSCO',
        givenName: 'one',
        familyName: 'test'
      }];

      const flightLookups = [ // flight lookups need to match a journey exactly
        {
          date: '2018-03-02 15:15',
          flightNumber: '451',
          carrier: 'CX',
          origin: 'NRT',
          destination: 'TPE'
        },
        {
          date: '2018-03-02 19:30',
          flightNumber: '401',
          carrier: 'CX',
          origin: 'TPE',
          destination: 'HKG'
        }
      ];

      assert.deepEqual(m.formatCheckinRequest(TEST_JOURNEYS, {passengerLookups, flightLookups, checkIn: true, requirements: {acknowledgeDGTerms: true}}),
        EXPECTED_CHECKIN_REQ)
    })

    it('should format request body for cancel checkin', () => {
      const passengerLookups = [{
        rloc: 'KDZSCO',
        givenName: 'one',
        familyName: 'test'
      }];

      const flightLookups = [ // flight lookups need to match a journey exactly
        {
          date: '2018-03-02 15:15',
          flightNumber: '451',
          carrier: 'CX',
          origin: 'NRT',
          destination: 'TPE'
        },
        {
          date: '2018-03-02 19:30',
          flightNumber: '401',
          carrier: 'CX',
          origin: 'TPE',
          destination: 'HKG'
        }
      ];

      assert.deepEqual(m.formatCheckinRequest(TEST_JOURNEYS, {passengerLookups, flightLookups, value: false, requirements: {acknowledgeDGTerms: true}}),
        EXPECTED_CANCEL_CHECKIN_REQ)
    })


    it('should throw an error if there is a problem with the journey', () => {
      const passengerLookups = [];
      const flightLookups = [];
      const checkin = {passengerLookups, flightLookups};
      assert.throws(() => {
        m.formatCheckinRequest([{pnr: '123', passengers: [], flights: []}, {pnr:'123'}], checkin);
      });
    });

    it('should throw an error if no flight lookups are provided', () => {
      const passengerLookups = [{
        rloc: 'KDZSCO',
        givenName: 'one',
        familyName: 'test'
      }];

      const flightLookups = [ // flight lookups need to match a journey exactly
        {
          date: '2018-03-02 15:15',
          flightNumber: '451',
          carrier: 'CX',
          origin: 'NRT',
          destination: 'TPE'
        }
      ];
      assert.throws(() => {
        m.formatCheckinRequest(TEST_JOURNEYS, {passengerLookups: [], flightLookups: []})
      }, Error, 'Could not match specified flight lookups to journey');
    });

    it('should throw if there is no journey that matches flight/pax lookups', () => {
      assert.throws(() => {
        m.formatCheckinRequest(TEST_JOURNEYS, {passengerLookups: [], flightLookups: []})
      }, Error, 'Could not match specified flight lookups to journey');
    });

    it('should throw an error if there is a problem with the checkin object', () => {
      assert.throws(() => {
        m.formatCheckinRequest(TEST_JOURNEYS, {})
      }, Error, /Cannot read property/);
    });

  });

  describe('formatBoardingPassRequest', () => {
      const passengerLookups = [{
        rloc: 'KDZSCO',
        givenName: 'one',
        familyName: 'test'
      }];

      const flightLookups = [ // flight lookups need to match a journey exactly
        {
          date: '2018-03-02 15:15',
          flightNumber: '451',
          carrier: 'CX',
          origin: 'NRT',
          destination: 'TPE'
        },
        {
          date: '2018-03-02 19:30',
          flightNumber: '401',
          carrier: 'CX',
          origin: 'TPE',
          destination: 'HKG'
        }
      ];

    it ('should return a formatted boarding pass request', () => {
      assert.deepEqual(m.formatBoardingPassRequest(TEST_JOURNEYS, {passengerLookups, flightLookups}),
        EXPECTED_BOARDINGPASS_REQ);
    });

    it ('should throw an error for bad inputs', () => {
      assert.throws(() => {
        m.formatBoardingPassRequest(TEST_JOURNEYS, {})
      }, Error, /Cannot read property/);
    });

  });

  describe('validateLookup', () => {

    const familyName = 'test';
    const givenName  = 'test';
    const rloc = '12345';
    const targetAirlineCode = 'CX';

    it('should pass if lookup has the expected key/values', () => {
      assert.isUndefined(m.validateLookup({rloc, familyName, givenName, targetAirlineCode}));
    });

    it('should throw an error if lookup does not have the expected key/values', () => {
      assert.throws(() => {
        m.validateLookup({familyName, givenName});
      }, Error, 'Missing parameters');
      assert.throws(() => {
        m.validateLookup({rloc, givenName});
      }, Error, 'Missing parameters');
      assert.throws(() => {
        m.validateLookup({rloc, familyName});
      }, Error, 'Missing parameters');
    });

  });

});
