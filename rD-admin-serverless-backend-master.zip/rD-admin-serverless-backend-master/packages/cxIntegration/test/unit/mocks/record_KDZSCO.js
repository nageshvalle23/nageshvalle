module.exports = {
  "lookup": {
    "rloc": "KDZSCO",
    "familyName": "test",
    "givenName": "one",
    "targetAirlineCode": "CX"
  },
    "pnr": {
      "rloc": "KDZSCO",
      "flights": [
        {
          "origin": "HKG",
          "destination": "KIX",
          "carrier": "CX",
          "flightNumber": "562",
          "date": "2018-03-02"
        },
        {
          "origin": "NRT",
          "destination": "TPE",
          "carrier": "CX",
          "flightNumber": "451",
          "date": "2018-03-02"
        },
        {
          "origin": "TPE",
          "destination": "HKG",
          "carrier": "CX",
          "flightNumber": "401",
          "date": "2018-03-02"
        }
      ],
      "passengers": [
        {
          "familyName": "test",
          "givenName": "one",
          "title": null,
          "ageCategory": "A",
          "coupons": [
            {
              "isCheckedIn": true,
              "isCheckInInhibited": false,
              "boardingPass": null,
              "origin": "HKG",
              "destination": "KIX",
              "carrier": "CX",
              "eTicketNumber": undefined,
              "flightNumber": "562",
              "departureDateTime": "2018-03-02 08:00"
            },
            {
              "isCheckedIn": false,
              "isCheckInInhibited": false,
              "boardingPass": {
                "allowFastTrack": undefined,
                "allowTSA": undefined,
                "barcodeData": undefined,
                "boardingGroup": "",
                "boardingTime": undefined,
                "eTicketNumber": undefined,
                "frequentFlierNumber": undefined,
                "gate": undefined,
                "iOSPassbookFile": null,
                "passengerClass": "Y",
                "qrCodeData": "test string",
                "seatNumber": undefined,
                "securityNumber": null,
                "sequenceNumber": "",
                "terminal": ""
              },
              "origin": "NRT",
              "destination": "TPE",
              "carrier": "CX",
              "flightNumber": "451",
              "eTicketNumber": undefined,
              "departureDateTime": "2018-03-02 15:15"
            },
            {
              "isCheckedIn": false,
              "isCheckInInhibited": false,
              "boardingPass": null,
              "origin": "TPE",
              "destination": "HKG",
              "carrier": "CX",
              "flightNumber": "401",
              "eTicketNumber": undefined,
              "departureDateTime": "2018-03-02 19:30"
            }
          ]
        }
      ]
    },
    "errors": null
}
