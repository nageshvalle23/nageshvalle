const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const assert = chai.assert;
const expect = chai.expect;

const moduleName = '../../api';

const placeholderStub = (fnName) => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = (customStubs) => _.defaults({}, customStubs, {
  ['request-promise']: {
    defaults: placeholderStub('request-promise-defaults'),
  },

  ['./helpers']: {
    formatCheckinRequest: placeholderStub('formatCheckinRequest'),
    formatBoardingPassRequest: placeholderStub('formatBoardingPassRequest'),
    findJourneyForLookup: placeholderStub('findJourneyForLookup'),
  },
});

const journeyResponse = require('./mocks/journey_KDZSCO.json');
const journeyResponse2 = require('./mocks/journey_WJ6EFB.json');
const bpResponse = require('./mocks/boardingpass_response_WJ6EFB.json');
const backfilledJourney = require('./mocks/backfilled_journey_WJ6EFB.json');

describe('API for CX DCS integration', () => {
  const lookup = {givenName: 'test', familyName: 'test', rloc: 'TTING', targetAirlineCode: 'CX'};
  const checkin = {
    passengerLookups: [{}],
    flightLookups: [{}],
    checkIn: true,
    requirements: {
      acknowledgeDGTerms: true,
    },
  };

  const boardingpass = {
    passengerLookups: [{}],
    flightLookups: [{}],
  };

  const get = sinon.stub();
  const put = sinon.stub();
  const post = sinon.stub();
  const setCookie = sinon.stub();
  const jar = () => ({
    setCookie: setCookie,
    _jar: {},
  });
  const cookie = sinon.stub();
  const formatCheckinRequest = sinon.stub();
  const formatBoardingPassRequest = sinon.stub();
  const findJourneyForLookup = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    'request-promise': {
      get: get,
      put: put,
      post: post,
      jar: jar,
      cookie: cookie,
    },

    ['./helpers']: {
      formatCheckinRequest: formatCheckinRequest,
      formatBoardingPassRequest: formatBoardingPassRequest,
      findJourneyForLookup: findJourneyForLookup
    },
  }));

  describe('login', () => {
    it('should return a journeys object', async () => {
      get.resolves({body: journeyResponse});
      const res = await m.login(lookup, 'QR');
      assert.deepEqual(res, journeyResponse);
    });

    it('should throw an error if cx does not send back any journey data', async () => {
      get.resolves({body: {}});
      await expect(m.login(lookup, 'QR')).to.be.eventually
        .rejectedWith('No Journeys')
        .and.be.instanceOf(Error);
    });

    it('should throw an error if the function is not called with the correct params', async () => {
      await expect(m.login({}, 'QR')).to.eventually
        .be.rejectedWith('Missing parameters')
        .and.be.instanceOf(Error);
    });

    it('should throw an error if there was a problem satisfying the request (non-200 response code)', async () => {
      get.rejects(Error('Status code error'));
      await expect(m.login(lookup, 'QR')).to.eventually
        .be.rejectedWith('Status code error')
        .and.be.instanceOf(Error);
    });
  });

  describe('checkIn', () => {
    it('should checkin a journey', async () => {
      get.resolves({body: journeyResponse}); // request to login
      put.resolves(journeyResponse); // request to checkin
      formatCheckinRequest.returns({});
      const res = await m.checkIn(lookup, checkin, 'QR');
      assert.deepEqual(res, journeyResponse);
    });

    it('should cancel checkin for a journey', async () => {
      get.resolves({body: journeyResponse}); // request to login
      put.resolves(journeyResponse); // request to checkin
      formatCheckinRequest.returns({});
      const res = await m.checkIn(lookup, checkin, 'QR');
      assert.deepEqual(res, journeyResponse);
    });

    it('should require DG terms to be acknowledged before checkin', async () => {
      checkin.requirements.acknowledgeDGTerms = false;
      await expect(m.checkIn(lookup, checkin, 'QR')).to.eventually
        .be.rejectedWith('Passengers must acknowledge DG terms to check in')
        .and.be.instanceOf(Error);
    });

    it('should throw an error if it does not receive a valid checkin object', async () => {
      get.resolves({body: {journeys: []}}); // login needs to resolve
      await expect(m.checkIn(lookup, {}, 'QR')).to.eventually
        .be.rejectedWith('Missing parameters')
        .and.be.instanceOf(Error);
    });

    it('should grab cookies from login response and add them to the checkin jar so that olci session persists', async () => {
      checkin.requirements.acknowledgeDGTerms = true;
      get.resolves({headers: {'set-cookie': ['cookiestring;domain=cluster.local']}, body: {journeys: []}});
      put.resolves({body: {journey: [{}]}});
      formatCheckinRequest.returns({});
      const c = {str: 'cookiestring', domain: 'domain'};
      cookie.returns(c);
      await m.checkIn(lookup, checkin, 'QR');
      assert(setCookie.called);
      setCookie.reset();
    });

    it('should return an error if no journeys come back with checkin response', async () => {
      checkin.requirements.acknowledgeDGTerms = true;
      get.resolves({body: journeyResponse}); // request to login
      put.resolves({body: {}});
      formatCheckinRequest.returns({});
      const c = {str: 'cookiestring', domain: 'domain'};
      await expect(m.checkIn(lookup, checkin, 'QR')).to.eventually
        .be.rejectedWith('No Journeys')
        .and.be.instanceOf(Error);
    });
  });

  describe('boardingPass', () => {

    it('should retrieve a boardingpass for a journey', async () => {
      get.resolves({body: journeyResponse2}); // request to login
      post.resolves(bpResponse); // request to boardingpass
      formatBoardingPassRequest.returns({});
      findJourneyForLookup.returns(journeyResponse2.journeys[0]);

      const res = await m.boardingPass(lookup, {
        passengerLookups: [{
          familyName: 'james',
          givenName: 'jesse',
          eTicketNumber: '0012137208513'
        }],
        flightLookups: [
          {
            flightNumber: '251',
            carrier: 'CX',
            origin: 'HKG',
            destination: 'LHR',
            date: '2020-10-14'
          },
          {
            flightNumber: '3175',
            carrier: 'IB',
            origin: 'LHR',
            destination: 'MAD',
            date: '2020-10-15'
          }
        ]
      }, 'QR');

      assert.deepEqual(res, backfilledJourney);
    });

    it('should throw an error if it does not get a valid lookup object', async () => {
      await expect(m.boardingPass({}, boardingpass, 'QR')).to.eventually
                                                          .be.rejectedWith('Missing parameters')
                                                          .and.be.instanceOf(Error);
    });

    it('should throw an error if it does not receive a valid checkin object', async () => {
      get.resolves({body: {journeys: []}}); // login needs to resolve
      await expect(m.boardingPass(lookup, {}, 'QR')).to.eventually
                                                    .be.rejectedWith('Missing parameters')
                                                    .and.be.instanceOf(Error);
    });
  });
});
