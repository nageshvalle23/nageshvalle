const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const assert = chai.assert;
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const moduleName = '../../index'

const placeholderStub = fnName => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = customStubs => _.defaults({}, customStubs, {
  ['@oneworld-digital/integration-utils']: {
    request: {
      body: placeholderStub('body'),
      params: placeholderStub('params'),
      response: placeholderStub('response')
    }
  },

  ['./converter']: {
    convertToRecord: placeholderStub('convertToRecord')
  },

  ['./api']: {
    login: placeholderStub('retrieveSession'),
    checkIn: placeholderStub('checkIn'),
    boardingPass: placeholderStub('boardingpass')
  }
});

describe('CC interface to CX api services', () => {
  const params = sinon.stub();
  const body = sinon.stub();
  const response = sinon.stub();

  const convertToRecord = sinon.stub();

  const login = sinon.stub();
  const checkIn = sinon.stub();
  const boardingPass = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    ['./api']: {
      login,
      checkIn,
      boardingPass
    },
    ['@oneworld-digital/integration-utils']: {
      request: {
        body,
        params,
        response
      }
    },
    ['./converter']: {
      convertToRecord
    }
  }));

  describe('GET a record', () => {

    let qs, event;
    before(() => {
      qs = {
        rLoc: 'test',
        givenName: 'test',
        familyName: 'test',
        carrier: 'QR'
      }
    });


    it('should respond with 400 bad req if api.login throws an error', async () => {
      params.returns(qs);

      event = {
        queryStringParameters: qs,
        headers: []
      };

      const cb = sinon.spy();

      login.rejects('Error');
      const res = await m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });

    it('should return a record and 200 response', async () => {
      params.returns(qs);

      event = {
        queryStringParameters: qs,
        headers: []
      };

      login.resolves({journeys:[]})
      convertToRecord.resolves({record: {}});

      const cb = sinon.spy();

      await m.record(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200));
    });
  });

  describe('checkIn', () => {
    let qs, event;
    before(() => {
      qs = {
        rLoc: 'test',
        givenName: 'test',
        familyName: 'test',
        carrier: 'QR'
      };
    });

    it('should check passengers in and respond with 200', async () => {
      checkIn.resolves({journey: []});
      convertToRecord.returns({pnr: '12345'});

      params.returns(qs);
      body.returns({});

      event = {
        queryStringParameters: qs,
        headers: []
      };

      const cb = sinon.spy();

      await m.checkin(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200, {pnr: '12345'}));
    });

    it('should respond with 400 for service failures', async () => {
      checkIn.rejects(Error);
      convertToRecord.returns({pnr: '12345'});

      const cb = sinon.spy();

      await m.checkin(qs, event, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });


  });

  describe('boardingpass', () => {
    let qs, event;
    before(() => {
      qs = {
        rLoc: 'test',
        givenName: 'test',
        familyName: 'test',
        carrier: 'QR'
      };
    });

    it('should check passengers in and respond with 200', async () => {
      boardingPass.resolves({journeys: []});
      convertToRecord.returns({pnr: '12345'});

      params.returns(qs);
      body.returns({});

      event = {
        queryStringParameters: qs,
        headers: []
      };

      const cb = sinon.spy();

      await m.boardingpass(event, {}, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(200, {pnr: '12345'}));
    });

    it('should respond with 400 for service failures', async () => {
      boardingPass.rejects(Error);
      convertToRecord.returns({pnr: '12345'});

      const cb = sinon.spy();

      await m.boardingpass(qs, event, cb);

      assert(cb.calledOnce);
      assert(response.calledWith(500));
    });


  });


});
