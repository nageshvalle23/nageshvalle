const rp = require('request-promise');
const url = require('url');
const {formatCheckinRequest, formatBoardingPassRequest, validateLookup, findJourneyForLookup, backfillBpJourney} = require('./helpers');

const REQ_TIMEOUT_IN_MS = 500000; // TODO: configurable - how long should this reasonably be?
const CX_REQ_ORIGIN = 'https://www-t0.ete.cathaypacific.com';

const CX_API_KEY = process.env.CX_API_KEY || 'api_key';
const CX_API_URL = process.env.CX_API_URL || 'https://t0.api.osc1.ct1.cathaypacific.com'
const CX_LOGIN_URL = `${CX_API_URL}/olcipartners-bff/v1/bookings`;
const CX_CHECKIN_URL = `${CX_API_URL}/olcipartners-bff/v1/acceptance`;
const CX_BOARDINGPASS_URL = `${CX_API_URL}/olcipartners-bff/v1/boardingpass/print`;


async function login(lookup, requestingCarrier) {
  validateLookup(lookup);
  const {body} = await _requestCXLogin(lookup, requestingCarrier);
  return body;
}

async function checkIn(lookup, checkin, requestingCarrier) {
  const {journeys, cookies} = await _getSessionAndJourneys(lookup, CX_CHECKIN_URL, requestingCarrier);

  // Validate checkin object (lookup is validated by login)
  // TODO: move this to utils? use a schema validator? seems useful for other integrations too
  if (!checkin.passengerLookups || !checkin.passengerLookups.length
    || !checkin.flightLookups || !checkin.flightLookups.length) {
      throw new Error('Missing parameters');
  }

  if (!checkin.requirements || !checkin.requirements.acknowledgeDGTerms) {
    throw new Error('Passengers must acknowledge DG terms to check in');
  }

  // gather journey info from login res to use as body data for checkin request
  const journeyCheckin = formatCheckinRequest(journeys, checkin);

  const options = {
    uri: CX_CHECKIN_URL,
    body: journeyCheckin,
    headers: {
      apiKey: CX_API_KEY,
      'Access-Channel': `CC${requestingCarrier}`,
      Origin: CX_REQ_ORIGIN,
      'content-type': 'application/json',
    },
    json: true,
    jar: cookies,
    timeout: REQ_TIMEOUT_IN_MS,
  };

  return _gatherAndReportErrors(checkin.checkIn ? rp.put(options) : rp.delete(options));
}

async function boardingPass(lookup, bpLookup, requestingCarrier) {
  const {journeys, cookies} = await _getSessionAndJourneys(lookup, CX_BOARDINGPASS_URL, requestingCarrier);

  // Validate checkin object (lookup is validated by login)
  if (!bpLookup.passengerLookups || !bpLookup.passengerLookups.length
      || !bpLookup.flightLookups || !bpLookup.flightLookups.length) {
    throw new Error('Missing parameters');
  }

  // gather journey info from login res to use as body data for checkin request
  const boardingPassReq = formatBoardingPassRequest(journeys, bpLookup);

  const journey = findJourneyForLookup(journeys, bpLookup);

  const bpJourney = (await _gatherAndReportErrors(rp.post({
    url: CX_BOARDINGPASS_URL,
    body: boardingPassReq,
    headers: {
      apiKey: CX_API_KEY,
      'Access-Channel': `CC${requestingCarrier}`,
      Origin: CX_REQ_ORIGIN,
    },
    json: true,
    jar: cookies,
    timeout: REQ_TIMEOUT_IN_MS,
  }))).journey;

  const backfilledJourney = backfillBpJourney(journey, bpJourney)

  return backfilledJourney;
}

async function flifo (lookup) {
  // Request
  // {"travelDate":"2019-04-27","carrierCode":"CX","flightNumber":"315","locale":"en_HK","departureArrival":"D"}

}

async function _getSessionAndJourneys(lookup, uri, requestingCarrier) {
  validateLookup(lookup);

  // Login sets session cookies set up for check in request
  const {headers, body} = await _requestCXLogin(lookup, requestingCarrier);

  // Grab cookies and add them back to the request
  const domain = url.parse(uri).host;

  let cookies = rp.jar();
  cookies._jar.rejectPublicSuffixes = false;
  if (headers && headers['set-cookie']) {
    headers['set-cookie'].map((c) => {
      // need to replace domain because they're set on a different domain
      cookies.setCookie(rp.cookie(c.replace(/domain=(\w*\.?)*/, `domain=${domain}`)), `https://${domain}`);
    });
  }

  return {journeys: body.journeys, cookies};
}

async function _requestCXLogin(lookup, requestingCarrier) {
  const {familyName, givenName, rloc} = lookup;

  return _gatherAndReportErrors(rp.get({
    url: CX_LOGIN_URL,
    qs: {
      txtFamilyName: familyName,
      txtGivenName: givenName,
      txtBookingRef: rloc,
    },
    headers: {
      apiKey: CX_API_KEY,
      'Access-Channel': `CC${requestingCarrier}`,
      Origin: CX_REQ_ORIGIN,
    },
    json: true,
    resolveWithFullResponse: true,
    timeout: REQ_TIMEOUT_IN_MS,
  }));
}

/*
 *  Parse errors out of cx api response and log/handle them
 *   - only checks for top level error right now but should eventually
 *     traverse object and pull out all nesteded errors (ex: passengers can have errors)
 *   - currently only throws if there is an error that results in no
 *     journeys being returned
 */
async function _gatherAndReportErrors(promisedApiCall) {
  const res = await promisedApiCall;

  const body = res.body || res; // api call does not always resolve with full response
  const errors = body.errors;

  if (Array.isArray(errors) && errors.length > 0) {
    console.error(`Error calling ${promisedApiCall.path}: ${JSON.stringify(errors, null, 2)}`);
    const cxError = errors[0]; // We don't have a way of reporting multiple errors yet

    if (cxError.errorCode !== 'W33Z00129') { // Expected error returned for cancel acceptance
      const err = new Error('CX Error');
      err.CARRIER_ERROR_CODE = cxError.errorCode;
      err.CARRIER_ERROR_MESSAGE = cxError.type; // cx does not give back a message with their errors
      throw err;
    }
  }

  if (!body.journey && !body.journeys) {
    throw new Error('No Journeys'); // TODO: consider something like common-errors
  }

  return res;
}

module.exports = {
  login,
  checkIn,
  boardingPass,
};
