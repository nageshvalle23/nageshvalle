const flifo = require('./api');
const converter = require('./converter')
const run = async () => {
  try {
    const res  = await flifo('2019-12-04', 'CX', '899')
    console.log(JSON.stringify(res.result.map(converter), null, '  '))
  } catch (err) {
    console.log(err)
  }
}


run()
