const REQ_TIMEOUT_IN_MS = 500000; // TODO: configurable - how long should this reasonably be?

const CX_FLIFO_API_URL =
  process.env.CX_FLIFO_API_URL ||
  'https://api.cathaypacific.com/partners-flight-status/v4.0/flightStatusByFlightNumber';
const CX_API_KEY = process.env.CX_API_KEY || 'api_key';
const rp = require('request-promise-native');

module.exports = function(date, carrierCode, flightNumber) {
  // Flight request format:
  // {"travelDate":"2019-05-31","carrierCode":"CX","flightNumber":"450","locale":"en_HK","departureArrival":"D"}
  const flifoReq = Object.assign(
    {
      locale: 'en_HK',
      departureArrival: 'D',
    },
    {
      travelDate: date,
      carrierCode,
      flightNumber,
    }
  );

  return _gatherAndReportErrors(
    rp.post({
      url: CX_FLIFO_API_URL,
      body: flifoReq,
      headers: {
        apiKey: CX_API_KEY,
      },
      json: true,
      timeout: REQ_TIMEOUT_IN_MS,
    })
  );
};

async function _gatherAndReportErrors(promisedApiCall) {
  const res = await promisedApiCall;

  const body = res.body || res; // api call does not always resolve with full response

  const errors = body.errors;

  if (Array.isArray(errors) && errors.length > 0) {
    console.error(`Error calling ${promisedApiCall.path}: ${JSON.stringify(errors, null, 2)}`);

    if (errors.every(err => err.code === 'ERR_FLIGHT_STATUS_004')) { // No flights found
      return res;
    }

    const cxError = errors[0];
    const err = new Error('CX Error');
    err.CARRIER_ERROR_CODE = cxError.errorCode;
    err.CARRIER_ERROR_MESSAGE = cxError.type; // cx does not give back a message with their errors
    throw err;
  }

  return res;
}
