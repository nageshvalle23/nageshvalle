const {DateTimeFormatter, LocalDate, LocalDateTime, ZonedDateTime, ZoneOffset} = require('js-joda');

require('js-joda-timezone');

const statusMap = {
  "ON TIME": 'SCHEDULED',
  REROUTED: 'REROUTED',
  ARRIVED: 'ARRIVED',
  DELAYED: 'DELAYED',
  CANCELLED: 'CANCELLED'
};

// const utcDatetime = (ts) => {
//   return ZonedDateTime.parse(ts)
//                       .withZoneSameInstant(ZoneOffset.UTC)
//                       .toString();
// }

// const localDatetime = (ts) => {
//   return ZonedDateTime.parse(ts)
//                       .toString();
// }

const utcDatetime = ts => {
  return ZonedDateTime.parse(ts, DateTimeFormatter.ISO_OFFSET_DATE_TIME)
    .withZoneSameInstant(ZoneOffset.UTC)
    .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
};

const localDatetime = ts => {
  return ZonedDateTime.parse(ts, DateTimeFormatter.ISO_OFFSET_DATE_TIME)
    .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
};

const makeCxDatetime = (dt, offset) => {
  return dt.replace(/\s/, 'T') + offset.substr(0, 3) + ':' + offset.substr(3);
}

module.exports = convertToFlight;

function convertToFlight(result) {

  const flight = makeFlight();

  flight.flightNumber = result.operatingFlight.flightNumber;
  flight.carrierCode = result.operatingFlight.carrierCode;

  result.sectors.forEach((s, i) => {
    const sector = makeSector();

    sector.codeShares = s.codeShareFlights.map(c => ({
      flightNumber: c.flightNumber,
      carrierCode: c.carrierCode
    }));
    const sectorStatus = s.flightStatus.toUpperCase();
    sector.status = statusMap[sectorStatus];
    sector.sourceStatus = sectorStatus;
    sector.departure.airportCode = s.origin;
    sector.arrival.airportCode = s.destination;

    if (['REROUTED', 'CANCELLED'].indexOf(sectorStatus) !== -1) {
      flight.summary.notice = true;
    }

    // TODO: waiting on terminal
    // TODO: waiting on gate
    // TODO: waiting on origin and destination to be included at the parent level
    if (s.origin === result.origin) {
      if (s.departActual) {
        flight.summary.departure.at.local = localDatetime(makeCxDatetime(s.departActual, s.originActualOffset));
        flight.summary.departure.at.utc = utcDatetime(makeCxDatetime(s.departActual, s.originActualOffset));
        flight.summary.departure.at.type = 'ACTUAL';
      } else if (s.departEstimated) {
        flight.summary.departure.at.local = localDatetime(makeCxDatetime(s.departEstimated, s.originEstimatedOffset));
        flight.summary.departure.at.utc = utcDatetime(makeCxDatetime(s.departEstimated, s.originEstimatedOffset));
        flight.summary.departure.at.type = 'ESTIMATED';
      } else {
        flight.summary.departure.at.local = localDatetime(makeCxDatetime(s.departScheduled, s.originScheduledOffset));
        flight.summary.departure.at.utc = utcDatetime(makeCxDatetime(s.departScheduled, s.originScheduledOffset));
        flight.summary.departure.at.type = 'SCHEDULED';
      }
    }

    if (s.destination === result.destination) {
      if (s.arrivalActual) {
        flight.summary.arrival.at.local = localDatetime(makeCxDatetime(s.arrivalActual, s.destinationActualOffset));
        flight.summary.arrival.at.utc = utcDatetime(makeCxDatetime(s.arrivalActual, s.destinationActualOffset));
        flight.summary.arrival.at.type = 'ACTUAL';
      } else if (s.arrivalEstimated) {
        flight.summary.arrival.at.local = localDatetime(makeCxDatetime(s.arrivalEstimated, s.destinationEstimatedOffset));
        flight.summary.arrival.at.utc = utcDatetime(makeCxDatetime(s.arrivalEstimated, s.destinationEstimatedOffset));
        flight.summary.arrival.at.type = 'ESTIMATED';
      } else {
        flight.summary.arrival.at.local = localDatetime(makeCxDatetime(s.arrivalScheduled, s.destinationScheduledOffset));
        flight.summary.arrival.at.utc = utcDatetime(makeCxDatetime(s.arrivalScheduled, s.destinationScheduledOffset));
        flight.summary.arrival.at.type = 'SCHEDULED';
      }
    }


    if (s.departScheduled) {
      sector.departure.scheduled = {
        local: localDatetime(makeCxDatetime(s.departScheduled, s.originScheduledOffset)),
        utc: utcDatetime(makeCxDatetime(s.departScheduled, s.originScheduledOffset)),
        source: 'CX'
      }
    }

    if (s.departEstimated) {
      sector.departure.estimated = {
        local: localDatetime(makeCxDatetime(s.departEstimated, s.originEstimatedOffset)),
        utc: utcDatetime(makeCxDatetime(s.departEstimated, s.originEstimatedOffset)),
        source: 'CX'
      }
    }

    if (s.departActual) {
      sector.departure.actual = {
        local: localDatetime(makeCxDatetime(s.departActual, s.originActualOffset)),
        utc: utcDatetime(makeCxDatetime(s.departActual, s.originActualOffset)),
        source: 'CX'
      }
    }

    if (s.arrivalScheduled) {
      sector.arrival.scheduled = {
        local: localDatetime(makeCxDatetime(s.arrivalScheduled, s.destinationScheduledOffset)),
        utc: utcDatetime(makeCxDatetime(s.arrivalScheduled, s.destinationScheduledOffset)),
        source: 'CX'
      }
    }

    if (s.arrivalEstimated) {
      sector.arrival.estimated = {
        local: localDatetime(makeCxDatetime(s.arrivalEstimated, s.destinationEstimatedOffset)),
        utc: utcDatetime(makeCxDatetime(s.arrivalEstimated, s.destinationEstimatedOffset)),
        source: 'CX'
      }
    }

    if (s.arrivalActual) {
      sector.arrival.actual = {
        local: localDatetime(makeCxDatetime(s.arrivalActual, s.destinationActualOffset)),
        utc: utcDatetime(makeCxDatetime(s.arrivalActual, s.destinationActualOffset)),
        source: 'CX'
      }
    }

    flight.sectors.push(sector);
  })

  return flight;
}


const makeFlight = () => (
  {
    flightNumber: null,
    carrierCode: null,
    // airlineName: null, // TODO: can we get this?
    // aircraftType: null, // TODO: can we get this?
    sectors: [],

    summary: {
      departure: {
        at: {
          utc: null,
          local: null,
          type: null // estimated, or actual
        }
      },
      arrival: {
        at: {
          utc: null,
          local: null,
          type: null // estimated, or actual
        }
      },
      notice: false
    }
  });

const makeSector = () => ({
  codeShares: [],
  status: 'UNKNOWN',
  sourceStatus: null,
  departure: {
    airportCode: null,
    airportName: null,
    cityName: null,
    countryId: null,
    terminal: null,
    gate: null,
    scheduled: {
      local: null,
      utc: null,
      source: null
    },
    estimated: {
      local: null,
      utc: null,
      source: null
    },
    actual: {
      local: null,
      utc: null,
      source: null
    }
  },
  arrival: {
    airportCode: null,
    airportName: null,
    cityName: null,
    countryId: null,
    terminal: null,
    gate: null,
    scheduled: {
      local: null,
      utc: null,
      source: null
    },
    estimated: {
      local: null,
      utc: null,
      source: null
    },
    actual: {
      local: null,
      utc: null,
      source: null
    }
  }
});
