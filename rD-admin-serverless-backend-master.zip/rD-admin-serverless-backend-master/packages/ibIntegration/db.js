const STAGE = process.env.stage;
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

const db = {}
module.exports = db

const TableName = `async-middleware-${STAGE}`

db.insertToDB = async (uniqueCode, payload, ttl) => {
    const RECORD_LIFE = Math.floor( (Date.now() + (1000 * 60 * ttl) ) / 1000)
    const params = {
        TableName,
        Item: {
            lambda_guid: uniqueCode,
            response: payload,
            record_life: RECORD_LIFE, 
        }
    }
    return await dynamo.put(params).promise()
}

