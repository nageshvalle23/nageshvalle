const uuid = require("uuid/v1");
const converter = require("./converter");
const api = require("./api");
const helpers = require("./helpers");
const db = require('./db')
const { isArray } = require('lodash');
const utils = require('./utility')
const {
  response,
  body,
  params
} = require("@oneworld-digital/integration-utils").request;

const API_GATEWAY_TIME_OUT = 28 // in seconds
const TIME_TO_LIVE = 5 // in minutes

const { convertToV1Params, convertToV2Params, convertToV1Body, v1RecordToV2Record, isV2Request, convertToV2Body } = require('@oneworld-digital/integration-utils').versionConverter;

// Boarding pass has segment and passenger ids as string
// as opposed to get booking & accept has numeric fields
exports.record = async (event, context, cb) => {
  let token, booking;

  try {
    // console.info("Record response from API gateway: ", JSON.stringify(event));
    const isV2 = isV2Request(event);
    // IB integration was originally written as v1 but we will only be supporting v2

    console.info("Record request body: ", JSON.stringify(body(event), null, 2))

    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    token = await api.retrieveToken(rloc, familyName);

    booking = await api.getBooking(rloc, familyName, token);

    let travelerRecord = converter.toRecord(booking);

    if (isV2) {
      travelerRecord = v1RecordToV2Record(travelerRecord);
    }

    await closeSession(token, booking);

    return cb(null, response(200, travelerRecord));
  } catch (err) {
    console.log(err)
    await closeSession(token, booking);
    return await _handleErrors(err, cb, false, {});
  }
};

// Note: doing v2 conversion -- doesn't look like we're actually using pax lookups here
//       do IB support checking in a single pax?
exports.checkin = async (event, context, cb) => {
  let booking, token;

  try {
    const isV2 = isV2Request(event);

    // IB integration was originally written as v1 but we will only be supporting v2

    console.info("Acceptance request body: ", JSON.stringify(body(event), null, 2));

    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);
    const checkin = isV2 ? convertToV1Body(body(event)) : body(event);

    token = await api.retrieveToken(rloc, familyName);

    booking = await api.getBooking(rloc, familyName, token);

    if (isV2) {
      await utils.callGetAndPutSecForAccept(booking, token, rloc, checkin.passengerLookups)
    }
    else {
      for (let eachPax of checkin.passengerLookups) {
        await utils.callGetAndPutSecForAccept(booking, token, rloc, eachPax)
      }
    }
    
    console.info('before accept');

    await api.AcceptCheckable(token, booking, checkin, isV2);

    console.info('after accept');


    booking = await api.getBooking(rloc, familyName, token);

    let travelerRecord = converter.toRecord(booking);

    if (isV2) {
      travelerRecord = v1RecordToV2Record(travelerRecord);
    }

    await closeSession(token, booking);
    return cb(null, response(200, travelerRecord));
  } catch (err) {
    await closeSession(token, booking);
    return await _handleErrors(err, cb, false, {});
  }
};

// Multi-Passenger Checkin
exports.multicheckin = async (event, context, cb) => {
  let booking, token;
  let startTime = Date.now();
  let uniqueCode = undefined;

  try {
    // * CODE IS ADDED HERE *********************************

    let reqBody = event;

    if (event.body) {
      console.log('event has body prop. using previous logic');
      reqBody = body(event);
    }

    console.log("Multi checkin request body: ", JSON.stringify(reqBody, null, 2));

    if (reqBody.hasOwnProperty('uniqueCode')) {
      uniqueCode = reqBody.uniqueCode;
      delete reqBody.uniqueCode;
    }


    // IB integration was originally written as v1 but we will only be supporting v2
    const { familyName, rloc } = utils.convertToV2Params(reqBody)

    const checkin = utils.convertToV2Body(reqBody)

    token = await api.retrieveToken(rloc, familyName);

    booking = await api.getBooking(rloc, familyName, token);

    for (let eachPax of checkin.passengerLookups) {
      await utils.callGetAndPutSecForAccept(booking, token, rloc, eachPax)
    }

    console.info('before accept');

    await api.AcceptCheckable(token, booking, checkin);

    console.info('after accept');

    booking = await api.getBooking(rloc, familyName, token);

    let travelerRecord = converter.toRecord(booking);

    travelerRecord = v1RecordToV2Record(travelerRecord);

    // * CODE IS ADDED HERE *********************************
    let endTime = Date.now();
    await logResponseToDB(uniqueCode, response(200, travelerRecord), startTime, endTime);
    console.info("after logResponseToDB");
    await closeSession(token, booking);

    return utils.partialCheckinStatusCode(travelerRecord, cb)

    // return cb(null, response(200, travelerRecord));
  } catch (err) {
    await closeSession(token, booking);
    let endTime = Date.now();
    return await _handleErrors(err, cb, true, { uniqueCode: uniqueCode, startTime: startTime, endTime: endTime });
  }
};

//Boarding Pass function
exports.boardingpass = async (event, context, cb) => {
  let booking, token;
  let travelerRecord = {};


  let startTime = Date.now();
  let uniqueCode = undefined;
  try {

    console.info(
      `Boardingpass function. event ${JSON.stringify(event, null, 2)}`
    );

    //Retrieve unique code sent by async middleware
    // let reqbody = body(event);
    let reqbody = event;

    if (event.body) {
      console.log('event has body prop. using previous logic');
      reqbody = body(event);
    }

    console.info(
      `Boardingpass function. reqbody ${JSON.stringify(reqbody, null, 2)}`
    );

    if (reqbody.hasOwnProperty('uniqueCode')) {
      uniqueCode = reqbody.uniqueCode;
      delete reqbody.uniqueCode;
    }

    // const isV2 = isV2Request(event);
    const isV2 = true;
    // IB integration was originally written as v1 but we will only be supporting v2
    const { familyName, rloc } = isV2 ? convertToV1Params(reqbody) : params(event);
    const bpLookup = isV2 ? convertToV1Body(reqbody) : reqbody;

    // 01 - get token
    token = await api.retrieveToken(rloc, familyName);
    console.info("after retrieveToken");
    // 02 - booking information
    booking = await api.getBooking(rloc, familyName, token);

    console.info("after getbooking");
    if (helpers.verifyPaxCheckedIn(booking, bpLookup)) {
      // passengers are already checked in - ok to call check in
      const checkin = {
        flightLookups: bpLookup.flightLookups,
        passengerLookups: bpLookup.passengerLookups,
        checkIn: true,
        requirements: {
          acknowledgeDGTerms: true
        }
      };

      // 03 - accept passengers - check in
      await api.accept(token, booking, checkin);
      console.info("after accept");

      // 04 - available boarding pass formats
      const boardingPassFormats = await api.boardingPassFormats(
        token,
        booking.checkinId
      );

      console.info("after boardingPassFormats");
      // 05 - print boarding pass
      const bp = await api.printBoardingPass(
        token,
        booking,
        boardingPassFormats
      );
      console.info("after printBoardingPass");
      // 05 - retrieve updated booking -
      booking = await api.getBooking(rloc, familyName, token);
      console.info("after getBooking 2nd time");
      travelerRecord = converter.toBpRecord(booking, bp, bpLookup.passengerLookups);

      console.info(
        `Boardingpass function. travelerRecord =  ${JSON.stringify(travelerRecord, null, 2)}`
      );

      //If the lambda ran for more than the API Gateway timeout limit, then insert response to DB
      let endTime = Date.now();
      await logResponseToDB(uniqueCode, response(200, travelerRecord), startTime, endTime)
      console.info("after logResponseToDB");
    }

    await closeSession(token, booking);
    console.info("after closeSession");
    return cb(null, response(200, travelerRecord));
  } catch (err) {
    await closeSession(token, booking);
    let endTime = Date.now()
    return await _handleErrors(err, cb, true, { uniqueCode: uniqueCode, startTime: startTime, endTime: endTime });
  }
};

//Multi Boarding pass function

exports.multiBoardingPass = async (event, context, cb) => {
  let booking, token;
  let travelerRecord = {};


  let startTime = Date.now();
  let uniqueCode = undefined;
  try {

    console.info(
      `Boardingpass function. event ${JSON.stringify(event, null, 2)}`
    );

    //Retrieve unique code sent by async middleware
    // let reqbody = body(event);
    let reqbody = event;

    if (event.body) {
      console.log('event has body prop. using previous logic');
      reqbody = body(event);
    }

    console.info(
      `Boardingpass function. reqbody ${JSON.stringify(reqbody, null, 2)}`
    );

    if (reqbody.hasOwnProperty('uniqueCode')) {
      uniqueCode = reqbody.uniqueCode;
      delete reqbody.uniqueCode;
    }

    // IB integration was originally written as v1 but we will only be supporting v2
    const { familyName, rloc } = utils.convertToV2Params(reqbody)

    const bpLookup = utils.convertToV2Body(reqbody)

    // 01 - get token
    token = await api.retrieveToken(rloc, familyName);
    console.info("after retrieveToken");
    // 02 - booking information
    booking = await api.getBooking(rloc, familyName, token);

    console.info("after getbooking");
    if (helpers.verifyPaxCheckedIn(booking, bpLookup)) {
      // passengers are already checked in - ok to call check in
      const checkin = {
        flightLookups: bpLookup.flightLookups,
        passengerLookups: bpLookup.passengerLookups,
        checkIn: true,
        requirements: {
          acknowledgeDGTerms: true
        }
      };

      // 03 - accept passengers - check in
      await api.accept(token, booking, checkin);
      console.info("after accept");

      // 04 - available boarding pass formats
      const boardingPassFormats = await api.boardingPassFormats(
        token,
        booking.checkinId
      );

      console.info("after boardingPassFormats");
      // 05 - print boarding pass
      const bp = await api.printBoardingPass(
        token,
        booking,
        boardingPassFormats
      );
      console.info("after printBoardingPass");
      // 05 - retrieve updated booking -
      booking = await api.getBooking(rloc, familyName, token);
      console.info("after getBooking 2nd time");
      travelerRecord = converter.toBpRecord(booking, bp, bpLookup.passengerLookups);

      console.info(
        `Multi Boardingpass function. travelerRecord =  ${JSON.stringify(travelerRecord, null, 2)}`
      );

      //If the lambda ran for more than the API Gateway timeout limit, then insert response to DB
      let endTime = Date.now();
      await logResponseToDB(uniqueCode, response(200, travelerRecord), startTime, endTime)
      console.info("after logResponseToDB");
    }

    await closeSession(token, booking);
    console.info("after closeSession");
    return cb(null, response(200, travelerRecord));
  } catch (err) {
    await closeSession(token, booking);
    let endTime = Date.now()
    return await _handleErrors(err, cb, true, { uniqueCode: uniqueCode, startTime: startTime, endTime: endTime });
  }
};


// Eligibility function
exports.eligibility = async (event, context, cb) => {

  let booking, token, eligibilityResponse;

  try {
    console.info("Eligibility request body: ", JSON.stringify(body(event), null, 2));

    const isV2 = true;
    const { familyName, givenName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);
    token = await api.retrieveToken(rloc, familyName);
    booking = await api.getBooking(rloc, familyName, token);

    if (utils.verifypaxAllowedForCheckin(booking, body(event).passengerRequest)) {
      const {familyName, givenName, eTicketNumber} = body(event).passengerRequest;
      return cb(null, response(200, {
        familyName,
        givenName,
        eTicketNumber,
        requiredDocuments: ['SEE_AGENT'],
        populatedDocuments: []
      }))
    }
    else {
      const { checkinId, passengers } = booking;
      const { paxFamilyName, paxGivenname } = isV2 ? utils.retrievePaxFields(body(event).passengerRequest) : params(event)
      let pax;

      if (passengers.length == 1) {
        pax = passengers[0]
      } else {
        if (passengers.some(item => item.name.toLowerCase() === paxGivenname.toLowerCase() && item.surname.toLowerCase() === paxFamilyName.toLowerCase())) {
          pax = passengers.filter(item => item.name.toLowerCase() === paxGivenname.toLowerCase() && item.surname.toLowerCase() === paxFamilyName.toLowerCase())[0];
        } else {
          throw new Error('Matching passenger not found')
        }
      }

      eligibilityResponse = await utils.handleGetDocsForPax(pax, token, checkinId)
      console.log(`eligibility response - ${JSON.stringify(eligibilityResponse)}`);

      await closeSession(token, booking);
      return cb(null, response(200, eligibilityResponse));
    }

  } catch (err) {
    await closeSession(token, booking);
    return await _handleErrors(err, cb, false, {});
  }

}

// Multi Eligibility Function
exports.multieligibility = async (event, context, cb) => {
  let booking, token, multiEligibilityResponse = [];

  try {
    console.info("Multi Eligibility request body: ", JSON.stringify(body(event), null, 2));

    const isV2 = true;
    const { familyName, rloc } = isV2 ? convertToV1Params(body(event)) : params(event);

    token = await api.retrieveToken(rloc, familyName);

    booking = await api.getBooking(rloc, familyName, token);

    const { checkinId } = booking;

    let paxLookups = [];
    let notAllowedPax = [];

    for (let eachPax of body(event).passengerRequests) {
        if (utils.verifypaxAllowedForCheckin(booking, eachPax)) {
          notAllowedPax.push(eachPax)
          multiEligibilityResponse.push({
            familyName: eachPax.familyName,
            givenName: eachPax.givenName,
            eTicketNumber: eachPax.eTicketNumber,
            requiredDocuments: ['SEE_AGENT'],
            populatedDocuments: []
          })
          // return cb(null, response(200, { requiredDocuments: ['SEE_AGENT'] }))
        }
        else {
          const { passengers } = booking;
          const { paxFamilyName, paxGivenname } = isV2 ? utils.retrievePaxFields(eachPax) : params(event)
          let pax;

          if (passengers.length == 1) {
            paxLookups.push(passengers[0])
          } else {
            if (passengers.some(item => item.name.toLowerCase() === paxGivenname.toLowerCase() && item.surname.toLowerCase() === paxFamilyName.toLowerCase())) {
              pax = passengers.filter(item => item.name.toLowerCase() === paxGivenname.toLowerCase() && item.surname.toLowerCase() === paxFamilyName.toLowerCase())[0];
              paxLookups.push(pax)
            } else {
              throw new Error('Matching passenger not found')
            }
          }
        }
    }

    //Now call multi-eligibility IB API

    if (notAllowedPax.length !== body(event).passengerRequests.length) {
      const multiEligibilityResponseForAllowed = await utils.handleGetDocsForMultiPax(paxLookups, token, checkinId, body(event).passengerRequests)

      multiEligibilityResponse.push(...multiEligibilityResponseForAllowed)
    }

    console.log(`multi eligibility response - ${JSON.stringify(multiEligibilityResponse)}`);

    await closeSession(token, booking);
    return cb(null, response(200, multiEligibilityResponse));
  }
  catch(err) {
    await closeSession(token, booking);
    return await _handleErrors(err, cb, false, {});  }

}

// Document update functionality
exports.documentsupdate = async (event, context, cb) => {

  let booking, token, updateDocsResponse;

  try {
    let reqBody = event;

    if (event.body) {
      console.log('event has body prop. using previous logic');
      reqBody = body(event);
    }

    console.log('CC Document Request ', JSON.stringify(reqBody));

    const isV2 = true;

    const { familyName, givenName, rloc } = isV2 ? convertToV1Params(reqBody) : params(event);
    token = await api.retrieveToken(rloc, familyName);

    console.log(`documentsupdate - Calling api.getBooking. rloc = ${rloc}`);

    booking = await api.getBooking(rloc, familyName, token);

    if (utils.verifypaxAllowedForCheckin(booking, reqBody.passengerRequest)) {
      return cb(null, response(200, { requiredDocuments: ['SEE_AGENT'] }))
    }
    else {
      const { checkinId, passengers } = booking;
      const { paxFamilyName, paxGivenname } = isV2 ? utils.retrievePaxFields(body(event).passengerRequest) : params(event)

      let pax;

      if (passengers.length == 1) {
        pax = passengers[0]
      } else {
        if (passengers.some(item => item.name.toLowerCase() === paxGivenname.toLowerCase() && item.surname.toLowerCase() === paxFamilyName.toLowerCase())) {
          pax = passengers.filter(item => item.name.toLowerCase() === paxGivenname.toLowerCase() && item.surname.toLowerCase() === paxFamilyName.toLowerCase())[0]

        } else {
          throw new Error('Matching passenger not found')
        }
      }

      updateDocsResponse = await utils.handleDocUpdateForPax(pax, token, checkinId, rloc, reqBody, paxFamilyName, paxGivenname)
      console.info('Document update response: ', updateDocsResponse);
      
      await closeSession(token, booking);
      return cb(null, response(200, updateDocsResponse));
    }
  }
  catch (err) {
    await closeSession(token, booking);
    return await _handleErrors(err, cb, false, {});
  }
}


async function closeSession(token, booking) {
  try {
    if (token && booking && booking.checkinId) {
      await api.closeSession(token, booking.checkinId);
    }
  } catch (err) {
    console.error('Failed to close session: ' + err);
  }
}

async function _handleErrors(err, cb, logtoDB, logInfo) {

  const body = {
    id: uuid(),
    message: err.CARRIER_ERROR_MESSAGE || err.message,
    type: err.CARRIER_ERROR_CODE ? 'OA' : 'Internal',
    code: err.CARRIER_ERROR_CODE || '500'
  };

  let responseCode;
  if (err.CARRIER_ERROR_MESSAGE && err.CARRIER_ERROR_CODE) {
    responseCode = 502;
  } else {
    responseCode = 500;
  }

  console.error(
    `Request failed with status ${responseCode
    } and body ${JSON.stringify(body, null, 2)}`
  );

  if (logtoDB) {
    await logResponseToDB(logInfo.uniqueCode, response(responseCode, body), logInfo.startTime, logInfo.endTime);
  }
  return cb(null, response(responseCode, body));
}

//If the lambda ran for more than the API Gateway timeout limit, then insert response to DB
async function logResponseToDB(dbKey, dbPayload, startTime, endTime) {
  console.info(`in  logResponseToDB. dbKey = ${dbKey}`);
  console.info(`in  logResponseToDB. endTime = ${endTime}, startTime = ${startTime}`);
  if (dbKey) {
    // if (Math.floor((endTime - startTime) / 1000) > API_GATEWAY_TIME_OUT ) {
    console.log("About to call DB Insert");
    await db.insertToDB(dbKey, dbPayload, TIME_TO_LIVE);
    // }
  }
}
