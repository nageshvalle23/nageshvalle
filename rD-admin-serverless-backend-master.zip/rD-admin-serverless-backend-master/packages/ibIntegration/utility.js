const api = require('./api.js')
const getCountryISO2 = require("country-iso-3-to-2");
const isArray = require('isarray');
const {
    response,
  } = require("@oneworld-digital/integration-utils").request;

function get3CharCountryCode(countryCode) {
    if (countryCode.length < 3) {
        return countryCode;
    }

    return getCountryISO2(countryCode);
}

module.exports = {

    isPSPTMandatory: function isPSPTMandatory(getSecurityResponse) {

        if (getSecurityResponse.passengersSecurityInformation[0].mandatoryDocuments !== null) {
            const isMandatoryDocCheck = getSecurityResponse.passengersSecurityInformation[0].mandatoryDocuments.some(item => item.documents[0].type.code === "PSPT" || item.documents[0].type.code === "VISA")
            if (isMandatoryDocCheck) {
                return true;
            } else {
                return false;
            }
        }
        return false;

    },

    // * The below method returns true, if the get response api call has already registered passport or visa.
    isPSPTAlreadyPopulated: function isPSPTAlreadyPopulated(getSecurityResponse, currentRequest) {

        if (currentRequest) {
            if (currentRequest.documents && Array.isArray(currentRequest.documents)) {
                const psptExists = currentRequest.documents.some(item => item.type === "PSPT" || item.type === "VISA");
                if (psptExists) {
                    return true;
                }
            }
        }

        if (getSecurityResponse.passengersSecurityInformation[0].mandatoryDocuments !== null) {
            const isMandatoryDocCheck = getSecurityResponse.passengersSecurityInformation[0].mandatoryDocuments.some(item => item.documents[0].type.code === "PSPT" || item.documents[0].type.code === "VISA")
            if (isMandatoryDocCheck) {
                const isMandatoryDocInGetResponse = getSecurityResponse.passengersSecurityInformation[0].documents.some(item => item.type.code === "PSPT" || item.type.code === "VISA")
                if (!isMandatoryDocInGetResponse) {
                    // return ibReqBody;
                    return false
                }
            }
        }
        return true

    },

    addExistingFieldsAndDocsToRequest: function addExistingFieldsAndDocsToRequest(ibReqBody, getSecurityResponse) {

        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].id)) { ibReqBody.id = getSecurityResponse.passengersSecurityInformation[0].id; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].name)) { ibReqBody.name = getSecurityResponse.passengersSecurityInformation[0].name; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].surname)) { ibReqBody.surname = getSecurityResponse.passengersSecurityInformation[0].surname; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].title)) { ibReqBody.title = getSecurityResponse.passengersSecurityInformation[0].title; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].gender)) { ibReqBody.gender = getSecurityResponse.passengersSecurityInformation[0].gender; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].birthDate)) { ibReqBody.birthDate = getSecurityResponse.passengersSecurityInformation[0].birthDate; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].inTransit)) { ibReqBody.inTransit = getSecurityResponse.passengersSecurityInformation[0].inTransit; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].destinationAddress)) {
            ibReqBody.destinationAddress = getSecurityResponse.passengersSecurityInformation[0].destinationAddress;

            let { country, ...otherProps } = getSecurityResponse.passengersSecurityInformation[0].destinationAddress;

            if (country !== null) {
                if (Object.keys(country).length > 1) {
                    ibReqBody.destinationAddress.country = getSecurityResponse.passengersSecurityInformation[0].destinationAddress.country.code;
                } else {
                    ibReqBody.destinationAddress.country = getSecurityResponse.passengersSecurityInformation[0].destinationAddress.country;
                }

            }


        }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].homeAddress)) {
            ibReqBody.homeAddress = getSecurityResponse.passengersSecurityInformation[0].homeAddress;

            let { country, ...otherProps } = getSecurityResponse.passengersSecurityInformation[0].homeAddress;

            if (country !== null) {
                if (Object.keys(country).length > 1) {
                    ibReqBody.homeAddress.country = getSecurityResponse.passengersSecurityInformation[0].homeAddress.country.code;
                } else {
                    ibReqBody.homeAddress.country = getSecurityResponse.passengersSecurityInformation[0].homeAddress.country;
                }
            }

        }
        // if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].emergencyContact)) { ibReqBody.emergencyContact = getSecurityResponse.passengersSecurityInformation[0].emergencyContact; }

        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].emergencyContact) && !this.isEmergencyContactEmpty(getSecurityResponse.passengersSecurityInformation[0].emergencyContact)) {
            ibReqBody.emergencyContact = {
                name: getSecurityResponse.passengersSecurityInformation[0].emergencyContact.name,
                phone: {
                    countryCode: getSecurityResponse.passengersSecurityInformation[0]?.emergencyContact?.phone?.countryCode?.code,
                    number: getSecurityResponse.passengersSecurityInformation[0].emergencyContact.phone.number
                },
                refused: getSecurityResponse.passengersSecurityInformation[0].emergencyContact.refused
            }
        }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].nationality)) {
            // ibReqBody.nationality = getSecurityResponse.passengersSecurityInformation[0].nationality;

            if (Object.keys(getSecurityResponse.passengersSecurityInformation[0].nationality).length > 1) {
                ibReqBody.nationality = getSecurityResponse.passengersSecurityInformation[0].nationality.code;
            } else {
                ibReqBody.nationality = getSecurityResponse.passengersSecurityInformation[0].nationality;
            }

        }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].cityOfBirth)) { ibReqBody.cityOfBirth = getSecurityResponse.passengersSecurityInformation[0].cityOfBirth; }
        if (!this.isEmptyObject(getSecurityResponse.passengersSecurityInformation[0].countryOfResidence)) { ibReqBody.countryOfResidence = getSecurityResponse.passengersSecurityInformation[0].countryOfResidence; }


        if (getSecurityResponse.passengersSecurityInformation[0].documents.length >= 1) {
            const otherDocs = getSecurityResponse.passengersSecurityInformation[0].documents.map(item => {
                return {
                    type: item.type.code,
                    expiryDate: item.expiryDate,
                    number: item.number,
                    issuerCountry: item.issuerCountry.code
                }
            })
            ibReqBody.documents = otherDocs;
        } else {
            ibReqBody.documents = [];
        }

    },

    addNewDocumentToRequestBody: function addNewDocumentToRequestBody(familyName, givenName, passengerId, reqDocument, ibReqBody, getSecurityResponse) {
        if (this.isPSPTMandatory(getSecurityResponse)) {

            if (this.isPSPTAlreadyPopulated(getSecurityResponse, ibReqBody)) {
                ibReqBody = this.addDocsAndFieldsToPutSecurityRequest(familyName, givenName, passengerId, reqDocument, ibReqBody);
            }
            else {
                if (reqDocument.type === "PASSPORT" || reqDocument.type === "VISA") {
                    ibReqBody = this.addDocsAndFieldsToPutSecurityRequest(familyName, givenName, passengerId, reqDocument, ibReqBody);
                } else {
                    return ["PASSPORT"];
                }
            }

        } else {
            ibReqBody = this.addDocsAndFieldsToPutSecurityRequest(familyName, givenName, passengerId, reqDocument, ibReqBody);
        }

    },

    getPutSecurityResponse: function getPutSecurityResponse(statusCode, errCode, errReason) {
        const passportCCFields = ['ID', 'GENDER', 'BIRTH_DATE', 'CITY_OF_BIRTH', 'NAME', 'SURNAME', 'NATIONALITY', 'LARGE_FAMILY_NUMBER'];
        const residentalFields = ['HOME', 'MUNICIPALITY', 'RESIDENT', 'COMMUNITY'];
        const destinationFiels = ['DESTINATION']
        const iBErrors = [
            { errCode: "TRM_APIM_900563", errStatus: "ID_DOCUMENT_REQUIRED" },
            { errCode: "TRM_APIM_900564", errStatus: "GENDER_REQUIRED" },
            { errCode: "TRM_APIM_900565", errStatus: "BIRTH_DATE_REQUIRED" },
            { errCode: "TRM_APIM_900566", errStatus: "MUNICIPALITY_CODE_REQUIRED" },
            { errCode: "TRM_APIM_900567", errStatus: "RESIDENT_NUMBER_REQUIRED" },
            { errCode: "TRM_APIM_900568", errStatus: "BIRTH_DATE_INCORRECT" },
            { errCode: "TRM_APIM_900569", errStatus: "COMMUNITY_CODE_REQUIRED" },
            { errCode: "TRM_APIM_900570", errStatus: "LARGE_FAMILY_NUMBER_REQUIRED" },
            { errCode: "TRM_APIM_900618", errStatus: "CITY_OF_BIRTH_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900619", errStatus: "DESTINATION_ADDRESS_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900620", errStatus: "DESTINATION_CITY_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900621", errStatus: "DESTINATION_COUNTRY_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900622", errStatus: "DESTINATION_ZIP_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900624", errStatus: "HOME_ADDRESS_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900625", errStatus: "HOME_CITY_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900626", errStatus: "HOME_COUNTRY_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900627", errStatus: "HOME_ZIP_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900628", errStatus: "NAME_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900629", errStatus: "NATIONALITY_REQUIRED_FLIELD" },
            { errCode: "TRM_APIM_900630", errStatus: "SURNAME_REQUIRED_FLIELD" }
        ];

        const newArr = iBErrors.map(item => {
            const { errCode, errStatus } = item;
            if (passportCCFields.some(item => errStatus.includes(item))) {
                return { ...item, errStatus: 'PASSPORT' }
            }
            if (destinationFiels.some(item => errStatus.includes(item))) {
                return { ...item, errStatus: 'DESTINATION_ADDRESS' }
            }
            if (residentalFields.some(item => errStatus.includes(item))) {
                return { ...item, errStatus: 'RESIDENT_ADDRESS' }
            }
        })

        switch (statusCode) {
            case 200:
                return 'Success!!'
            case 404:
                return { error: errReason, errorDesc: 'Some passengers in the request does not exist in the booking referenced by the checkinId' }
            case 408:
                return { error: errReason, errorDesc: 'Request has exceeded the time limit' }
            case 409:
                return { error: errReason, errorDesc: 'There has been an error in updating some passenger' }
                return
            case 410:
                return { error: errReason, errorDesc: 'resource no longer available' }
            case 400:
                return { error: errCode, errDesc: `${errReason}` }
            case 412:
                return { error: errReason, errorDesc: `${newArr.filter(item => item.errCode === errCode)[0].errStatus} required` }
        }
    },


    addDocsAndFieldsToPutSecurityRequest: function addDocsAndFieldsToPutSecurityRequest(familyName, givenName, passengerId, document, ibReqBody) {

        ibReqBody.id = passengerId;
        ibReqBody.name = givenName;
        ibReqBody.surname = familyName;
        ibReqBody.inTransit = false;
        if (document.type === "PASSPORT" || document.type === "VISA") {
            ibReqBody.gender = document.payload.gender;
            ibReqBody.nationality = get3CharCountryCode(document.payload.nationality);
            ibReqBody.birthDate = document.payload.dateOfBirth;

            ibReqBody.documents.push({
                type: document.type === "PASSPORT" ? "PSPT" : "VISA",
                expiryDate: document.payload.expiryDate,
                number: document.payload.passportNumber,
                issuerCountry: get3CharCountryCode(document.payload.countryOfIssue)
            })
            console.log(`ibReqBody: ${JSON.stringify(ibReqBody.documents)}`)
            return [ibReqBody]
        }


        else if (document.type === "DESTINATION_ADDRESS") {
            ibReqBody.destinationAddress = {
                address: document.payload.street,
                city: document.payload.city,
                state: document.payload.stateProv,
                zipCode: document.payload.postalCode,
                country: get3CharCountryCode(document.payload.country)
            }

            return [ibReqBody]
        }


        else if (document.type === "RESIDENT_ADDRESS") {
            ibReqBody.homeAddress = {
                address: document.payload.address,
                city: document.payload.city,
                state: document.payload.state,
                zipCode: document.payload.zipCode,
                country: get3CharCountryCode(document.payload.countryOfResidence)
            }

            return [ibReqBody]
        }

        else if (document.type === "EMERGENCY_CONTACT") {
            ibReqBody.emergencyContact = {
                name: `${document.payload.givenName} ${document.payload.familyName}`,
                phone: {
                    countryCode: document.payload.phone.countryCode,
                    number: document.payload.phone.number
                },
                refused: document.payload.refused
            }

            return[ibReqBody]
        }
        
        else {
            return [ibReqBody]
        }

    },

    sendDocsNotPopulatedInGetSecResponse: function sendDocsNotPopulatedInGetSecResponse(getSecResponse) {

        const { passengersSecurityInformation } = getSecResponse;
        const { emergencyContact, destinationAddress, mandatoryDocuments, requiredFields } = passengersSecurityInformation[0];
        console.log(requiredFields)
        let resultDocs = [];

        // Look in requiredfields and push to array
        for (let item of requiredFields) {
            if (item.startsWith('DESTINATION') && !resultDocs.includes('DESTINATION_ADDRESS')) {
                resultDocs.push('DESTINATION_ADDRESS');
            }

            if (item.startsWith('HOME') && !resultDocs.includes('RESIDENT_ADDRESS')) {
                resultDocs.push('RESIDENT_ADDRESS');
            }
            // Ignoring EMERGENCY_CONTACT as it is supposed to be pre-populated from carrier side
            if (item.startsWith('EMERGENCY') && !resultDocs.includes('EMERGENCY_CONTACT')) {
                // resultDocs.push('EMERGENCY_CONTACT');
                console.log('Info - EMERGENCY_CONTACT required, but ignoring as it is to be set by Carrier');
            }
        }

        // Look in mandatoryDocuments and push to array
        if (mandatoryDocuments.length >= 1) {
            let mandatoryDocx = mandatoryDocuments[0].documents;
            const newArr = mandatoryDocx.map(item => {
                const { type } = item;
                const { code } = type;
                // console.log(code);
                if (code === 'PSPT') {
                    return 'PASSPORT'
                }
                else if (code === 'VISA') {
                    return 'VISA'
                }
                else {
                    return 'SEE_AGENT'
                }
            })
            resultDocs.push(...newArr);
        }
        // console.log(resultDocs)
        // [ 'RESIDENT_ADDRESS', 'DESTINATION_ADDRESS', 'PASSPORT' ]

        const ccResponseDoc = []
        for (let item of resultDocs) {
            if (item === 'RESIDENT_ADDRESS') {
                // Look in Get Sec Response whether its populated or not
                if (passengersSecurityInformation[0].homeAddress === null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'DESTINATION_ADDRESS') {
                if (passengersSecurityInformation[0].destinationAddress === null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'PASSPORT') {
                if (!passengersSecurityInformation[0].documents.some(item => item.type.code === "PSPT") && passengersSecurityInformation.documents !== null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'VISA') {
                if (!passengersSecurityInformation[0].documents.some(item => item.type.code === "VISA") && passengersSecurityInformation.documents !== null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'SEE_AGENT') {
                ccResponseDoc.push(item)
            }
            else {
                break;
            }
        }
        return ccResponseDoc
    },

    retrieveDocumentsFromGetSecResponse: function retrieveDocumentsFromGetSecResponse(mandatoryDocuments, requiredFields) {
        let resultDocs = [];

        // Look in requiredfields and push to array
        for (let item of requiredFields) {
            if (item.startsWith('DESTINATION') && !resultDocs.includes('DESTINATION_ADDRESS')) {
                resultDocs.push('DESTINATION_ADDRESS');
            }

            if (item.startsWith('HOME') && !resultDocs.includes('RESIDENT_ADDRESS')) {
                resultDocs.push('RESIDENT_ADDRESS');
            }
            // Ignoring EMERGENCY_CONTACT as it is supposed to be pre-populated from carrier side
            if (item.startsWith('EMERGENCY') && !resultDocs.includes('EMERGENCY_CONTACT')) {
                // resultDocs.push('EMERGENCY_CONTACT');
                console.log('Info - EMERGENCY_CONTACT required, but ignoring as it is to be set by Carrier');
            }
        }

        // Look in mandatoryDocuments and push to array
        if (mandatoryDocuments.length >= 1) {
            let mandatoryDocx = mandatoryDocuments[0].documents;
            const newArr = mandatoryDocx.map(item => {
                const { type } = item;
                const { code } = type;
                // console.log(code);
                if (code === 'PSPT') {
                    return 'PASSPORT'
                }
                else if (code === 'VISA') {
                    return 'VISA'
                }
                else {
                    return 'SEE_AGENT'
                }
            })
            resultDocs.push(...newArr);
        }
        return resultDocs;
    },

    getAllDocumentsFromGetSec: function getAllDocumentsFromGetSec(getSecResponse, destinationCountry) {
        const { passengersSecurityInformation } = getSecResponse;
            return passengersSecurityInformation.map((paxInfo) => {
                const { mandatoryDocuments, requiredFields } = paxInfo;
                const resultDocs = this.retrieveDocumentsFromGetSecResponse(mandatoryDocuments, requiredFields)
                let populatedDocs = [];
                let nonPopulatedDocs = [];

                populatedDocs = this.getPopulatedDocsFromGetSecResponse(resultDocs, paxInfo, destinationCountry);
                nonPopulatedDocs = this.getNonPopulatedDocsFromGetSecResponse(resultDocs, paxInfo, destinationCountry);
                return {
                    requiredDocuments: nonPopulatedDocs,
                    populatedDocs
                }
            })

    },


    getNonPopulatedDocsFromGetSecResponse: function getPopulatedDocsFromGetSecResponse(resultDocs, passengersSecurityInformation, destinationCountry) {
        const ccResponseDoc = [];
        let result = [];

        for (let item of resultDocs) {
            if (item === 'RESIDENT_ADDRESS') {
                // Look in Get Sec Response whether its populated or not
                if (passengersSecurityInformation.homeAddress === null) {
                    // if (destinationCountry === 'US') {
                    //     addressDocs.push(item);
                    // } 
                    // else {
                    //     ccResponseDoc.push(item);
                    // }
                    ccResponseDoc.push(item);
                }
            }
            else if (item === 'DESTINATION_ADDRESS') {
                if (passengersSecurityInformation.destinationAddress === null) {
                    // if (destinationCountry === 'US') {
                    //     addressDocs.push(item);
                    // } 
                    // else {
                    //     ccResponseDoc.push(item);
                    // }
                    ccResponseDoc.push(item);
                }
            }
            else if (item === 'PASSPORT') {
                if (!passengersSecurityInformation.documents.some(item => item.type.code === "PSPT") && passengersSecurityInformation.documents !== null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'VISA') {
                if (!passengersSecurityInformation.documents.some(item => item.type.code === "VISA") && passengersSecurityInformation.documents !== null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'SEE_AGENT') {
                ccResponseDoc.push(item)
            }
            else {
                break;
            }
        }

        if (destinationCountry === 'US' && ccResponseDoc.length > 0) {
            result.push(ccResponseDoc);
        }
        else {
            result = ccResponseDoc;
        }

        return result;
    },

    getPopulatedDocsFromGetSecResponse: function getPopulatedDocsFromGetSecResponse(resultDocs, passengersSecurityInformation, destinationCountry) {
        const ccResponseDoc = []
        let result = [];

        for (let item of resultDocs) {
            if (item === 'RESIDENT_ADDRESS') {
                // Look in Get Sec Response whether its populated or not
                if (passengersSecurityInformation.homeAddress !== null) {
                    // if (destinationCountry === 'US') {
                    //     addressDocs.push(item);
                    // } 
                    // else {
                    //     ccResponseDoc.push(item);
                    // }
                    ccResponseDoc.push(item);           
                }
            }
            else if (item === 'DESTINATION_ADDRESS') {
                if (passengersSecurityInformation.destinationAddress !== null) {
                    // if (destinationCountry === 'US') {
                    //     addressDocs.push(item);
                    // } 
                    // else {
                    //     ccResponseDoc.push(item);
                    // }
                    ccResponseDoc.push(item);
                }
            }
            else if (item === 'PASSPORT') {
                if (passengersSecurityInformation.documents.some(item => item.type.code === "PSPT") && passengersSecurityInformation.documents !== null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'VISA') {
                if (passengersSecurityInformation.documents.some(item => item.type.code === "VISA") && passengersSecurityInformation.documents !== null) {
                    ccResponseDoc.push(item)
                }
            }
            else if (item === 'SEE_AGENT') {
                ccResponseDoc.push(item)
            }
            else {
                break;
            }
        }

        if (destinationCountry === 'US' && ccResponseDoc.length > 0) {
            result.push(ccResponseDoc);
        }
        else {
            result = ccResponseDoc
        }

        return result
    },

    isEmptyObject: function isEmptyObject(obj) {
        if (typeof obj === 'object' && obj != null && Object.keys(obj).length !== 0) {
            return false;
        } else if (typeof obj === 'string' && obj) {
            return false;
        }
        else {
            return true;
        }
    },

    isEmergencyContactEmpty: function isEmergencyContactEmpty(obj) {
        if (obj.name === null && obj.phone === null && obj.refused) {
            return true
        }
        return false
    },

    handleGetDocsForPax: async function handleGetDocsForPax(passengerData, token, checkinId) {
        let eligibilityResponse;

        if (passengerData.requiredInformation.some(item => item === 'API') && passengerData.requiredInformation.some(item => item === 'EMERGENCY_DATA')) {
            eligibilityResponse = await this.handleGetSecResponse(passengerData, token, checkinId);
            eligibilityResponse = {...eligibilityResponse, requiredDocuments: eligibilityResponse.requiredDocuments.concat('EMERGENCY_CONTACT')}
        }
        else if (passengerData.requiredInformation.some(item => item === 'API')) {
            eligibilityResponse = await this.handleGetSecResponse(passengerData, token, checkinId);
        }
        else if (passengerData.requiredInformation.some(item => item === 'EMERGENCY_DATA')) {
            eligibilityResponse = {
                requiredDocuments: ['EMERGENCY_CONTACT'],
                populatedDocuments: []
            }
        }
        else {
            // eligibilityResponse = this.handleGetSecResponse(passengerData, token, checkinId)
            eligibilityResponse = {
                "requiredDocuments": [],
                "populatedDocuments": []
            }
        }

        return eligibilityResponse;
    },

    handleGetDocsForMultiPax: async function handleGetDocsForMultiPax(passengerData, token, checkinId, ccPaxReqs) {
        const multiEligibilityResponse = [];

        for (const pax of passengerData) {
            let paxEligibilityRes;
            const ccPax = ccPaxReqs.find((item) => pax.name.toLowerCase() === item.givenName.toLowerCase() && pax.surname.toLowerCase() === item.familyName.toLowerCase());

            if (pax.requiredInformation.some((item) => item === "API") && pax.requiredInformation.some(item => item === 'EMERGENCY_DATA')) {
                paxEligibilityRes = await this.handleGetSecResponse(pax, token, checkinId, ccPax)
                paxEligibilityRes = {...paxEligibilityRes, requiredDocuments: paxEligibilityRes.requiredDocuments.concat('EMERGENCY_CONTACT')}
            }
            else if (pax.requiredInformation.some(item => item === 'API')) {
                paxEligibilityRes = await this.handleGetSecResponse(pax, token, checkinId, ccPax);

            }
            else if (pax.requiredInformation.some(item => item === 'EMERGENCY_DATA')) {
                paxEligibilityRes = {
                    requiredDocuments: ['EMERGENCY_CONTACT'],
                    populatedDocuments: [],
                    familyName: ccPax.familyName,
                    givenName: ccPax.givenName,
                    eTicketNumber: ccPax.eTicketNumber
                }
            }
            else {
                // const paxEligibilityRes = await this.handleGetSecResponse(pax, token, checkinId, ccPax)
                paxEligibilityRes = {
                    requiredDocuments: [],
                    populatedDocumnets: [],
                    familyName: ccPax.familyName,
                    givenName: ccPax.givenName,
                    eTicketNumber: ccPax.eTicketNumber
                }

            }
            multiEligibilityResponse.push(paxEligibilityRes);
        }

        return multiEligibilityResponse;

    },

    handleGetSecResponse: async function handleGetSecResponse(passengerData, token, checkinId, ccPaxReq) {
        const targetResponse = await api.getSecurityDocs(token, checkinId, passengerData.id)
        const finalDestination = this.getFinalDestination(targetResponse);

        const allDocuments = this.getAllDocumentsFromGetSec(targetResponse, finalDestination);

        let responseObj = {
            requiredDocuments: allDocuments[0].requiredDocuments,
            populatedDocuments: allDocuments[0].populatedDocs
        }

        if (ccPaxReq) {
            responseObj.familyName = ccPaxReq.familyName
            responseObj.givenName = ccPaxReq.givenName
            responseObj.eTicketNumber = ccPaxReq.eTicketNumber
        }

        return responseObj

    },

    handleDocUpdateForPax: async function handleDocUpdateForPax(passengerData, token, checkinId, rloc, reqBody, familyName, givenName) {
        if (passengerData.requiredInformation.some(item => item === 'API')) {

            console.log(`documentsupdate - Calling api.getSecurityDocs. rloc = ${rloc}, checkinId = ${checkinId}`);

            let passengerId = passengerData.id;

            const getSecurityResponse = await api.getSecurityDocs(token, checkinId, passengerId)

            let ibReqBody = {};

            console.log(`documentsupdate - Calling utils.addExistingFieldsAndDocsToRequest. rloc = ${rloc}`);
            this.addExistingFieldsAndDocsToRequest(ibReqBody, getSecurityResponse);

            let addDocumentException;

            console.log(`documentsupdate - Calling utils.addNewDocumentToRequestBody. rloc = ${rloc}`);
            if (Array.isArray(reqBody.document)) {

                for (let reqDoc of reqBody.document) {
                    addDocumentException = this.addNewDocumentToRequestBody(familyName, givenName, passengerId, reqDoc, ibReqBody, getSecurityResponse);
                    if (addDocumentException) { break; }
                }

            } else {
                addDocumentException = this.addNewDocumentToRequestBody(familyName, givenName, passengerId, reqBody.document, ibReqBody, getSecurityResponse);
            }

            if (!addDocumentException && this.isEmptyObject(ibReqBody)) {
                throw new Error('Error creating update document request');
            }

            let resultDocs;

            if (addDocumentException) {
                resultDocs = addDocumentException;
            } else {
                console.log(`Put Security final request = ${JSON.stringify(ibReqBody, null, 2)}`);
                resultDocs = await api.updateSecurityDocs(checkinId, [ibReqBody], token);
            }

            //If putsec returns 200 OK and no further require docs, check getsec again
            if (resultDocs && resultDocs.length === 0) {
                console.log(`documentsupdate - Calling api.getSecurityDocs. rloc = ${rloc}, checkinId = ${checkinId}`);

                const getSecResponseAfterUpdatingDocuments = await api.getSecurityDocs(token, checkinId, passengerId);
                const finalDestination = this.getFinalDestination(getSecResponseAfterUpdatingDocuments);

                const docsFromGetSecRes = this.retrieveDocumentsFromGetSecResponse(getSecResponseAfterUpdatingDocuments.passengersSecurityInformation[0].mandatoryDocuments, getSecResponseAfterUpdatingDocuments.passengersSecurityInformation[0].requiredFields)
                const requiredDocuments = this.getNonPopulatedDocsFromGetSecResponse(docsFromGetSecRes, getSecResponseAfterUpdatingDocuments.passengersSecurityInformation[0], finalDestination);
                const populatedDocuments = this.getPopulatedDocsFromGetSecResponse(docsFromGetSecRes, getSecResponseAfterUpdatingDocuments.passengersSecurityInformation[0], finalDestination);

                return {
                    requiredDocuments,
                    populatedDocuments
                }
            }

            // return resultDocs;

            // If getSecurity Response throws any Error
            // Commenting below line because IB API can send TRM_APIM_9006 for different error scenarios, not just when APIS are not required
            // if (getSecurityResponse.data.errors.some(item => item.code === "TRM_APIM_9006")) {
            //     return { "requiredDocuments": [] }
            // }

        }
        else {
            // return this.handleGetSecResponse(passengerData, token, checkinId)
            console.info('Skipping Get Security call as Requirements[] is empty in Booking Response')
            return {
                "requiredDocuments": [],
                "populatedDocuments": []
            }
        }

    },

    convertToV2Params: function convertToV2Params({ recordRequest }) {
        const { rloc, familyName } = recordRequest;
        return {
            rloc,
            familyName,
        };
    },

    convertToV2Body: function convertToV2Body({ requirements, flightRequests, passengerRequests }) {
        const v2Body = {
            flightLookups: flightRequests.map(this._flightRequestToLookup),
            passengerLookups: passengerRequests
        }

        if (typeof requirements === 'object' && requirements !== undefined) {
            v2Body.requirements = {
                acknowledgeDGTerms: requirements.acknowledgeDGTerms
            };
        }
        return v2Body;
    },

    _flightRequestToLookup: function _flightRequestToLookup({ date, flightNumber, carrierCode, origin, destination }) {
        return {
            carrier: carrierCode,
            date, flightNumber, origin, destination,
        };
    },

    retrievePaxFields: function retrievePaxFields(payload) {
        const { givenName, familyName } = payload;
        return {
            paxFamilyName: familyName,
            paxGivenname: givenName,
        }
    },

    callGetAndPutSecForAccept: async function callGetAndPutSecForAccept(booking, token, rloc, paxReq) {
        if (this.verifypaxAllowedForCheckin(booking, paxReq)) {
            throw new Error('Target is unable to check-in for all passengers - please try again  - if this message continues online check-in is not possible - please check-in via agent desk.')
        }
        else {
            const { checkinId, passengers } = booking;

            if (isArray(paxReq)) {
                var { familyName, givenName } = paxReq[0];
            }
            else {
                var { familyName, givenName } = paxReq;
            }

            let pax;

            if (passengers.length == 1) {
                pax = passengers[0]
            } else {
                if (passengers.some(item => item.name.toLowerCase() === givenName.toLowerCase() && item.surname.toLowerCase() === familyName.toLowerCase())) {
                    pax = passengers.filter(item => item.name.toLowerCase() === givenName.toLowerCase() && item.surname.toLowerCase() === familyName.toLowerCase())[0]

                } else {
                    throw new Error('Matching passenger not found')
                }
            }

            console.log('Iam at callGetAndPutSecForAccept function')
            // Calling Get Security call
            let eligibilityResponse, getSecurityResponse

            if (pax.requiredInformation.some(item => item === "API")) {

                console.log('Iam at getSecurity function')

                getSecurityResponse = await api.getSecurityDocs(token, checkinId, pax.id)

                resultDocs = this.retrieveDocumentsFromGetSecResponse(getSecurityResponse.passengersSecurityInformation[0].mandatoryDocuments, getSecurityResponse.passengersSecurityInformation[0].requiredFields)

                eligibilityResponse = this.getNonPopulatedDocsFromGetSecResponse(resultDocs, getSecurityResponse.passengersSecurityInformation[0]);

                // eligibilityResponse = this.sendDocsNotPopulatedInGetSecResponse(getSecurityResponse)

                if (eligibilityResponse.length === 0) {

                    console.log('Iam at put security function')

                    console.log('Eligibility response: ', { requiredDocuments: eligibilityResponse })

                    let ibReqBody = {};

                    console.log(`documentsupdate - Calling utils.addExistingFieldsAndDocsToRequest. rloc = ${rloc}`);

                    this.addExistingFieldsAndDocsToRequest(ibReqBody, getSecurityResponse);

                    console.log(`Put Security final request = ${JSON.stringify(ibReqBody, null, 2)}`);

                    // Calling Put Security call

                    resultDocs = await api.updateSecurityDocs(checkinId, [ibReqBody], token);

                    console.log('Document update response: ', resultDocs);
                }
                else {
                    throw new Error('Documents needs to be updated for checkin')
                }
            }
        }
    },

    verifypaxAllowedForCheckin: function verifypaxAllowedForCheckin(booking, paxReq) {
        const { passengers } = booking;
        //For single acceptance
        if (isArray(paxReq)) {
            return this.checkAllowedFlag(passengers, ...paxReq)
        }
        //Multi acceptance
        else {
            return this.checkAllowedFlag(passengers, paxReq)
        }
    },

    checkAllowedFlag: function checkAllowedFlag(passengers, ccPax) {
        const paxFound = passengers.filter((pax) => pax.surname.toLowerCase() === ccPax.familyName.toLowerCase() && pax.name.toLowerCase() === ccPax.givenName.toLowerCase())[0];
        if (paxFound.status.code === 'NOT_ALLOWED') {
            return true
        }
        return false

    },

    partialCheckinStatusCode: function partialCheckinStatusCode(v2Response, cb) {
        if (v2Response.pnr.passengers.every((pax) => pax.coupons[0].isCheckedIn === true)) {
            return cb(null, response(200, v2Response));
        }
        return cb(null, response(206, v2Response))
    },

    processNameAndTitle: function processNameAndTitle(name) {
        //list of titles supported by MH carrier
        const titlesList = [
          "mr",
          "mrs",
          "ms",
          "master",
          "miss",
          "dato'",
          "datin",
          "datuk",
          "tun",
          "puansri",
          "tansri",
          "tohpuan",
          "datoseri",
          "datukseri",
          "datinseri",
          "datinsri",
          "dato`sri",
          "datuksri",
        ];

        const nameParts = name.split(' ');
        let title = null;
        let processedName = name;

        for (let i = 0; i < nameParts.length; i++) {
          const namePart = nameParts[i];

          for (let j = 0; j < titlesList.length; j++) {
            const titleOption = titlesList[j];

            if (namePart.toUpperCase() === titleOption.toUpperCase()) {
              title = namePart.split(" ").find((item) => titlesList.includes(item.toLowerCase()));
              processedName = name.replace(new RegExp(titleOption, 'i'), '').trim();
              break;
            }
          }

          if (title) {
            break;
          }
        }

        return { paxName: processedName, paxTitle: title };
    },

    getFinalDestination: function getFinalDestination(targetResponse) {
        let finalDestination = targetResponse?.requiredFieldsOptions.length > 0 ? targetResponse?.requiredFieldsOptions.map((destCountry) => {
            if (destCountry.field === 'DESTINATION_COUNTRY' && destCountry.values.some((countryCode) => countryCode.code === 'US')) {
                console.log('US destination found');
                return 'US'
            }
            else {
                console.log('Non US Destintion is found');
                return 'NON-US'
            }
        }) : ['NON-US'];

        return finalDestination[0];
    }
}

