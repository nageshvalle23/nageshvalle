const svc = require("./index");

const lookup = {
  rloc: 'PVQ22P',
  familyName: 'FAKE',
  givenName: 'ONE'
};

const passengerLookups = [
  {
    familyName: 'FAKE',
    givenName: 'ONE',
    eTicketNumber: '0752000452653'
  }
];

const flightLookups = [

  {
    "origin": "LIS",
    "destination": "MAD",
    "flightNumber": "3103",
    "carrier": "IB",
    "date": "2021-01-16"
  },
  {
    "origin": "MAD",
    "destination": "DOH",
    "flightNumber": "0150",
    "carrier": "QR",
    "date": "2021-01-17"
  }
]

const event = {
  queryStringParameters: lookup,
  body: JSON.stringify({
    passengerLookups,
    flightLookups,
    checkIn: true,
    requirements: {
      acknowledgeDGTerms: true
    }
  })
}
// ------------------------------ get booking  -------------------------------
/* svc.record(event, null, (err, response) => {
 *   console.log(JSON.stringify(JSON.parse(response.body), null, '  '))
 * }); */


// ------------------- check in  -------------------------------
// svc.checkin({
//   queryStringParameters: lookup,
//   body: JSON.stringify({
//     passengerLookups,
//     flightLookups,
//     checkIn: true,
//     requirements: {
//       acknowledgeDGTerms: true
//     }
//   })
// }, null, (err, res) => {
//   console.log(JSON.stringify(JSON.parse(res.body), null, '  '), '<<<<<<<<<<<<<')
// })

// ------------------- boarding card formats -------------------
// svc.boardingpass({
//   queryStringParameters: lookup,
//   body: JSON.stringify({
//     passengerLookups,
//     flightLookups
//   })
//   },
//   null,
//   (err, response) => {
//     console.log(JSON.stringify(JSON.parse(response.body), null, '   '))
//   });