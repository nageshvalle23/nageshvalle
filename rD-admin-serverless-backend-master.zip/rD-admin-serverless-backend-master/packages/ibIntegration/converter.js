const dlv = require("dlv");
const dateUtil = require("@oneworld-digital/integration-utils").date;
const helpers = require("./helpers");

exports.toRecord = function (booking, boardingPass) {
  const flights = extractFlights(booking);
  const paxs = extractPaxs(booking, boardingPass);

  const record = {
    lookup: null,
    pnr: {
      rloc: booking.resiberLocator,
      flights: flights,
      passengers: paxs
    },
    errors: null
  };

  return record;
};

exports.toBpRecord = function (booking, boardingPass, paxLookups) {
  const flights = extractFlights(booking);
  const paxs = bpextractPaxs(booking, boardingPass, paxLookups);

  const record = {
    // lookup: null,
    pnr: {
      rloc: booking.resiberLocator,
      flights: flights,
      passengers: paxs
    },
    // errors: null
  };

  return record;
};

function extractFlights(booking) {
  let flights = {};

  Object.assign(
    flights,
    ibSegmentsToCcFlight(booking.outwardSegments),
    ibSegmentsToCcFlight(booking.returnSegments)
  );

  return Object.values(flights);
}

function extractPaxs(booking, boardingPass, clientCarrier) {
  const passengers = {};

    for (let pax of booking.passengers) {
        const outwardSeg = ibSegmentsToCcCoupon(
          booking.outwardSegments,
          boardingPass,
          pax.id,
        );
        const returnSeg = ibSegmentsToCcCoupon(
          booking.returnSegments,
          boardingPass,
          pax.id,
        );

        const coupons = Object.values(Object.assign({}, outwardSeg, returnSeg));

        // infant details are included on the adult coupon.
        // split adult / infant coupons. infant has same details except for ticket#
        let adultCoupons = [];
        let infantCoupons = [];
        coupons.forEach(c => {
          adultCoupons.push(c.adult);

          if (!!c.infant) {
            infantCoupons.push(c.infant);
          }
        });

        if (!passengers[pax.id]) {
          passengers[pax.id] = {
            familyName: pax.surname,
            givenName: pax.name,
            title: pax.title,
            ageCategory: pax.type,
            coupons: adultCoupons,
          };
        } else {
          passengers[pax.id].coupons = passengers[pax.id].coupons.concat(
            adultCoupons
          );
        }

        if (!!pax.infant) {
          passengers[pax.id + "INF"] = {
            familyName: pax.infant.surname,
            givenName: pax.infant.name,
            ageCategory: "INFANT",
            coupons: infantCoupons
          };
        }
      }

  return Object.values(passengers);
}

function bpextractPaxs(booking, boardingPass, paxLookups) {
  const passengers = {};

  for (let eachPax of paxLookups) {
    for (let pax of booking.passengers) {
      if (eachPax.familyName.toLowerCase() === pax.surname.toLowerCase() && eachPax.givenName.toLowerCase() === pax.name.toLowerCase()) {
        const outwardSeg = ibSegmentsToCcCoupon(
          booking.outwardSegments,
          boardingPass,
          pax.id,
          paxLookups
        );
        const returnSeg = ibSegmentsToCcCoupon(
          booking.returnSegments,
          boardingPass,
          pax.id,
          paxLookups
        );

        const coupons = Object.values(Object.assign({}, outwardSeg, returnSeg));

        // infant details are included on the adult coupon.
        // split adult / infant coupons. infant has same details except for ticket#
        let adultCoupons = [];
        let infantCoupons = [];
        coupons.forEach(c => {
          adultCoupons.push(c.adult);

          if (!!c.infant) {
            infantCoupons.push(c.infant);
          }
        });

        if (!passengers[pax.id]) {
          passengers[pax.id] = {
            familyName: pax.surname,
            givenName: pax.name,
            title: pax.title,
            ageCategory: pax.type,
            coupons: adultCoupons
          };
        } else {
          passengers[pax.id].coupons = passengers[pax.id].coupons.concat(
            adultCoupons
          );
        }

        if (!!pax.infant) {
          passengers[pax.id + "INF"] = {
            familyName: pax.infant.surname,
            givenName: pax.infant.name,
            ageCategory: "INFANT",
            coupons: infantCoupons
          };
        }
      }
    }
  }

  return Object.values(passengers);
}

function ibFlightToCcFlight(ibFlight) {
  return {
    origin: dlv(ibFlight, "departure.airport.code"),
    destination: dlv(ibFlight, "arrival.airport.code"),
    flightNumber: dlv(ibFlight, "operatingFlightNumber.number"),
    carrier: dlv(ibFlight, "operatingFlightNumber.company.code"),
    date: dateUtil.toLookupDate(new Date(dlv(ibFlight, "departure.date")))
  };
}

function ibFlightToCcCoupon(ibFlight, bp, pax) {
  const { origin, destination, carrier, flightNumber } = ibFlightToCcFlight(
    ibFlight
  );
  const checkedIn = helpers.isCouponCheckedIn(pax);

  const coupon = {
    adult: {
      isCheckedIn: checkedIn,
      boardingPass: formatBoardingPass(bp, pax.id),
      departureDateTime: dlv(ibFlight, "departure.date"),
      origin,
      destination,
      carrier,
      flightNumber,
      eTicketNumber: dlv(pax, "ticket.number")
    }
  };

  if (!!pax.infantTicket) {
    let infant = Object.assign({}, coupon.adult);
    infant.eTicketNumber = dlv(pax, "infantTicket.number");

    coupon.infant = infant;
  }

  return coupon;
}

function formatBoardingPass(bp, paxId) {
  // boarding pass endpoints return segment & pax id as string - not numeric

  if (bp !== undefined) {
    const pax = bp.passengers.find(p => p.id == paxId);

    if (pax.barcode) {
      return {
        barcodeData: pax.barcodeContent,
        qrCodeData: "",
        seatNumber: pax.seat.row + pax.seat.column,
        passengerClass: dlv(pax, "cabinClass.type"), // code / type / description
        boardingTime: dlv(bp, "boarding.date"),
        eTicketNumber: pax.ticketNumber,
        frequentFlierNumber: pax.frequentFlyer,
        sequenceNumber: "",
        iOSPassbookFile: "", // TODO
        gate: dlv(bp, "boarding.gate"),
        terminal: dlv(bp, "departure.terminal"),
        securityNumber: "",
        boardingGroup: pax.boardingNumber, // TODO same as boardingNumber?
        allowTSA: "",
        allowFastTrack: pax.fastTrack
      };
    }
  }

  return null;
}

function ibSegmentsToCcFlight(segments) {
  const flights = {};
  for (let s of segments) {
    const flightKey =
      dlv(s, "departure.airport.code") +
      dlv(s, "arrival.airport.code") +
      dlv(s, "departure.date") +
      dlv(s, "operatingFlightNumber.number");
    flights[flightKey] = ibFlightToCcFlight(s);
  }
  return flights;
}

function ibSegmentsToCcCoupon(segments, boardingPass, paxId, paxLookups) {
  // boarding pass endpoints return segment & pax id as string - not numeric.
  // getbooking & accept return numeric ids
  const coupons = {};
  let bp;
  for (let flight of segments) {
    const pax = flight.passengers.find(p => p.id === paxId);

    if (boardingPass !== undefined && paxLookups !== undefined) {
      bp = boardingPass.boardingCards.find(b => b.id == flight.id);
    }
    coupons[flight.id] = ibFlightToCcCoupon(flight, bp, pax);
  }
  return coupons;
}
