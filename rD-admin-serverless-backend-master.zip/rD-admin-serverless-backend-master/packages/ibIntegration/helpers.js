const dlv = require("dlv");
const dateUtil = require("@oneworld-digital/integration-utils").date;

function isPaxCheckable(status) {
  if (status === 'CHECKABLE' || status === 'CHECKED') {
    return 'CHECKABLE'
  }
  else {
    return "UNCHECKABLE"
  }
  // return dlv(cpn, "status.code") === "CHECKABLE" ? "CHECKABLE" : "UNCHECKABLE";
}

function isCouponCheckedIn(cpn) {
  return dlv(cpn, "status.code") === "CHECKED" ? true : false;
}

function verifyCheckablilityAndGetCheckinRequest_V1andV2(segmentIds, paxs, checkin) {
  if (paxs[0].coupons.some(item => item.isCheckinStatus === 'UNCHECKABLE')) {
    throw new Error('Target is unable to check-in for all segments - please try again  - if this message continues online check-in is not possible - please check-in via agent desk.')
  }
  else {
    // proceed with checkin
    const checkinRequest = getCheckinRequestForAccept(segmentIds, paxs, checkin)
    return checkinRequest
  }
}

function verifyCheckablilityAndGetCheckinRequest_MultiCheckin(segmentIds, paxs, checkin) {
  // logic to check whether any paxs are checkable or not
  const allPaxCheckableEligibility = paxs.some(item => {
    return item.coupons.some(cpn => cpn.isCheckinStatus === 'UNCHECKABLE')
  })

  // If any pax UNCHECKABLE throw an error 
  if (allPaxCheckableEligibility) {
    throw new Error('Target is unable to check-in for all segments - please try again  - if this message continues online check-in is not possible - please check-in via agent desk.')
  }
  else {
    const checkinRequest = getCheckinRequestForAccept(segmentIds, paxs, checkin)
    return checkinRequest
  }
}

function getCheckinRequestForAccept(segmentIds, paxs, checkin) {
  if (
    !paxs ||
    !paxs.length ||
    !segmentIds ||
    !segmentIds.length ||
    segmentIds.length !== checkin.flightLookups.length
  ) {
    throw new Error("Checkin lookup error");
  }

  const checkinRequest = {
    dangerousItemsInfoAccepted: dlv(checkin, "requirements.acknowledgeDGTerms"),
    segments: segmentIds.map(seg => ({
      id: seg,
      passengers: paxs.map(pax => pax.id)
    }))
  };

  return checkinRequest;
}

function formatCheckinRequest(booking, checkin) {
  const segmentIds = getFlightSegmentIds(booking, checkin.flightLookups);
  const paxs = getLookupPassengers(booking, checkin.passengerLookups, false);
  if (
    !paxs ||
    !paxs.length ||
    !segmentIds ||
    !segmentIds.length ||
    segmentIds.length !== checkin.flightLookups.length
  ) {
    throw new Error("Checkin lookup error");
  }
  const checkinRequest = {
    dangerousItemsInfoAccepted: dlv(checkin, "requirements.acknowledgeDGTerms"),
    segments: segmentIds.map(seg => ({
      id: seg,
      passengers: paxs.map(pax => pax.id)
    }))
  };
  return checkinRequest;
}

function formatCheckinRequestForAccept(booking, checkin, isV2) {
  const segmentIds = getFlightSegmentIds(booking, checkin.flightLookups);
  const paxs = getLookupPassengers(booking, checkin.passengerLookups, false);

  if (isV2 !== undefined && isV2 && paxs.length === 1) {
    const checkinRequest = verifyCheckablilityAndGetCheckinRequest_V1andV2(segmentIds, paxs, checkin)
    return checkinRequest
  }
  else {
    const checkinRequest = verifyCheckablilityAndGetCheckinRequest_MultiCheckin(segmentIds, paxs, checkin)
    return checkinRequest
  }
}

function verifyBoardingPassFormat(boardingPassFormats) {
  // DOWNLOAD channel required
  // NATIVE format required on each segment
  var formatsValid;

  if (!boardingPassFormats.channels.includes("DOWNLOAD")) {
    throw new Error("Required boarding pass DOWNLOAD is not available.");
  }
  boardingPassFormats.documents.forEach(doc => {
    doc.segments.forEach(seg => {
      if (!seg.formats.includes("NATIVE")) {
        throw new Error("Required boarding pass format is not available.");
      } else {
        formatsValid = true;
      }
    });
  });

  if (formatsValid === undefined) {
    throw new Error("Required boarding pass format is not available.");
  }
}

function formatBoardingPassRequest(boardingPassFormats) {
  verifyBoardingPassFormat(boardingPassFormats);
  var segmentJSON = boardingPassFormats.documents[0].segments.map(seg => {
    if (seg.formats.includes("NATIVE")) {
      return {
        id: seg.id,
        passengers: seg.passengers.map(pax => pax.id)
      };
    } else {
      return null;
    }
  });

  segmentJSON = segmentJSON.filter(seg => seg !== null);

  const bpRequest = [
    {
      format: "NATIVE",
      sharings: [
        {
          channel: "DOWNLOAD",
          segments: segmentJSON
        }
      ]
    }
  ];

  return bpRequest;
}

/**
 *  Check that passenger lookup matches record in IB booking
 */
function _matchPaxLookup(lookup, pax) {
  return (
    lookup.givenName.toLowerCase() === pax.name.toLowerCase() &&
    lookup.familyName.toLowerCase() === pax.surname.toLowerCase() &&
    lookup.eTicketNumber === pax.eTicketNumber
  );
}

/**
 *  Infants are filtered out of IB check in requests because they
 *  inherit the checkin status from an adult, however they do receive
 *  boarding passes so must be included there
 */
function getLookupPassengers(booking, passengerLookups, includeInfants) {
  // Match booking passengers to lookup
  let passengers = consolidatePassengerBooking(booking).filter((pax) => {
    return passengerLookups.some((lookup) => {
      return _matchPaxLookup(lookup, pax);
    })
  });

  // Filter infants if necessary
  let expectedPax = passengerLookups.length;
  if (!includeInfants) {
    const infantsInLookup = passengers.filter((pax) => {
      return (
        pax.type === 'INFANT' &&
        passengerLookups.some((lookup) => {
          return _matchPaxLookup(lookup, pax);
        })
      );
    })
    expectedPax -= infantsInLookup.length;
    passengers = passengers.filter((pax) => pax.type !== 'INFANT');
  }

  // Check that lookups match passenger result (no unknown lookups)
  if (expectedPax !== passengers.length) {
    throw new Error('Passenger lookup error');
  }

  return passengers;
}

// builds a consolidated passenger object for both adults & infants
//   from IB booking object. combines passenger with coupon data.
function consolidatePassengerBooking(booking) {
  const allSegments = booking.outwardSegments.concat(booking.returnSegments);
  const consolidatedPax = {};
  booking.passengers.map(b => {
    var infant;
    var adult = {
      id: b.id,
      name: b.name,
      surname: b.surname,
      type: b.type,
      eTicketNumber: "",
      coupons: []
    };
    if (b.infant) {
      infant = {
        id: b.id + "_INF",
        name: b.infant.name,
        surname: b.infant.surname,
        type: "INFANT",
        eTicketNumber: "",
        coupons: []
      };
    }
    // build coupons
    // found during testing - eTicketNumber is not always populated on every segment.
    allSegments.map(seg => {
      seg.passengers.find(segPax => {
        if (adult.id === segPax.id) {
          adult.eTicketNumber = !!adult.eTicketNumber
            ? adult.eTicketNumber
            : dlv(segPax, "ticket.number");
          adult.coupons.push({
            status: isCouponCheckedIn(segPax),
            segId: seg.id,
            isCheckinStatus: isPaxCheckable(segPax.status.code)
          });
          //adult.checkinStatus = segPax.status.code
          // infant inherits the status from adult
          if (segPax.infantTicket) {
            infant.eTicketNumber = !!infant.eTicketNumber
              ? infant.eTicketNumber
              : dlv(segPax, "infantTicket.number");
            infant.coupons.push({
              status: isCouponCheckedIn(segPax),
              segId: seg.id,
              isCheckinStatus: isPaxCheckable(segPax.status.code)
            });
          }
        }
      });
    });
    if (adult) {
      consolidatedPax[adult.id] = adult;
    }
    if (infant) {
      consolidatedPax[infant.id] = infant;
    }
  });
  // console.log('consolidatedPax are = ', consolidatedPax)
  return Object.values(consolidatedPax);
}

function getFlightSegmentIds(booking, flightLookups) {
  var segmentIds = Object.values(
    Object.assign(
      {},
      getFlightSegmentIdsPerSegment(booking.outwardSegments, flightLookups),
      getFlightSegmentIdsPerSegment(booking.returnSegments, flightLookups)
    )
  );

  return segmentIds;
}

function getFlightSegmentIdsPerSegment(segment, flightLookups) {
  var segmentIds = {};

  // find flight segment ids for lookups in booking (outwardSegment and returnSegment)
  for (let flight of flightLookups) {
    const match = segment.find(b => {
      return (
        flight.flightNumber === dlv(b, "operatingFlightNumber.number") &&
        flight.date ===
        dateUtil.toLookupDate(new Date(dlv(b, "departure.date")))
      );
    });

    if (match) {
      segmentIds[match.id] = match.id;
    }
  }
  return segmentIds;
}

function verifyPaxCheckedIn(booking, bpLookup) {
  const lookupSegmentIds = getFlightSegmentIds(booking, bpLookup.flightLookups);
  const lookupPassengers = getLookupPassengers(booking, bpLookup.passengerLookups, true);

  if (
    !lookupPassengers ||
    !lookupPassengers.length ||
    !lookupSegmentIds ||
    !lookupSegmentIds.length ||
    lookupSegmentIds.length !== bpLookup.flightLookups.length
  ) {
    throw new Error("Boarding pass look up error");
  }

  // iterate through lookup flights
  //  ensure each lookup pax is checked in.
  lookupSegmentIds.map(lkupSeg => {
    currentSeg = lookupPassengers.map(lkupPax => {
      const couponFound = lkupPax.coupons.findIndex(c => {
        // passenger is not check in
        if (c.segId === lkupSeg && !c.status) {
          throw new Error("Cannot issue boarding pass");
        }
        return c.segId === lkupSeg && c.status;
      });
      // did not find match across booking & lookup
      if (couponFound === -1) {
        throw new Error("Cannot issue boarding pass. Coupon not found");
      }
    });
  });
  return true;
}

module.exports = {
  consolidatePassengerBooking: consolidatePassengerBooking,
  isCouponCheckedIn: isCouponCheckedIn,
  verifyBoardingPassFormat: verifyBoardingPassFormat,
  formatCheckinRequest: formatCheckinRequest,
  formatBoardingPassRequest: formatBoardingPassRequest,
  verifyPaxCheckedIn: verifyPaxCheckedIn,
  formatCheckinRequestForAccept: formatCheckinRequestForAccept
};


// ***********************************OLD CODE BASED ON 1A TESTING***********************************************

// function verifyCheckablilityAndGetCheckinRequest_MultiCheckin(segmentIds, paxs, checkin) {
  // logic to check whether any paxs are checkable or not
//   const allPaxCheckableEligibility = paxs.some(item => {
//     return item.coupons.some(cpn => cpn.isCheckinStatus === 'UNCHECKABLE')
//   })

  // If any pax UNCHECKABLE throw an error 
//   if (allPaxCheckableEligibility) {
//     throw new Error('Target is unable to check-in for all segments - please try again  - if this message continues online check-in is not possible - please check-in via agent desk.')
//   }
//   else {
//     const checkinRequest = getCheckinRequestForAccept(segmentIds, paxs, checkin)
//     return checkinRequest
//   }
// }