const queryString = require('query-string');
const axios = require('axios');
const helpers = require('./helpers');
const utils = require('./utility');

const IB_API_KEY = process.env.IB_API_KEY || 'api_key';
const IB_API_URL = process.env.IB_API_URL || 'https://test.api.iberia.com/iberia/uatd';
const IB_AUTH_TOKEN = process.env.IB_AUTH_TOKEN || 'auth_token';

const GET_TOKEN_PATH = '/security/authentication/v1/token';
const GET_BOOKING_PATH = '/cki/pac-prm/rs/checkin/v2/booking/';
const ACCEPT_PAX_PATH = '/cki/pac-pacc/rs/pacc/v2/';
const BOARDING_PASS_PATH = '/cki/pac-bpm/rs/bpm/v2/';
const SECURITY_DOCUMENTS_PATH = '/trm-apim/rs/v3/info/';
const CLOSE_SESSSION_PATH = '/cki/pac-prm/rs/checkin/v2/';

exports.retrieveToken = async function() {
  const res = await _gatherAndReportErrors(axios({
    method: 'post',
    url: IB_API_URL + GET_TOKEN_PATH,
    data: queryString.stringify({
      "grant_type": "client_credentials",
    }),
    headers: {
      'API_KEY' : IB_API_KEY,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization' : 'Basic ' + IB_AUTH_TOKEN,
      'cache-control' : 'no-cache'
    },
  }));

  const access_token = res.data.access_token;

  if (!access_token) {
    throw new Error('Failed to retrieve token');
  }

  return access_token;
};

exports.closeSession = async function(token, checkinId) {
  await _gatherAndReportErrors(axios({
    method: 'DELETE',
    url: IB_API_URL + CLOSE_SESSSION_PATH + checkinId,
    headers: {
      'API_KEY' : IB_API_KEY,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept-Language': 'en-US',
      'Authorization' : 'Bearer ' + token,
      'Request-ClientId' : 'carrier_connect',
      'cache-control' : 'no-cache'
    },
  }));
};

exports.getBooking = async function(rloc, familyName, token) {

  if ((!rloc || /.+/.test(rloc) === false) || (!familyName || /.+/.test(familyName) === false) ||
      (!token || /.+/.test(token) === false)) {
    throw new Error('Missing parameters');
  }

  const famNameBase64 = Buffer.from(familyName).toString('base64');

  console.info(`In getBooking. get booking Req Url = ${IB_API_URL + GET_BOOKING_PATH + rloc}`);
  console.info(`In getBooking. get booking Req Payload = ${'Request-Surname : ' + famNameBase64}`);

  const res = await _gatherAndReportErrors(axios({
    method: 'get',
    url: IB_API_URL + GET_BOOKING_PATH + rloc,
    headers: {
      'API_KEY' : IB_API_KEY,
      'Accept-Language': 'en-US',
      'Authorization' : 'Bearer ' + token,
      'cache-control' : 'no-cache',
      'Request-Surname' : famNameBase64,
    },
  }));

  console.info(`In getBooking. get booking Response = ${JSON.stringify(res.data, null, 2)}`);

  if (!res.data.checkinId) {
    throw new Error('Failed to retrieve token');
  }

  const updatedPaxs = res.data.passengers.map((pax) => {
    const {paxName, paxTitle} = utils.processNameAndTitle(pax.name);
    return {...pax, name: paxName, title: paxTitle ? paxTitle : pax.title}
  })
  const modifiedBooking = {...res.data, passengers: updatedPaxs}
  // console.log('Modified boooking response: ', JSON.stringify(modifiedBooking));

  return modifiedBooking;
};


exports.accept = async function(token, booking, checkin) {
  if ((!checkin || /.+/.test(checkin) === false) ||
      (!token || /.+/.test(token) === false) ||
      (!booking || /.+/.test(booking) === false) ) {
    throw new Error('Missing parameters');
  }

  if (!checkin.passengerLookups || !checkin.passengerLookups.length
    || !checkin.flightLookups || !checkin.flightLookups.length) {
      throw new Error('Missing parameters');
  }

  if (!checkin.requirements || (checkin.requirements.acknowledgeDGTerms != true)) {
    throw new Error('Passengers must acknowledge DG terms to check in');
  }
  // create json block for segment/pax data
  var checkinRequest = helpers.formatCheckinRequest(booking, checkin);

  console.info(`In accept. accept-checkin Req Url = ${IB_API_URL + ACCEPT_PAX_PATH + booking.checkinId + '/accept'}`);
  console.info(`In accept. accept-checkin Req Payload = ${JSON.stringify(checkinRequest, null, 2)}`);

  const accept = await _gatherAndReportErrors(axios({
    method: 'post',
    url: IB_API_URL + ACCEPT_PAX_PATH + booking.checkinId + '/accept',
    headers: {
      'API_KEY' : IB_API_KEY,
      'Accept-Language': 'en-US',
      'Authorization' : 'Bearer ' + token,
      'Content-Type' : 'application/json',
      'cache-control' : 'no-cache'
    },
    data: checkinRequest,
  }));

  console.info(`In accept. accept-checkin Response Status = ${accept.status}`);
  console.info(`In accept. accept-checkin Response Body = ${JSON.stringify(accept.data, null, 2)}`);

  if (accept.status !== 200) {
    new Error('IB checkin failed');
  }

  // the response data is in res.data but it isn't the booking data
  return accept;
};


exports.AcceptCheckable = async function(token, booking, checkin, isV2) {
  if ((!checkin || /.+/.test(checkin) === false) ||
      (!token || /.+/.test(token) === false) ||
      (!booking || /.+/.test(booking) === false) ) {
    throw new Error('Missing parameters');
  }
  if (!checkin.passengerLookups || !checkin.passengerLookups.length
    || !checkin.flightLookups || !checkin.flightLookups.length) {
      throw new Error('Missing parameters');
  }
  if (!checkin.requirements || (checkin.requirements.acknowledgeDGTerms != true)) {
    throw new Error('Passengers must acknowledge DG terms to check in');
  }
  // create json block for segment/pax data
  var checkinRequest = helpers.formatCheckinRequestForAccept(booking, checkin, isV2);
  console.info(`In accept. accept-checkin Req Url = ${IB_API_URL + ACCEPT_PAX_PATH + booking.checkinId + '/accept'}`);
  console.info(`In accept. accept-checkin Req Payload = ${JSON.stringify(checkinRequest, null, 2)}`);

  const accept = await _gatherAndReportErrors(axios({
    method: 'post',
    url: IB_API_URL + ACCEPT_PAX_PATH + booking.checkinId + '/accept',
    headers: {
      'API_KEY' : IB_API_KEY,
      'Accept-Language': 'en-US',
      'Authorization' : 'Bearer ' + token,
      'Content-Type' : 'application/json',
      'cache-control' : 'no-cache'
    },
    data: checkinRequest,
  }));
  console.info(`In accept. accept-checkin Response Status = ${accept.status}`);
  console.info(`In accept. accept-checkin Response Body = ${JSON.stringify(accept.data, null, 2)}`);

  if (accept.status !== 200) {
    new Error('IB checkin failed');
  }
  // the response data is in res.data but it isn't the booking data
  return accept;
};


exports.boardingPassFormats = async function(token, checkinId) {
  if ((!checkinId || /.+/.test(checkinId) === false) || (!token || /.+/.test(token) === false)) {
    throw new Error('Missing parameters');
  }
  console.info(`In boardingPassFormats. boarding-document Request Url = ${IB_API_URL + BOARDING_PASS_PATH + checkinId + '/boarding-document'}`);

  const bp = await _gatherAndReportErrors(axios({
    method: 'get',
    url: IB_API_URL + BOARDING_PASS_PATH + checkinId + '/boarding-document',
    headers: {
      'API_KEY' : IB_API_KEY,
      'Accept-Language': 'en-US',
      'Authorization' : 'Bearer ' + token,
      'Request-ClientId' : 'carrier_connect'
    }
  }));

  // console.info(`boardingPassFormats. bp = ${JSON.stringify(bp, null, 2)}`);

  if (!bp.data) {
    throw new Error('Failed to retrieve bp format data');
  }

  console.info(`In boardingPassFormats. boarding-document Response = ${JSON.stringify(bp.data, null, 2)}`);

  return bp.data;
};

exports.printBoardingPass = async function(token, booking, boardingPasses) {
  if ((!booking || /.+/.test(booking) === false) || (!token || /.+/.test(token) === false)) {
    throw new Error('Missing parameters');
  }

  var boardingPassRequest = helpers.formatBoardingPassRequest(boardingPasses);

  console.info(`In printBoardingPass. boardingPassRequest Url = ${IB_API_URL + BOARDING_PASS_PATH + booking.checkinId + '/boarding-document/print'}`);
  console.info(`In printBoardingPass. boardingPassRequest Payload = ${JSON.stringify(boardingPassRequest, null, 2)}`);

  const bp = await _gatherAndReportErrors(axios({
    method: 'post',
    url: IB_API_URL + BOARDING_PASS_PATH + booking.checkinId + '/boarding-document/print',
    headers: {
      'API_KEY' : IB_API_KEY,
      'Accept-Language': 'en-US',
      'Authorization' : 'Bearer ' + token,
      'Request-ClientId' : 'carrier_connect'
    },
    data: boardingPassRequest,
  }));

  // console.info(`printBoardingPass. bp = ${JSON.stringify(bp, null, 2)}`);
  if (!bp.data) {
    throw new Error('Failed to retrieve bp data');
  }

  console.info(`In printBoardingPass. boardingPassResponse = ${JSON.stringify(bp.data, null, 2)}`);

  return bp.data;
};


exports.getSecurityDocs = async function (token, checkinId, passengerId) {

  console.info(`In getSecurityDocs. GET Security Url = ${IB_API_URL + SECURITY_DOCUMENTS_PATH + checkinId + '/security?passengerId=' + passengerId}`);

  const response = await _gatherAndReportErrors(axios({
    method: 'get',
    url: IB_API_URL + SECURITY_DOCUMENTS_PATH + checkinId + '/security?passengerId=' + passengerId,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept-Language': 'en-US',
      'Content-Type' : 'application/json',
      'cache-control' : 'no-cache',
      'Authorization' : `Bearer ${token}`,
      'API_KEY' : IB_API_KEY
    }
  }))

  if (!response.data) {
    throw new Error('Failed to retrieve response data');
  }

  console.log(`In getSecurityDocs. GET Security response = ${JSON.stringify(response.data,null,2)}`);
  return response.data;
}

exports.updateSecurityDocs = async function (checkinId, ibReqBody, token) {

  console.info(`In updateSecurityDocs. PUT Security Req Url = ${IB_API_URL + SECURITY_DOCUMENTS_PATH + checkinId + '/security'}`);
  console.info(`In updateSecurityDocs. PUT Security Req Payload = ${JSON.stringify(ibReqBody, null, 2)}`);


  const response = await _gatherAndReportErrorsForRegDocs(axios({
    method: 'put',
    url: IB_API_URL + SECURITY_DOCUMENTS_PATH + checkinId + '/security',
    data: ibReqBody,
    headers: {
      'Content-Type': 'application/json',
      'Accept-Language': 'en-US',
      'Accept': 'application/json,text/*;q=0.99',
      'cache-control' : 'no-cache',
      'Authorization' : `Bearer ${token}`,
      'API_KEY' : IB_API_KEY
    },
  }))

  if (response.status === 200) {
    console.log(`Passenger Security Information updated Successfully for checkinid = ${checkinId}`)
 
    if (response.requiredDocuments) {
      return response.requiredDocuments;
    }  else
    {
      return [];
    }
  }

}

async function _gatherAndReportErrors(promisedApiCall) {
try {
  return await promisedApiCall;
} catch (axiosError) {
  const err = new Error('IB error');
  console.log(`In _gatherAndReportErrors. Status = ${axiosError.response.status},  Error = ${JSON.stringify(axiosError.response.data,null,2)}`)	
  err.CARRIER_ERROR_CODE = axiosError.response.status;

  // code from iberia isn't necessarily the http response code. could be their error code - FRAM_A0005
  if (axiosError.response.data && axiosError.response.data.errors && Array.isArray(axiosError.response.data.errors)) {
    let errMessage = '';
    let errCode = '';
    axiosError.response.data.errors.forEach( e => {
      errMessage += e.reason + ' | ';
      errCode += e.code + ' | ';
    })
    err.CARRIER_ERROR_MESSAGE = errMessage;
    err.CARRIER_ERROR_CODE = errCode
  } if (axiosError.response.data.error && axiosError.response.data.error_description) {
    err.CARRIER_ERROR_MESSAGE = axiosError.response.data.error + ' ' + axiosError.response.data.error_description;
  } else if (axiosError.message && axiosError.response.status) {
    err.CARRIER_ERROR_MESSAGE = axiosError.message + ' ' + axiosError.response.statusText;
  }

  console.error(`Request failed to ${axiosError.config.url} with status ${axiosError.response.status} and reason ${err.CARRIER_ERROR_MESSAGE}`)
  throw err;
}
}

async function _gatherAndReportErrorsForRegDocs(promisedApiCall) {
  try {
    return await promisedApiCall;
  } catch (axiosError) {
    const err = new Error('IB error');
    console.log(`In _gatherAndReportErrors. Status = ${axiosError.response.status},  Error = ${JSON.stringify(axiosError.response.data,null,2)}`)	
    err.CARRIER_ERROR_CODE = axiosError.response.status;


    switch (axiosError.response.status) {
      // case 409:console.log('need to send 200 with Document, if it is a document')
      //   break;
      case 412:
        return handle412Error(axiosError);
      default:
          // code from iberia isn't necessarily the http response code. could be their error code - FRAM_A0005
              if (axiosError.response.data && axiosError.response.data.errors && Array.isArray(axiosError.response.data.errors)) {
                let errMessage = '';
                let errCode = '';
                axiosError.response.data.errors.forEach( e => {
                  // errMessage += e.reason + ' | ';
                  errMessage += (e.description ? e.description: e.reason) + ' | ';  

                  errCode += e.code + ' | ';
                })
                err.CARRIER_ERROR_MESSAGE = errMessage;
                err.CARRIER_ERROR_CODE = errCode
              } if (axiosError.response.data.error && axiosError.response.data.error_description) {
                err.CARRIER_ERROR_MESSAGE = axiosError.response.data.error + ' ' + axiosError.response.data.error_description;
              } else if (axiosError.message && axiosError.response.status) {
                err.CARRIER_ERROR_MESSAGE = axiosError.message + ' ' + axiosError.response.statusText;
              }

              console.error(`Request failed to ${axiosError.config.url} with status ${axiosError.response.status} and reason ${err.CARRIER_ERROR_MESSAGE}`)
              throw err;
        // break;
    }


  }
}

function handle412Error(axiosError) {
  let requiredDocuments = [];
  if (axiosError.response.data && axiosError.response.data.errors && Array.isArray(axiosError.response.data.errors)) {


    axiosError.response.data.errors.forEach( e => {

      let reqdoc = transformIBErrorToCCMessage(e.code)
      
      if (!requiredDocuments.indexOf(reqdoc)) {
        requiredDocuments.push(reqdoc);
      }

    })

  } else {
    //TODO: Handle axiosError.response.data.error if it is expected
    throw new Error('Unrecognized IB error code');
  }

  return {status:200, requiredDocuments:requiredDocuments};//would never be NULL - it is either populated or error is raised

}


function transformIBErrorToCCMessage(errCode) {
  const passportCCFields = ['ID', 'GENDER', 'BIRTH_DATE', 'CITY_OF_BIRTH', 'NAME', 'SURNAME', 'NATIONALITY', 'LARGE_FAMILY_NUMBER'];
  const residentalFields = ['HOME', 'MUNICIPALITY', 'RESIDENT', 'COMMUNITY'];
  const destinationFields = ['DESTINATION']
  const iBErrors = [
      { errCode: "TRM_APIM_900563", errStatus: "ID_DOCUMENT_REQUIRED" },
      { errCode: "TRM_APIM_900564", errStatus: "GENDER_REQUIRED" },
      { errCode: "TRM_APIM_900565", errStatus: "BIRTH_DATE_REQUIRED" },
      { errCode: "TRM_APIM_900566", errStatus: "MUNICIPALITY_CODE_REQUIRED" },
      { errCode: "TRM_APIM_900567", errStatus: "RESIDENT_NUMBER_REQUIRED" },
      { errCode: "TRM_APIM_900568", errStatus: "BIRTH_DATE_INCORRECT" },
      { errCode: "TRM_APIM_900569", errStatus: "COMMUNITY_CODE_REQUIRED" },
      { errCode: "TRM_APIM_900570", errStatus: "LARGE_FAMILY_NUMBER_REQUIRED" },
      { errCode: "TRM_APIM_900618", errStatus: "CITY_OF_BIRTH_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900619", errStatus: "DESTINATION_ADDRESS_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900620", errStatus: "DESTINATION_CITY_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900621", errStatus: "DESTINATION_COUNTRY_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900622", errStatus: "DESTINATION_ZIP_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900624", errStatus: "HOME_ADDRESS_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900625", errStatus: "HOME_CITY_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900626", errStatus: "HOME_COUNTRY_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900627", errStatus: "HOME_ZIP_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900628", errStatus: "NAME_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900629", errStatus: "NATIONALITY_REQUIRED_FLIELD" },
      { errCode: "TRM_APIM_900630", errStatus: "SURNAME_REQUIRED_FLIELD" },
      { errCode: "API_STREET_ADDRESS", errStatus: "DESTINATION_ADDRESS_REQUIRED" }
  ];

  const newArr = iBErrors.map(item => {
      const { errCode, errStatus } = item;
      if (passportCCFields.some(item => errStatus.includes(item))) {
          return { ...item, errStatus: 'PASSPORT' }
      }
      if (destinationFields.some(item => errStatus.includes(item))) {
          return { ...item, errStatus: 'DESTINATION_ADDRESS' }
      }
      if (residentalFields.some(item => errStatus.includes(item))) {
          return { ...item, errStatus: 'RESIDENT_ADDRESS' }
      }
  })


  if (newArr.some(item => item.errCode === errCode)) {
    return newArr.filter(item => item.errCode === errCode)[0].errStatus;
  }else
  {
    return 'SEE_AGENT';
  }


}
