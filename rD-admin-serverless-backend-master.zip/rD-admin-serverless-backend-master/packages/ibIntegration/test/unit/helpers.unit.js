const chai = require('chai');
const assert = chai.assert;

const TEST_BOOKING_NOT_CHECKED_IN = require('../mocks/VD5DMB-02-IbBooking.json');
const TEST_BOOKING_CHECKED_IN = require('../mocks/L9BC9-02-IbBooking.json');
const TEST_BOOKING_PARTIAL_CHECKED_IN = require('../mocks/TEST01-02-IbBooking.json');
const TEST_BOARDING_CARD_FORMAT = require('../mocks/L9BC9-04-IbBoardingCardFormats.json');
const TEST_BOOKING_INFANT = require('../mocks/QPQ4Y4-02-IbBooking.json');
const TEST_BOOKING_STAGED_INFANT = require('../mocks/InfantStaged-02-Booking.json');

describe('Helper functions for CC -> IB integration', () => {

  const m = require('../../helpers');

  describe('verifyBoardingPassFormat', () => {

    it('should fail if DOWNLOAD is not an available channel', () => {
      const boardingPassFormat = {
        channels: ['EMAIL', 'SNAILMAIL', 'CARRIERPIGEON'],
        documents: [{
          segments: [{
            id: '2',
            formats: ['PDF', 'NATIVE']
          }]
        }]
      };

      assert.throws(() => m.verifyBoardingPassFormat(boardingPassFormat), 'Required boarding pass DOWNLOAD is not available.');
    })

    it('should fail if NATIVE format is not available on each segment', () => {
      const boardingPassFormat = {
        channels: ['EMAIL', 'DOWNLOAD', 'CARRIERPIGEON'],
        documents: [{
          segments: [{
            id: '2',
            formats: ['PDF', 'NATIVE']
          }, {
            id: '3',
            formats: ['PDF', 'FOO']
          }]
        }, {
          segments: [{
            id: '4',
            formats: ['PDF', 'NATIVE']
          }]
        }]
      };

      // testing multiple documents, multiple segments. All segments must offer NATIVE format. 
      assert.throws(() => m.verifyBoardingPassFormat(boardingPassFormat), 'Required boarding pass format is not available.');
    })

    it('should succeed if NATIVE format and DOWNLOAD channel', () => {
      const boardingPassFormat = {
        channels: ['EMAIL', 'DOWNLOAD', 'CARRIERPIGEON'],
        documents: [{
          segments: [{
            id: '2',
            formats: ['PDF', 'NATIVE']
          }, {
            id: '3',
            formats: ['PDF', 'NATIVE']
          }]
        }, {
          segments: [{
            id: '4',
            formats: ['PDF', 'NATIVE']
          }]
        }]
      };

      assert.isUndefined(m.verifyBoardingPassFormat(boardingPassFormat), 'Required boarding pass format is not available.');
    })

  });

  describe('isCouponCheckedIn', () => {

    it('should return false if coupon status code does not exist', () => {
      const coupon = {
        status: { nocodefield: 'no code here' }
      }
      assert.isFalse(m.isCouponCheckedIn(coupon));
    })

    it('should true if checked in', () => {
      const coupon = {
        status: { code: 'CHECKED' }
      }
      assert.isTrue(m.isCouponCheckedIn(coupon));
    })

    it('should false if not checked in', () => {
      const coupon = {
        status: { code: 'foo' }
      }
      assert.isFalse(m.isCouponCheckedIn(coupon));
    })
  })


  describe('formatCheckinRequestForAccept', () => {

    it('verify check in request format for pax traveling with infant - infant listed on lookup', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "0438",
            "date": "2019-06-27",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "BIO"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "ADULT",
            "eTicketNumber": "0752381910401"
          },
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "BABY",
            "eTicketNumber": "0752381910402"
          }
        ]
      };

      assert.deepEqual(JSON.stringify(m.formatCheckinRequestForAccept(TEST_BOOKING_INFANT, checkin)),
        '{"dangerousItemsInfoAccepted":true,"segments":[{"id":2,"passengers":[1]}]}');
    })

    it('verify check in request format for pax traveling with infant - infant not listed on lookup', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "0438",
            "date": "2019-06-27",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "BIO"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "ADULT",
            "eTicketNumber": "0752381910401"
          }
        ]
      };

      assert.deepEqual(JSON.stringify(m.formatCheckinRequestForAccept(TEST_BOOKING_INFANT, checkin)),
        '{"dangerousItemsInfoAccepted":true,"segments":[{"id":2,"passengers":[1]}]}');
    })

    it('verify check in request format for 2 pax / 2 flights', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "3170",
            "date": "2019-03-01",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "LHR"
          },
          {
            "flightNumber": "0252",
            "date": "2019-03-01",
            "carrier": "CX",
            "origin": "LHR",
            "destination": "HKG"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "JAMES",
            "givenName": "JESSE",
            "eTicketNumber": "0012300236605"
          },
          {
            "familyName": "JAMES",
            "givenName": "JEN",
            "eTicketNumber": "0012300236606"
          }
        ]
      };

      assert.deepEqual(JSON.stringify(m.formatCheckinRequestForAccept(TEST_BOOKING_NOT_CHECKED_IN, checkin)),
        '{"dangerousItemsInfoAccepted":true,"segments":[{"id":3,"passengers":[1,2]},{"id":4,"passengers":[1,2]}]}');
    })

    it('should throw an error if passenger does not exist on booking', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "3170",
            "date": "2019-03-01",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "LHR"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "foo",
            "givenName": "JESSE",
            "eTicketNumber": "00000000000"
          }
        ]
      };

      assert.throws(() => m.formatCheckinRequestForAccept(TEST_BOOKING_NOT_CHECKED_IN, checkin), 'Passenger lookup error');
    })

    it('should throw an error if eTicketNumber is not correct', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "3170",
            "date": "2019-03-01",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "LHR"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "JAMES",
            "givenName": "JEN",
            "eTicketNumber": "000000000"
          }
        ]
      };

      assert.throws(() => m.formatCheckinRequestForAccept(TEST_BOOKING_NOT_CHECKED_IN, checkin), 'Passenger lookup error');
    })

    it('should throw an error if ALL passengers do not exist on booking', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "3170",
            "date": "2019-03-01",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "LHR"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "foo",
            "givenName": "JESSE",
            "eTicketNumber": "00000000000"
          },
          {
            "familyName": "JAMES",
            "givenName": "JESSE",
            "eTicketNumber": "00000000000"
          }
        ]
      };

      assert.throws(() => m.formatCheckinRequestForAccept(TEST_BOOKING_NOT_CHECKED_IN, checkin), 'Passenger lookup error');
    })


    it('should throw an error if flight does not exist on booking', () => {

      const checkin = {
        "checkIn": true,
        "requirements": { "acknowledgeDGTerms": true },
        "flightLookups": [
          {
            "flightNumber": "9999",
            "date": "2019-03-01",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "LHR"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "JAMES",
            "givenName": "JESSE",
            "eTicketNumber": "0012300236605"
          }
        ]
      };

      assert.throws(() => m.formatCheckinRequestForAccept(TEST_BOOKING_NOT_CHECKED_IN, checkin), 'Checkin lookup error');
    })
  })


  describe('formatBoardingPassRequest', () => {

    it('verify check in request format for 2 pax / 2 flights', () => {

      const bpRequest = [{
        "format": "NATIVE",
        "sharings": [
          {
            "channel": "DOWNLOAD",
            "segments": [
              {
                "id": "2",
                "passengers": ["1"]
              }
            ]
          }
        ]
      }];
      assert.deepEqual(m.formatBoardingPassRequest(TEST_BOARDING_CARD_FORMAT), bpRequest);
    })

    it('verify check in request format for 2 pax / 2 flights', () => {

      const bpRequest = [{
        "format": "NATIVE",
        "sharings": [
          {
            "channel": "DOWNLOAD",
            "segments": [
              {
                "id": "2",
                "passengers": ["1"]
              }
            ]
          }
        ]
      }];
      assert.deepEqual(m.formatBoardingPassRequest(TEST_BOARDING_CARD_FORMAT), bpRequest);
    })
  })

  describe('verifyPaxCheckedIn', () => {

    it('should succeed when passenger is checked in - Adult + Infant', () => {

      const bpLookup = {
        "flightLookups": [
          {
            "flightNumber": "0438",
            "date": "2019-06-27",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "BIO"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "ADULT",
            "eTicketNumber": "0752381910401"
          },
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "BABY",
            "eTicketNumber": "0752381910402"
          }
        ]
      };

      assert.isTrue(m.verifyPaxCheckedIn(TEST_BOOKING_STAGED_INFANT, bpLookup));
    })


    it('should fail since lkup flight is not on booking', () => {

      const bpLookup = {
        "flightLookups": [
          {
            "flightNumber": "0000",
            "date": "2019-06-27",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "BIO"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "BABY",
            "eTicketNumber": "0752381910402"
          }
        ]
      };
      assert.throws(() => m.verifyPaxCheckedIn(TEST_BOOKING_STAGED_INFANT, bpLookup), 'Boarding pass look up error');
    })

    it('should throw an error when passenger is not checked in', () => {

      const bpLookup = {
        "flightLookups": [
          {
            "flightNumber": "3170",
            "date": "2019-03-01",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "LHR"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "JAMES",
            "givenName": "JESSE",
            "eTicketNumber": "0012300236605"
          }
        ]
      };

      assert.throws(() => m.verifyPaxCheckedIn(TEST_BOOKING_NOT_CHECKED_IN, bpLookup), 'Cannot issue boarding pass');
    })

    it('should succeed when passenger is checked in', () => {

      const bpLookup = {
        "flightLookups": [
          {
            "flightNumber": "0730",
            "date": "2019-02-22",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "BCN"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "ONE",
            "eTicketNumber": "0752379977125"
          }
        ]
      };

      assert.isTrue(m.verifyPaxCheckedIn(TEST_BOOKING_CHECKED_IN, bpLookup));
    })


    it('should fail when pnr is partially checked in', () => {

      const bpLookup = {
        "flightLookups": [
          {
            "flightNumber": "0630",
            "date": "2019-02-27",
            "carrier": "IB",
            "origin": "MAD",
            "destination": "BCN"
          }
        ],
        "passengerLookups": [
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "ONE",
            "eTicketNumber": "0752379977132"
          },
          {
            "familyName": "CARRIERCONNECT",
            "givenName": "TWO",
            "eTicketNumber": "0752379977132"
          }
        ]
      };

      assert.throws(() => m.verifyPaxCheckedIn(TEST_BOOKING_PARTIAL_CHECKED_IN, bpLookup),
        'Cannot issue boarding pass');
    })

  })

  describe('consolidatePassengerBooking', () => {

    it('should succeed - consolidate pnr: 2 flights with 2 adult passengers', () => {
      const expected = [
        {
          id: 1,
          name: 'JESSE',
          surname: 'JAMES',
          type: 'ADULT',
          eTicketNumber: '0012300236605',
          coupons: [
            {
              status: false,
              segId: 3,
              isCheckinStatus: "CHECKABLE"
            },
            {
              status: false,
              segId: 4,
              isCheckinStatus: "CHECKABLE"
            }],
        },
        {
          id: 2,
          name: 'JEN',
          surname: 'JAMES',
          type: 'ADULT',
          eTicketNumber: '0012300236606',
          coupons: [{
            status: false,
            segId: 3,
            isCheckinStatus: "CHECKABLE"
          },
          {
            status: false,
            segId: 4,
            isCheckinStatus: "CHECKABLE"
          }],
        }
      ];
      const actual = m.consolidatePassengerBooking(TEST_BOOKING_NOT_CHECKED_IN);
      assert.deepEqual(actual, expected);
    })
  })

  // it('should succeed - consolidate pnr: 1 flight with adult / infant passenger', () => {
  //   const expected = [
  //     {
  //       id: 1,
  //       name: 'ADULT',
  //       surname: 'CARRIERCONNECT',
  //       type: 'ADULT',
  //       eTicketNumber: '0752381910401',
  //       coupons: [{
  //         status: false,
  //         segId: 2,
  //         isCheckinStatus: "CHECKABLE"
  //       }],
  //     },
  //     {
  //       id: '1_INF',
  //       name: 'BABY',
  //       surname: 'CARRIERCONNECT',
  //       type: 'INFANT',
  //       eTicketNumber: '0752381910402',
  //       coupons: [{
  //         status: false,
  //         segId: 2,
  //         isCheckinStatus: "CHECKABLE"
  //       }],
  //     }
  //   ];
  //   const actual = m.consolidatePassengerBooking(TEST_BOOKING_INFANT);
  //   assert.deepEqual(actual, expected);
  // })
});
