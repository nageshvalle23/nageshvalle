const chai = require('chai');
const assert = chai.assert;

const RECORD_L9BC9 = require('../mocks/L9BC9-Record.json');
const RECORD_W_BOARDING_PASS = require('../mocks/L9BC9-Record-Bp.json');
const BOOKING = require('../mocks/L9BC9-02-IbBooking.json');
const BOARDING_PASS = require('../mocks/L9BC9-05-IbBoardingCard.json');
const PAX_LOOKUPS = require('../mocks/CCpax-lookups.json')
const TEST_BOOKING_INFANT = require('../mocks/QPQ4Y4-02-IbBooking.json');
const RECORD_INFANT_QPQ4Y4 = require('../mocks/QPQ4Y4-Record.json');

describe('Convert IB bookings to CC Record', () => {

  console.info('converter.unit.js')
  const lookup = {givenName: 'ONE', familyName: 'CARRIERCONNECT', rloc: 'L9BC9', targetAirlineCode: 'IB'};

  const m = require('../../converter');

  // TODO
  // outward only booking
  // outward & return booking
  // return only booking??
  // test converting just a booking
  // test converting a booking & boardingpass
  describe('convert', () => {
    it('should convert a booking to a valid record', () => {
      const r = m.toRecord(BOOKING);
      assert.deepEqual(r, RECORD_L9BC9);
    });

    it('should convert a booking with infant to a valid record', () => {
      const r = m.toRecord(TEST_BOOKING_INFANT);
      assert.deepEqual(r, RECORD_INFANT_QPQ4Y4);
    });

    it('should convert a booking + boarding pass to a valid record', () => {
      const r = m.toBpRecord(BOOKING, BOARDING_PASS,PAX_LOOKUPS);
      assert.deepEqual(r, RECORD_W_BOARDING_PASS);
    });
  });

});
