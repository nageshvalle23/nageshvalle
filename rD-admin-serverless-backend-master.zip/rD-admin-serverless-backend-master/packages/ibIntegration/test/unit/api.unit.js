const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const assert = chai.assert;

const moduleName = '../../api';

const placeholderStub = (fnName) => () => {
  throw new Error('Please stub this function call: ' + fnName);
};

const createStubs = (customStubs) => _.defaults({}, customStubs, {
  ['axios']: placeholderStub('params'),
  ['./helpers']: {
    formatCheckinRequest: placeholderStub('formatCheckinRequest'),
    formatBoardingPassRequest: placeholderStub('formatBoardingPassRequest'),
  },
});

describe('API for IBIS', () => {
  const axios = sinon.stub();
  const formatCheckinRequest = sinon.stub();
  const formatBoardingPassRequest = sinon.stub();

  const m = proxyquire(moduleName, createStubs({
    ['axios']: axios,

    ['./helpers']: {
      formatCheckinRequest: formatCheckinRequest,
      formatBoardingPassRequest: formatBoardingPassRequest,
    },
  }));

  describe('retrieve token', () => {
    after(() => {
      axios.reset();
    });

    it('should return a token object', async () => {
      const res = {
        data: {
          access_token: '1234567890'
        }
      }

      axios.returns(res);
      const session = await m.retrieveToken();

      assert(axios.calledOnce);
      assert.equal(session, '1234567890');
    });


    it('should throw an error if the response does not have expected values', async () => {
      const res = {
        data: {
          foo: '1234567890'
        }
      }

      axios.returns(res);
      await assert.isRejected(m.retrieveToken(), Error);
    });

  });


  describe('getBooking', () => {
    after(() => {
      axios.reset();
    });

    it('should throw an error if there are missing parameters', async () => {
      await assert.isRejected(m.getBooking('rloc', 'LastName'), Error);
      await assert.isRejected(m.getBooking('rloc', '','token'), Error);
      await assert.isRejected(m.getBooking('rloc', null,'token'), Error);
      await assert.isRejected(m.getBooking(null, 'LastName','token'), Error);
      await assert.isRejected(m.getBooking('', 'LastName','token'), Error);

    })

    it('should throw an error if the response does not contain a check in id', async () => {
      axios.returns({
        data: {
          iAmNotACheckInId: 'abcdefghijklmnopqrstuvwxyz'
        }
      });
      await assert.isRejected(m.getBooking('abc123', 'Joey', '1234567890'), Error);
    })


    // it('should return a booking object with check in id', async () => {
    //   axios.returns({
    //     data: {
    //       checkinId: 'abcdefghijklmnopqrstuvwxyz'
    //     }
    //   })
    //   console.error('m.getBooking()', await m.getBooking('abc123', 'Joey', '1234567890'))
    //   assert.deepEqual(await m.getBooking('abc123', 'Joey', '1234567890'), {checkinId: 'abcdefghijklmnopqrstuvwxyz'})
    // })

    it('should return a booking object with check-in ID and modified passengers', async () => {
      axios.returns({
        data: {
          checkinId: 'abcdefghijklmnopqrstuvwxyz',
          passengers: [
            { name: 'John Doe', title: 'Mr' },
            { name: 'Jane Smith', title: 'Ms' }
          ]
        }
      });
    
      const expectedBooking = {
        checkinId: 'abcdefghijklmnopqrstuvwxyz',
        passengers: [
          { name: 'John Doe', title: 'Mr' },
          { name: 'Jane Smith', title: 'Ms' }
        ]
      };
    
      console.error('m.getBooking()', await m.getBooking('abc123', 'Joey', '1234567890'));
      assert.deepEqual(await m.getBooking('abc123', 'Joey', '1234567890'), expectedBooking);
    });
    
  })

  describe('checkIn', () => {
    after(() => {
      axios.reset();
    });

    it('should throw an error if there are missing parameters', async () => {

      var checkIn = {
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        }
      };
      formatCheckinRequest.returns('checkin json');
      await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));

      checkIn = {
        passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
        }
      };
      await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));

    })

    it('should succeed', async () => {

      const checkIn = {
        passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        }
      };
      formatCheckinRequest.returns('checkin json');

      axios.returns({
        status: 200
      });

      assert.deepEqual(await m.accept('token', {booking: 'booking'}, checkIn), {status:200});
    })

    it('should require DG terms to be acknowledged before checkin', async () => {

      formatCheckinRequest.returns('checkin json');
      const checkIn = {
        passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: false
        }
      };
      await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));

    });

  });

  describe('boarding pass formats', () => {
    after(() => {
      axios.reset();
    });

    it('should throw an error if there are missing parameters', async () => {

      await assert.isRejected(m.boardingPassFormats('1234567890'));
      await assert.isRejected(m.boardingPassFormats('','1234567890'));

    })

    it('should succeed', async () => {

      axios.returns({
        data: 'boarding pass data'
      });
      const formats = await m.boardingPassFormats('1234567890', 'abcdefghijklmnop');

      assert.deepEqual(formats, 'boarding pass data');
    })
  })

  describe('printBoardingPass', () => {
    after(() => {
      axios.reset();
    });

    it('should fail if there are missing parameters', async () => {

      var checkIn = {
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        }
      };
      formatBoardingPassRequest.returns('checkin json');
      await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));

      checkIn = {
        passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
        }
      };
      await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));

    })

    it('should fail if an error is received from the BP format verification ', async () => {

      var checkIn = {
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        }
      };
      formatBoardingPassRequest.rejects(Error);
      await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));
    })

    it('should succeed', async () => {

      const checkIn = {
        passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
        flightLookups: [{f: 'flight1'},{f: 'flight2'}],
        requirements: {
          acknowledgeDGTerms: true
        }
      };
      formatCheckinRequest.returns('checkin json');

      axios.returns({
        status: 200
      });

      assert.deepEqual(await m.accept('token', {booking: 'booking'}, checkIn), {status:200});
    })

    // it('should require DG terms to be acknowledged before checkin', async () => {

    //   formatCheckinRequest.returns('checkin json');
    //   const checkIn = {
    //     passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
    //     flightLookups: [{f: 'flight1'},{f: 'flight2'}],
    //     requirements: {
    //       acknowledgeDGTerms: false
    //     }
    //   };
    //   await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn));

    //   const checkIn2 = {
    //     passengerLookups: [{p: 'pax1'},{p: 'pax2'}],
    //     flightLookups: [{f: 'flight1'},{f: 'flight2'}],
    //     requirements: {
    //       acknowledgeDGTerms: 'false'
    //     }
    //   };
    //   await assert.isRejected(m.accept('token', {booking: 'booking'}, checkIn2));
    // });

  });

});
