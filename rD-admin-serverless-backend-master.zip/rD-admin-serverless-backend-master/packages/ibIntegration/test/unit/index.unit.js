const _ = require('lodash');
const proxyquire = require('proxyquire');
const sinon = require('sinon');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);
const assert = chai.assert;

describe('index', () => {
  const retrieveToken = sinon.stub();
  const getBooking = sinon.stub();
  const accept = sinon.stub();
  const boardingPassFormats = sinon.stub();
  const printBoardingPass = sinon.stub();
  const closeSession = sinon.stub();

  const toRecord = sinon.stub();

  const verifyPaxCheckedIn = sinon.stub();

  const m = proxyquire('../../index', {
    ['./api']: {
      retrieveToken,
      getBooking,
      accept,
      boardingPassFormats,
      printBoardingPass,
      closeSession
    },
    ['./converter']: {
      toRecord
    },
    ['./helpers']: {
      verifyPaxCheckedIn
    }
  });

  const event = {
    body: `{
        "recordRequest": {
          "familyName": "Calamandrei",
          "givenName": "Mario",
          "rloc": "WELVAC",
          "carrierCode": "OG"
        },
        "requirements": {
          "acknowledgeDGTerms": true,
          "acceptance": true
        },
        "flightRequests": [
          {
            "destination": "KDW",
            "date": "2019-11-16",
            "carrierCode": "OG",
            "flightNumber": "611",
            "origin": "ZUK"
          },
          {
            "destination": "LHV",
            "date": "2019-11-16",
            "carrierCode": "CX",
            "flightNumber": "814",
            "origin": "KDW"
          }
        ],
        "passengerRequest": {
          "familyName": "Calamandrei",
          "givenName": "Mario",
          "eTicketNumber": "10249495247990"
        }
    }`
  }

  // describe('Get Record', () => {

  //   it('should respond with 502 if a downstream service call fails', (done) => {
  //     retrieveToken.rejects('Error');
  //     m.record(event, {}, (err, res) => {
  //       assert.equal(res.statusCode, 500);
  //       done();
  //     });
  //   });

  //   it('should respond with 200 if record succeeds', (done) => {
  //     retrieveToken.resolves({token:[]})
  //     getBooking.resolves({booking: {}});
  //     closeSession.resolves(true);

  //     m.record(event, {}, (err, res) => {
  //       assert.equal(res.statusCode, 200);
  //       done();
  //     });
  //   });

  // });

  // describe('Check In', () => {

  //   it('should check passengers in and respond with 200', (done) => {
  //     retrieveToken.resolves({token:[]})
  //     getBooking.resolves({booking: {}});
  //     accept.resolves(true);
  //     toRecord.resolves({record: {}});
  //     closeSession.resolves(true);

  //     m.checkin(event, {}, (err, res) => {
  //       assert.equal(res.statusCode, 200);
  //       done();
  //     });
  //   });

  //   it('should respond with 500 for service failures', (done) => {
  //     accept.rejects('Error');
  //     m.checkin(event, {}, (err, res) => {
  //       assert.equal(res.statusCode, 500);
  //       done();
  //     });
  //   });

  // });

/*
  describe('Boarding Pass', () => {

    it('should retrieve boarding pass', (done) => {
      retrieveToken.resolves({token:[]})
      getBooking.resolves({booking: {}});
      verifyPaxCheckedIn.returns(true);
      accept.resolves(true);
      boardingPassFormats.resolves({boardingPassFormat: {}});
      printBoardingPass.resolves({bp: {}});
      toRecord.resolves({record: {}});
      closeSession.resolves(true);

      m.boardingpass(event, {}, (err, res) => {
        assert.equal(res.statusCode, 200);
        done();
      });
    });

    it('should respond with 500 for boarding pass failures', (done) => {
      retrieveToken.resolves({token:[]})
      getBooking.resolves({booking: {}});
      verifyPaxCheckedIn.returns(true);
      accept.resolves(true);
      boardingPassFormats.resolves({boardingPassFormat: {}});
      printBoardingPass.resolves({bp: {}});
      toRecord.resolves({record: {}});
      closeSession.resolves(true);

      m.boardingpass(event, {}, (err, res) => {
        assert.equal(res.statusCode, 500);
        done();
      });
    });


    it('should respond with 500 if pax not checked in', (done) => {
      retrieveToken.resolves({token:[]})
      getBooking.resolves({booking: {}});
      verifyPaxCheckedIn.returns(false);

      m.boardingpass(event, {}, (err, res) => {
        assert.equal(res.statusCode, 500);
        done();
      });
    });

  });
*/
});
