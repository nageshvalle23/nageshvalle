const fetch = require("node-fetch");
const axios = require("axios");
const qs = require("qs");
const API_URL = process.env.API_URL_1A || "https://test.airlines.api.amadeus.com";
const REQ_TIMEOUT_IN_MS = 500000;
const { createLogger, logApiData } = require('./logger');
const { store } = require('./store');


const apiCredentials = {
  AT: {
    clientId: process.env.AT_1A_CLIENT_ID,
    clientSecret: process.env.AT_1A_CLIENT_SECRET,
  },
  MH: {
    clientId: process.env.MH_1A_CLIENT_ID,
    clientSecret: process.env.MH_1A_CLIENT_SECRET,
  },
  UL: {
    clientId: process.env.UL_1A_CLIENT_ID,
    clientSecret: process.env.UL_1A_CLIENT_SECRET,
  },
  RJ: {
    clientId: process.env.RJ_1A_CLIENT_ID,
    clientSecret: process.env.RJ_1A_CLIENT_SECRET,
  },
  JL: {
    clientId: process.env.JL_1A_CLIENT_ID,
    clientSecret: process.env.JL_1A_CLIENT_SECRET,
  },
  BA: {
    clientId: process.env.BA_1A_CLIENT_ID,
    clientSecret: process.env.BA_1A_CLIENT_SECRET,
  },
};

exports.getSession = async function (targetCarrier) {
  const startTime = new Date().getTime();
  const payload = {
    client_secret: apiCredentials[targetCarrier].clientSecret,
    client_id: apiCredentials[targetCarrier].clientId,
    grant_type: "client_credentials",
  };
  const encodedPayload = qs.stringify(payload);
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v1/security/oauth2/token`,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    data: encodedPayload,
  });
  if (res.status === 200 && res.data) {
    const endTime = new Date().getTime();
    console.info(`--- Response time for session --- ${endTime - startTime}ms`, 'transaction id --> ', store.transactionId)
    return res.data;
  }
  else {
    console.log("get session function error", 'transaction id --> ', store.transactionId);
    throw new Error("Error occured on axios call");
  }
};

exports.searchCustomer = async function (session, lookup) {
  const startTime = new Date().getTime();
  if ((!session || /.+/.test(session) === false) || (!lookup || /.+/.test(lookup) === false)) {
    throw new Error('Missing parameters');
  }
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v2/checkin/journeys`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    data: {
      orderId: lookup.rloc,
      lastName: lookup.familyName,
    },
  });
  logApiData(res, 'Identification Call', null);
  console.info(`----- Response Time for search customer ---- ${new Date().getTime() - startTime}ms ---`, 'transaction id --> ', store.transactionId);
  return res;
};

exports.fetchBoardingPass = async (session, journeyId) => {
  const startTime = new Date().getTime();
  if ((!session || /.+/.test(session) === false) || (!journeyId || /.+/.test(journeyId) === false)) {
    throw new Error('Missing parameters');
  }

  const res = await axios({
    method: "POST",
    url: `${API_URL}/v2/checkin/boarding-passes`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    data: {
      deliveryMethod: {
        deliveryMethodType: "BoardingPassInResponseDelivery",
        documentType: "boardingPassData",
      },
      languageCode: "en-GB",
      journeyId: journeyId,
    },
  });
  logApiData(res, 'fetchBoardingPass', null);
  console.info(`---- Response time for boarding pass ${new Date().getTime() - startTime} ms ---- `, 'transaction id --> ', store.transactionId);
  return res;
};



exports.fetchBoardingPassByJourneyElementId = async (session, journeyId, journeyElementId) => {
  const startTime = new Date().getTime();
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v2/checkin/boarding-passes`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    data: {
      deliveryMethod: {
        deliveryMethodType: "BoardingPassInResponseDelivery",
        documentType: "boardingPassData",
      },
      languageCode: "en-GB",
      journeyId: journeyId,
      journeyElementIds: [journeyElementId]
    },
  });
  logApiData(res, 'POST - fetchBoardingPassByJourneyElementId', null);
  if (!res.data) {
    throw new Error('Could not find the data node in fetchBoardingPassByJourneyElementId function');
  }
  console.info(`--- Response time for boarding pass by journey id = ${journeyId} journey element id= ${journeyElementId}--${new Date().getTime() - startTime} ms`, 'transaction id --> ', store.transactionId);
  return res.data;
}

exports.fetchBoardingPassByJourneyElementIds = async (journeyId, journeyElementIds, session) => {
  const startTime = new Date().getTime();
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v2/checkin/boarding-passes`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    data: {
      deliveryMethod: {
        deliveryMethodType: "BoardingPassInResponseDelivery",
        documentType: "boardingPassData",
      },
      languageCode: "en-GB",
      journeyId: journeyId,
      journeyElementIds: journeyElementIds
    },
  });
  logApiData(res, 'POST - fetchBoardingPassByJourneyElementId', null);
  if (!res.data) {
    throw new Error('Could not find the data node in fetchBoardingPassByJourneyElementId function');
  }
  console.info(`--- Response time for boarding pass by journey id = ${journeyId} journey element ids = ${journeyElementIds}--${new Date().getTime() - startTime} ms`, 'transaction id --> ', store.transactionId);
  return res.data;
}

exports.fetchRequiredDocuments = async (session, travelerId, journeyId) => {
  const startTime = new Date().getTime();
  const res = await axios({
    method: "GET",
    url: `${API_URL}/v2/checkin/journeys/${journeyId}/travelers/${travelerId}/regulatory-details`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
  });
  console.info(`-- Response time for GET Requirements--- ${new Date().getTime() - startTime} ms---`, 'transaction id --> ', store.transactionId);
  return res;
};

exports.updateContactInformation = async (session, journeyId) => {
  const res = await axios({
    method: "POST",
    url: `${API_URL}/checkin/journeys/${journeyId}/contacts`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`
    },
    data: [
      {
        category: "personal",
        contactType: "Phone"
      }
    ]
  });
  return res
};

exports.updateDocs = async (session, data, journeyId, travelerId) => {
  const startTime = new Date().getTime();
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v2/checkin/journeys/${journeyId}/travelers/${travelerId}/regulatory-details`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    data
  });
  console.info(`----- Response Time for POST Requirements = ${new Date().getTime() - startTime} ms`, 'transaction id --> ', store.transactionId);
  return res
}

exports.getJourneyElementsInformationInAJourney = async (session, journeyId) => {
  const startTime = new Date().getTime();
  const res = await axios({
    method: "GET",
    url: `${API_URL}/v2/checkin/journey-elements?journeyId=${journeyId}`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
  });
  logApiData(res, 'GET - getJourneyElementsInformationInAJourney', null);
  if (!res.data) {
    throw new Error('Could not find the data node in getFlightElementIdsOfTraveler function');
  }
  console.info(`--- Response Time for getting journey elements information in a journey= ${new Date().getTime() - startTime} ms`, 'transaction id --> ', store.transactionId);
  return res.data;
}

exports.acceptanceByJourneyElementId = async (session, journeyElementId) => {
  try {
    const startTime = new Date().getTime();
    if ((!session || /.+/.test(session) === false) || (!journeyElementId || /.+/.test(journeyElementId) === false)) {
      throw new Error('Missing parameters');
    }

    const res = await axios({
      method: "POST",
      url: `${API_URL}/v2/checkin/journey-elements/${journeyElementId}/acceptance`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
    });

    createLogger(res)

    if (!res.data) {
      throw new Error('Could not find the data node in getFlightElementIdsOfTraveler function');
    }

    console.info(`-- Response time for acceptance by journey element id for journeyelement id = ${journeyElementId} = ${new Date().getTime() - startTime}ms.`, 'transaction id --> ', store.transactionId)
    return res.data;
  } catch (e) {
    createLogger(e.response)
    // for now lets assume 500 means its ok.
    if (e.response.status === 500) {
      return e.response.data;
    }
  }

}

exports.deleteTravelerFromAcceptanceCheckIn = async (session, travelerIds, journeyId) => {
  const startTime = new Date().getTime();
  if (travelerIds.length === 0) return true;

  const combined = travelerIds.reduce((acc, travelerId) => {
    if (acc === '') return travelerId
    else return acc.concat(',', travelerId)
  }, '')

  if ((!session || /.+/.test(session) === false) || (!journeyId || /.+/.test(journeyId) === false)) {
    throw new Error('Missing parameters');
  }
  const res = await axios({
    method: "DELETE",
    url: `${API_URL}/v2/checkin/journeys/${journeyId}/travelers?travelerIds=${combined}`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
  });

  if (res.status === 204) {
    logApiData(res, 'Delete traveler from acceptance check-in', null);
    console.info(`--- Response time for DELETE Acceptance Checkin =  ${new Date().getTime() - startTime}ms `, 'transaction id --> ', store.transactionId);
    return true
  }
}

exports.travelerAcceptanceForJourney = async (session, journeyId) => {
  try {
    const startTime = new Date().getTime();
    if ((!session || /.+/.test(session) === false) || (!journeyId || /.+/.test(journeyId) === false)) {
      throw new Error('Missing parameters');
    }
    const res = await axios({
      method: "POST",
      url: `${API_URL}/v2/checkin/journeys/${journeyId}/acceptance`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
    });
    logApiData(res, 'POST - Traveler/(s) acceptance for a journey', null);
    console.info(`---- Response Time for Traveler Acceptance for a journey = ${new Date().getTime() - startTime} ms`, 'transaction id --> ', store.transactionId);
    return {
      checkInStatus: 201,
      body: res.data
    }
  } catch (e) {
    logApiData(null, 'POST - Traveler/(s) acceptance for a journey - Error', e);
    return {
      checkInStatus: e.response.status,
      body: e.response
    }
  }
}

exports.travelerAcceptanceForJourneyWithSecurityQuestionsFlag = async (session, journeyId, securityQuestionsAnswered) => {
  try {
    const startTime = new Date().getTime();
    if ((!session || /.+/.test(session) === false) || (!journeyId || /.+/.test(journeyId) === false)) {
      throw new Error('Missing parameters');
    }
    const res = await axios({
      method: "POST",
      url: `${API_URL}/v2/checkin/journeys/${journeyId}/acceptance?areSecurityQuestionsAnswered=${securityQuestionsAnswered}`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
    });
    logApiData(res, 'POST - Traveler/(s) acceptance for a journey with security questions answered flag', null);
    console.log(`---- Security questions answered flag value: ${securityQuestionsAnswered}`);
    console.log(`---- Response Time for Traveler Acceptance for a journey = ${new Date().getTime() - startTime} ms`);
    return {
      checkInStatus: 201,
      body: res.data
    }
  } catch (e) {
    logApiData(null, 'POST - Traveler/(s) acceptance for a journey - Error', e);
    return {
      checkInStatus: e.response.status,
      body: e.response
    }
  }
}

exports.getAcceptanceStatusOfJourney = async (session, journeyId) => {
  try {
    const startTime = new Date().getTime();
    if ((!session || /.+/.test(session) === false) || (!journeyId || /.+/.test(journeyId) === false)) {
      throw new Error('Missing parameters');
    }
    const res = await axios({
      method: "GET",
      url: `${API_URL}/v2/checkin/journeys/${journeyId}/acceptance`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
    });
    logApiData(res, 'GET - Traveler/(s) acceptance status of a journey', null);
    console.info(`--- Response time for GET acceptance of a journey = ${new Date().getTime() - startTime} ms`, 'transaction id --> ', store.transactionId);
    return {
      fetchStatus: 200,
      body: res.data.data
    }
  } catch (e) {
    logApiData(null, 'GET - Traveler/(s) acceptance status of a journey', e);
    return {
      fetchStatus: e.response.status,
      body: e.response
    }
  }
}
