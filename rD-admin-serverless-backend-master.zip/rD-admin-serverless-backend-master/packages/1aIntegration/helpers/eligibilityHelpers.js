
const flatten = require('flat');
const { amadeusToCCDocumentMap } = require('../maps');
const helpers = require('../helpers');
const { store } = require('../store');


const supportedCCDocuments = {
  PASSPORT: ['givenName', 'middleName', 'familyName', 'passportNumber', 'expiryDate', 'issueDate', 'countryOfIssue', 'gender', 'dateOfBirth', 'nationality'],
  VISA: ['documentNumber', 'expiryDate', 'countryOfIssue'],
  RESIDENT_ADDRESS: ['countryOfResidence'],
  HOME_ADDRESS: ['street', 'city', 'stateProv', 'postalCode', 'country']
}

// supports only visa.
// assumption: if they ask for name, we can populate it with pspt or pnr and visa accepts single document update.
// const handleCountryEntryDocument = (countryEntryNode) => {
//   // const supportedCCDocuments = ['visa', 'passport', 'homeaddress', 'destinationaddress'];
//   const visaIndex = countryEntryNode.detailsChoices.findIndex(detailChoice => {
//     return detailChoice.regulatoryType.toLowerCase() === 'visa';
//   })
//   if (visaIndex === -1) return ['SEE_AGENT'];
//   const requiredDocuments = new Set();
//   const requiredFieldsOfVisaDocument = countryEntryNode.detailsChoices[visaIndex].requiredDetailsFields;
//   for (let requiredField of requiredFieldsOfVisaDocument) {
//     requiredField = requiredField.toLowerCase();
//     if (requiredField === 'number' || requiredField === 'expiryDate'.toLowerCase() || requiredField === 'issuanceCountryCode'.toLowerCase()) {
//       if (compareRequiredFieldAgainstGlobalStore(requiredField, 'visa', globalStore, null));
//       requiredDocuments.add('VISA');
//     }
//     else if (requiredField === 'nationalityCountryCode'.toLowerCase()) {
//       requiredDocuments.add('PASSPORT');
//     }
//     // else if (requiredField === 'name') {
//     //   requiredDocuments.add('DEFAULT_NAME')
//     // }
//     else {
//       requiredDocuments.add('SEE_AGENT')
//     }
//   }
//   return Array.from(requiredDocuments);
// }

// // supports only passport not identityCard
// const handleIdentityDocument = (identityDocumentNode) => {
//   const passportIndex = identityDocumentNode.detailsChoices.findIndex(detailChoice => {
//     return detailChoice.regulatoryType.toLowerCase() === 'passport';
//   })
//   if (passportIndex === -1) return ['SEE_AGENT'];
//   const requiredDocuments = new Set();
//   const requiredFieldsOfPassportDocument = identityDocumentNode.detailsChoices[passportIndex].requiredDetailsFields;
//   for (let requiredField of requiredFieldsOfPassportDocument) {
//     requiredField = requiredField.toLowerCase();
//     if (requiredField === 'name' || requiredField === 'number'.toLowerCase() || requiredField === 'nationalityCountryCode'.toLowerCase()
//       || requiredField === 'expiryDate'.toLowerCase() || requiredField === 'issuanceCountry'.toLowerCase()
//     ) {
//       requiredDocuments.add('PASSPORT');
//     }
//     else {
//       requiredDocuments.add('SEE_AGENT')
//     }
//   }
//   return Array.from(requiredDocuments);
// }

// const handlePersonalDetails = (personalDetailsNode) => {
//   const personalDetailsIndex = personalDetailsNode.detailsChoices.findIndex(detailChoice => {
//     return detailChoice.regulatoryType.toLowerCase() === 'personaldetails';
//   })
//   if (personalDetailsIndex === -1) return ['SEE_AGENT'];
//   const requiredDocuments = new Set();
//   const requiredFieldsOfPersonalDetails = personalDetailsNode.detailsChoices[personalDetailsIndex].requiredDetailsFields;
//   for (let requiredField of requiredFieldsOfPersonalDetails) {
//     requiredField = requiredField.toLowerCase();
//     // birthplace is defualted to nationality
//     if (requiredField === 'birthdate' || requiredField === 'birthplace' || requiredField === 'name'
//       || requiredField === 'gender' || requiredField === 'nationalitycountrycode') {
//       requiredDocuments.add('PASSPORT');
//     }
//     // else if (requiredField === 'purposeofvisit') {
//     //   requiredDocuments.add('DEFAULT_PURPOSE_OF_VISIT')
//     // } 
//     else if (requiredField.toLowerCase() === 'countryOfResidenceCode'.toLowerCase()) requiredDocuments.add('RESIDENT_ADDRESS');
//     else requiredField.add('SEE_AGENT');
//   }
//   return Array.from(requiredDocuments);
// }

// const handleHomeAddress = (homeAddressNode) => {
//   const homeAddressIndex = homeAddressNode.detailsChoices.findIndex(detailChoice => {
//     return detailChoice.regulatoryType.toLowerCase() === 'homeAddress'.toLowerCase();
//   })
//   if (homeAddressIndex === -1) return ['SEE_AGENT'];
//   const requiredFieldsOfHomeAddress = homeAddressNode.detailsChoices[homeAddressIndex].requiredDetailsFields;
//   const requiredDocuments = new Set();
//   for (let requiredField of requiredFieldsOfHomeAddress) {
//     requiredField = requiredField.toLowerCase();
//     // birthplace is defualted to nationality
//     if (requiredField === 'countryCode'.toLowerCase()) {
//       requiredDocuments.add('RESIDENT_ADDRESS');
//     }
//     else {
//       requiredDocuments.add('SEE_AGENT');
//     }
//   }
//   return Array.from(requiredDocuments);
// }

// const handleDestinationAddress = (destinationAddressNode) => {
//   // ['street', 'city', 'stateProv', 'postalCode', 'country']
//   const destinationAddressIndex = countryEntryNode.detailsChoices.findIndex(detailChoice => {
//     return detailChoice.regulatoryType.toLowerCase() === 'destinationAddress'.toLowerCase();
//   })
//   if (destinationAddressIndex === -1) return ['SEE_AGENT'];
//   const requiredFieldsOfDestinationAddress = destinationAddressNode.detailsChoices[destinationAddressIndex].requiredDetailsFields;
//   const requiredDocuments = new Set();
//   for (let requiredField of requiredFieldsOfDestinationAddress) {
//     requiredField = requiredField.toLowerCase();
//     // birthplace is defualted to nationality
//     if (requiredField === 'countryCode'.toLowerCase() || requiredField === 'cityName'.toLowerCase()
//       || requiredField === 'lines' || requiredField === 'stateCode' || requiredField === 'zipCOde') {
//       requiredDocuments.add('DESTINATION_ADDRESS');
//     }
//     else {
//       requiredDocuments.add('SEE_AGENT');
//     }
//   }
//   return Array.from(requiredDocuments);
// }


// const convertRequiredDocumentsToCarrierConnectLevel = (eligibilityResponse) => {
//   const { data } = eligibilityResponse.data;
//   if (!data.hasOwnProperty('missingDetails')) {
//     return []
//   }
//   let requiredDocuments = [];
//   for (let missingNode of data.missingDetails) {
//     switch (missingNode.detailsCategory) {
//       case 'countryEntryDocument':
//         console.log('country entry document asked', 'transaction id --> ', store.transactionId);
//         requiredDocuments.push(handleCountryEntryDocument(missingNode));
//         break;
//       case 'identityDocument':
//         console.log('identity document asked', 'transaction id --> ', store.transactionId);
//         requiredDocuments.push(handleIdentityDocument(missingNode));
//         break;
//       case 'personalDetails':
//         console.log('personal details asked', 'transaction id --> ', store.transactionId);
//         requiredDocuments.push(handlePersonalDetails(missingNode));
//         break;
//       case 'destinationAddress':
//         console.log('destination address asked', 'transaction id --> ', store.transactionId);
//         requiredDocuments.push(handleDestinationAddress(missingNode));
//         break;
//       case 'homeAddress':
//         console.log('home address asked', 'transaction id --> ', store.transactionId);
//         requiredDocuments.push(handleHomeAddress(missingNode));
//         break;
//       default:
//         console.log('see agent', 'transaction id --> ', store.transactionId);
//         requiredDocuments.push(['SEE_AGENT']);
//     }
//   }
//   return requiredDocuments;
// }

const convertExistingDocumentsToCarrierConnectLevel = (eligibilityResponse) => {
  const { data } = eligibilityResponse.data;
  if (!data.hasOwnProperty('storedDetails')) {
    return []
  }

  let storedDetails = [];
  for (let storedDetailNode of data.storedDetails) {
    if (storedDetailNode.hasOwnProperty('document')) {
      if (storedDetailNode.document.documentType.toLowerCase() === 'passport' || storedDetailNode.document.documentType.toLowerCase() === 'visa') {
        storedDetails.push(storedDetailNode.document.documentType.toUpperCase());
      }
    }
    else if (storedDetailNode.hasOwnProperty('address')) {
      if (storedDetailNode.address.type.toLowerCase() === 'homeAddress'.toLowerCase()) {
        storedDetails.push('RESIDENT_ADDRESS');
      }
      else if (storedDetailNode.address.type.toLowerCase() === 'destinationAddress'.toLowerCase()) {
        storedDetails.push('DESTINATION_ADDRESS');
      }
    }
    else if (storedDetailNode.hasOwnProperty('phoneNumber')) {
      if (storedDetailNode?.phoneNumber?.purpose?.toLowerCase() === 'emergencyContact'.toLowerCase()) storedDetails.push('EMERGENCY_CONTACT');
    }

  }
  return storedDetails;
}


const flattenDocument = (document) => {
  let flatDocument = flatten(document);

  for (let key in flatDocument) {
    let newKey = key.slice(key.lastIndexOf('.') + 1);
    flatDocument[newKey] = flatDocument[key];
    if (newKey !== key) delete flatDocument[key];
  }
  return flatDocument
}


const extractStoredNodesFromStoredDetails = (storedDetails) => {
  let response = [];
  for (let detail of storedDetails) {
    if (detail.hasOwnProperty('document')) {
      const sub = {
        documentName: detail.document.documentType,
        documentProps: flattenDocument(detail.document)
      };
      response.push(sub);
    }
    else if (detail.hasOwnProperty('personalDetails')) {
      const sub = {
        documentName: "personalDetails",
        documentProps: flattenDocument(detail.personalDetails)
      };
      response.push(sub);
    } else if (detail.hasOwnProperty('address')) {
      const sub = {
        documentName: detail.address.type,
        documentProps: flattenDocument(detail.address)
      }
      response.push(sub);
    }
  }
  return response;
}

const getAllPopulatedDocuments = (eligibilityResponses, substituteName) => {
  const populatedNodesPerJourney = eligibilityResponses.map(eligibilityResponse => {
    if (eligibilityResponse.storedDetails && eligibilityResponse.storedDetails.length > 0) return extractStoredNodesFromStoredDetails(eligibilityResponse.storedDetails)
    return [];
  }).flat();
  const merged = [];
  const mergedObject = {};
  for (let i = 0; i < populatedNodesPerJourney.length; i++) {
    let foundIndex = -1;
    for (let j = 0; j < merged.length; j++) {
      if (merged[j].documentName === populatedNodesPerJourney[i].documentName) {
        foundIndex = j
        break;
      }
    }
    if (foundIndex != -1) {
      merged[foundIndex].documentProps = { ...populatedNodesPerJourney[i].documentProps, ...merged[foundIndex].documentProps }
    } else {
      merged.push(populatedNodesPerJourney[i])
    }
  }
  for (let object of merged) {
    mergedObject[object.documentName] = object.documentProps;
  }
  // check in merged object if has a name property if not then populate it.
  for (let key of Object.keys(mergedObject)) {
    if (!mergedObject[key].hasOwnProperty('firstName')) mergedObject[key].firstName = substituteName.firstName;
    if (!mergedObject[key].hasOwnProperty('lastName')) mergedObject[key].lastName = substituteName.lastName;
  }
  return mergedObject;
}

const convertToCCRequiredDocuments = (eligibilityResponse, globalStore, firstName, lastName) => {
  const allRequiredFields = getAllMissingDocumentsPerJourney(eligibilityResponse.data.data);

  //get actual missing fields in comparison with the global store
  const { requiredFieldsForEachDoc } = helpers.createObjectForRequestTo1aDocumentUpdate(allRequiredFields, globalStore, returnActualMissingFields = true)
  const requiredFields = requiredFieldsForEachDoc;

  let requiredCCDocuments = [];

  for (let doc of requiredFields) {
    const { documentName, documentProps } = doc;
    // check if this document is supported by cc - if not 'SEE_AGENT'
    if (!amadeusToCCDocumentMap[documentName]) {
      requiredCCDocuments.push('SEE_AGENT');
      break;
    }

    // we can decide to throw SEE_AGENT if all the stored fields within a certain doc are already present inside the store and still asks for it
    // avoid partial update in case we are not able to populate all missing fields of passport and visa - avoid partial update to pp and visa
    if (documentName == 'passport' || documentName == 'visa') {
      // this would signify that actual missing fields inside a doc are none
      if (documentProps.length == 0) {
        requiredCCDocuments.push('SEE_AGENT');
        break;
      }
    }

    for (let requiredField of documentProps) {
      const CC_DOCS = amadeusToCCDocumentMap[documentName];
      let isExistentWithinCCDOCS = false; // basically a flag to check if its a field supported within CC
      for (let ccDoc in CC_DOCS) {
        if (CC_DOCS?.[ccDoc]?.[requiredField]) {
          requiredCCDocuments.push(ccDoc);
          isExistentWithinCCDOCS = true;
        }
        // exceptional required field is name- we dont request for any cc document in this case since it can be picked up from pnr
        if (requiredField.toLowerCase() == 'name') {
          isExistentWithinCCDOCS = true;
        }
      }
      if (!isExistentWithinCCDOCS) requiredCCDocuments.push('SEE_AGENT')
    }
  }

  console.log(requiredCCDocuments, '= from the generator CC required docs function', 'transaction id --> ', store.transactionId);
  return requiredCCDocuments;
}

// check for each document if we can populate it with existing fields. 
/* 
  Assumptions: 
  1. Only Passport is supported not identity document
  2. 
*/
const extractMissingDetailsFromMissingDetailsNode = (missingDetails, journeyId, travelerId) => {
  let response = [];
  const supportedCCDocuments = ['visa', 'passport', 'personalDetails', 'homeAddress', 'destinationAddress', 'emergencyContact'];
  for (let detail of missingDetails) {
    const detailChoices = detail.detailsChoices;
    for (let detailChoice of detailChoices) {
      response.push({
        documentName: detailChoice.regulatoryType,
        documentProps: detailChoice.requiredDetailsFields,
        documentCatagory: detail.detailsCategory,
        optional: detailChoice.canBeDeclined,
        ccSupported: supportedCCDocuments.includes(detailChoice.regulatoryType) ? true : false
      })
    }
  }
  return preProcessor(response);
}

// if required docs are identityCard and passport - we ll remove identity card 
function preProcessor(response) {
  const isIdentityCard = response.findIndex(element => element['documentName'].toLowerCase() === 'identitycard');
  const isPassport = response.findIndex(element => element['documentName'].toLowerCase() == 'passport');

  // remove identity card element if both passport and identity card are present as required docs
  if (isIdentityCard > -1 && isPassport > -1) response.splice(isIdentityCard, 1);

  return response;
}
// const compareRequiredFieldAgainstGlobalStore = (requiredFieldName, requiredFieldDocumentName, globalStore, searchSpecifications) => {
//   const possibleSearchLocations = oneARequiredToStoredMap[requiredFieldDocumentName][requiredFieldName];
//   for (let documentName of Object.keys(possibleSearchLocations)) {
//     const fieldNameInStoredDetail = possibleSearchLocations[documentName];
//     if (globalStore[documentName] && globalStore[documentName][fieldNameInStoredDetail]) {
//       return true;
//     }
//   }
//   return false;
// }

const getAllMissingDocumentsPerJourney = (eligibilityResponse) => {
  if (!eligibilityResponse.missingDetails) return [];
  return extractMissingDetailsFromMissingDetailsNode(eligibilityResponse.missingDetails);
}
// /* Currently not using */
// const getAllMissingDocuments = (eligibilityResponses) => {
//   const missingDetailsPerJourney = eligibilityResponses.map(eligibilityResponse => extractMissingDetailsFromMissingDetailsNode(eligibilityResponse.missingDetails, eligibilityResponse.travelerId, eligibilityResponse.journeyId))
// }
// /* Currently not using */
// const generateResourceMapping = (eligibilityResponses) => {
//   let resources = [];

// }

const handleNamePropertyInsideGlobalStore = (globalStore) => {
  for (let key in globalStore) {
    if (globalStore[key]?.firstName) {
      if (!globalStore[key].name) globalStore[key].name = {};
      globalStore[key].name.firstName = globalStore[key].firstName;
      delete globalStore[key]?.firstName
    }
    if (globalStore[key]?.lastName) {
      if (!globalStore[key].name) globalStore[key].name = {};
      globalStore[key].name.lastName = globalStore[key].lastName;
      delete globalStore[key]?.lastName
    }
  }
  return globalStore
}

module.exports = {
  getAllPopulatedDocuments,
  getAllMissingDocumentsPerJourney,
  handleNamePropertyInsideGlobalStore,
  convertToCCRequiredDocuments,
  convertExistingDocumentsToCarrierConnectLevel
}
