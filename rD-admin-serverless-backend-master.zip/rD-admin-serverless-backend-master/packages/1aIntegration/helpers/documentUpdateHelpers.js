const eligibilityHelpers = require('./eligibilityHelpers');
const api = require('../api');
const _ = require('lodash');
const { createObjectForRequestTo1aDocumentUpdate, handleGender } = require('../helpers');
const { getCountryCode } = require('../getCountryCode');
const { createLogger } = require('../logger');
const { store } = require('../store');
const { normalizeCountryCode, getStateIsoCode }=require('../utils')


// Below fn to be used within eligiblity adaptor
const recursivelyUpdateWithExistingInformation = async (session, globalStore, journeyId, travelerId, eligibilityResponse) => {
    console.info(`------ Inside Recursive function for journey ${journeyId} ------ `, 'transaction id --> ', store.transactionId);
    let requiredFieldsForEachDoc = eligibilityHelpers.getAllMissingDocumentsPerJourney(eligibilityResponse.data.data);

    console.log(requiredFieldsForEachDoc, '= required fields for each document', 'transaction id --> ', store.transactionId);

    const objectForRequestTo1aDocumentUpdate = createObjectForRequestTo1aDocumentUpdate(requiredFieldsForEachDoc, globalStore, returnActualMissingFields = true);
    const { object } = objectForRequestTo1aDocumentUpdate

    const actualRequiredFieldsPerDocument = objectForRequestTo1aDocumentUpdate.requiredFieldsForEachDoc;

    const fieldsForPassport = actualRequiredFieldsPerDocument.find((element) => {
        if (element.documentName.toLowerCase() == 'passport') return element
    });

    const fieldsForVisa = actualRequiredFieldsPerDocument.find((element) => {
        if (element.documentName.toLowerCase() == 'visa') return element
    });

    const fieldsForDestinationAddress = actualRequiredFieldsPerDocument.find((element) => {
        if (element.documentName.toLowerCase() == 'destinationaddress') return element
    })

    // Avoid Partial Update on visa if visa exist
    if (fieldsForVisa && fieldsForVisa?.documentProps?.length != 0) {
        if (object?.document?.documentType == 'visa') delete object.document;
    }
    // Avoid Partial Update on passport if passport exist
    if (fieldsForPassport && fieldsForPassport?.documentProps?.length != 0) {
        if (object?.document?.documentType == 'passport') delete object.document;
    }
    // Avoid Partial Update on destinationaddress if destionation exist
    if (fieldsForDestinationAddress && fieldsForDestinationAddress?.documentProps?.length != 0) {
        if (object?.address?.type == 'destinationAddress') delete object.address;
    }

    const requestTo1A = {
        detailsToAdd: [object]
    }

    console.log('doc update request = ', JSON.stringify(requestTo1A), 'transaction id --> ', store.transactionId);

    // Base case
    if (Object.keys(object).length == 0) return eligibilityResponse;

    console.log('Doing doc update inside recursion fn', 'transaction id --> ', store.transactionId);

    // call document update here
    const new1aEligibilityResponse = await api.updateDocs(session, requestTo1A, journeyId, travelerId);
    createLogger(new1aEligibilityResponse);

    const newRequiredFields = eligibilityHelpers.getAllMissingDocumentsPerJourney(new1aEligibilityResponse.data.data);

    // one more base case - if the requirements are same as previously then we can exit the recursion ie. its time to ask the user for docs!
    if (_.isEqual(requiredFieldsForEachDoc, newRequiredFields)) return new1aEligibilityResponse;

    console.log('Calling recursion again, logged just before the return..', 'transaction id --> ', store.transactionId);
    // recursively keep calling the function until its exhausted usage of the global store
    return recursivelyUpdateWithExistingInformation(session, globalStore, journeyId, travelerId, new1aEligibilityResponse);
}

const handleDocument = async (document, lookup, isIdCard = null) => {
    const { givenName, familyName } = lookup;
    const object = {};
    const detailsToDecline=[]

    for (let doc of document) {
        const { type, payload } = doc;

        if (type == 'PASSPORT') {
            const { givenName, familyName, dateOfBirth, gender, passportNumber, expiryDate, nationality, countryOfIssue } = payload;
            const modifiedGender = handleGender(gender);

            const documentObject = {
                number: passportNumber,
                expiryDate,
                issuanceLocation: countryOfIssue,
                name: {
                    firstName: givenName,
                    lastName: familyName,
                },
                nationalityCode: nationality,
                gender: modifiedGender,
                birthDate: dateOfBirth,
                documentType: isIdCard ? 'identityCard' : 'passport'
            }

            const personalDetails = {
                birthDate: dateOfBirth,
                birthPlace: nationality,
                // name: {
                //     firstName: givenName,
                //     lastName: familyName
                // },
                gender: modifiedGender,
                nationalityCode: nationality,
                purposeOfVisit: 'work'
            }

            object.personalDetails = personalDetails;
            object.document = documentObject;
        }

        if (type == 'VISA') {
            const { expiryDate, countryOfIssue, documentNumber } = payload;

            const documentObject = {
                name: {
                    firstName: givenName,
                    lastName: familyName
                },
                number: documentNumber,
                expiryDate,
                nationalityCode: countryOfIssue,
                issuanceCountryCode: normalizeCountryCode(countryOfIssue),
                // issuanceLocation: countryOfIssue,
                documentType: 'visa'
            }

            object.document = documentObject;

        }

        if (type == 'DESTINATION_ADDRESS') {
            const { street, city, stateProv, postalCode, country } = payload;

            const addressObject = {
                lines: [street],
                zipCode: postalCode,
                countryCode: normalizeCountryCode(country),
                cityName: city,
                stateCode: getStateIsoCode(payload),
                type: 'destinationAddress'
            }
            object.address = addressObject;
        }

        if (type == 'RESIDENT_ADDRESS') {
            let { countryOfResidence } = payload;
        countryOfResidence=normalizeCountryCode(countryOfResidence)
            const addressObject = {
                countryCode: countryOfResidence,
                type: 'homeAddress'
            }

            object.address = addressObject;

            // * adding a pre check if personal details exist.
            if (!object.hasOwnProperty('personalDetails')) object.personalDetails = {}
            object.personalDetails.countryOfResidenceCode = countryOfResidence;
        }

        if (type == 'EMERGENCY_CONTACT') {
            const { familyName, givenName, phone, email, refused } = payload;
               if(!refused){
            const { countryCode, number } = phone;

            const emergencyContactObject = {
                countryPhoneExtension: countryCode,
                number,
                countryCode: getCountryCode(countryCode.replace(/^(?:\+|0*)(\d+)/, "+$1")), // regex to remove all 0's after the plus until number
                name: {
                    firstName: givenName,
                    lastName: familyName
                },

                purpose: 'emergencyContact'
            }
            object.phoneNumber = emergencyContactObject;
        }
        else{
            detailsToDecline.push('emergencyContact')
        }
        }
    }

    const detailsToAdd = [object];
        const requestTo1A = {
            detailsToAdd,
            detailsToDecline
        }
        return requestTo1A;

}

module.exports = { recursivelyUpdateWithExistingInformation, handleDocument };
