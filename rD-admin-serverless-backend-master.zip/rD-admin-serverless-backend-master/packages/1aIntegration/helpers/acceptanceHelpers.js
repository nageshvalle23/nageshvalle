const api = require('../api');
const utils = require('../utils');
const  _handleErrors  = require('../handleErrorsMethod');
const { createLogger } = require('../logger');
const { store } = require('../store');
const helpers = require('../helpers');

const fetchStatusConditions = (checkedInJourneyElementsBeforeCheckIn, notCheckedInJourneyElementsBeforeCheckIn,
  checkedInJourneyElementsAfterCheckIn, notCheckedInJourneyElementsAfterCheckIn) => {

  checkedInJourneyElementsBeforeCheckIn = checkedInJourneyElementsBeforeCheckIn.flat(Infinity);
  notCheckedInJourneyElementsBeforeCheckIn = notCheckedInJourneyElementsBeforeCheckIn.flat(Infinity);
  checkedInJourneyElementsAfterCheckIn = checkedInJourneyElementsAfterCheckIn.flat(Infinity);
  notCheckedInJourneyElementsAfterCheckIn = notCheckedInJourneyElementsAfterCheckIn.flat(Infinity);

  let status = 200;
  // This is old logic to support partial acceptance on single segment checkin
  // const status500Conditions = checkedInJourneyElementsAfterCheckIn.length === 0 ||
  //                             (JSON.stringify(checkedInJourneyElementsBeforeCheckIn) === JSON.stringify(checkedInJourneyElementsAfterCheckIn) &&
  //                             notCheckedInJourneyElementsBeforeCheckIn.length !== 0)

  // const status206Conditions = checkedInJourneyElementsAfterCheckIn.length !== 0 &&
  //                             JSON.stringify(checkedInJourneyElementsBeforeCheckIn) !== JSON.stringify(checkedInJourneyElementsAfterCheckIn)

  // const status200Conditions = JSON.stringify(notCheckedInJourneyElementsAfterCheckIn) === JSON.stringify(checkedInJourneyElementsAfterCheckIn) ||
  //                             notCheckedInJourneyElementsAfterCheckIn.length === 0;

  // if (status500Conditions) {
  //   status = 500; // for no checkin we are throwing 500
  // } else if (status206Conditions) status = 206;

  if (notCheckedInJourneyElementsAfterCheckIn.some(element => element === 'not-checked-into-single-segment')) return { status: 500 };

  if (notCheckedInJourneyElementsAfterCheckIn.length > 0) status = 500;
  else status = 200;
  return {
    status
  };
}

const checkInTravelerIntoJourneys = async (session, travelersInformation) => {
  const acceptanceResponses = [];
  let checkedInJourneyElements = [];
  let notCheckedInJourneyElements = [];
  let securityQuestionsAnswered = process.env.SECURITY_QUESTIONS_ANSWERED.toLowerCase();
  let securityQuestionAsked = false;
  for (let journeyObject of travelersInformation) {
    const journeyId = journeyObject.travelers[0]?.journeyId
    if (!journeyId) continue;
    let checkInResponse = await api.travelerAcceptanceForJourney(session, journeyId);
    // check if security question is asked and if yes execute acceptance with the flag enabled
    if (checkInResponse.checkInStatus === 201 && checkInResponse.body.data.hasOwnProperty('securityQuestionsToAnswer')) {
      console.log(`security questions are asked, defaulting the value to ${securityQuestionsAnswered} and executing acceptance again`);
      checkInResponse = await api.travelerAcceptanceForJourneyWithSecurityQuestionsFlag(session, journeyId, securityQuestionsAnswered);
    }
    acceptanceResponses.push(checkInResponse.body);
    if (checkInResponse.checkInStatus === 201) {
      checkedInJourneyElements.push(checkInResponse.body.data?.checkedInJourneyElements ? checkInResponse.body.data?.checkedInJourneyElements.map(elem => elem.id) : []);
      notCheckedInJourneyElements.push(checkInResponse.body.data?.notCheckedInJourneyElements ? checkInResponse.body.data?.notCheckedInJourneyElements.map(elem => elem.id) : []);
    } else {
      // do a get acceptance for journey call and check which elements are checked-in and which are not
      // const acceptanceStatusForNewJourney = await api.getAcceptanceStatusOfJourney(session, journeyId);
      // if (checkInStatusOfJourneyForAcceptanceTraveler.fetchStatus === 200) {
      //   checkedInJourneyElements.push(acceptanceStatusForNewJourney.body?.checkedInJourneyElements ? acceptanceStatusForNewJourney.body.checkedInJourneyElements : ['nothing']);
      //   notCheckedInJourneyElements.push(acceptanceStatusForNewJourney.body?.notCheckedInJourneyElements ? acceptanceStatusForNewJourney.body.notCheckedInJourneyElements : ['all']);
      // } else {
        checkedInJourneyElements.push(['not-checked-into-single-segment']);
        notCheckedInJourneyElements.push(['not-checked-into-single-segment']);
      // }

    }
  }
  return {
    acceptanceResponses,
    checkedInJourneyElements,
    notCheckedInJourneyElements
  }
}

const checkIfAcceptanceInEligible = (dictionaries, acceptanceTravelers) => {
  let acceptanceErrors = [];
  for (let journeyElement of Object.values(dictionaries.journeyElement)) {
    if (acceptanceTravelers.includes(journeyElement.travelerId)) {
      if (journeyElement.acceptanceEligibility.status.toLowerCase() === 'ineligible') {
        acceptanceErrors.push({travelerId: journeyElement.travelerId, inEligibilityReasons: journeyElement.acceptanceEligibility.reasons, flightId: journeyElement.flightId });
      }
    }
  }
  return acceptanceErrors;
}

const fetchCheckedInJourneyElementsForTravelers = (dictionaries, travelerIds) => {
  let checkedInJourneyElements = [];
  let notCheckedInJourneyElements = [];

  for (let journeyElement of Object.values(dictionaries.journeyElement)) {
    if (travelerIds.includes(journeyElement.travelerId)) {
      if (journeyElement.checkInStatus.toLowerCase() === 'accepted') {
        checkedInJourneyElements.push(journeyElement.id);
      } else {
        notCheckedInJourneyElements.push(journeyElement.id);
      }
    }
  }
  return { checkedInJourneyElements, notCheckedInJourneyElements };
}

const deleteNotRequiredTravelersFromJourneyAndCheckInStatus = async (session, travelersInformation, travelerIDs) => {
  let checkedInJourneyElements = [];
  let notCheckedInJourneyElements = [];

  for (let journeyObject of travelersInformation) {
    const allTravelersExcludingAcceptanceTraveler = journeyObject.travelers.filter(traveler => !travelerIDs.includes(traveler.id)).reduce((acc, element) => {
      acc.push(element.id)
      return acc
    }, []);
    const journeyObjectId = journeyObject.travelers[0]?.journeyId;
    const deleteUserFromAcceptanceJourneyResponse = await api.deleteTravelerFromAcceptanceCheckIn(session, allTravelersExcludingAcceptanceTraveler, journeyObjectId);
    // const checkInStatusOfJourneyForAcceptanceTraveler = await api.getAcceptanceStatusOfJourney(session, journeyObjectId);
    // if (checkInStatusOfJourneyForAcceptanceTraveler.fetchStatus === 200) {
    //   checkedInJourneyElements.push(checkInStatusOfJourneyForAcceptanceTraveler.body?.checkedInJourneyElements ? checkInStatusOfJourneyForAcceptanceTraveler.body.checkedInJourneyElements : []);
    //   notCheckedInJourneyElements.push(checkInStatusOfJourneyForAcceptanceTraveler.body?.notCheckedInJourneyElements ? checkInStatusOfJourneyForAcceptanceTraveler.body.notCheckedInJourneyElements : []);
    // } else {
    //   throw new Error('Unable to get the acceptance status of a journey');
    // }
    if (deleteUserFromAcceptanceJourneyResponse) {
      console.log('Deleted users from journey Id :- ', JSON.stringify(journeyObjectId, null, 2), 'Traveler Ids :-', JSON.stringify(allTravelersExcludingAcceptanceTraveler, null, 2), 'transaction id --> ', store.transactionId);
    } else {
      throw new Error('Unable to delete user from acceptance journey');
    }
  }
  // return { checkedInJourneyElements, notCheckedInJourneyElements }
}

const fetchPassengerCheckinStatus = (passenger, checkinType) => {
  let checkedInStatuses = [];
  for (let coupons of passenger.coupons) {
    checkedInStatuses.push(coupons.isCheckedIn);
  }
  if (checkinType === 'full') return checkedInStatuses.every(checkedInStatus => checkedInStatus);
  else if (checkinType === 'partial') return checkedInStatuses.some(checkedInStatus => checkedInStatus);
  else if (checkinType === 'none') return checkedInStatuses.every(checkedInStatuses => !checkedInStatuses);
}

const allowedToExecutePostAcceptance = (inEligibilityReasonsForAllTravelers, travelerId = null) => {
  let isAllowed = true;
  inEligibilityReasonsForAllTravelers.forEach(travelerInformation => {
    if (travelerId && travelerInformation.travelerId === travelerId) {
      travelerInformation.inEligibilityReasons.forEach(sub => {
        if (sub.toLowerCase() !== 'ticketproblem') isAllowed = false;
      })
    } else if (!travelerId) {
      travelerInformation.inEligibilityReasons.forEach(sub => {
        if (sub.toLowerCase() !== 'ticketproblem') isAllowed = false;
      })
    }
  })
  return isAllowed;
}

const acceptanceSubRoutine = async (session, identificationResponse /** use this instead of making a lookup call again */, passengerRequests, flightLookups,targetAirlineCode) => {
  let err = null, passengers, flights, errorFound = false, isMisMatch = false;

  // console.log('Fetching journey for lookup: ', JSON.stringify(lookup, null, 2));
  // let journey = await api.searchCustomer(session, lookup);
  let journey = identificationResponse;
  // console.log("Journey fetched successfully", JSON.stringify(journey.data));
  // console.log('Fetching journey for lookup: ', JSON.stringify(lookup, null, 2), 'transaction id --> ', store.transactionId);
  // let journey = await api.searchCustomer(session, lookup);
  console.log("Journey fetched successfully", JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

  // createLogger(journey);

  // const acceptancePassenger = passengerRequest.givenName;
  let checkedInJourneyElementsBeforeCheckIn = [];
  let notCheckedInJourneyElementsBeforeCheckIn = [];
  let checkedInJourneyElementsAfterCheckIn = [];
  let notCheckedInJourneyElementsAfterCheckIn = [];
  let travelerIds = [];
  // retrieves traveler ids in all journeys
  // ? assumption: traveler id is same in all journeys (checked with a single pnr they sent)

  // let travelerID = utils.fetchTravelerIdsInAllJourneys(journey.data.data, acceptancePassenger)
  for (let passengerRequest of passengerRequests) {
    // const travelerIdInformation = utils.fetchTravelerIdsInAllJourneys(journey.data.data, passengerRequest.givenName);
    const travelerIdInformation = utils.fetchTravelerIdsInAllJourneys(journey.data.data, passengerRequest.paxInfo.givenName,passengerRequest.paxInfo.familyName);
    if (!(travelerIdInformation.length > 0 && travelerIdInformation[0].travelerId)) throw new Error ('Invalid name');
    travelerIds.push(travelerIdInformation[0].travelerId);
  }

  let modified = utils.filterValidJourneys(journey, flightLookups, travelerIds);
  journey = modified.journeysResponse;
  const isPartial = modified.journeyDeleted;
  console.log("Journey modified successfully", 'transaction id --> ', store.transactionId);
  console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

  if (utils.targetCarrierDoesNotMatchJourneysFirstFlight(journey.data.data,targetAirlineCode)) {
    console.log("Journey.FirstFlight CarrierCode does not match Target Airline CarrierCode", 'transaction id --> ', store.transactionId);
    isMisMatch = true;
    return { passengers, flights, errorFound, err,  isPartial ,isMisMatch};
  }


  // check if the traveler is acceptance eligible
  const acceptanceInEligibilityErrors = checkIfAcceptanceInEligible(journey.data.dictionaries, travelerIds);
  const acceptanceInEligibleTravelers = acceptanceInEligibilityErrors.map(elem => {
    const eligibleToMakePostCall = allowedToExecutePostAcceptance(acceptanceInEligibilityErrors, elem.travelerId);
    if (!eligibleToMakePostCall) return elem.travelerId;
  });


  // remove ineligible travelers
  const eligibleTravelers = travelerIds.filter(travelerId => {
    return !acceptanceInEligibleTravelers.includes(travelerId)
  })
  const travelersInformation = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);

  if(eligibleTravelers.length > 0) {
    // const beforeCheckInOperations = await deleteNotRequiredTravelersFromJourneyAndCheckInStatus(session, travelersInformation, travelerIds);
    const beforeCheckInOperations = await deleteNotRequiredTravelersFromJourneyAndCheckInStatus(session, travelersInformation, eligibleTravelers);
  }

  const checkInStatuses = fetchCheckedInJourneyElementsForTravelers(journey.data.dictionaries, travelerIds);
  checkedInJourneyElementsBeforeCheckIn.push(checkInStatuses.checkedInJourneyElements);
  notCheckedInJourneyElementsBeforeCheckIn.push(checkInStatuses.notCheckedInJourneyElements);

  let acceptanceResponses = [];
  if (eligibleTravelers.length > 0) {
    const { acceptanceResponses: postAcceptanceResponses, checkedInJourneyElements, notCheckedInJourneyElements } = await checkInTravelerIntoJourneys(session, travelersInformation);
    acceptanceResponses = postAcceptanceResponses;
    checkedInJourneyElementsAfterCheckIn.push(checkedInJourneyElements);
    notCheckedInJourneyElementsAfterCheckIn.push(notCheckedInJourneyElements);
  } else {
    checkedInJourneyElementsAfterCheckIn.push(checkInStatuses.checkedInJourneyElements);
    notCheckedInJourneyElementsAfterCheckIn.push(checkInStatuses.notCheckedInJourneyElements);
  }


  err = acceptanceResponses.length > 0 ? helpers.handleAcceptanceErrors(acceptanceResponses) : { CARRIER_ERROR_MESSAGE: '[]' };
  if (JSON.parse(err.CARRIER_ERROR_MESSAGE) !== '[]') errorFound = true;
  // Create a new journey here. this is required because we removed some pax from the journey & checkin statuses also updated.
  // journey = await api.searchCustomer(session, lookup);

  let flightIdsLinkedToJourneyElements = utils.fetchFlightsIdFromJourneyElement(journey.data.dictionaries);
  // const travelersInAllJourneys = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);
  const updatedTravelersInAllJourneys = utils.updateJourneyElementsCheckinStatuses(checkedInJourneyElementsAfterCheckIn, travelersInformation);

  //  ! Error. Creating pax of unwanted user also
  passengers = await utils.generatePassengersObjectForCCResponse(
    session,
    updatedTravelersInAllJourneys,
    flightIdsLinkedToJourneyElements,
    journey,
    { methodType: 'multiAcceptance', travelerId: 'could be anything, it dosent matter here :)' }
  );
  flights = utils.generateCCFlightsObject(journey.data);

  return { passengers, flights, errorFound, err, acceptanceInEligibilityErrors, isPartial ,isMisMatch};
}





module.exports = {
  fetchStatusConditions,
  checkInTravelerIntoJourneys,
  deleteNotRequiredTravelersFromJourneyAndCheckInStatus,
  acceptanceSubRoutine,
  fetchPassengerCheckinStatus,
  checkIfAcceptanceInEligible,
  fetchCheckedInJourneyElementsForTravelers,
  allowedToExecutePostAcceptance
}

