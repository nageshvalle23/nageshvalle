const api = require('../api');
const _ = require('lodash');
const uuid = require('uuid').v1;
// here are the util methods for the grouper method

const filterPassengerRequests = (identificationResponse, passengerRequests, matchConfiguration) => {
  let allTravelers = Object.values(identificationResponse.data.dictionaries.traveler);
  allTravelers = allTravelers.map(singleTraveler => {
    return JSON.stringify({
      givenName: singleTraveler.names[0].firstName,
      familyName: singleTraveler.names[0].lastName
    })
  })

  const filteredPassengerRequests = passengerRequests.filter(passengerRequest => {
    const searchVariable = JSON.stringify({
      givenName: passengerRequest.givenName,
      familyName: passengerRequest.familyName
    })
    if (matchConfiguration === 'not-matched') {
      if (allTravelers.includes(searchVariable)) return false;
      return true;
    }
    else if (matchConfiguration === 'matched') {
      if (allTravelers.includes(searchVariable)) return true;
      return false;
    }
  }).map(element => {
    return {
      // paxInfo: JSON.parse(element),
      paxInfo: element,
      identificationResponse: identificationResponse
    }
  });
  return filteredPassengerRequests;
}


exports.grouper = async (recordLookup, passengerRequests, session) => {
  const returnPayload = [];
  const identificationResponses = [];
  let identificationResponse = await api.searchCustomer(session, recordLookup);
  let unMatchedPassengerRequests = filterPassengerRequests(identificationResponse, passengerRequests, 'not-matched');
  let matchedPassengerRequests = [filterPassengerRequests(identificationResponse, passengerRequests, 'matched')];
  if (unMatchedPassengerRequests.length !== 0) {
    const groupedFamilyNames = [...new Set(unMatchedPassengerRequests.map(pr => pr.paxInfo.familyName))]
    // for each grouped family name execute a search customer
    for (let groupedFamilyName of groupedFamilyNames) {
      try {
        identificationResponse = await api.searchCustomer(session, { rloc: recordLookup.rloc, familyName: groupedFamilyName });
      } catch (e) {
        if (e.code === 'ECONNABORTED' || e.code === 'ENOTFOUND' || e.code === 'ECONNREFUSED') {
          throw new Error('Network error while performing 1A identification request')
        } else {
          console.log(e);
          throw new Error('Invalid family or given name in passenger requests');
        }
      }
      // matchedPassengerRequests.push(filterPassengerRequests(identificationResponse, passengerRequests, 'matched'));
      let temp = filterPassengerRequests(identificationResponse, unMatchedPassengerRequests.map(el => el.paxInfo), 'matched');
      if (temp.length !== 0) matchedPassengerRequests.push(filterPassengerRequests(identificationResponse, unMatchedPassengerRequests.map(el => el.paxInfo), 'matched'));
      unMatchedPassengerRequests = filterPassengerRequests(identificationResponse, unMatchedPassengerRequests.map(el => el.paxInfo), 'not-matched');

      // remove duplicate pax from matchedPassengerRequests
      // this might not be required now but lets see.
      // const matchedPassengerFamilyAndGivenNames = [...new Set(matchedPassengerRequests.map(el => JSON.stringify(el.paxInfo)))];
    }
    if (passengerRequests.length !== matchedPassengerRequests.flat(Infinity).length) throw new Error('Invalid given name identified');

  } else {
    // matchedPassengerRequests = [matchedPassengerRequests];
  }
  return matchedPassengerRequests;
}


  // const clonedPassengerRequests = _.cloneDeep(passengerRequests);
  // const clonedRecordLookup = _.cloneDeep(recordLookup);
  // const initialPassengerRequestsLength = clonedPassengerRequests.length;

// while (clonedPassengerRequests.length != 0 && initialPassengerRequestsLength > 0) {
//   let identificationResponse = null;
//   if (clonedRecordLookup) {
//     clonedRecordLookup = null;
//   } else {
//     identificationResponse = await api.searchCustomer(session, { rloc: recordLookup.rloc, familyName: clonedPassengerRequests[0].familyName });
//   }
//   // update cloned passengers requests with new data -> group the requests as per identification response

//   const passengersInformationFrom1A =  Object.values(identificationResponse.data.traveler).map(travelerNode => {
//     return {
//       familyName: travelerNode[0].lastName,
//       givenName: travelerNode[0].firstName
//     }
//   });


//   identificationResponses.push(identificationResponse);
// }