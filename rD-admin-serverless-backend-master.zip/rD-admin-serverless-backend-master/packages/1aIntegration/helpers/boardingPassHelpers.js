////////////////borading pass
const utils = require('../utils');
const converter = require('../converter');
const moment = require('moment');
const api = require('../api');
const { store } = require('../store');

const makeCouponObject = (flightId, flightInformation, boardingPassInformation = null, checkedInStatus = null, isCheckInInhibited = null, journeyElementId) => {
  return {
    flightNumber: flightInformation.operatingAirlineFlightNumber,

    departureDateTime: moment(flightInformation.departure.dateTime.split('+')[0]).format('YYYY-MM-DD HH:mm'),
    // departureDateTime: moment(flightInformation.departure.dateTime).format('YYYY-MM-DD HH:mm'),
    carrierCode: flightInformation.operatingAirlineCode,
    origin: flightInformation.departure.locationCode,
    eTicketNumber: boardingPassInformation === null ? journeyElementId : boardingPassInformation?.eTicketNumber,
    destination: flightInformation.arrival.locationCode,
    isCheckedIn: checkedInStatus.toLowerCase() === 'accepted' ? true : false,
    isCheckInInhibited: isCheckInInhibited,
    boardingPass: boardingPassInformation
  }

}

const updatePassengerCoupons = async (existingPassenger, traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session) => {
  const newCoupons = await createCoupons(traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session);
  existingPassenger.coupons.push(...newCoupons);
}

// this should be boardingpass not boardingpasses
const fetchBoardingPassResult = (boardingPassResponses, journeyElementId) => {
  const targetBoardingPass = { data: [null] };
  for (let singleBoardingPassResponse of boardingPassResponses) {
    const boardingPassNodes = singleBoardingPassResponse.data;
    if (!boardingPassNodes) continue;
    for (let boardingPasses of boardingPassNodes) {
      if (boardingPasses.journeyElementIds.includes(journeyElementId)) {
        // need to pass this as an array because down the line logic need not be changed.
        targetBoardingPass.data = [boardingPasses];
      }
    }
  }
  return targetBoardingPass;
}


const createCoupons = async (traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session, boardingPassesInformation) => {
  const coups = [];

  for (let journeyElement of traveler.flightsInformation) {
    const flightId = flightIdsLinkedToJourneyElements[journeyElement.journeyElementId];
    const flightInformation = journey.data.dictionaries.flight[flightId];
    let boardingPassInformation = null, boardingPassDocumentType = 'boardingPass';
    if (journeyElement.checkInStatus.toLowerCase() === 'accepted' && (requestOptions.methodType.toLowerCase() === 'multiboardingpass' || requestOptions.methodType.toLowerCase() === 'boardingpass')) {
      // boardingPassInformation = await api.fetchBoardingPassByJourneyElementId(session, traveler.journeyId, journeyElement.journeyElementId);
      boardingPassInformation = fetchBoardingPassResult(boardingPassesInformation, journeyElement.journeyElementId);
      // check if the document type is confirmation or boardingpass and return default 'boardingPass' if not first case.
      // if there is no documentType property, we will assume default is boardingPassType
      console.log(`boarding pass document type found as ${boardingPassInformation.data[0].documentType} for these journey elements ${boardingPassInformation.data[0].journeyElementIds}, transaction id -->  ${store.transactionId}`)
      if (boardingPassInformation.data[0].hasOwnProperty('documentType') && boardingPassInformation.data[0].documentType === 'confirmation') {
        boardingPassDocumentType = 'confirmation'
      }
      // Not changing this for now, but this should be executed only when boardingPassDocumentType is not "confirmation"
      boardingPassInformation = converter.convertToCCBoardingPass(boardingPassInformation, journeyElement.journeyElementId);
    }
    if (boardingPassDocumentType === 'confirmation') boardingPassInformation = null;
    coups.push(makeCouponObject(flightId, flightInformation, boardingPassInformation, journeyElement.checkInStatus, journeyElement.acceptanceEligibility.toLowerCase() === 'eligible', journeyElement.journeyElementId));
  }

  return coups;
}

const createPassengerObject = async (traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session, boardingPassInformation) => {
  const coups = await createCoupons(traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session, boardingPassInformation);
  let ageCategory = traveler.ageCategory;
  if (traveler.ageCategory.toLowerCase() === 'adt') {
    ageCategory = "ADULT";
  } else if (traveler.ageCategory.toLowerCase() === 'chd') {
    ageCategory = "CHILD";
  } else if (traveler.ageCategory.toLowerCase() === 'yth') {
    ageCategory = "YOUTH";
  }
  return {
    givenName: traveler.firstName,
    familyName: traveler.lastName,
    title: traveler.title,
    ageCategory: ageCategory,
    id: traveler.id,
    coupons: coups
  };
}

const generatePassengersObjectForCCResponse = async (session, travelersInAllJourneys, flightIdsLinkedToJourneyElements, journey, requestOptions, boardingPassInformation) => {
	const passengers = [];

	// Iterate through all travelers in each journey
	for (let travelersOfSingleJourney of travelersInAllJourneys) {
		for (let traveler of travelersOfSingleJourney.travelers) {

			// Skip traveler if request type is boarding pass and traveler ID doesn't match
      // request options traveler id is an array since its multi-boarding pass
			if (requestOptions && (requestOptions.methodType.toLowerCase() === 'multiboardingpass' || requestOptions.methodType.toLowerCase() === 'boardingpass' ) && !requestOptions.travelerId.includes(traveler.id)) continue;

			// Check if traveler already exists in passengers
			const existingPassenger = passengers.find((pax) => pax.id === traveler.id);

			// If traveler does not exist in passengers, create a new passenger object
			if (!existingPassenger) {
				const pax = await createPassengerObject(traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session, boardingPassInformation);
				passengers.push(pax);
			} else {
				// Update existing passenger's coupons
				await updatePassengerCoupons(existingPassenger, traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session, boardingPassInformation);
			}
		}
	}
	for (let passenger of passengers) {
		if (passenger.hasOwnProperty('id')) delete passenger.id
	}
	return passengers;
}

function isEmptyObject(obj) {
  return obj === null || obj === undefined || Object.keys(obj).length === 0;
}

const fetchBoardingPasses = async (travelersInAllJourneys, validTravelers, session) => {
  const boardingPasses = [];

  const journeyMap = new Map();
  for (let travelersOfSingleJourney of travelersInAllJourneys) {
    for (let traveler of travelersOfSingleJourney.travelers) {
      const validTravelerJourneyElements = [];
      if (validTravelers.includes(traveler.id)) {
        validTravelerJourneyElements.push(traveler.flightsInformation.map(je => je.journeyElementId).flat(Infinity))
      }
      let existingJourneyElements = journeyMap.get(traveler.journeyId)
      let validElements;
      if (!isEmptyObject(existingJourneyElements) && validTravelerJourneyElements.length > 0) {
        //existing key. append value
        validElements = validTravelerJourneyElements.concat(existingJourneyElements);
        journeyMap.set(traveler.journeyId, validElements);

      } else if (validTravelerJourneyElements.length > 0) {
        // new key
        journeyMap.set(traveler.journeyId, validTravelerJourneyElements);

      }
    }

  }

  // Call BP Endpoint once per Journey for selected journey elements (flights)
  for (let [journeyId, validElementsForJourney] of journeyMap) {
    console.log(journeyId + " = " + validElementsForJourney);
    const boardingPassResponse = await api.fetchBoardingPassByJourneyElementIds(journeyId, validElementsForJourney.flat(Infinity), session);
    boardingPasses.push(boardingPassResponse);

  }

  return boardingPasses;


}


const boardingpassModule = async (session, identificationResponse /*lookup*/, passengerRequests, flightLookups,targetAirlineCode) => {
  let err = null, passengers, flights, errorFound = false, isMisMatch = false;
  let travelerIds = [];


  // let journey = await api.searchCustomer(session, lookup);
  let journey = identificationResponse;
  // console.log("Journey fetched successfully", JSON.stringify(journey.data));
  // let journey = await api.searchCustomer(session, lookup);
  console.log("Journey fetched successfully", JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);


  for (let passengerRequest of passengerRequests) {
    const travelerIdInformation = utils.fetchTravelerIdsInAllJourneys(journey.data.data, passengerRequest.paxInfo.givenName,passengerRequest.paxInfo.familyName);
    if (!(travelerIdInformation.length > 0 && travelerIdInformation[0].travelerId)) throw new Error ('Invalid name');
    travelerIds.push(travelerIdInformation[0].travelerId);
  }

  modified = utils.filterValidJourneys(journey, flightLookups, travelerIds, 'multiboardingpass');
  journey = modified.journeysResponse;

  console.log("Journey modified successfully", 'transaction id --> ', store.transactionId);
  console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

  if (utils.targetCarrierDoesNotMatchJourneysFirstFlight(journey.data.data,targetAirlineCode)) {
    console.log("Journey.FirstFlight CarrierCode does not match Target Airline CarrierCode", 'transaction id --> ', store.transactionId);
    isMisMatch = true;
    return { passengers, flights, isMisMatch};
  }

  let flightIdsLinkedToJourneyElements = utils.fetchFlightsIdFromJourneyElement(journey.data.dictionaries);
  const travelersInAllJourneys = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);

  const boardingpasses = await fetchBoardingPasses(travelersInAllJourneys, travelerIds, session);

  passengers = await generatePassengersObjectForCCResponse(
    session,
    travelersInAllJourneys,
    flightIdsLinkedToJourneyElements,
    journey,
    { methodType: 'multiboardingpass', travelerId: travelerIds },
    boardingpasses
  );
  console.log('Generated passengers object', 'transaction id --> ', store.transactionId);
  flights = utils.generateCCFlightsObject(journey.data);
  return { passengers, flights };
}


module.exports = {
  fetchBoardingPasses,
  generatePassengersObjectForCCResponse,
  boardingpassModule
}
