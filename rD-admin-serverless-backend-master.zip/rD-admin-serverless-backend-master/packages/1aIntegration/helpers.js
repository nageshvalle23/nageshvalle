const uuid = require("uuid").v1;
const api = require("./api");
const { amadeusToamadeusMap } = require('./maps');
const { store } = require('./store');


const handleGender = (gender) => {
	let modifiedGender = null;
	if (gender == 'MALE' || gender == 'FEMALE') {
		modifiedGender = gender.toLowerCase();
	}
	else if (gender == 'X') { // ? does x mean Unspecified gender?
		modifiedGender = 'unspecified'
	} else if (gender == 'U') { // ? does u mean unknown ?
		modifiedGender = 'unknown'
	}
	return modifiedGender;
}

const handleAcceptanceErrors = (acceptanceResponses) => {
	let errorMessages = [];
	const errorAcceptances = acceptanceResponses.filter((acceptanceResponse1a) => {
		const errors = acceptanceResponse1a.data.errors || acceptanceResponse1a.errors;
		if (errors && errors.length > 0) return true
	})
	let code;
	errorAcceptances.forEach((singleErrorAcceptance) => {
		code = singleErrorAcceptance.data.errors ? singleErrorAcceptance.data.errors[0].code : singleErrorAcceptance.errors[0].code;
		if (singleErrorAcceptance.data.errors) {
			singleErrorAcceptance.data.errors.forEach((eachError) => {
				errorMessages.push(eachError);
			})
		}
		if (singleErrorAcceptance.errors) {
			singleErrorAcceptance.errors.forEach((eachError) => {
				errorMessages.push(eachError);
			})
		}
	})

	const err = {
		id: uuid(),
		CARRIER_ERROR_CODE: code,
		CARRIER_ERROR_MESSAGE: JSON.stringify({
			id: uuid(),
			message: JSON.stringify(errorMessages),
			code
		})
	}
	return err;
}


const fetchRequiredFieldsPerDocument = (eligibilityResponse) => {
	let response = []
	const { data } = eligibilityResponse.data;
	if (data.statusCleared || !data.hasOwnProperty('missingDetails')) {
		return response
	}
	if (data.hasOwnProperty('missingDetails')) {
		data.missingDetails.forEach(detail => {
			const requiredFieldsinDetailChoices = detail.detailsChoices.map(choices => {
				return {
					choiceName: choices.regulatoryType,
					requiredFields: choices.requiredDetailsFields
				}
			});
			const obj = {};
			// return requiredFieldsinDetailChoices;
			const detailCategory = detail.detailsCategory;
			obj[detailCategory] = requiredFieldsinDetailChoices;
			response.push(obj);
		})
	}
	return response;
}

const updateDefaultFields = async (eligibilityResponse, session, journeyNode) => {
	const requiredFieldsPerDocument = fetchRequiredFieldsPerDocument(eligibilityResponse);

	for (eachMissingDocument of requiredFieldsPerDocument) {
		if (eachMissingDocument.personalDetails && eachMissingDocument?.personalDetails[0]?.requiredFields?.includes('purposeOfVisit')) {
			const requestToBeSentTo1A = {
				"detailsToAdd": [
					{
						"personalDetails": {
							"purposeOfVisit": "work"
						}
					}
				]
			};
			const documentUpdateResponseFrom1a = await api.updateDocs(
				session,
				requestToBeSentTo1A,
				journeyNode.journeyId,
				journeyNode.travelerId,
			);

			// new eligibility response
			eligibilityResponse = documentUpdateResponseFrom1a;
			break;
		}
	}
	return eligibilityResponse;
}


const createObjectForRequestTo1aDocumentUpdate = (requiredFieldsForEachDoc, globalStore, returnActualMissingFields = null) => {
	const object = {};
	for (eachDocument of requiredFieldsForEachDoc) {
		const { documentName, documentProps } = eachDocument;
		for (requiredField of documentProps) {

			if (documentName.toLowerCase() == 'personaldetails') {
				const placesWhereIMightFindTheRequiredField = amadeusToamadeusMap[documentName][requiredField];
				if (requiredField.toLowerCase() == 'purposeofvisit') {
					if (!object.personalDetails) object.personalDetails = {};
					object.personalDetails.purposeOfVisit = 'work';
				}
				for (key in placesWhereIMightFindTheRequiredField) {
					if (globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]]) {
						const foundValue = globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]];
						if (!object.personalDetails) object.personalDetails = {};
						if (requiredField.toLowerCase() == 'name') {
							const { firstName, lastName } = foundValue;
							object.personalDetails.name = {};
							object.personalDetails.name.firstName = firstName;
							object.personalDetails.name.lastName = lastName;
						} else {
							object.personalDetails[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						}
						if (returnActualMissingFields) {
              //Return props other than what was found above
							let newProps = documentProps.filter((element) => {
								if (element !== requiredField) return true
							})
							eachDocument.documentProps = newProps;
						}
						break;
					}
				}
			}

			if (documentName.toLowerCase() == 'passport') {
				const placesWhereIMightFindTheRequiredField = amadeusToamadeusMap[documentName][requiredField];
				for (key in placesWhereIMightFindTheRequiredField) {
					if (globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]]) {
						const foundValue = globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]];
						if (!object.document) object.document = {};
						object.document.documentType = 'passport';
						object.document[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						if (requiredField.toLowerCase() == 'name') {
							const { firstName, lastName } = foundValue;
							object.document.name = {};
							object.document.name.firstName = firstName;
							object.document.name.lastName = lastName;
						} else {
							object.document[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						}
						if (returnActualMissingFields) {
							let newProps = eachDocument.documentProps.filter((element) => {
								if (element !== requiredField) return true
							})
							eachDocument.documentProps = newProps;
						}
						break;
					}
				}
			}

			if (documentName.toLowerCase() == 'visa') {
				const placesWhereIMightFindTheRequiredField = amadeusToamadeusMap[documentName][requiredField];
				for (key in placesWhereIMightFindTheRequiredField) {
					if (globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]]) {
						const foundValue = globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]];
						if (!object.document) object.document = {};
						object.document.documentType = 'visa';
						object.document[placesWhereIMightFindTheRequiredField[key]] = foundValue;

						if (requiredField.toLowerCase() == 'name') {
							const { firstName, lastName } = foundValue;
							object.document.name = {};
							object.document.name.firstName = firstName;
							object.document.name.lastName = lastName;
						} else {
							object.document[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						}
						if (returnActualMissingFields) {
							let newProps = eachDocument.documentProps.filter((element) => {
								if (element !== requiredField) return true
							})
							eachDocument.documentProps = newProps;
						}
						break;
					}
				}
			}

			if (documentName.toLowerCase() == 'homeaddress') {
				const placesWhereIMightFindTheRequiredField = amadeusToamadeusMap[documentName][requiredField];
				for (key in placesWhereIMightFindTheRequiredField) {
					if (globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]]) {
						const foundValue = globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]];
						if (!object.address) object.address = {};
						object.address.type = 'homeAddress';
						object.address[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						if (returnActualMissingFields) {
							let newProps = eachDocument.documentProps.filter((element) => {
								if (element !== requiredField) return true
							})
							eachDocument.documentProps = newProps;
						}
						break;
					}
				}
			}

			if (documentName.toLowerCase() == 'destinationaddress') {
				const placesWhereIMightFindTheRequiredField = amadeusToamadeusMap[documentName][requiredField];
				for (key in placesWhereIMightFindTheRequiredField) {
					if (globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]]) {
						const foundValue = globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]];
						if (!object.address) object.address = {};
						object.address.type = 'destinationAddress';
						object.address[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						if (returnActualMissingFields) {
							let newProps = eachDocument.documentProps.filter((element) => {
								if (element !== requiredField) return true
							})
							eachDocument.documentProps = newProps;
						}
						break;
					}
				}
			}

			//emergencyContact changes
			if (documentName.toLowerCase() == 'emergencycontact') {
				const placesWhereIMightFindTheRequiredField = amadeusToamadeusMap[documentName][requiredField];
				for (key in placesWhereIMightFindTheRequiredField) {
					if (globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]]) {
						const foundValue = globalStore?.[key]?.[placesWhereIMightFindTheRequiredField[key]];
						if (!object.phoneNumber) object.phoneNumber = {};
						object.phoneNumber.purpose = 'emergencyContact';
						object.phoneNumber[placesWhereIMightFindTheRequiredField[key]] = foundValue;
						if (returnActualMissingFields) {
							let newProps = eachDocument.documentProps.filter((element) => {
								if (element !== requiredField) return true
							})
							eachDocument.documentProps = newProps;
						}
						break;
					}
				}
			}
		}
	}
	return { object, requiredFieldsForEachDoc };
}

module.exports = {
	handleGender,
	handleAcceptanceErrors,
	fetchRequiredFieldsPerDocument,
	updateDefaultFields,
	createObjectForRequestTo1aDocumentUpdate
}
