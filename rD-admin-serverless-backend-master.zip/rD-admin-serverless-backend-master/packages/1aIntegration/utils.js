

const uuid = require("uuid").v1;
const api = require('./api');
const { format, parseISO } = require('date-fns');
const { State} = require("country-state-city");
const { countryToAlpha2, countryToAlpha3 } = require("country-to-iso");
const {
	createPassengerObject,
	updatePassengerCoupons,
	getJourneyElementsInformation,
} = require('./converter');
const { store } = require('./store');
const getCountryISO2 = require("country-iso-3-to-2");
const _handleErrors = require('./handleErrorsMethod');
const xml2js = require('xml2js');

/*

Non-ideal old code

exports.handleDocument = (eligibilityResponse, ccEligibilityResponse, document, lookup) => {
	const { requiredDocuments } = ccEligibilityResponse;
	const { givenName, familyName } = lookup;
	const detailsToAdd = [{}];
	const detailsToDecline = [];

	const requestTo1A = {
		detailsToAdd
		// detailsToDecline // ? shown as a mandatory field but worked without passing this!
	}



	for (let doc of document) {
		const { type, payload } = doc;

		if (type == 'PASSPORT' && requiredDocuments.includes('PASSPORT')) {
			const { givenName, familyName, dateOfBirth, gender, passportNumber, expiryDate, nationality, countryOfIssue, documentNumber } = payload;
			const modifiedGender = handleGender(gender);
			// as per what amadeus accepts basically map the cc fields to amadeus api
			const modifiedDocumentObject = {
				number: passportNumber,
				expiryDate,
				issuanceLocation: countryOfIssue,
				name: {
					firstName: givenName,
					lastName: familyName,
				},
				nationalityCode: nationality,
				gender: modifiedGender,
				birthDate: dateOfBirth,
				documentType: 'passport'
			}

			const personalDetails = {
				birthDate: dateOfBirth,
				birthPlace: nationality,
				name: {
					firstName: givenName,
					lastName: familyName
				},
				gender: modifiedGender,
				nationalityCode: nationality,
				purposeOfVisit: "work"
			}

			detailsToAdd[0].personalDetails = personalDetails;
			detailsToAdd[0].document = modifiedDocumentObject;
		}

		if (type == 'VISA' && requiredDocuments.includes('VISA')) {
			const { expiryDate, countryOfIssue, documentNumber } = payload;

			const modifiedDocumentObject = {
				nationalityCode: fetchNationalityCode(eligibilityResponse),
				name: {
					firstName: givenName,
					lastName: familyName
				},
				number: documentNumber,
				expiryDate,
				issuanceLocation: countryOfIssue,
				issuanceCountryCode: countryOfIssue,
				documentType: 'visa'
			}

			detailsToAdd[0].document = modifiedDocumentObject;

		}

		if (type == 'DESTINATION_ADDRESS' && requiredDocuments.includes('DESTINATION_ADDRESS')) {
			const { street, city, stateProv, postalCode, country } = payload;

			const modifiedDocumentObject = {
				lines: [street],
				zipCode: postalCode,
				countryCode: country,
				cityName: city,
				stateCode: stateProv,
				type: 'destinationAddress'
			}
			detailsToAdd[0].address = modifiedDocumentObject;
		}

		if (type == 'RESIDENT_ADDRESS' && requiredDocuments.includes('RESIDENT_ADDRESS')) {
			const { countryOfResidence } = payload;

			const modifiedDocumentObject = {
				countryCode: countryOfResidence,
				type: 'homeAddress'
			}

			detailsToAdd[0].address = modifiedDocumentObject;

			// * adding a pre check if personal details exist.
			if (!detailsToAdd[0].hasOwnProperty('personalDetails')) detailsToAdd[0].personalDetails = {}
			detailsToAdd[0].personalDetails.countryOfResidenceCode = countryOfResidence;
		}
	}

	return requestTo1A;
}

*/

// [{<journey element>: <flight id> }]
/* OLD Code
exports.fetchFlightsIdFromJourneyElement = async (session, journey) => {
	let flightIdsLinkedToJourneyElements = {};
	for (let journeyItem of journey) {
		const journeyElementInformation =
			await api.getJourneyElementsInformationInAJourney(session, journeyItem.id);
		for (let item of journeyElementInformation.data) {
			flightIdsLinkedToJourneyElements[item.id] = item.flightId;
		}
	}
	return flightIdsLinkedToJourneyElements;
}*/

exports.fetchFlightsIdFromJourneyElement = (dictionaries) => {
	let flightIdsLinkedToJourneyElements = {};
	if (!dictionaries || !dictionaries.journeyElement) throw new Error('Dictonaries or journey elements data is not found');
	for (let journeyElement of Object.values(dictionaries.journeyElement)) {
		flightIdsLinkedToJourneyElements[journeyElement.id] = journeyElement.flightId;
	}
	return flightIdsLinkedToJourneyElements;
}

// returns array containing journeys and each journey contains its traveler information.
// old code
/*exports.fetchTravelersInAllJourneys = async (session, journey, travelerId = null) => {
	const travelersInAllJourneys = await Promise.all(journey.map(async (journey) => {
		const journeyInformation = await api.getJourneyElementsInformationInAJourney(session, journey.id);
		return {
			travelers: journey.travelers.map(traveler => {
				return {
					id: traveler.id,
					firstName: traveler.names[0].firstName,
					lastName: traveler.names[0].lastName,
					title: traveler.names[0].title,
					flightsInformation: getJourneyElementsInformation(journeyInformation, traveler.id) || null, // the || null added to avoid falsy undefined value when unit testing
					journeyId: journey.id, // can we optimise this?
					ageCatagory: traveler.passengerTypeCode
				};
			}).filter(element => travelerId === null || travelerId === element.id), // this is a new change (if record do not work remove this)
		};
	}));
	return travelersInAllJourneys;
}*/

const fetchJourneyElementInformationFromDictonaries = (journeyElementId, dictionaries) => {
	if (!dictionaries) throw new Error('Dictonaries array was empty!');
	if (!dictionaries.journeyElement[journeyElementId]) throw new Error('Journey Element not found in dictionaries - Internal');
	return {
		travelerId: dictionaries.journeyElement[journeyElementId]?.travelerId,
		journeyElementId: dictionaries.journeyElement[journeyElementId]?.id,
		checkInStatus: dictionaries.journeyElement[journeyElementId]?.checkInStatus,
		boardingPassPrintStatus: dictionaries.journeyElement[journeyElementId]?.boardingPassPrintStatus,
		acceptanceEligibility: dictionaries.journeyElement[journeyElementId]?.acceptanceEligibility.status,
		isCheckInInhibitedStatus:getInhibitedStatus(dictionaries.journeyElement[journeyElementId]?.acceptanceEligibility)

	}
}
const getInhibitedStatus = (acceptanceEligibility) => {
  if (acceptanceEligibility.reasons) {
    if (!acceptanceEligibility.reasons.length) {
      return (acceptanceEligibility.status == 'ineligible')
    }
    const containsTicketProblem = acceptanceEligibility.reasons.includes("ticketProblem");
    const containsRegulatoryDetailsInhibition = acceptanceEligibility.reasons.includes("regulatoryDetailsInhibition");

    const filteredArray = acceptanceEligibility.reasons.filter(item => item !== "ticketProblem" && item !== "regulatoryDetailsInhibition");
    if (filteredArray.length) {
      return (acceptanceEligibility.status == 'ineligible')
    }
    else if (containsRegulatoryDetailsInhibition && acceptanceEligibility.status == 'ineligible') return true
    else if (containsTicketProblem && acceptanceEligibility.status == 'ineligible') return false
    else return true
  } else {
    return (acceptanceEligibility.status == 'ineligible')
  }
}

const fetchJourneyElementIdsByTravelerIdAndJourneyId = (dictionaries, travelerId, journeyElementsInJourney) => {
	journeyElementsInJourney = journeyElementsInJourney.map(elem => elem.id);
	return Object.values(dictionaries.journeyElement).filter(element => element.travelerId === travelerId && journeyElementsInJourney.includes(element.id));
}

exports.travelersInformationByJourney = (journey, dictionaries, travelerId = null) => {
	const travelersPerJourney = journey.map(journey => {
		return {
			travelers: journey.travelers.map(traveler => {
				const journeyElementIdsLinkedToATraveler = fetchJourneyElementIdsByTravelerIdAndJourneyId(dictionaries, traveler.id, journey.journeyElements);
				return {
					id: traveler.id,
					firstName: traveler.names[0].firstName,
					lastName: traveler.names[0].lastName,
					title: traveler.names[0].title,
					journeyId: journey.id,
					ageCategory: traveler.passengerTypeCode,
					flightsInformation: journeyElementIdsLinkedToATraveler.map(journeyElementFromDictonaries => fetchJourneyElementInformationFromDictonaries(journeyElementFromDictonaries.id, dictionaries))
				}
			}).filter(element => travelerId === null || travelerId === element.id),
		}
	})
	return travelersPerJourney;
}

exports.updateJourneyElementsCheckinStatuses = (checkedInJourneyElements, travelersInformation) => {
	checkedInJourneyElements = checkedInJourneyElements.flat(Infinity);
	for (let journeyIndex in travelersInformation) {
		for (let travelerIndex in travelersInformation[journeyIndex].travelers) {
			for (let flightInformationIndex in travelersInformation[journeyIndex].travelers[travelerIndex].flightsInformation) {
				const travelerJourneyElementId = travelersInformation[journeyIndex].travelers[travelerIndex].flightsInformation[flightInformationIndex].journeyElementId;
				if (checkedInJourneyElements.includes(travelerJourneyElementId)) {
					travelersInformation[journeyIndex].travelers[travelerIndex].flightsInformation[flightInformationIndex].acceptanceEligibility = 'eligible';
					travelersInformation[journeyIndex].travelers[travelerIndex].flightsInformation[flightInformationIndex].checkInStatus = 'accepted';
				}
			}
		}
	}
	return travelersInformation;
}

// This creates passengers object that we return back to CC.
exports.generatePassengersObjectForCCResponse = async (session, travelersInAllJourneys, flightIdsLinkedToJourneyElements, journey, requestOptions) => {
	const passengers = [];

	// Iterate through all travelers in each journey
	for (let travelersOfSingleJourney of travelersInAllJourneys) {
		for (let traveler of travelersOfSingleJourney.travelers) {

			// Skip traveler if request type is boarding pass and traveler ID doesn't match
			if (requestOptions && (requestOptions.methodType.toLowerCase() === 'boardingpass' ) && requestOptions.travelerId !== traveler.id) continue;

			// Check if traveler already exists in passengers
			const existingPassenger = passengers.find((pax) => pax.id === traveler.id);

			// If traveler does not exist in passengers, create a new passenger object
			if (!existingPassenger) {
				const pax = await createPassengerObject(traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session);
				passengers.push(pax);
			} else {
				// Update existing passenger's coupons
				await updatePassengerCoupons(existingPassenger, traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session);
			}
		}
	}
	for (let passenger of passengers) {
		if (passenger.hasOwnProperty('id')) delete passenger.id
	}
	return passengers;
}

// returns traveler ids of all travelers in all journeys
exports.fetchTravelerIdsInAllJourneys = (journey, passengerName,lastName) => {
	const travelerInformation = journey
		.map((element) => {
			const travelersIdsInJourney = element.travelers.map((traveler) => {
				return {
					travelerId: traveler.id,
					firstName: traveler.names[0].firstName,
					journeyId: element.id,
					lastName:traveler.names[0].lastName
				};
			});
			return travelersIdsInJourney;
		})
		.reduce((merged, subArray) => merged.concat(subArray))
		.filter((traveler) => traveler.firstName.toLowerCase() === passengerName.toLowerCase() && traveler.lastName.toLowerCase()===lastName.toLowerCase());
	return travelerInformation;
}

exports.generateCCFlightsObject = (journeyData) => {
    const flights = journeyData.data.map((journey) => {
        const matchingFlights = journey.flights.map((journeyFlight) => {
            const flightInformation = journeyData.dictionaries.flight[journeyFlight.id];

            if (flightInformation) {
                return {
                    flightNumber: flightInformation.operatingAirlineFlightNumber,
                    date: flightInformation.departure.dateTime,
                    carrierCode: flightInformation.operatingAirlineCode,
                    origin: flightInformation.departure.locationCode,
                    destination: flightInformation.arrival.locationCode,
                };
            }
            return null; // Return null for flights that don't have a match
        }).filter(flight => flight !== null); // Filter out null values for each journey

        return matchingFlights;
    }).flat(); // Flatten the array of flights for all journeys

    return flights.sort((f1, f2) => {
        const f1Date = new Date(f1.date);
        const f2Date = new Date(f2.date);
        return f1Date - f2Date;
    }).map(element => {
        element.date = element.date.split('T')[0];
        return element;
    });
}
// format(parseISO(flightInformation.departure.dateTime), 'yyyy-MM-dd'),

exports.fetchRequiredFieldsPerDocument = (eligibilityResponse) => {
	let response = []
	const { data } = eligibilityResponse.data;
	if (data.statusCleared || !data.hasOwnProperty('missingDetails')) {
		return response
	}
	if (data.hasOwnProperty('missingDetails')) {
		data.missingDetails.forEach(detail => {
			const requiredFieldsinDetailChoices = detail.detailsChoices.map(choices => {
				return {
					choiceName: choices.regulatoryType,
					requiredFields: choices.requiredDetailsFields
				}
			});
			const obj = {};
			// return requiredFieldsinDetailChoices;
			const detailCategory = detail.detailsCategory;
			obj[detailCategory] = requiredFieldsinDetailChoices;
			response.push(obj);
		})
	}
	return response;
}

// flightlookups
/* carrierCode, date, flightNumber, origin, destination */
const flightValidator = (journeysResponse, flightLookups) => {
	if (!flightLookups || flightLookups.length == 0) throw new Error('No flight lookups provided');
	const flightDictionaries = Object.values(journeysResponse.data.dictionaries.flight);
	const foundFlightsInformation = []; // this stores flight ids
	for (let flight of flightLookups) {
		const { carrierCode, date, flightNumber, origin, destination } = flight;
		if (!carrierCode || !date || !flightNumber || !origin || !destination) throw new Error('Flight lookups contain missing attributes');
		let flightFound = false;
		for (let flightObject of flightDictionaries) {
			if (carrierCode === flightObject.operatingAirlineCode &&
				flightNumber === flightObject.operatingAirlineFlightNumber &&
				origin === flightObject.departure.locationCode &&
				destination === flightObject.arrival.locationCode &&
				date === flightObject.departure.dateTime.split('T')[0]) {
					flightFound = true;
					foundFlightsInformation.push(flightObject.id);
					break;
			}
		}
		if (!flightFound) throw new Error('Invalid flight object detected!');
	}
	return foundFlightsInformation;
}

exports.filterValidJourneys = (journeysResponse, flightLookups, travelerIds, methodName = null) => {
	const validJourneyElements = [];
	const journeyElements = Object.values(journeysResponse.data.dictionaries.journeyElement);
	let journeyDeleted = false;
	// format this into a new function because this is used in multi-acceptance also

	const flightsFound = flightValidator(journeysResponse, flightLookups);

	for (let journeyElement of journeyElements) {
		// if (travelerIds.includes(journeyElement.travelerId) && flightsFound.includes(journeyElement.flightId)) {
		// 	validJourneyElements.push(journeyElement.id);
		// }
		if (flightsFound.includes(journeyElement.flightId)) {
			validJourneyElements.push(journeyElement.id);
		}
	}

	// if (validJourneyElements.length === 0) throw new Error('Provided traveler(s) do not travel on these flights');
	if (validJourneyElements.length === 0) throw new Error('Journey Elements do not match to the flight lookups');
	// remove invalid journeys
	// assumptions:
	// remove unwanted journeys
	// if partial journey found throw error.
	const removableJourneyIds = [];
	let removableJourneyElements = [];
	for (let journey of journeysResponse.data.data) {
		const flightsInJourney = journey.flights;
		let singleFlightMatched = false;
		let singleFlightNotMatched = false;
		for (let flight of flightsInJourney) {
			if (flightsFound.includes(flight.id)) singleFlightMatched = true;
			else {
				singleFlightNotMatched = true;
			}
		}
		if (singleFlightNotMatched && singleFlightMatched) {
      //It means flights matched partially e.g. 1 of 2 flights matched
			// this is for boarding pass only. allow single segments!
			if (!methodName) throw new Error('Provided flights are in-sufficient to checkin to a journey');
			// else if (methodName === 'boardingpass') {

			// }
		}
		if (singleFlightNotMatched && !singleFlightMatched) {
			//It means no flights matched e.g. 1 of 2 flights matched
      // remove this journey
			removableJourneyIds.push(journey.id);
			removableJourneyElements.push(journey.journeyElements.map(element => element.id))
		}
	}
	removableJourneyElements = removableJourneyElements.flat(Infinity);
	// remove useless journeys from dictonaries
	journeysResponse.data.data = journeysResponse.data.data.filter(journey => {
		if (!removableJourneyIds.includes(journey.id)) return true;
	})
	// remove the journeyElements from journey data nodes
	for (let journeyIndex in journeysResponse.data.data) {
		journeysResponse.data.data[journeyIndex].journeyElements = journeysResponse.data.data[journeyIndex].journeyElements.filter(elem => {
			return validJourneyElements.includes(elem.id)
		})
	}
	// delete unwanted journey elements from dictonaries
	Object.values(journeysResponse.data.dictionaries.journeyElement).forEach(jl => {
		if (!validJourneyElements.includes(jl.id)) {
			delete journeysResponse.data.dictionaries.journeyElement[jl.id];
			journeyDeleted = true;
		}
	})
	return { journeysResponse, journeyDeleted, removableJourneyElements };
}


exports.filterValidJourneysForEligibility = (journeysResponse, flightLookups, methodName = null) => {
	const validJourneyElements = [];
	const journeyElements = Object.values(journeysResponse.data.dictionaries.journeyElement);
	let journeyDeleted = false;
	// format this into a new function because this is used in multi-acceptance also

	const flightsFound = flightValidator(journeysResponse, flightLookups);

	for (let journeyElement of journeyElements) {

		if (flightsFound.includes(journeyElement.flightId)) {
			validJourneyElements.push(journeyElement.id);
		}
	}

	if (validJourneyElements.length === 0) throw new Error('Journey Elements do not match to the flight lookups');

  const removableJourneyIds = [];
	let removableJourneyElements = [];
	let usedFlights = [];
  let journeyMismatchOccured = false;
  for (let journey of journeysResponse.data.data) {
		const flightsInJourney = journey.flights;
		let singleFlightMatched = false;
		let singleFlightNotMatched = false;
    let journeyFlightsMatched = [];
		for (let flight of flightsInJourney) {
			if (flightsFound.includes(flight.id))
      {
        singleFlightMatched = true;
			  let idx = flightsFound.findIndex((element) => element == flight.id);
        usedFlights.push(flight.id);
        journeyFlightsMatched.push(flight.id);
        flightsFound.splice(idx,1); //remove element
      }
      else {
				singleFlightNotMatched = true;
			}
		}

    if (journeyFlightsMatched.length == 0) {
      console.log("No match for journey on Target side. Being removed", 'transaction id --> ', store.transactionId);
      // journey can be removed since no cc.flights have matched, which means Client does not want
      removableJourneyIds.push(journey.id);
			removableJourneyElements.push(journey.journeyElements.map(element => element.id))
    }else if (journeyFlightsMatched.length == flightsInJourney.length) {
      //all flights in journey have matched
    }else {
      // some flights in journey did not find a match in the incoming request, i.e its a partial match for Targets journey
      journeyMismatchOccured = true;
      console.log("Partial journey match on Target side", 'transaction id --> ', store.transactionId);
      // throw new Error('Journey mismatch');

    }

	}

  //some flights in CC request did not find a match to one of the Journey's flights
  if (flightsFound.length>0) {
    console.log("Partial journey match on Request side. Some flights in request could not be matched in Target's journey", 'transaction id --> ', store.transactionId);
    journeyMismatchOccured = true;
    // throw new Error('Journey mismatch');
  }

	removableJourneyElements = removableJourneyElements.flat(Infinity);
	// remove useless journeys from dictonaries
	journeysResponse.data.data = journeysResponse.data.data.filter(journey => {
		if (!removableJourneyIds.includes(journey.id)) return true;
	})
	// remove the journeyElements from journey data nodes
	for (let journeyIndex in journeysResponse.data.data) {
		journeysResponse.data.data[journeyIndex].journeyElements = journeysResponse.data.data[journeyIndex].journeyElements.filter(elem => {
			return validJourneyElements.includes(elem.id)
		})
	}
	// delete unwanted journey elements from dictonaries
	Object.values(journeysResponse.data.dictionaries.journeyElement).forEach(jl => {
		if (!validJourneyElements.includes(jl.id)) {
			delete journeysResponse.data.dictionaries.journeyElement[jl.id];
			journeyDeleted = true;
		}
	})
	return { journeysResponse, journeyDeleted, removableJourneyElements,journeyMismatchOccured };
}


/* OLD NON-IDEAL UNUSED CODE
const fetchNationalityCode = (eligibilityResponse) => {
	let nationalityCode = null;
	const { data } = eligibilityResponse.data;
	const storedDetails = data.storedDetails;
	for (eachDocument of storedDetails) {

		if (eachDocument?.personalDetails?.nationalityCode) {
			nationalityCode = eachDocument?.personalDetails?.nationalityCode;
			break;
		}
		if (eachDocument?.document?.nationalityCode) {
			nationalityCode = eachDocument?.document?.nationalityCode;
			break;
		}

	}
	return nationalityCode;
}
*/


exports.groupByFamilyName = (passengerRequests) => {
	const foundFamilyNames = [];
	const groupedPassengerRequests = [];
	for (let passengerRequest of passengerRequests) {
		if (foundFamilyNames.includes(passengerRequest.familyName)) {
			const index = groupedPassengerRequests.findIndex(passengerRequestsInGroupedArray => {
				return passengerRequestsInGroupedArray[0].familyName === passengerRequest.familyName;
			})
			groupedPassengerRequests[index].push({familyName: passengerRequest.familyName, givenName: passengerRequest.givenName }); // currently ignoring e ticket number
		} else {
			foundFamilyNames.push(passengerRequest.familyName);
			groupedPassengerRequests.push([{familyName: passengerRequest.familyName, givenName: passengerRequest.givenName }]);
		}
	}
	return groupedPassengerRequests;
}

exports.normalizeCountryCode=(countryCode) =>{
    if (countryCode.length < 3) {
        return countryCode;
    }
    return getCountryISO2(countryCode);
}

exports.targetCarrierDoesNotMatchJourneysFirstFlight = (journeys, targetAirlineCode) => {
  for (let journey of journeys) {
    if (journey.flights[0].id.split('-')[0].toLowerCase() !== targetAirlineCode.toLowerCase()) {
      console.log("Journey.FirstFlight CarrierCode does not match Target Airline CarrierCode", 'transaction id --> ', store.transactionId);
      return true;
    }
  }
  return false;
}

exports.returnJourneyMismatchError=(cb) =>{
  const err = {
    id: "ERR_JOURNEY_MISMATCH_OR_NOT_FOUND",
    CARRIER_ERROR_CODE: 500,
    CARRIER_ERROR_MESSAGE: this.serializeObjectToXML({
      id: uuid(),
      message: "Client's flights do not match with Target's Journey",
      code: 500
    })
  };
  return _handleErrors(err, cb);
}
exports.getStateIsoCode = (payload) => {
  const payloadCountryCode = countryToAlpha2(payload.country)

  const listOfStatesInCountry = State.getStatesOfCountry(payloadCountryCode);

  let matchingstates = listOfStatesInCountry.filter((state) => {
    if ((state.isoCode.toLowerCase() === payload.stateProv.toLowerCase()) || (state.name.toLowerCase().replace(/\s+/g, '') === payload.stateProv.toLowerCase().replace(/\s+/g, '')) )
      return true;
  });

  if (matchingstates.length > 0) {
    return matchingstates[0]?.isoCode;
  }else{
    return payload.stateProv;
  }

};

exports.serializeObjectToXML = (obj)=>{
  const builder = new xml2js.Builder( {rootName: 'info',  headless: true, renderOpts: { pretty: false }  });
  return builder.buildObject(obj);
}
