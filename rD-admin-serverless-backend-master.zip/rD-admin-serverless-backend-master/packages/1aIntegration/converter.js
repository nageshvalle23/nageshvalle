
const dlv = require('dlv');
const { DateTime } = require('luxon');
const api = require('./api');
const moment = require('moment');
const { store } = require('./store');

// passengerTypeCode -- age category
// -- ? eTicketNumber
// acceptanceEligability.status -- isCheckinInhibited




const convertToCCBoardingPass = function (targetboardingPass, journeyElementId) {

  const boardingPassResponse = targetboardingPass?.data[0];
  // console.log(boardingPassResponse, '= boarding pass', 'transaction id --> ', store.transactionId);

  const ccBoardingPassData = {
    barcodedata: boardingPassResponse?.boardingPassData?.barcodeStream || null, // ? doubts re; barcode
    seatNumber: boardingPassResponse?.boardingPassData?.legs[0]?.seat?.seatNumber || null,
    passengerClass: boardingPassResponse?.boardingPassData?.legs[0]?.seat?.cabin  || null,
    boardingTime: boardingPassResponse?.boardingPassData?.legs[0]?.boardingDateTime || null,
    eTicketNumber: boardingPassResponse?.boardingPassData?.ticketNumber || null, // ? return journey element id as ticket number for now
   frequentFlyerNumber: boardingPassResponse?.boardingPassData?.frequentFlyerCards?.[0]?.cardNumber|| null,
    gate: boardingPassResponse?.boardingPassData?.legs[0]?.boardingGate || null,
    terminal: boardingPassResponse?.boardingPassData?.flight?.departure?.terminal || null, // ! invalid path mentioned here. Get this from dictonaries.
    securityNumber:  boardingPassResponse?.boardingPassData?.sequenceNumber || null, // ? Security number field not found in amadeus
    boardingGroup: boardingPassResponse?.boardingPassData?.priorities?.boardingGroup || null,
    allowTSA: boardingPassResponse?.boardingPassData?.priorities?.tsaPreCheck || null, // ! returning null instead of false. check this
    allowFastTrack: boardingPassResponse?.boardingPassData?.priorities?.isFastTrack || null, // ! returning null instead of false. 
    // ? did not find mobile wallet fields for ios and android
    mobilewallerURL_ios: null,
    mobilewalletURL_android: null
  }
  return ccBoardingPassData;
}



const generateRequiredDocuments = (eligibilityResponse) => {

  const { data } = eligibilityResponse.data;
  if (data.statusCleared || !data.hasOwnProperty('missingDetails')) {
    return []
  }
  // This returns array of arrays.
  if (data.hasOwnProperty('missingDetails')) {
    let visaConfigurations = {
      supportedCCAttributes: ['number', 'expiryDate', 'issuanceLocation', 'name', 'issuanceCountry'],
    };
    let missingDocuments = data.missingDetails.map(detail => {
      const detailChoices = detail.detailsChoices.map(choices => choices.regulatoryType)

      // Additional code to handle visa
      const requiredFieldsinDetailChoices = detail.detailsChoices.map(choices => {
        return {
          choiceName: choices.regulatoryType,
          requiredFields: choices.requiredDetailsFields
        }
      });
      for (let detail of requiredFieldsinDetailChoices) {
        if (detail.choiceName.toLowerCase() === 'visa') {
          let requiredCCFields = [];
          for (let requiredField of detail.requiredFields) {
            if (!visaConfigurations.supportedCCAttributes.some(ccSupportedField => ccSupportedField === requiredField) && requiredField !== 'nationalityCountryCode') {
              visaConfigurations.requiredAttributesMatch = false;
              requiredCCFields.push('SEE_AGENT');
              break;
            } else {
              // if (requiredField.toLowerCase() === 'nationalityCountryCode'.toLowerCase()) {
              //   requiredCCFields.push('PASSPORT');
              // } else {
              //   requiredCCFields.push('VISA'); // dupicate elements will be removed at the end.
              // }
              requiredCCFields.push('VISA');
            }
          }
          return requiredCCFields; // this returns array of items
        }
      }
      // visa code ends here
      if (detailChoices.some(detailChoice => detailChoice.toLowerCase() === 'identityCard'.toLowerCase())) return ['passport']
      // ? TODO:  This should'nt return all choices. Single choice is enough. Leaving it like this since CC docs are out of scope.
      return detailChoices; // this returns array of array items. 
    }).reduce((merged, sub) => merged.concat(sub));

    console.log('missing documents', missingDocuments, 'transaction id --> ', store.transactionId);
    missingDocuments = missingDocuments.map(detail => {
      if (detail.toLowerCase() === 'personalDetails'.toLowerCase()) return ['PASSPORT', 'RESIDENT_ADDRESS']
      else if (detail.toLowerCase() !== 'personaldetails' && detail.toLowerCase() !== 'passport' && detail.toLowerCase() !== 'visa' && detail.toLowerCase() !== 'RESIDENT_ADDRESS'.toLowerCase()) return ['SEE_AGENT']
      return [detail.toUpperCase()]
    }).reduce((merged, sub) => merged.concat(sub));
    return Array.from(new Set(missingDocuments))
  }
}

// This function do not identify personalDetails at all.
const generateExistingDocument = (eligibilityResponse) => {
  const { data } = eligibilityResponse.data;
  if (!data.hasOwnProperty('storedDetails')) {
    return []
  }

  if (data.hasOwnProperty('storedDetails')) {
    let existingDetails = data.storedDetails.map(storedDetail => {
      if (storedDetail.hasOwnProperty('personalDetails')) {
        return 'personalDetails'
      }
      else if (storedDetail.hasOwnProperty('document')) {
        return storedDetail.document.documentType;
      } else if (storedDetail.hasOwnProperty('address')) {
        if (storedDetail.address.type.toLowerCase() === 'destingationaddress') return 'DESTINATION_ADDRESS';
        else return 'RESIDENT_ADDRESS';
      }
    })
    // remove personal details from existing documents as it is not supported by cc anymore
    // instead return that with [passport & resident_address]
    existingDetails = existingDetails.map(detail => {
      if (detail.toLowerCase() === 'personalDetails'.toLowerCase()) {
        return null
        // return ['PASSPORT', 'RESIDENT_ADDRESS']
      }
      return [detail.toUpperCase()]
    }).flat().filter(element => element);
    return Array.from(new Set(existingDetails));
  }
}

const getJourneyElementsInformation = (journeyInformation, travelerId) => {
  const journeyElements = []
  for (let journeyElement of journeyInformation.data) {
    if (journeyElement.travelerId === travelerId) {
      journeyElements.push({
        travelerId: travelerId,
        journeyElementId: journeyElement.id,
        checkInStatus: journeyElement.checkInStatus,
        boardingPassPrintStatus: journeyElement.boardingPassPrintStatus,
        acceptanceEligibility: journeyElement.acceptanceEligibility.status // we are assuming this is checkInInhibited
      })
    }
  }
  return journeyElements;
}

const makeCouponObject = (flightId, flightInformation, boardingPassInformation = null, checkedInStatus = null, isCheckInInhibited = null, journeyElementId) => {
  return {
    flightNumber: flightInformation.operatingAirlineFlightNumber,
    // departureDateTime: flightInformation.departure.dateTime,
    departureDateTime: moment(flightInformation.departure.dateTime.split('+')[0]).format('YYYY-MM-DD HH:mm'),
    carrierCode: flightInformation.operatingAirlineCode,
    origin: flightInformation.departure.locationCode,
    eTicketNumber: boardingPassInformation === null ? journeyElementId : boardingPassInformation?.eTicketNumber,
    destination: flightInformation.arrival.locationCode,
    isCheckedIn: checkedInStatus.toLowerCase() === 'accepted' ? true : false,
    isCheckInInhibited: isCheckInInhibited,
    boardingPass: boardingPassInformation
  }

}

const createPassengerObject = async (traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session) => {
  const coups = await createCoupons(traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session);
  let ageCategory = traveler.ageCategory;
  if (traveler.ageCategory.toLowerCase() === 'adt') {
    ageCategory = "ADULT";
  } else if (traveler.ageCategory.toLowerCase() === 'chd') {
    ageCategory = "CHILD";
  } else if (traveler.ageCategory.toLowerCase() === 'yth') {
    ageCategory = "YOUTH";
  }
  return {
    givenName: traveler.firstName,
    familyName: traveler.lastName,
    title: traveler.title,
    ageCategory: ageCategory,
    id: traveler.id,
    coupons: coups
  };
}

const updatePassengerCoupons = async (existingPassenger, traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session) => {
  const newCoupons = await createCoupons(traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session);
  existingPassenger.coupons.push(...newCoupons);
}

const createCoupons = async (traveler, flightIdsLinkedToJourneyElements, journey, requestOptions, session) => {
  const coups = [];

  for (let journeyElement of traveler.flightsInformation) {
    const flightId = flightIdsLinkedToJourneyElements[journeyElement.journeyElementId];
    const flightInformation = journey.data.dictionaries.flight[flightId];
    let boardingPassInformation = null;

    if (journeyElement.checkInStatus.toLowerCase() === 'accepted' && requestOptions.methodType.toLowerCase() === 'boardingpass') {
      boardingPassInformation = await api.fetchBoardingPassByJourneyElementId(session, traveler.journeyId, journeyElement.journeyElementId);
      boardingPassInformation = convertToCCBoardingPass(boardingPassInformation, journeyElement.journeyElementId);
    }

    coups.push(makeCouponObject(flightId, flightInformation, boardingPassInformation, journeyElement.checkInStatus, journeyElement.isCheckInInhibitedStatus, journeyElement.journeyElementId));
  }

  return coups;
}

module.exports = {
  createCoupons,
  updatePassengerCoupons,
  createPassengerObject,
  makeCouponObject,
  getJourneyElementsInformation,
  generateExistingDocument,
  generateRequiredDocuments,
  convertToCCBoardingPass
}