const { phoneMap } = require('./phoneMap.js');

exports.getCountryCode = (phoneExtension) => {
    const details = phoneMap.find((element) => element.dial_code === phoneExtension)
    if (!details) throw Error('Invalid country phone extension');
    return details.code;
}