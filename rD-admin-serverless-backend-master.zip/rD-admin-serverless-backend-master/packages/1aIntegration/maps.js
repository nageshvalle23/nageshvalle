const amadeusToamadeusMap = {
    "visa": {
        "name": {
            "visa": "name",
            "passport": "name",
            "personalDetails": "name"
        },
        "gender": {
            "visa": "gender",
            "passport": "gender",
            "personalDetails": "gender"
        },
        "birthDate": {
            "visa": "birthDate",
            "passport": "birthDate",
            "personalDetails": "birthDate"
        },
        "birthPlace": {
            "visa": "birthPlace",
            "passport": "birthPlace",
            "personalDetails": "birthPlace"
        },
        "nationalityCountryCode": {
            "visa": "nationalityCode",
            "personalDetails": "nationalityCode",
            "passport": "nationalityCode",
        },
        "number": {
            "visa": "number"
        },
        "expiryDate": {
            "visa": "expiryDate"
        },
        "effectiveDate": {
            "visa": "effectiveDate"
        },
        "issuanceDate": {
            "visa": "issuanceDate"
        },
        "issuanceCountry": {
            "visa": "issuanceCountryCode"
        }
    },
    "passport": {
        "name": {
            "passport": "name",
            "visa": "name",
            "personalDetails": "name"
        },
        "number": {
            "passport": "number"
        },
        "effectiveDate": {
            "passport": "effectiveDate"
        },
        "issuanceDate": {
            "passport": "issuanceDate"
        },
        "issuanceCountry": {
            "passport": "issuanceCountryCode"
        },
        "nationalityCountryCode": {
            "passport": "nationalityCode",
            "visa": "nationalityCode",
            "personalDetails": "nationalityCode"
        },
        "gender": {
            "passport": "gender",
            "visa": "gender",
            "personalDetails": "gender"
        },
        "birthDate": {
            "passport": "birthDate",
            "visa": "birthDate",
            "personalDetails": "birthDate"
        },
        "birthPlace": {
            "passport": "birthPlace",
            "visa": "birthPlace",
            "personalDetails": "birthPlace"
        },
        "expiryDate": {
            "passport": "expiryDate"
        }
    },
    "personalDetails": {
        "name": {
            "passport": "name",
            "visa": "name",
            "personalDetails": "name"
        },
        "birthDate": {
            "passport": "birthDate",
            "visa": "birthDate",
            "personalDetails": "birthDate"
        },
        "birthPlace": {
            "passport": "birthPlace",
            "visa": "birthPlace",
            "personalDetails": "birthPlace"
        },
        "gender": {
            "passport": "gender",
            "visa": "gender",
            "personalDetails": "gender"
        },
        "nationalityCountryCode": {
            "passport": "nationalityCode",
            "visa": "nationalityCode",
            "personalDetails": "nationalityCode"
        },
        "countryOfResidenceCode": {
            "passport": "countryOfResidenceCode",
            "homeAddress": "countryCode",
            "personalDetails": "countryOfResidenceCode"
        }
    },
    "homeAddress": {
        "lines": {
            "homeAddress": "lines"
        },
        "zipCode": {
            "homeAddress": "zipCode"
        },
        "countryCode": {
            "homeAddress": "countryCode",
            "personalDetails": "countryOfResidenceCode"
        },
        "cityName": {
            "homeAddress": "cityName"
        },
        "stateCode": {
            "homeAddress": "stateCode"
        },
        "postalBox": {
            "homeAddress": "postalBox"
        },
        "text": {
            "homeAddress": "text"
        }
    },
    "destinationAddress": {
        "lines": {
            "destinationAddress": "lines"
        },
        "zipCode": {
            "destinationAddress": "zipCode"
        },
        "countryCode": {
            "destinationAddress": "countryCode",
            "personalDetails": "countryOfResidenceCode"
        },
        "cityName": {
            "destinationAddress": "cityName"
        },
        "stateCode": {
            "destinationAddress": "stateCode"
        },
        "postalBox": {
            "destinationAddress": "postalBox"
        },
        "text": {
            "destinationAddress": "text"
        },
        // latest change based on what we observed nationalitycode is asked by 1a in destinationAddress
        "nationalityCountryCode": {
            "passport": "nationalityCode",
            "visa": "nationalityCode",
            "personalDetails": "nationalityCode"
        },
    },
    "emergencyContact": {
        "number": {
            "emergencyContact": "number"
        },
        "nationalityCountryCode": {
            "emergencyContact": "nationalityCode"
        },
        "countryPhoneExtension": {
            "emergencyContact": "countryCode"
        },
        "name": {
            "emergencyContact": "name"
        }
    }
}

const amadeusToCCDocumentMap = {
    //1a document
    // where we can find 1a document required fields from CC docs
    // 1a : cc 
    "passport": {
        "PASSPORT": {
            "number": "passportNumber",
            "gender": "gender",
            "nationalityCountryCode": "nationality",
            "birthDate": "dateOfBirth",
            "expiryDate": "expiryDate",
            "issuanceLocation": "countryOfIssue",
            "issuanceCountry": "countryOfIssue"
        }
    },
    "countryOfResidence": {
        "RESIDENT_ADDRESS": {
            "countryOfResidence": "countryOfResidence"
        }
    },
    "personalDetails": {
        "PASSPORT": {
            "gender": "gender",
            "birthDate": "dateOfBirth",
            "nationalityCountryCode": "nationality",
        },
        "RESIDENT_ADDRESS": {
            "countryOfResidenceCode": "countryOfResidence"
        }
    },
    "visa": {
        "VISA": {
            "number": "documentNumber",
            "expiryDate": "expiryDate",
            "issuanceLocation": "countryOfIssue",
            "issuanceCountry": "countryOfIssue"
        },
        "PASSPORT": {
            "gender": "gender",
            "birthDate": "dateOfBirth",
            "nationalityCountryCode": "nationality"
        },
        "RESIDENT_ADDRESS": {
            "countryOfResidenceCode": "countryOfResidence"
        }
    },
    "homeAddress": {
        "RESIDENT_ADDRESS": {
            "countryCode": "countryOfResidence"
        }
    },
    "destinationAddress": {
        "DESTINATION_ADDRESS": {
            "lines": "street",
            "zipCode": "postalCode",
            "countryCode": "country",
            "cityName": "city",
            "stateCode": "stateProv"
        }
    },
    "emergencyContact": {
        // for emergency contact its set to true for certain fields to mean that certain fields are supported by cc
        "EMERGENCY_CONTACT": {
            "number": "phone",
            "nationalityCountryCode": true,
            "countryCode": "countryCode",
            "countryPhoneExtension": "countryCode",
            "name": "name"
        }
    }
}


module.exports = {
    amadeusToamadeusMap,
    amadeusToCCDocumentMap
}