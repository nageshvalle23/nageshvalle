const api = require("./index");
const qs = require("qs");
const moment = require('moment-timezone');
const axios = require('axios');

// const prompt = require("prompt-sync")({ sigint: true });


const rloc = process.argv[2] || 'UFIVX9';
// const family = process.argv[3] || 'KUMAR';
const family = process.argv[3] || 'WOODS';
const given = process.argv[4] || 'DONG YUAN';
// const given = process.argv[4] || 'WAI YIN';
const checkinVal = process.argv[5] === "true";
const executeRegularAdapterService = true;
const executeTimeZoneConverter = false;


function generateRandomString(length) {
  var chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var result = "";
  for (var i = length; i > 0; --i) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

const lookup = {
  rloc: rloc,
  familyName: family,
  givenName: given,
  targetAirlineCode: "JL",
  requestingCarrier: "OG"
};

const passengerRequest = {
  familyName: family,
  givenName: given
}

const passengerRequests = [
  // {
  //   familyName: family,
  //   givenName: given,
  //   eTicketNumber: "1234567890"
  // },
  // {
  //   familyName: family,
  //   givenName: "JENIFFER",
  //   eTicketNumber: "1234567890"
  // },
  // {
  //   familyName: family,
  //   givenName: "SHIV",
  //   eTicketNumber: "1234567890"
  // },
  {
    "givenName": "MIGUEL",
    "familyName": "JONES",
    eTicketNumber: "0921221111"
  },
  {
    "givenName": "JOSE",
    "familyName": "JONES",
    "eTicketNumber": "0751413653030"
  },
  {
    "givenName": "LUIS",
    "familyName": "JONES",
    "eTicketNumber": "0751413653030"
  },
  // {
  //   familyName: "SMITHFOUR",
  //   givenName: "MIGUEL",
  //   eTicketNumber:"0921221911"
  // }
]

const document = [
  // {
  //   "type": "PASSPORT",
  //   "payload": {
  //     "givenName": given,
  //     "familyName": family,
  //     "dateOfBirth": "1955-01-25",
  //     "gender": "MALE",
  //     "passportNumber": generateRandomString(10),
  //     "expiryDate": "2032-01-25",
  //     "nationality": "USA",
  //     "countryOfIssue": "PAK"
  //   }
  // },
  {
    "type": "EMERGENCY_CONTACT",
    "payload": {
      "givenName": "HELEN1",
      "familyName": "SMITHTWO1",
      "phone": {
        "countryCode": "+44",
        "number": "89191911912"
      },
      "email": "mailto:abc@xyz1.com",
      "refused": false
    }
  }
  // {
  //   "type": "VISA",
  //   "payload": {
  //     "documentNumber": generateRandomString(10),
  //     "expiryDate": "2025-01-09",
  //     "countryOfIssue": "USA"
  //   }
  // }
  // {
  //   "type": "DESTINATION_ADDRESS",
  //   "payload": {
  //     "street": "123 Street whatever",
  //     "city": "Beijing",
  //     "stateProv": "CHN",
  //     "postalCode": "122345",
  //     "country": "CHN"
  //   }
  // },
]

const flightRequests = [
  {
    "flightNumber": "9802",
    "date": "2023-08-11",
    "carrierCode": "JL",
    "origin": "HND",
    "destination": "LHR"
  },
  {
    "flightNumber": "3175",
    "date": "2023-08-12",
    "carrierCode": "IB",
    "origin": "LHR",
    "destination": "MAD"
  }
]

const event = {
  queryStringParameters: lookup,
  body: JSON.stringify({
    passengerRequest,
    passengerRequests,
    flightRequests,
    document
  }),
  headers: {
    'x-cc-request-id': 123434
  }
};

if (executeRegularAdapterService) {
  const res = api.record(event, {}, (err, res) => {
    const body = JSON.parse(res.body);
    console.log('Status Code: ', res.statusCode);
    console.log(JSON.stringify(body, null, 2));
  }).then(() => { })
}



// ****************************************************** Code to fetch the acceptance windows

const API_URL = process.env.API_URL || "https://test.airlines.api.amadeus.com";
const apiCredentials = {
  AT: {
    clientId: process.env.AT_1A_CLIENT_ID,
    clientSecret: process.env.AT_1A_CLIENT_SECRET,
  },
  MH: {
    clientId: process.env.MH_1A_CLIENT_ID,
    clientSecret: process.env.MH_1A_CLIENT_SECRET,
  },
  UL: {
    clientId: process.env.UL_1A_CLIENT_ID,
    clientSecret: process.env.UL_1A_CLIENT_SECRET,
  },
  RJ: {
    clientId: process.env.RJ_1A_CLIENT_ID,
    clientSecret: process.env.RJ_CLIENT_SECRET,
  },
  JL: {
    clientId: process.env.JL_1A_CLIENT_ID,
    clientSecret: process.env.JL_1A_CLIENT_SECRET,
  },
  BA: {
    clientId: process.env.BA_1A_CLIENT_ID,
    clientSecret: process.env.BA_1A_CLIENT_SECRET,
  },
};

const getSession = async (targetCarrier) => {
  const payload = {
    client_secret: apiCredentials[targetCarrier].clientSecret,
    client_id: apiCredentials[targetCarrier].clientId,
    grant_type: "client_credentials",
  };
  const encodedPayload = qs.stringify(payload);
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v1/security/oauth2/token`,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    data: encodedPayload,
  });
  if (res.status === 200 && res.data) return res.data;
  else {
    console.log("get session function error");
    throw new Error("Error occured on axios call");
  }
}


const printTimeInIST = async (session) => {
  if ((!session || /.+/.test(session) === false) || (!lookup || /.+/.test(lookup) === false)) {
    throw new Error('Missing parameters');
  }
  const res = await axios({
    method: "POST",
    url: `${API_URL}/v2/checkin/journeys`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
    },
    data: {
      orderId: lookup.rloc,
      lastName: lookup.familyName,
    },
  });

  const journey = res.data;
  if (!journey.dictionaries) {
    console.log('No journeys found');
  }
  for (let journeyElement of Object.values(journey.dictionaries.journeyElement)) {
    const openingTime = journeyElement?.acceptanceEligibility?.eligibilityWindow?.openingDateAndTime;
    const closingTime = journeyElement?.acceptanceEligibility?.eligibilityWindow?.closingDateAndTime;
    const timeInISTOpening = moment(openingTime).tz('Asia/Kolkata').format('YYYY-MM-DD hh:mm A');
    const timeInISTClosing = moment(closingTime).tz('Asia/Kolkata').format('YYYY-MM-DD hh:mm A');
    console.log(`\nFlight ID - ${journeyElement.flightId} \n\t:: Opening Time - ${timeInISTOpening} \n\t:: Closing Time - ${timeInISTClosing}`);
  }
}


(async () => {
  if (executeTimeZoneConverter) printTimeInIST(await getSession(lookup.targetAirlineCode));
})();