require("dotenv").config();
const uuid = require("uuid").v1;
const api = require("./api");
const chalk = require("chalk");
const utils = require("./utils");
const helpers = require('./helpers');

const {
  generateRequiredDocuments,
  generateExistingDocument,
} = require("./converter");
const warmer = require("lambda-warmer");

const _handleErrors = require('./handleErrorsMethod');

const { params, body, response } =
  require("@oneworld-digital/integration-utils").request;
const { isV2Request, convertToV1Params, convertToV1Body, v1RecordToV2Record } =
  require("@oneworld-digital/integration-utils").versionConverter;

const documentUpdateHelpers = require('./helpers/documentUpdateHelpers');

const info = chalk.blue;
const error = chalk.bold.red;
const warning = chalk.yellow;
const ccResponseLogger = chalk.white;
const oneAResponseLogger = chalk.green;

const { createLogger } = require('./logger');
const eligibilityHelpers = require('./helpers/eligibilityHelpers');
const acceptanceHelpers = require('./helpers/acceptanceHelpers');
const boardingpassHelpers = require('./helpers/boardingPassHelpers');
const { grouper } = require('./helpers/groupPassengers');
const { store } = require('./store');
/* ASSUMPTIONS doc update and eligibility for 1a integration

1.)  ID Card & PSPT - If ID card is asked by 1A,  Adpater will update it using PSPT fields (if it exists). Assumption  PSPT == ID card. if PSPT does not exist, then SEE_AGENT to Client
2.)  Purpose Of visit is always sent as "Work" (if it is not present on the PNR)
3.) When Nationality Code is asked for Personal details by 1A, PSPT & Nationality code is sent by the Adapter  since CC does not have Nationality code outside of PSPT
4.) When CountryOfResidence is asked by 1A, Adpater sends CountrofResidence & HomeAddress.Countrofresidence
5.) If 1A ask for a document & same document is in StoredDetails a missing field (supported by CC), then this is not treated as a populated document  (in response to the Client). e.. Visa has name & document number, but 1A is asking for all VISA fields again. Then Adapter sends VISA as required document (i.e does not included it in populated documents since it is partially filled)

*/

exports.record = async (event, context, cb) => {
  try {
    console.log("In record");
    const isV2 = isV2Request(event);

    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    console.info("Record request body: ", JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId)

    let { givenName, familyName, rloc, targetAirlineCode, requestingCarrier } =
      isV2 ? convertToV1Params(body(event)) : params(event);

    const lookup = { givenName, familyName, rloc, targetAirlineCode };

    console.log("found lookups", lookup, 'transaction id --> ', store.transactionId);
    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const session = await api.getSession(targetAirlineCode);
    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    const journey = await api.searchCustomer(session, lookup);
    console.log(info("Fetched journey successfully"), 'transaction id --> ', store.transactionId);
    // const isCheckedIn = journey.data.data[0].acceptance.isAccepted; //returns pax checkin status

    createLogger(journey);

    // * refactored code.
    let flightIdsLinkedToJourneyElements = utils.fetchFlightsIdFromJourneyElement(journey.data.dictionaries);

    // * refactored code
    const travelersInAllJourneys = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);

    // * Refactored code.
    const passengers = await utils.generatePassengersObjectForCCResponse(session,
      travelersInAllJourneys,
      flightIdsLinkedToJourneyElements,
      journey, { methodType: 'record', travelerId: null }
    );
    const flights = utils.generateCCFlightsObject(journey.data);


    let record = {
      pnr: {
        rloc: rloc,
        passengers: passengers,
        flights: flights
      }
    };

    // console.log('record response', JSON.stringify(record), 'transaction id --> ', store.transactionId);
    if (isV2) {
    }
    console.log(ccResponseLogger('record response', JSON.stringify(record, null, 2)), 'transaction id --> ', store.transactionId);
    return cb(null, response(200, record));
  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    // console.log(error(err), 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
};

// single eligibility
exports.eligibility = async (event, context, cb) => {
  try {
    console.log("In eligibility");
    const isV2 = isV2Request(event);

    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];


    console.info("Eligibility request body: ", JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);

    let {
      givenName, familyName, rloc,
      //passengerRequest,
      requestingCarrier,
      targetAirlineCode,
    } = isV2 ? convertToV1Params(body(event)) : params(event);

    const lookup = { givenName, familyName, rloc, targetAirlineCode };

    console.log("found lookups", lookup, 'transaction id --> ', store.transactionId);

    let flightLookups = body(event).flightRequests;
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);

    const passengerRequest = body(event).passengerRequest;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const session = await api.getSession(targetAirlineCode);

    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    let journey = await api.searchCustomer(session, lookup);
    console.log(info("Fetched journey successfully"), 'transaction id --> ', store.transactionId);

    createLogger(journey);


    const modified = utils.filterValidJourneysForEligibility(journey, flightLookups);
    journey = modified.journeysResponse;
    // const isPartial = modified.journeyDeleted;
    const isMisMatch = modified.journeyMismatchOccured;

    console.log(info("Journey modified successfully"), 'transaction id --> ', store.transactionId);
    console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

    if (isMisMatch || utils.targetCarrierDoesNotMatchJourneysFirstFlight(journey.data.data,targetAirlineCode)) {
      return utils.returnJourneyMismatchError(cb);
    }



    const passengerGivenName = passengerRequest.givenName;
    let passengerFamilyName=passengerRequest.familyName

    const travelerInformation = utils.fetchTravelerIdsInAllJourneys(journey.data.data, passengerGivenName,passengerFamilyName);

    console.log(`Traveler Information = ${JSON.stringify(travelerInformation)}`, 'transaction id --> ', store.transactionId);

    if (travelerInformation.length === 0) throw new Error('Invalid traveler name');

    const eligibilityResponses = [];

    const eligibilityCCResponse = {
      requiredDocuments: [],
      populatedDocuments: []
    }
    //check if there are more than one journey
    if (travelerInformation.length > 1) {

      const requiredFieldsOfAllEligibilities = [];
      for (let journeyNode of travelerInformation) {

        const { travelerId, journeyId } = journeyNode;
        let eligibilityResponse = await api.fetchRequiredDocuments(
          session,
          travelerId,
          journeyId
        );
        console.log('Eligibility for Journey Id = ', journeyId, 'transaction id --> ', store.transactionId);

        const resourcesForStoredDetails = eligibilityHelpers.getAllPopulatedDocuments(
          [eligibilityResponse.data.data],
          { firstName: passengerGivenName , lastName: familyName }
        )

        const globalStore = eligibilityHelpers.handleNamePropertyInsideGlobalStore(resourcesForStoredDetails);

        console.log(`Retreived global store =  ${JSON.stringify(globalStore)}`, 'transaction id --> ', store.transactionId);

        console.log('---- Document Updation inside Eligibility (POST requirements) -----', 'transaction id --> ', store.transactionId);

        // for (eachEligibilityResponse of eligibilityResponses) {


        console.log(`Eligibility Response for ${journeyId} = ${JSON.stringify(eligibilityResponse.data)}`, 'transaction id --> ', store.transactionId);

        console.info('----Start Recursion doc update inside eligibility ---- ', 'transaction id --> ', store.transactionId);

        eligibilityResponse = await documentUpdateHelpers.recursivelyUpdateWithExistingInformation(session, globalStore, journeyId, travelerId, eligibilityResponse);

        console.info('----- End of recursion -----', 'transaction id --> ', store.transactionId);

        createLogger(eligibilityResponse);

        eligibilityResponses.push(eligibilityResponse);
        const requiredFieldsForEachDoc = eligibilityHelpers.getAllMissingDocumentsPerJourney(eligibilityResponse.data.data);
        requiredFieldsOfAllEligibilities.push(requiredFieldsForEachDoc)
      }

      //Get populated documents
      for (let eligibilityResponse of eligibilityResponses) {
        eligibilityCCResponse.populatedDocuments.push(eligibilityHelpers.convertExistingDocumentsToCarrierConnectLevel(eligibilityResponse));
      }

      eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.flat(Infinity);
      eligibilityCCResponse.populatedDocuments = Array.from(new Set(eligibilityCCResponse.populatedDocuments));

      // checking if all the eligibility responses dont have anything required
      const isCleared = requiredFieldsOfAllEligibilities.every((requriedFieldsForEachEligibility) => requriedFieldsForEachEligibility.length == 0);
      if (!isCleared) {
        eligibilityCCResponse.requiredDocuments.push('SEE_AGENT');
      }
      console.log(ccResponseLogger('eligibility response = ', JSON.stringify(eligibilityCCResponse, null, 2)), 'transaction id --> ', store.transactionId);
      return cb(null, response(200, eligibilityCCResponse));
    }
    // when there is single journey
    const { journeyId, travelerId } = travelerInformation[0];

    let eligibilityResponse = await api.fetchRequiredDocuments(
      session,
      travelerId,
      journeyId
    );

    console.log(`Eligibility response for ${journeyId}`, 'transaction id --> ', store.transactionId);

    createLogger(eligibilityResponse);

    const resourcesForStoredDetails = eligibilityHelpers.getAllPopulatedDocuments(
      [eligibilityResponse.data.data],
      { firstName: passengerGivenName , lastName: familyName }
    )

    const globalStore = eligibilityHelpers.handleNamePropertyInsideGlobalStore(resourcesForStoredDetails);

    console.log(`Retreived global store =  ${JSON.stringify(globalStore)}`, 'transaction id --> ', store.transactionId);

    console.log('---- Document Updation inside Eligibility (POST requirements) -----', 'transaction id --> ', store.transactionId);

    // for (eachEligibilityResponse of eligibilityResponses) {


    console.log(`Eligibility Response for ${journeyId} = ${JSON.stringify(eligibilityResponse.data)}`, 'transaction id --> ', store.transactionId);

    console.info('----Start Recursion doc update inside eligibility ---- ', 'transaction id --> ', store.transactionId);

    eligibilityResponse = await documentUpdateHelpers.recursivelyUpdateWithExistingInformation(session, globalStore, journeyId, travelerId, eligibilityResponse);

    console.info('----- End of recursion -----', 'transaction id --> ', store.transactionId);

    createLogger(eligibilityResponse);

    let ccRequiredDocuments = eligibilityHelpers.convertToCCRequiredDocuments(eligibilityResponse, globalStore, firstName = passengerGivenName , lastName = familyName);

    eligibilityCCResponse.populatedDocuments.push(eligibilityHelpers.convertExistingDocumentsToCarrierConnectLevel(eligibilityResponse));
    eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.flat(Infinity);
    eligibilityCCResponse.populatedDocuments = Array.from(new Set(eligibilityCCResponse.populatedDocuments));

    ccRequiredDocuments = ccRequiredDocuments.flat(Infinity);
    eligibilityCCResponse.requiredDocuments = Array.from(new Set(ccRequiredDocuments));

    eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.filter((element) => (!eligibilityCCResponse.requiredDocuments.includes(element)))

    console.log(ccResponseLogger('eligibility response', JSON.stringify(eligibilityCCResponse, null, 2)), 'transaction id --> ', store.transactionId);
    return cb(null, response(200, eligibilityCCResponse));


  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
};

const nameMatchConfig = {
  AT: {
    exactNameMatchForRecord: false//process.env.AT_1A_IS_EXACT_NAME_MATCH
  },
  MH: {
    exactNameMatchForRecord: false//process.env.MH_1A_IS_EXACT_NAME_MATCH
  },
  UL: {
    exactNameMatchForRecord: false//process.env.UL_1A_IS_EXACT_NAME_MATCH
  },
  RJ: {
    exactNameMatchForRecord: false//process.env.RJ_1A_IS_EXACT_NAME_MATCH
  },
  JL: {
    exactNameMatchForRecord: false//process.env.JL_1A_IS_EXACT_NAME_MATCH
  },
  BA: {
    exactNameMatchForRecord: false//process.env.BA_1A_IS_EXACT_NAME_MATCH
  },
};

// multi eligibility
// ? should we follow camel case naming convention here? Ib didnt follow
exports.multieligibility = async (event, context, cb) => {
  try {
    console.log("In multieligibility");
    const isV2 = isV2Request(event);

    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    console.info("Eligibility request body: ", JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);

    let {
      givenName, familyName, rloc,
      //passengerRequests,
      requestingCarrier,
      targetAirlineCode,
    } = isV2 ? convertToV1Params(body(event)) : params(event);

    const lookup = { givenName, familyName, rloc, targetAirlineCode };

    // console.log("found lookups", lookup, 'transaction id --> ', store.transactionId);

    const passengerRequests = body(event).passengerRequests;


    let flightLookups = body(event).flightRequests;
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const session = await api.getSession(targetAirlineCode);

    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    let isExactNameMatch = nameMatchConfig[lookup.targetAirlineCode].exactNameMatchForRecord;

    let journey;

    if (isExactNameMatch) {
      const isSameSurname = passengerRequests.every((element, index) => (element.familyName == familyName));
      if (isSameSurname) journey = await api.searchCustomer(session, lookup);

    } else {
      //if carrier does not use exact name match for record lookup , then it returns all pax in search customer
      //no need for separate lookups per surname
      journey = await api.searchCustomer(session, lookup);
    }

    // const isSameSurname = passengerRequests.every((element, index) => (element.familyName == familyName));
    // if (isSameSurname) journey = await api.searchCustomer(session, lookup);
    let ccMultiEligibilityResponse = [];

    for (let eachPax of passengerRequests) {
      const { givenName, familyName, eTicketNumber } = eachPax;


      if (isExactNameMatch) {
        if (!isSameSurname) journey = await api.searchCustomer(session, { rloc, familyName });
      }


      console.info(`------------- Eligibility for passenger ${givenName} ----------`, 'transaction id --> ', store.transactionId);
      console.log(info("Fetched journey successfully"), 'transaction id --> ', store.transactionId);

      createLogger(journey);

      const modified = utils.filterValidJourneysForEligibility(journey, flightLookups);
      journey = modified.journeysResponse;
      // const isPartial = modified.journeyDeleted;
      const isMisMatch = modified.journeyMismatchOccured;

      console.log(info("Journey modified successfully"), 'transaction id --> ', store.transactionId);
      console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

      if (isMisMatch || utils.targetCarrierDoesNotMatchJourneysFirstFlight(journey.data.data,targetAirlineCode)) {
        return utils.returnJourneyMismatchError(cb);
      }

      const passengerGivenName = givenName;
      let passengerFamilyName=familyName

      const travelerInformation = utils.fetchTravelerIdsInAllJourneys(journey.data.data, passengerGivenName,passengerFamilyName);

      console.log(`Traveler Information = ${JSON.stringify(travelerInformation)}`, 'transaction id --> ', store.transactionId);

      if (travelerInformation.length === 0) throw new Error('Invalid traveler name');

      const eligibilityResponses = [];

      //check if there are more than one journey
      if (travelerInformation.length > 1) {

        const requiredFieldsOfAllEligibilities = [];
        for (let journeyNode of travelerInformation) {

          const { travelerId, journeyId } = journeyNode;
          let eligibilityResponse = await api.fetchRequiredDocuments(
            session,
            travelerId,
            journeyId
          );
          console.log('1A Eligibility Response for = ', journeyId, 'transaction id --> ', store.transactionId);
          createLogger(eligibilityResponse);
          const resourcesForStoredDetails = eligibilityHelpers.getAllPopulatedDocuments(
            [eligibilityResponse.data.data],
            { firstName: passengerGivenName , lastName: familyName }
          )

          const globalStore = eligibilityHelpers.handleNamePropertyInsideGlobalStore(resourcesForStoredDetails);

          console.log(`Retreived global store =  ${JSON.stringify(globalStore)}`, 'transaction id --> ', store.transactionId);

          console.log('---- Document Updation inside Eligibility (POST requirements) -----', 'transaction id --> ', store.transactionId);

          console.info('----Start Recursion doc update inside eligibility ---- ', 'transaction id --> ', store.transactionId);

          eligibilityResponse = await documentUpdateHelpers.recursivelyUpdateWithExistingInformation(session, globalStore, journeyId, travelerId, eligibilityResponse);

          console.info('----- End of recursion -----', 'transaction id --> ', store.transactionId);

          console.log('---- Final Eligibility Response after recursion ----- ', 'transaction id --> ', store.transactionId);

          createLogger(eligibilityResponse)

          eligibilityResponses.push(eligibilityResponse);
          const requiredFieldsForEachDoc = eligibilityHelpers.getAllMissingDocumentsPerJourney(eligibilityResponse.data.data);
          requiredFieldsOfAllEligibilities.push(requiredFieldsForEachDoc)
        }

        const eligibilityCCResponse = {
          eTicketNumber,
          givenName,
          familyName,
          requiredDocuments: [],
          populatedDocuments: []
        }

        //Get populated documents
        //Get populated documents
        for (let eligibilityResponse of eligibilityResponses) {
          eligibilityCCResponse.populatedDocuments.push(eligibilityHelpers.convertExistingDocumentsToCarrierConnectLevel(eligibilityResponse));
        }

        eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.flat(Infinity);
        eligibilityCCResponse.populatedDocuments = Array.from(new Set(eligibilityCCResponse.populatedDocuments));

        // checking if all the eligibility responses dont have anything required
        const isCleared = requiredFieldsOfAllEligibilities.every((requriedFieldsForEachEligibility) => requriedFieldsForEachEligibility.length == 0);

        //If docs are required for any journey, we throw a "see agent" since CC cannot specify to which journey docs belong
        if (!isCleared) eligibilityCCResponse.requiredDocuments.push('SEE_AGENT');

        console.log(ccResponseLogger('eligibility response = ', JSON.stringify(eligibilityCCResponse, null, 2)), 'transaction id --> ', store.transactionId);

        ccMultiEligibilityResponse.push(eligibilityCCResponse);
      }
      else {
        // when there is single journey
        const { journeyId, travelerId } = travelerInformation[0];

        let eligibilityResponse = await api.fetchRequiredDocuments(
          session,
          travelerId,
          journeyId
        );

        console.log(`Eligibility response for ${journeyId}`, 'transaction id --> ', store.transactionId);

        createLogger(eligibilityResponse);

        const resourcesForStoredDetails = eligibilityHelpers.getAllPopulatedDocuments(
          [eligibilityResponse.data.data],
          { firstName: passengerGivenName , lastName: familyName }
        )

        const globalStore = eligibilityHelpers.handleNamePropertyInsideGlobalStore(resourcesForStoredDetails);

        console.log(`Retreived global store =  ${JSON.stringify(globalStore)}`, 'transaction id --> ', store.transactionId);

        console.log('---- Document Updation inside Eligibility (POST requirements) -----', 'transaction id --> ', store.transactionId);

        console.log(`Eligibility Response for ${journeyId} = ${JSON.stringify(eligibilityResponse.data)}`, 'transaction id --> ', store.transactionId);

        console.info('----Start Recursion doc update inside eligibility ---- ', 'transaction id --> ', store.transactionId);

        eligibilityResponse = await documentUpdateHelpers.recursivelyUpdateWithExistingInformation(session, globalStore, journeyId, travelerId, eligibilityResponse);

        console.info('----- End of recursion -----', 'transaction id --> ', store.transactionId);

        createLogger(eligibilityResponse);

        const eligibilityCCResponse = {
          eTicketNumber,
          givenName,
          familyName,
          requiredDocuments: [],
          populatedDocuments: []
        }

        let ccRequiredDocuments = eligibilityHelpers.convertToCCRequiredDocuments(eligibilityResponse, globalStore, firstName = passengerGivenName , lastName = familyName);

        eligibilityCCResponse.populatedDocuments.push(eligibilityHelpers.convertExistingDocumentsToCarrierConnectLevel(eligibilityResponse));
        eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.flat(Infinity);
        eligibilityCCResponse.populatedDocuments = Array.from(new Set(eligibilityCCResponse.populatedDocuments));

        ccRequiredDocuments = ccRequiredDocuments.flat(Infinity);
        eligibilityCCResponse.requiredDocuments = Array.from(new Set(ccRequiredDocuments));

        eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.filter((element) => (!eligibilityCCResponse.requiredDocuments.includes(element)))

        ccMultiEligibilityResponse.push(eligibilityCCResponse);
      }
    }

    console.log(ccResponseLogger('multi eligibility response', JSON.stringify(ccMultiEligibilityResponse, null, 2)), 'transaction id --> ', store.transactionId);
    return cb(null, response(200, ccMultiEligibilityResponse));

  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
}

// document update
exports.documentsupdate = async (event, context, cb) => {
  try {
    console.log("In documentsupdate");
    const isV2 = isV2Request(event);

    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    let {
      givenName, familyName, rloc, requestingCarrier,
      targetAirlineCode,
    } = isV2 ? convertToV1Params(body(event)) : params(event);



    console.log('CC Document request', JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);

    let document = body(event).document;
    let passengerRequest = body(event).passengerRequest;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const lookup = { givenName, familyName, rloc, targetAirlineCode };

    console.log('found lookups: ', lookup, 'transaction id --> ', store.transactionId);

    let flightLookups = body(event).flightRequests;
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);

    const passengerGivenName = passengerRequest.givenName;
    let passengerFamilyName=passengerRequest.familyName

    const session = await api.getSession(targetAirlineCode);

    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    let journey = (await api.searchCustomer(session, lookup));

    createLogger(journey)

    console.log(info("Fetched journey successfully"), 'transaction id --> ', store.transactionId);


    const modified = utils.filterValidJourneysForEligibility(journey, flightLookups);
    journey = modified.journeysResponse;
    // const isPartial = modified.journeyDeleted;
    const isMisMatch = modified.journeyMismatchOccured;

    console.log(info("Journey modified successfully"), 'transaction id --> ', store.transactionId);
    console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

    if (isMisMatch) {
      return utils.returnJourneyMismatchError(cb);
    }

    // Contains firstname, journeyid, travelerid
    const travelerInformation = utils.fetchTravelerIdsInAllJourneys(journey.data.data, passengerGivenName,passengerFamilyName);    // const travelerInformation = journey.data

    console.log(JSON.stringify(travelerInformation), '= traveler information', 'transaction id --> ', store.transactionId);

    const eligibilityCCResponse = {
      requiredDocuments: [],
      populatedDocuments: []
    };

    if (travelerInformation.length === 0) throw new Error('Invalid traveler name');
    //check if there are more than one journey
    if (travelerInformation.length > 1) {

      const requiredFieldsOfAllEligibilities = [];
      for (let journeyNode of travelerInformation) {

        const { travelerId, journeyId } = journeyNode;
        const eligibilityResponse = await api.fetchRequiredDocuments(
          session,
          travelerId,
          journeyId
        );

        eligibilityResponses.push(eligibilityResponse);
        const requiredFieldsForEachDoc = eligibilityHelpers.getAllMissingDocumentsPerJourney(eligibilityResponse.data.data);
        requiredFieldsOfAllEligibilities.push(requiredFieldsForEachDoc)
      }

      //Get populated documents
      for (let eligibilityResponse of eligibilityResponses) {
        eligibilityCCResponse.populatedDocuments.push(eligibilityHelpers.convertExistingDocumentsToCarrierConnectLevel(eligibilityResponse));
      }

      eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.flat(Infinity);
      eligibilityCCResponse.populatedDocuments = Array.from(new Set(eligibilityCCResponse.populatedDocuments));

      // checking if all the eligibility responses dont have anything required
      const isCleared = requiredFieldsOfAllEligibilities.every((requriedFieldsForEachEligibility) => requriedFieldsForEachEligibility.length == 0);
      if (!isCleared) {
        eligibilityCCResponse.requiredDocuments.push('SEE_AGENT');
      }
      console.log(ccResponseLogger('eligibility response = ', JSON.stringify(eligibilityCCResponse, null, 2)), 'transaction id --> ', store.transactionId);
      return cb(null, response(200, eligibilityCCResponse));
    }
    let ccRequiredDocumentsCombined = [];


    console.info('------- UPDATE DOCS ------- ', 'transaction id --> ', store.transactionId);

    // for (journeyNode of travelerInformation) {
    const { travelerId, journeyId } = travelerInformation[0];
    // here we pass 1a eligibility response in order to check requirements for each journey
    const requestToBeSentTo1A = await documentUpdateHelpers.handleDocument(
      document, lookup
    );

    console.log(`Document update request for journey ID : ${journeyId} = ${JSON.stringify(requestToBeSentTo1A)}`, 'transaction id --> ', store.transactionId);

    // checking to see if the request to 1a is empty or not
    // we update here
    let documentUpdateResponse = await api.updateDocs(session, requestToBeSentTo1A, journeyId, travelerId);

    console.log(`1a document update response for journey ${journeyId}`, 'transaction id --> ', store.transactionId);

    createLogger(documentUpdateResponse);

    // ccRequiredDocumentsCombined.push(ccRequiredDocuments);

    // This part here is for our logging to see the eligibility response after doc update:
    // const eligibilityResponse_post_update = await api.fetchRequiredDocuments(
    //   session,
    //   travelerId,
    //   journeyId
    // );

    // console.log(`--- Testing Eligibility second time for journey ID --- : ${journeyId}`, 'transaction id --> ', store.transactionId);

    // createLogger(eligibilityResponse_post_update);



    // Create new global store based on the finalizedEligibilityResponses
    console.info('---- Creating new global store based off finalized doc update responses ---- ', 'transaction id --> ', store.transactionId);

    let resourcesForStoredDetails_post_update = eligibilityHelpers.getAllPopulatedDocuments(
      [documentUpdateResponse.data.data],
      { firstName: passengerGivenName , lastName: familyName }
    )

    let globalStore_post_update = eligibilityHelpers.handleNamePropertyInsideGlobalStore(resourcesForStoredDetails_post_update);

    console.log('Global store post updation = ', globalStore_post_update, 'transaction id --> ', store.transactionId);

    // Creating cc required documents based on each finalized eligibility

    const ccRequiredDocuments = eligibilityHelpers.convertToCCRequiredDocuments(documentUpdateResponse, globalStore_post_update, firstName = passengerGivenName , lastName = familyName);
    ccRequiredDocumentsCombined.push(ccRequiredDocuments);





    eligibilityCCResponse.populatedDocuments.push(eligibilityHelpers.convertExistingDocumentsToCarrierConnectLevel(documentUpdateResponse));

    eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.flat(Infinity);
    eligibilityCCResponse.populatedDocuments = Array.from(new Set(eligibilityCCResponse.populatedDocuments));

    ccRequiredDocumentsCombined = ccRequiredDocumentsCombined.flat(Infinity);
    eligibilityCCResponse.requiredDocuments = Array.from(new Set(ccRequiredDocumentsCombined));

    eligibilityCCResponse.populatedDocuments = eligibilityCCResponse.populatedDocuments.filter((element) => (!eligibilityCCResponse.requiredDocuments.includes(element)))

    console.log(ccResponseLogger('doc update response', JSON.stringify(eligibilityCCResponse, null, 2)), 'transaction id --> ', store.transactionId);
    return cb(null, response(200, eligibilityCCResponse));


  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
};


exports.singleAcceptance = async (event, context, cb) => {
  try {
    console.log("In singleAcceptance");
    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    console.log('Single acceptance request body', JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);

    const isV2 = isV2Request(event);
    let {
      givenName, familyName, rloc,
      // passengerRequest,
      requestingCarrier,
      targetAirlineCode,
    } = isV2 ? convertToV1Params(body(event)) : params(event);
    // we need to do acceptance for passenger request.
    const lookup = { givenName, familyName, rloc, targetAirlineCode };
    let passengerRequest = body(event).passengerRequest;
    console.log("found passenger lookups", lookup, 'transaction id --> ', store.transactionId);

    let flightLookups = body(event).flightRequests;
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const session = await api.getSession(targetAirlineCode);
    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    let journey = await api.searchCustomer(session, lookup);
    console.log(info("Journey fetched successfully"), 'transaction id --> ', store.transactionId);
    // createLogger(journey);

    const acceptancePassengerGivenName = passengerRequest.givenName;
    let acceptancePassengerFamilyName=passengerRequest.familyName
    let travelerID = utils.fetchTravelerIdsInAllJourneys(journey.data.data, acceptancePassengerGivenName,acceptancePassengerFamilyName)
    if (!(travelerID.length > 0 && travelerID[0].travelerId)) throw new Error('Invalid name');
    travelerID = travelerID[0].travelerId;

    const modified = utils.filterValidJourneys(journey, flightLookups, [travelerID]);

    journey = modified.journeysResponse;
    const isPartial = modified.journeyDeleted;

    console.log(info("Journey modified successfully"), 'transaction id --> ', store.transactionId);
    console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

    if (utils.targetCarrierDoesNotMatchJourneysFirstFlight(journey.data.data,targetAirlineCode)) {
      console.log(info("Journey.FirstFlight CarrierCode does not match Target Airline CarrierCode"), 'transaction id --> ', store.transactionId);
      return utils.returnJourneyMismatchError(cb);
    }





    let checkedInJourneyElementsBeforeCheckIn = [];
    let notCheckedInJourneyElementsBeforeCheckIn = [];
    let checkedInJourneyElementsAfterCheckIn = [];
    let notCheckedInJourneyElementsAfterCheckIn = [];
    // retrieves traveler ids in all journeys
    // ? assumption: traveler id is same in all journeys (checked with a single pnr they sent)




    // check if the traveler is acceptance eligible
    // if in-eligible, we throw back travelerId, reasons, flight ID
    const acceptanceInEligibilityErrors = acceptanceHelpers.checkIfAcceptanceInEligible(journey.data.dictionaries, [travelerID]);

    // check if we have ticket problem as the only ineligibility reason! if yes then do check-in
    const eligibleToMakePostCall = acceptanceHelpers.allowedToExecutePostAcceptance(acceptanceInEligibilityErrors);

    // acceptanceInEligibilityErrors.length > 0 (initial condition)
    if (!eligibleToMakePostCall) {
      console.log('Not executing POST acceptance because customer has ineligible reason(s)', 'transaction id --> ', store.transactionId);
      const err = {
        id: uuid(),
        CARRIER_ERROR_CODE: 500,
        CARRIER_ERROR_MESSAGE: this.serializeObjectToXML({
          id: uuid(),
          message: acceptanceInEligibilityErrors,
          code: 500
        })
      }
      return _handleErrors(err, cb);
    }

    // const travelersInformation = await utils.fetchTravelersInAllJourneys(session, journey.data.data, null);
    const travelersInformation = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);

    // this variable below is not used anywhere. Clean up this
    const beforeCheckInOperations = await acceptanceHelpers.deleteNotRequiredTravelersFromJourneyAndCheckInStatus(session, travelersInformation, [travelerID]);
    // checkedInJourneyElementsBeforeCheckIn.push(beforeCheckInOperations.checkedInJourneyElements);
    // notCheckedInJourneyElementsBeforeCheckIn.push(beforeCheckInOperations.notCheckedInJourneyElements);
    const checkInStatuses = acceptanceHelpers.fetchCheckedInJourneyElementsForTravelers(journey.data.dictionaries, [travelerID]);
    checkedInJourneyElementsBeforeCheckIn.push(checkInStatuses.checkedInJourneyElements);
    notCheckedInJourneyElementsBeforeCheckIn.push(checkInStatuses.notCheckedInJourneyElements);

    const { acceptanceResponses, checkedInJourneyElements, notCheckedInJourneyElements } = await acceptanceHelpers.checkInTravelerIntoJourneys(session, travelersInformation);
    checkedInJourneyElementsAfterCheckIn.push(checkedInJourneyElements);
    notCheckedInJourneyElementsAfterCheckIn.push(notCheckedInJourneyElements);

    const { status } = acceptanceHelpers.fetchStatusConditions(checkedInJourneyElementsBeforeCheckIn, notCheckedInJourneyElementsBeforeCheckIn, checkedInJourneyElementsAfterCheckIn, notCheckedInJourneyElementsAfterCheckIn);
    if (status === 500) {
      const err = helpers.handleAcceptanceErrors(acceptanceResponses)
      // return _handleErrors(err, cb);
      return _handleErrors({ CARRIER_ERROR_MESSAGE: utils.serializeObjectToXML({ postAcceptanceError: err.CARRIER_ERROR_MESSAGE, acceptanceInEligibilityErrors: acceptanceInEligibilityErrors }), CARRIER_ERROR_CODE: err.CARRIER_ERROR_CODE }, cb);
    }

    // Create a new journey here
    // do not make another search customer call
    // journey = await api.searchCustomer(session, lookup);
    // console.log(JSON.stringify(acceptanceResponses, null, 2), 'transaction id --> ', store.transactionId);
    let flightIdsLinkedToJourneyElements = utils.fetchFlightsIdFromJourneyElement(journey.data.dictionaries);
    // const travelersInAllJourneys = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);
    const updatedTravelersInAllJourneys = utils.updateJourneyElementsCheckinStatuses(checkedInJourneyElements, travelersInformation);

    const passengers = await utils.generatePassengersObjectForCCResponse(
      session,
      updatedTravelersInAllJourneys,
      flightIdsLinkedToJourneyElements,
      journey,
      { methodType: 'singleAcceptance', travelerId: travelerID }
    );
    const flights = utils.generateCCFlightsObject(journey.data).flat(Infinity);

    let acceptanceCCResponse = {
      pnr: {
        rloc: rloc,
        passengers: passengers,
        flights: flights
      }
    };

    console.log(ccResponseLogger('single acceptance response', JSON.stringify(acceptanceCCResponse, null, 2)), 'transaction id --> ', store.transactionId);

    return cb(null, response(isPartial ? 206 : status, acceptanceCCResponse));
  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
}

exports.multiAcceptance = async (event, context, cb) => {
  try {
    console.log("In multiAcceptance");
    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    console.log('Multi acceptance request body', JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);

    const isV2 = isV2Request(event);
    let {
      givenName, familyName, rloc,
      // passengerRequest,
      requestingCarrier,
      targetAirlineCode,
    } = isV2 ? convertToV1Params(body(event)) : params(event);
    // we need to do acceptance for passenger request.
    const lookup = { givenName, familyName, rloc, targetAirlineCode };
    let passengerRequests = body(event).passengerRequests;
    console.log("found passenger lookups", lookup, 'transaction id --> ', store.transactionId);

    let flightLookups = body(event).flightRequests;
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const session = await api.getSession(targetAirlineCode);
    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    let passengers = [];
    let flights = [];

    let mainStatus = 200;
    const responseStore = [];

    // if we get the final status as 500... we will throw back inEligibility reasons from journey elements
    // in search customer call and also throw back post-acceptance api errors
    let targetErrorCode = null, targetErrorMessages = [], groupedAcceptanceInEligibilityErrors = [];
    let isPartialCheckin = false;


    //* this is an old method which is not used currently
    // const groupedPassengerRequests = utils.groupByFamilyName(passengerRequests, lookup);

    // * this is the new method which does efficient grouping of pax in family requests.
    const groupedPassengerRequests = await grouper(lookup, passengerRequests, session);

    for (let passengerRequests of groupedPassengerRequests) {
      // const { passengers: paxInfo, flights: flightsInfo, errorFound, err, acceptanceInEligibilityErrors, isPartial } = await acceptanceHelpers.acceptanceSubRoutine(session, { familyName: passengerRequests[0].familyName, givenName: "anything works", rloc }, passengerRequests, flightLookups);
      const { passengers: paxInfo, flights: flightsInfo, errorFound, err, acceptanceInEligibilityErrors, isPartial, isMisMatch } = await acceptanceHelpers.acceptanceSubRoutine(session, passengerRequests[0].identificationResponse, passengerRequests, flightLookups,targetAirlineCode);
      if(isMisMatch) return utils.returnJourneyMismatchError(cb);
      if (isPartial) isPartialCheckin = true;
      if (acceptanceInEligibilityErrors.length > 0) {
        groupedAcceptanceInEligibilityErrors.push(acceptanceInEligibilityErrors);
      }
      responseStore.push({ errorFound, err });
      if (errorFound) {
        targetErrorMessages.push(err.CARRIER_ERROR_MESSAGE);
        if (!targetErrorCode) targetErrorCode = err.CARRIER_ERROR_CODE; // we keep track of only first target error code.
      }
      passengers.push(paxInfo);
      if (flights.length === 0) flights.push(flightsInfo);
    }
    groupedAcceptanceInEligibilityErrors = groupedAcceptanceInEligibilityErrors.flat(Infinity);
    passengers = passengers.flat(Infinity)
    // for multi-acceptance service....we dont need to worry about checked-in and not checked-in journey elements. All you need to do is create pax object
    let checkinStatusesOfPassengers = [];
    for (let pax of passengers) {
      if (pax.coupons) {
        const checkedInForAllSegments = acceptanceHelpers.fetchPassengerCheckinStatus(pax, 'full');
        const checkedInForSomeSegments = acceptanceHelpers.fetchPassengerCheckinStatus(pax, 'partial');
        const checkedInForNoSegments = acceptanceHelpers.fetchPassengerCheckinStatus(pax, 'none');
        if (checkedInForAllSegments) checkinStatusesOfPassengers.push('full');
        else if (checkedInForSomeSegments) checkinStatusesOfPassengers.push('partial');
        else if (checkedInForNoSegments) checkinStatusesOfPassengers.push('none');
      }
    }
    if (!checkinStatusesOfPassengers.every(elem => elem === 'full')) {
      if (checkinStatusesOfPassengers.some(elem => elem === 'full')) {
        mainStatus = 206;
      } else {
        mainStatus = 500; // at this point we assume we have errors in targetErrorMessages array
      }
    }

    if (isPartialCheckin && mainStatus !== 500) mainStatus = 206;

    // the code should work perfectly even if we do not keep the below statement.
    // the condition is handled perfectly in the above if/else blocks. I kept it here for better understanding
    if (checkinStatusesOfPassengers.every(elem => elem === 'none')) mainStatus = 500; // at this point we assume we have errors in targetErrorMessages array

    if (mainStatus === 500) return _handleErrors({ CARRIER_ERROR_MESSAGE: utils.serializeObjectToXML({ postAcceptanceErrors: targetErrorMessages, acceptanceInEligibilityErrors: groupedAcceptanceInEligibilityErrors }), CARRIER_ERROR_CODE: targetErrorCode }, cb);

    flights = flights.map(JSON.stringify);
    let uniqueFlights = new Set(flights);
    flights = Array.from(uniqueFlights).map(JSON.parse);
    flights = flights.flat(Infinity);
    let acceptanceCCResponse = {
      pnr: {
        rloc: rloc,
        passengers: passengers,
        flights: flights
      }
    };

    console.log(ccResponseLogger('multi acceptance response', JSON.stringify(acceptanceCCResponse, null, 2)), 'transaction id --> ', store.transactionId);

    return cb(null, response(mainStatus, acceptanceCCResponse));
  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
}

exports.boardingpass = async (event, context, cb) => {

  try {
    console.log("In boardingpass");
    const isV2 = isV2Request(event);

    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    console.info("Boarding pass request body: ", JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);

    let {
      givenName, familyName, rloc,
      // passengerRequest,
      requestingCarrier,
      targetAirlineCode,
      // document,
    } = isV2 ? convertToV1Params(body(event)) : params(event);
    const lookup = { givenName, familyName, rloc, targetAirlineCode };
    console.log("found passenger lookups", lookup, 'transaction id --> ', store.transactionId);

    let flightLookups = body(event).flightRequests;
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);

    let passengerRequest = body(event).passengerRequest;

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    const session = await api.getSession(targetAirlineCode);
    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    let journey = await api.searchCustomer(session, lookup);
    console.log(info("Journey fetched successfully"), 'transaction id --> ', store.transactionId);

    // createLogger(journey);

    const boardingpassPassengerGivenName = passengerRequest.givenName;
    let boardingpassPassengerFamilyName=passengerRequest.familyName


    const travelerID = utils.fetchTravelerIdsInAllJourneys(journey.data.data, boardingpassPassengerGivenName,boardingpassPassengerFamilyName);

    if (travelerID.length === 0) throw new Error('Invalid boarding pass traveler name');

    modified = utils.filterValidJourneys(journey, flightLookups, [travelerID[0].travelerId], 'boardingpass');
    journey = modified.journeysResponse;
    console.log(info("Journey modified successfully"), 'transaction id --> ', store.transactionId);
    console.log('Modified journey response', JSON.stringify(journey.data), 'transaction id --> ', store.transactionId);

    if (utils.targetCarrierDoesNotMatchJourneysFirstFlight(journey.data.data,targetAirlineCode)) {
      console.log(info("Journey.FirstFlight CarrierCode does not match Target Airline CarrierCode"), 'transaction id --> ', store.transactionId);
      return utils.returnJourneyMismatchError(cb);
    }


    let flightIdsLinkedToJourneyElements = utils.fetchFlightsIdFromJourneyElement(journey.data.dictionaries);
    const travelersInAllJourneys = utils.travelersInformationByJourney(journey.data.data, journey.data.dictionaries, null);
    const boardingpasses = await boardingpassHelpers.fetchBoardingPasses(travelersInAllJourneys, [travelerID[0].travelerId], session);

    // modifiy travelersInAllJourneys to include journeyElements that match the flight lookups
    const passengers = await boardingpassHelpers.generatePassengersObjectForCCResponse(
      session,
      travelersInAllJourneys,
      flightIdsLinkedToJourneyElements,
      journey,
      { methodType: 'boardingpass', travelerId: [travelerID[0].travelerId] },
      boardingpasses
    );

    console.log(info('Generated passengers object'), 'transaction id --> ', store.transactionId);
    const flights = utils.generateCCFlightsObject(journey.data).flat(Infinity);
    console.log(info('Generated Flights object'), 'transaction id --> ', store.transactionId);
    let boardingpassResponse = {
      pnr: {
        rloc: rloc,
        passengers: passengers,
        flights: flights
      }
    };

    console.log(ccResponseLogger('boarding pass response', JSON.stringify(boardingpassResponse, null, 2)), 'transaction id --> ', store.transactionId);

    return cb(null, response(200, boardingpassResponse));
  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
}

exports.multiBoardingpass = async (event, contect, cb) => {
  try {
    console.log("In multiBoardingpass");
    console.log(event.headers['x-cc-request-id'], '= CC transaction id', 'transaction id --> ', store.transactionId);
    store.transactionId = event.headers['x-cc-request-id'];

    console.log('Multi Boarding pass request body', JSON.stringify(body(event), null, 2), 'transaction id --> ', store.transactionId);
    const isV2 = isV2Request(event);
    let {
      givenName, familyName, rloc,
      requestingCarrier,
      targetAirlineCode,
    } = isV2 ? convertToV1Params(body(event)) : params(event);

    const lookup = { givenName, familyName, rloc, targetAirlineCode };
    let passengerRequests = body(event).passengerRequests;
    let flightLookups = body(event).flightRequests;


    console.log("found passenger lookups", lookup, 'transaction id --> ', store.transactionId);
    console.log('found flight lookups', flightLookups, 'transaction id --> ', store.transactionId);
    console.log('Passenger Requests', JSON.stringify(passengerRequests, null, 2), 'transaction id --> ', store.transactionId);

    const session = await api.getSession(targetAirlineCode);
    console.log(info("Fetched session successfully"), 'transaction id --> ', store.transactionId);

    if (!requestingCarrier) {
      requestingCarrier = event.headers["x-client-carrier"];
    }

    let passengers = [];
    let flights = [];


    //* this is an old method which is not used currently
    // const groupedPassengerRequests = utils.groupByFamilyName(passengerRequests, lookup);

    // * this is the new method which does efficient grouping of pax in family requests.
    const groupedPassengerRequests = await grouper(lookup, passengerRequests, session);

    for (let passengerRequests of groupedPassengerRequests) {
      // let { passengers: pax, flights: flightInfo } = await boardingpassHelpers.boardingpassModule(session, { familyName: passengerRequests[0].familyName, givenName: "anything works", rloc }, passengerRequests, flightLookups);
      let { passengers: pax, flights: flightInfo , isMisMatch} = await boardingpassHelpers.boardingpassModule(session, passengerRequests[0].identificationResponse, passengerRequests, flightLookups, targetAirlineCode);

      if(isMisMatch) return utils.returnJourneyMismatchError(cb);
      passengers.push(pax);
      if (flights.length === 0) flights.push(flightInfo);
    }

    flights = flights.map(JSON.stringify);
    let uniqueFlights = new Set(flights);
    flights = Array.from(uniqueFlights).map(JSON.parse);
    flights = flights.flat(Infinity)
    let boardingpassCCResponse = {
      pnr: {
        rloc: rloc,
        passengers: passengers.flat(Infinity),
        flights: flights
      }
    };

    console.log(ccResponseLogger('multi boarding pass response', JSON.stringify(boardingpassCCResponse, null, 2)), 'transaction id --> ', store.transactionId);

    return cb(null, response(200, boardingpassCCResponse));
  } catch (e) {
    console.log(e, 'transaction id --> ', store.transactionId);
    return _handleErrors(e, cb);
  }
}


// function _handleErrors(err, cb) {
//   const body = {
//     id: uuid(),
//     message: err.CARRIER_ERROR_MESSAGE
//       ? `Type: ${err.CARRIER_ERROR_MESSAGE}`
//       : err.message,
//     type: err.CARRIER_ERROR_CODE || err.statusCode ? "OA" : "Internal",
//     code: err.CARRIER_ERROR_CODE || "500",
//   };

//   let responseCode;

//   // TODO: 502 vs 500 may not be sufficient. Do we need to support 400 and others?
//   if (err.CARRIER_ERROR_MSG || err.CARRIER_ERROR_CODE) {
//     responseCode = 502;
//   } else {
//     responseCode = 500;
//   }

//   console.error(`Could not satisfy request ${JSON.stringify(body, null, 2)}`);
//   return cb(null, response(responseCode, body));
// }


