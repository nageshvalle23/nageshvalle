// const _ = require("lodash");
// const proxyquire = require("proxyquire");
// const sinon = require("sinon");
// const chai = require("chai");
// const chaiAsPromised = require("chai-as-promised");
// const { generateExistingDocument } = require("../../converter");

// chai.use(chaiAsPromised);
// const assert = chai.assert;

// const moduleName = "../../index";

// const placeholderStub = (fnName) => () => {
//   throw new Error("Please stub this function call: " + fnName);
// };

// const createStubs = (customStubs) =>
//   _.defaults({}, customStubs, {
//     ['@oneworld-digital/integration-utils']: {
//       versionConverter: {
//         isV2Request: placeholderStub("isV2Request"),
//         convertToV1Params: placeholderStub("convertToV1Params")
//       },
//       request: {
//         params: placeholderStub("params")
//       }
//     },
//     ["./api"]: {
//       getSession: placeholderStub("getSession"),
//       searchCustomer: placeholderStub("searchCustomer"),
//       getJourneyElementsInformationInAJourney: placeholderStub("getJourneyElementsInformationInAJourney"),
//       fetchRequiredDocuments: placeholderStub("fetchRequiredDocuments"),
//       updateDocs: placeholderStub("updateDocs"),
//       acceptanceByJourneyElementId: placeholderStub(
//         "acceptanceByJourneyElementId"
//       ),
//       fetchBoardingPassByJourneyElementId: placeholderStub(
//         "fetchBoardingPassByJourneyElementId"
//       ),
//     },
//     ["./converter"]: {
//       generateRequiredDocuments: placeholderStub("generateRequiredDocuments"),
//       generateExistingDocument: placeholderStub("generateExistingDocument"),
//     },
//     ["./utils"]: {
//       fetchFlightsIdFromJourneyElement: placeholderStub(
//         "fetchFlightsIdFromJourneyElement"
//       ),
//       fetchTravelersInAllJourneys: placeholderStub(
//         "fetchTravelersInAllJourneys"
//       ),
//       generatePassengersObjectForCCResponse: placeholderStub(
//         "generatePassengersObjectForCCResponse"
//       ),
//       generateCCFlightsObject: placeholderStub("generateCCFlightsObject"),
//       fetchTravelerIdsInAllJourneys: placeholderStub(
//         "fetchTravelerIdsInAllJourneys"
//       ),
//       handleDocument: placeholderStub("handleDocument"),
//     },
//   });

// describe("index", () => {
//   //Stub the all API's
//   const getSession = sinon.stub();
//   const searchCustomer = sinon.stub();
//   const getJourneyElementsInformationInAJourney = sinon.stub();
//   const fetchRequiredDocuments = sinon.stub();
//   const updateDocs = sinon.stub();
//   const acceptanceByJourneyElementId = sinon.stub();
//   const fetchBoardingPassByJourneyElementId = sinon.stub();

//   //Stub the all CONVERTER methods
//   const generateRequiredDocuments = sinon.stub();
//   const generateExistingDocument = sinon.stub();

//   //Stub the all UTILS methods
//   const fetchFlightsIdFromJourneyElement = sinon.stub();
//   const fetchTravelersInAllJourneys = sinon.stub();
//   const fetchTravelerIdsInAllJourneys = sinon.stub();
//   const generatePassengersObjectForCCResponse = sinon.stub();
//   const generateCCFlightsObject = sinon.stub();
//   const handleDocument = sinon.stub();

//   //Stub the all INTEGRATION UTILS methods

//   const isV2Request = sinon.stub();
//   const convertToV1Params = sinon.stub();
//   const params = sinon.stub();

//   const m = proxyquire(
//     moduleName,
//     createStubs({
//       ['@oneworld-digital/integration-utils']: {
//         versionConverter: {
//           isV2Request,
//           convertToV1Params,
//         }
//       },
//       ["./api"]: {
//         getSession,
//         searchCustomer,
//         fetchRequiredDocuments,
//         updateDocs,
//         acceptanceByJourneyElementId,
//         fetchBoardingPassByJourneyElementId,
//       },
//       ["./converter"]: {
//         generateRequiredDocuments,
//         generateExistingDocument,
//       },
//       ["./utils"]: {
//         fetchFlightsIdFromJourneyElement,
//         fetchTravelersInAllJourneys,
//         generatePassengersObjectForCCResponse,
//         generateCCFlightsObject,
//         fetchTravelerIdsInAllJourneys,
//         handleDocument,
//       },
//     })
//   );

//   describe("Record endpoint", () => {
//       it("should respond with 200 if record succeeds", async () => {
//         const qs = {
//           rloc: "bar123",
//           familyName: "foo",
//         };
      
//         const event = {
//           queryStringParameters: qs,
//           body: null,
//           headers: {
//             "x-client-carrier": "OG",
//           }
//         };
      
//         getSession.returns({ access_token: "asdsf" });
//         searchCustomer.returns({ data: require("../mocks/journeys.json") });
//         getJourneyElementsInformationInAJourney.returns(require("../mocks/journey-elements.json"))
      
//         await m.record(event, {}, (err, res) => {
//           assert.equal(res.statusCode, 200);
//         });
//       });

//     it("should respond with 502 if a downstream service call fails", async () => {
//       const qs = {
//         familyName: "foo",
//       };

//       const event = {
//         queryStringParameters: qs,
//         body: null,
//         headers: {
//           "x-client-carrier": "OG",
//         }
//       };
//       getSession.rejects(Error);

//       await m.record(event, {}, (err, res) => {
//         assert.equal(res.statusCode, 500);
//       });
//     });
//   });
  
//   describe("eligibility", () => {
//     const qs = {
//       recordRequest: {
//         familyName: "James",
//         givenName: "Lever",
//         rloc: "LKFMN",
//         carrierCode: "MH",
//       },
//       passengerRequest: {
//         familyName: "Lever",
//         givenName: "James",
//         eTicketNumber: null,
//       },
//     };

//     const event = {
//       queryStringParameters: qs,
//       body: null,
//       headers: {
//         "x-client-carrier": "OG",
//       }
//     };

//     it("should send an required documents", async () => {
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchTravelerIdsInAllJourneys.returns([
//         { travelerId: "abc", journeyId: "xyz" },
//       ]);
//       fetchRequiredDocuments.returns({data: require("../mocks/eligibility.json")});

//       await m.eligibility(event, {}, (err, res) => {
//         assert.equal(res.statusCode, 200);
//       });
//     });

//     it("should respond with 500 for service failures", async () => {
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchRequiredDocuments.rejects(Error);

//       await m.eligibility(event, {}, (err, res) => {
//         assert.strictEqual(res.statusCode, 500);
//       });
//     });
//   });

//   describe("document update", async () => {
//     const qs = {
//       recordRequest: {
//         familyName: "James",
//         givenName: "Lever",
//         rloc: "LKFMN",
//         carrierCode: "MH",
//       },
//       passengerRequest: {
//         familyName: "Lever",
//         givenName: "James",
//         eTicketNumber: null,
//       },
//       document: [
//         {
//           type: "PASSPORT",
//           payload: {
//             countryOfIssue: "USA",
//             dateOfBirth: "1980-07-25",
//             givenName: "NORA",
//             familyName: "ALI",
//             passportNumber: "1234hjsdj8",
//             expiryDate: "2025-07-25",
//             gender: "MALE",
//             nationality: "USA",
//           },
//         },
//       ],
//     };

//     const event = {
//       queryStringParameters: qs,
//       body: null,
//       headers: {
//         "x-client-carrier": "OG",
//       }
//     };

//     it("should send an updated documents", async () => {
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchTravelerIdsInAllJourneys.returns([
//         { travelerId: "abc", journeyId: "xyz" },
//       ]);
//       fetchRequiredDocuments.returns({data: require("../mocks/eligibility.json")});
//       handleDocument.returns({});
//       updateDocs.returns({data: require("../mocks/regulatory.json")});

//       await m.documentsupdate(event, {}, (err, res) => {
//         assert.strictEqual(res.statusCode, 200);
//       });
//     });

//     it("should respond with 500 for service failures", async () => {
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       handleDocument.returns({});
//       updateDocs.rejects(Error);

//       await m.documentsupdate(event, {}, (err, res) => {
//         assert.strictEqual(res.statusCode, 500);
//       });
//     });
//   });

//   describe("Checkin formats", async () => {
//     const qs = {
//       recordRequest: {
//         familyName: "James",
//         givenName: "Lever",
//         rloc: "LKFMN",
//         carrierCode: "MH",
//       },
//       requirements: {
//         acknowledgeDGTerms: true,
//         acceptance: true,
//       },
//       passengerRequest: {
//         familyName: "Lever",
//         givenName: "James",
//         eTicketNumber: null,
//       },
//     };

//     const event = {
//       queryStringParameters: qs,
//       body: null,
//       headers: {
//         "x-client-carrier": "OG",
//       }
//     };

//     it("should check passengers in and respond with 200", async () => { 
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchTravelerIdsInAllJourneys.returns([{ travelerId: "123" }]);
//       fetchTravelersInAllJourneys.returns([
//         {
//           travelers: [
//             {
//               id: 1,
//               firstName: "JAMES",
//               lastName: "LEVER",
//               title: "MR",
//               flightsInformation: [
//                 {
//                   travelerId: "123",
//                   journeyElementId: "123abc",
//                   checkInStatus: true,
//                   boardingPassPrintStatus: true,
//                   acceptanceEligibility: "eligible",
//                 },
//               ],
//               journeyId: "xyz", // can we optimise this?
//               ageCatagory: "ADT",
//             },
//           ],
//         },
//       ]);
//       acceptanceByJourneyElementId.returns({
//         data: require("../mocks/accept.json"),
//       });
//       fetchFlightsIdFromJourneyElement.returns([]);
//       generatePassengersObjectForCCResponse.returns([]);
//       generateCCFlightsObject.returns([]);

//       await m.singleAcceptance(event, {}, (err, res) => {
//         assert.equal(res.statusCode, 200);
//         assert.deepStrictEqual(JSON.parse(res.body), {
//           pnr: {
//             rloc: "LKFMN",
//             passengers: [],
//             flights: [],
//           },
//         });
//       });
//     });

//     it("should respond with 500 for service failures", async () => {
//       isV2Request.returns(true);
//       convertToV1Params.returns(qs);  
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       acceptanceByJourneyElementId.rejects(Error);

//       await m.singleAcceptance(event, {}, (err, res) => {
//         assert.equal(res.statusCode, 500);
//       });
//     });
//   });

//   describe("boardingpass formats", async () => {
//     const qs = {
//       recordRequest: {
//         familyName: "James",
//         givenName: "Lever",
//         rloc: "LKFMN",
//         carrierCode: "MH",
//       },
//       passengerRequest: {
//         familyName: "Lever",
//         givenName: "James",
//         eTicketNumber: null,
//       },
//     };

//     const event = {
//       queryStringParameters: qs,
//       body: null,
//       headers: {
//         "x-client-carrier": "OG",
//       }
//     };

//     it("should retrieve boarding pass", async () => {
//       isV2Request.returns(true);
//       convertToV1Params.returns(qs);  
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchTravelerIdsInAllJourneys.returns([{ travelerId: "123" }]);
//       fetchFlightsIdFromJourneyElement.returns([]);
//       fetchTravelersInAllJourneys.returns([]);
//       fetchBoardingPassByJourneyElementId.returns(
//         require("../mocks/boradingPass.json")
//       );
//       generatePassengersObjectForCCResponse.returns([]);
//       generateCCFlightsObject.returns([]);

//       await m.boardingpass(event, {}, (err, res) => {
//         assert.equal(res.statusCode, 200);
//         assert.deepStrictEqual(JSON.parse(res.body), {
//           pnr: {
//             rloc: "LKFMN",
//             passengers: [],
//             flights: [],
//           },
//         });
//       });
//     });

//     it("should respond with 500 for service failures", async () => {
//       isV2Request.returns(true);
//       convertToV1Params.returns(qs);  
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchBoardingPassByJourneyElementId.rejects(Error);

//       await m.boardingpass(event, {}, (err, res) => {
//         assert.strictEqual(res.statusCode, 500);
//       });
//     });
//   });

//   describe("multi eligibility", async () => {
//     const qs = {
//       recordRequest: {
//         familyName: "James",
//         givenName: "Lever",
//         rloc: "LKFMN",
//         carrierCode: "MH",
//       },
//       passengerRequests: [
//         {
//           givenName: "Jane",
//           familyName: "Doe",
//           eTicketNumber: "1234567890",
//         },
//         {
//           givenName: "Bob",
//           familyName: "Smith",
//           eTicketNumber: "0987654321",
//         },
//       ],
//     };

//     const event = {
//       queryStringParameters: qs,
//       body: null,
//       headers: {
//         "x-client-carrier": "OG",
//       }
//     };

//     it("should return the required and populated documents for each passenger", async () => {
//       // Set up the stubs to return the expected values
//       isV2Request.returns(true);
//       convertToV1Params.returns(qs);  
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchTravelerIdsInAllJourneys.returns([
//         { travelerId: "abc", journeyId: "xyz" },
//       ]);
//       fetchRequiredDocuments.returns(require("../mocks/eligibility.json"));
//       generateRequiredDocuments.returns(["PASSPORT"]);
//       generateExistingDocument.returns(["VISA"]);

//       await m.multiEligibility(event, {}, (err, res) => {
//         // Check that the response is as expected
//         assert.strictEqual(res.statusCode, 200);
//         assert.deepStrictEqual(JSON.parse(res.body), [
//           {
//             givenName: "Jane",
//             familyName: "Doe",
//             eTicketNumber: "1234567890",
//             requiredDocuments: ["PASSPORT"],
//             populatedDocuments: ["VISA"],
//           },
//           {
//             givenName: "Bob",
//             familyName: "Smith",
//             eTicketNumber: "0987654321",
//             requiredDocuments: ["PASSPORT"],
//             populatedDocuments: ["VISA"],
//           },
//         ]);
//       });
//     });

//     it("should respond with 500 for service failures", async () => {
//       isV2Request.returns(true);
//       convertToV1Params.returns(qs);  
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchRequiredDocuments.rejects(Error);

//       await m.eligibility(event, {}, (err, res) => {
//         assert.equal(res.statusCode, 500);
//       });
//     });
//   });

//   describe("multi-checkin", async () => {
//     const qs = {
//       recordRequest: {
//         familyName: "James",
//         givenName: "Lever",
//         rloc: "LKFMN",
//         carrierCode: "MH",
//       },
//       passengerRequests: [
//         {
//           givenName: "Jane",
//           familyName: "Doe",
//           eTicketNumber: "1234567890",
//         },
//         {
//           givenName: "Bob",
//           familyName: "Smith",
//           eTicketNumber: "0987654321",
//         },
//       ],
//     };

//     const event = {
//       queryStringParameters: qs,
//       body: null,
//       headers: {
//         "x-client-carrier": "OG",
//       }
//     };

//     it("should checkin for each passenger", async () => {
//       // Set up the stubs to return the expected values
//       isV2Request.returns(true);
//       convertToV1Params.returns(qs);  
//       getSession.returns({ access_token: "asdsf" });
//       searchCustomer.returns({ data: require("../mocks/journeys.json") });
//       fetchTravelerIdsInAllJourneys.returns([{ travelerId: "123" }]);
//       fetchTravelersInAllJourneys.returns([
//         {
//           travelers: [
//             {
//               id: 1,
//               firstName: "JAMES",
//               lastName: "LEVER",
//               title: "MR",
//               flightsInformation: [
//                 {
//                   travelerId: "123",
//                   journeyElementId: "123abc",
//                   checkInStatus: true,
//                   boardingPassPrintStatus: true,
//                   acceptanceEligibility: "eligible",
//                 },
//               ],
//               journeyId: "xyz", // can we optimise this?
//               ageCatagory: "ADT",
//             },
//           ],
//         },
//       ]);
//       acceptanceByJourneyElementId.returns({
//         data: require("../mocks/accept.json"),
//       });
//       fetchFlightsIdFromJourneyElement.returns([]);
//       generatePassengersObjectForCCResponse.returns([
//         {
//           firstName: "Jane",
//           lastName: "Doe",
//           title: "MRS",
//           ageCatagory: "ADT",
//           id: "1234567890",
//           coupons: [],
//         },
//         {
//           firstName: "Bob",
//           lastName: "Smith",
//           title: "MR",
//           ageCatagory: "ADT",
//           id: "0987654321",
//           coupons: [],
//         },
//       ]);
//       generateCCFlightsObject.returns([]);

//       await m.multiAcceptance(event, {}, (err, res) => {
//         // Check that the response is as expected
//         assert.strictEqual(res.statusCode, 200);
//         assert.deepStrictEqual(JSON.parse(res.body), {
//           pnr: {
//             rloc: "LKFMN",
//             passengers: [
//               {
//                 firstName: "Jane",
//                 lastName: "Doe",
//                 title: "MRS",
//                 ageCatagory: "ADT",
//                 id: "1234567890",
//                 coupons: [],
//               },
//               {
//                 firstName: "Bob",
//                 lastName: "Smith",
//                 title: "MR",
//                 ageCatagory: "ADT",
//                 id: "0987654321",
//                 coupons: [],
//               },
//             ],
//             flights: [],
//           },
//         });
//       });
//     });
//   });

// });


// // ***********************************OLD CODE***************************************

//   // describe("GET a record", () => {
//   //   beforeEach(() => {
//   //     getSession.reset();
//   //   });

//     // it("should respond with 502 if a downstream service call fails", async () => {
//     //   const qs = {
//     //     familyName: "foo",
//     //   };

//     //   const event = {
//     //     queryStringParameters: qs,
//     //     body: null,
//     //     headers: {
//     //       "x-client-carrier": "OG",
//     //     }
//     //   };

//     //   isV2Request.returns(true);
//     //   convertToV1Params.returns(qs);    
//     //   getSession.rejects(Error);

//     //   await m.record(event, {}, (err, res) => {
//     //     assert.equal(res.statusCode, 500);
//     //   });
//     // });

//   //   it("should respond with 200 if record succeeds", async () => {
//   //     const qs = {
//   //       rloc: "bar123",
//   //       familyName: "foo",
//   //       requestingCarrier: "OG",
//   //     };

//   //     const event = {
//   //       queryStringParameters: qs,
//   //       body: null,
//   //       headers: {
//   //         "x-client-carrier": "OG",
//   //       }
//   //     };

//   //     isV2Request.returns(true);
//   //     convertToV1Params.returns(qs);    
//   //     getSession.returns({ access_token: "asdsf" });
//   //     searchCustomer.returns({ data: require("../mocks/journeys.json") });
//   //     fetchFlightsIdFromJourneyElement.returns([]);
//   //     fetchTravelersInAllJourneys.returns([]);
//   //     generatePassengersObjectForCCResponse.returns([]);
//   //     generateCCFlightsObject.returns([]);

//   //     await m.record(event, {}, (err, res) => {
//   //       assert.equal(res.statusCode, 200);
//   //       assert.deepStrictEqual(JSON.parse(res.body), {
//   //         pnr: {
//   //           rloc: "bar123",
//   //           passengers: [],
//   //           flights: [],
//   //         },
//   //       });
//   //     });
//   //   });
//   // });
