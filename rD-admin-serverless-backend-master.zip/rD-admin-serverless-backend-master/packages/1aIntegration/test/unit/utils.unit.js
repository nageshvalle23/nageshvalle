// const _ = require("lodash");
// const proxyquire = require("proxyquire");
// const sinon = require("sinon");
// const chai = require("chai");
// const chaiAsPromised = require("chai-as-promised");

// chai.use(chaiAsPromised);

// const assert = chai.assert;

// // get mocks
// const requestTo1A_passport = require('../mocks/utils/requestTo1a_passport.json');
// const requestTo1A_visa = require('../mocks/utils/requestTo1a_visa.json');
// const requestTo1A_destination_address = require('../mocks/utils/requestTo1a_destination_address.json');
// const requestTo1A_resident_address = require('../mocks/utils/requestTo1a_resident_address.json');
// const requestTo1A_resident_visa = require('../mocks/utils/requestTo1a_resident_visa.json');

// const travelersInAllJourneys = require('../mocks/utils/travelersInAllJourneys.json');


// const journey_mock = require('../mocks/utils/journey_mock.json');

// const moduleName = '../../utils';

// const placeholderStub = (fnName) => () => {
//     throw new Error("Please stub this function call: " + fnName);
// };

// const createStubs = (customStubs) =>
//     _.defaults({}, customStubs, {
//         ["./helpers"]: {
//             handleGender: placeholderStub("handleGender")
//         },
//         ["./api"]: {
//             getJourneyElementsInformationInAJourney: placeholderStub("getJourneyElementsInformationInAJourney"),
//             fetchBoardingPassByJourneyElementId: placeholderStub("fetchBoardingPassByJourneyElementId")
//         },
//         ["./converter"]: {
//             convertToCCBoardingPass: placeholderStub("convertToCCBoardingPass"),
//             makeCouponObject: placeholderStub("makeCouponObject"),
//             getJourneyElementsInformation: placeholderStub("getJourneyElementsInformation"),
//             createPassengerObject: placeholderStub("createPassengerObject"),
//             updatePassengerCoupons: placeholderStub("updatePassengerCoupons")
//         }
//     });


// describe('utils.js', () => {

//     describe('handleDocument', () => {
//         const handleGender = sinon.stub();
//         // const getJourneyElementsInformationInAJourney = sinon.stub();
//         // const fetchBoardingPassByJourneyElementId = sinon.stub();


//         const m = proxyquire(moduleName,
//             createStubs({
//                 ["./helpers"]: {
//                     handleGender: handleGender
//                 }
//             })
//         );

//         it('should return the correct request to 1a for PASSPORT', () => {
//             handleGender.returns('male')
//             const ccDocumentRequest = [{
//                 type: "PASSPORT",
//                 payload: {
//                     "countryOfIssue": "USA",
//                     "dateOfBirth": "1980-07-25",
//                     "givenName": "NORA",
//                     "familyName": "ALI",
//                     "passportNumber": "17181919111",
//                     "expiryDate": "2025-07-25",
//                     "gender": "MALE",
//                     "nationality": "USA"
//                 }
//             }];

//             const r = m.handleDocument(ccDocumentRequest);
//             assert.deepStrictEqual(r, requestTo1A_passport);
//         })

//         it('should return the correct request to 1a for VISA', () => {
//             handleGender.returns('male')
//             const ccDocumentRequest = [{
//                 type: "PASSPORT",
//                 payload: {
//                     "countryOfIssue": "USA",
//                     "dateOfBirth": "1980-07-25",
//                     "givenName": "NORA",
//                     "familyName": "ALI",
//                     "passportNumber": "17181919111",
//                     "expiryDate": "2025-07-25",
//                     "gender": "MALE",
//                     "nationality": "USA"
//                 }
//             },
//             {
//                 type: "VISA",
//                 payload: {
//                     documentNumber: '123456789',
//                     expiryDate: '2029-01-01',
//                     countryOfIssue: 'USA',
//                 }
//             }];

//             const r = m.handleDocument(ccDocumentRequest);
//             assert.deepStrictEqual(r, requestTo1A_visa);
//         })

//         it('should return the correct request to 1a for DESTINATION_ADDRESS', () => {
//             handleGender.returns('male')
//             const ccDocumentRequest = [{
//                 type: "PASSPORT",
//                 payload: {
//                     "countryOfIssue": "USA",
//                     "dateOfBirth": "1980-07-25",
//                     "givenName": "NORA",
//                     "familyName": "ALI",
//                     "passportNumber": "17181919111",
//                     "expiryDate": "2025-07-25",
//                     "gender": "MALE",
//                     "nationality": "USA"
//                 }
//             },
//             {
//                 type: "DESTINATION_ADDRESS",
//                 payload: {
//                     street: 'XYZ',
//                     city: 'ABC',
//                     stateProv: 'ARKANSAS',
//                     postalCode: '00000',
//                     country: 'USA'
//                 }
//             }];

//             const r = m.handleDocument(ccDocumentRequest);
//             assert.deepStrictEqual(r, requestTo1A_destination_address);
//         })

//         it('should assign empty personalDetails when no PASSPORT and only RESIDENT_ADDRESS', () => {
//             const ccDocumentRequest = [
//                 {
//                     type: "RESIDENT_ADDRESS",
//                     payload: {
//                         countryOfResidence: 'USA'
//                     }
//                 }];

//             const r = m.handleDocument(ccDocumentRequest);
//             assert.deepStrictEqual(r, requestTo1A_resident_address);
//         })

//         it('should contain personalDetails already when PASSPORT or VISA along with RESIDENT_ADDRESS', () => {
//             const ccDocumentRequest = [
//                 {
//                     type: "PASSPORT",
//                     payload: {
//                         "countryOfIssue": "USA",
//                         "dateOfBirth": "1980-07-25",
//                         "givenName": "NORA",
//                         "familyName": "ALI",
//                         "passportNumber": "17181919111",
//                         "expiryDate": "2025-07-25",
//                         "gender": "MALE",
//                         "nationality": "USA"
//                     }
//                 },
//                 {
//                     type: "RESIDENT_ADDRESS",
//                     payload: {
//                         countryOfResidence: 'USA'
//                     }
//                 }];

//             const r = m.handleDocument(ccDocumentRequest);
//             assert.deepStrictEqual(r, requestTo1A_resident_visa);
//         })
//     })

//     describe('fetchFlightsIdFromJourneyElement', () => {
//         const getJourneyElementsInformationInAJourney = sinon.stub();
//         const fetchBoardingPassByJourneyElementId = sinon.stub();

//         const m = proxyquire(moduleName,
//             createStubs({
//                 ["./api"]: {
//                     getJourneyElementsInformationInAJourney,
//                     fetchBoardingPassByJourneyElementId,
//                 }
//             })
//         );

//         const mockSession = {
//             access_token: 'abc'
//         }

//         it('should return flight ids linked to journey elements', async () => {
//             getJourneyElementsInformationInAJourney.onCall(0).returns(require('../mocks/utils/getJourneyElementsInformationInAJourney.json'));

//             const expectedResponse = {
//                 "500E21E800025FF1": "MH-2646-20230430",
//                 "500E21E800025FF2": "MH-2646-20230430",
//             }
//             const r = await m.fetchFlightsIdFromJourneyElement(mockSession, require('../mocks/utils/journey_mock.json'));
//             assert.deepStrictEqual(r, expectedResponse);
//         })
//     })

//     describe('fetchTravelersInAllJourneys', () => {
//         const getJourneyElementsInformationInAJourney = sinon.stub();
//         const getJourneyElementsInformation = sinon.stub();
//         const m = proxyquire(moduleName,
//             createStubs({
//                 ["./api"]: {
//                     getJourneyElementsInformationInAJourney
//                 },
//                 ["./converter"]: {
//                     getJourneyElementsInformation
//                 }
//             })
//         );


//         const mockSession = {
//             access_token: 'abc'
//         }

//         it('should return all travelers in a particular journey', async () => {
//             getJourneyElementsInformation.onCall(0).returns(require('../mocks/utils/getJourneyElementsInformation_1.json'));
//             getJourneyElementsInformation.onCall(1).returns(require('../mocks/utils/getJourneyElementsInformation_2.json'));
//             getJourneyElementsInformationInAJourney.returns(require('../mocks/utils/getJourneyElementsInformationInAJourney.json'));

//             const r = await m.fetchTravelersInAllJourneys(mockSession, require('../mocks/utils/journey_mock.json'));

//             assert.deepStrictEqual(r, require('../mocks/utils/fetchTravelersInAllJourneys_expected.json'))
//         })

//         it('should return only single traveler info on all journey when traveler id passed as argument', async () => {
//             getJourneyElementsInformation.onCall(0).returns(require('../mocks/utils/getJourneyElementsInformation_1.json'));
//             getJourneyElementsInformation.onCall(1).returns(require('../mocks/utils/getJourneyElementsInformation_2.json'));
//             getJourneyElementsInformationInAJourney.returns(require('../mocks/utils/getJourneyElementsInformationInAJourney.json'));

//             const r = await m.fetchTravelersInAllJourneys(mockSession, require('../mocks/utils/journey_mock.json'), '510D91E7000292A3');

//             assert.deepStrictEqual(r, require('../mocks/utils/fetchTravelersInAllJourneys_singleTravelerId_expectedResponse.json'));
//         })


//     })

//     describe('fetchTravelerIdsInAllJourneys', () => {
//         const m = require(moduleName);
//         it('should return fetch travelers ids on all journeys', () => {
//             const mockTravelerName = 'KENNY';
//             const r = m.fetchTravelerIdsInAllJourneys(require('../mocks/utils/journey_mock.json'), mockTravelerName);
//             assert.deepStrictEqual(r, require('../mocks/utils/fetchTravelerIdsInAllJourneys_expected.json'))
//         })

//         it('should return empty array with no traveler ids when no passenger matches', () => {
//             const mockTravelerName = 'abc';
//             const r = m.fetchTravelerIdsInAllJourneys(require('../mocks/utils/journey_mock.json'), mockTravelerName);
//             assert.deepStrictEqual(r, []);
//         })

//     })

//     describe('generatePassengersObjectForCCResponse', () => {

//         const createPassengerObject = sinon.stub();
//         const updatePassengerCoupons = sinon.stub();

//         const m = proxyquire(moduleName,
//             createStubs({
//                 ["./converter"]: {
//                     createPassengerObject,
//                     updatePassengerCoupons
//                 }
//             })
//         );

//         const mockSession = {
//             access_token: "abc"
//         }


//         it('should return valid passenger objects for cc', async () => {
//             const firstTime = { "firstName": "ANNE", "lastName": "ROGERS", "title": "MRS", "ageCatagory": "ADT", "id": "510D91E7000292A2", "coupons": [{ "flightNumber": "2646", "departureDateTime": "2023-04-30T11:35:00+08:00", "carrierCode": "MH", "origin": "KUL", "eTicketNumber": "500E21E800025FF1", "destination": "BKI", "isCheckedIn": true, "isCheckedInInhibited": false, "boardingPass": null }] }
//             const secondTime = { "firstName": "KENNY", "lastName": "ROGERS", "title": "MR", "ageCatagory": "ADT", "id": "510D91E7000292A3", "coupons": [{ "flightNumber": "2646", "departureDateTime": "2023-04-30T11:35:00+08:00", "carrierCode": "MH", "origin": "KUL", "eTicketNumber": "500E21E800025FF2", "destination": "BKI", "isCheckedIn": true, "isCheckedInInhibited": false, "boardingPass": null }] }

//             createPassengerObject.onCall(0).returns(firstTime);
//             createPassengerObject.onCall(1).returns(secondTime);
//             const flightIdsLinkedToJourneyElements = { "500E21E800025FF1": 'MH-2646-20230430', "500E21E800025FF2": 'MH-2646-20230430' }
//             const journey = {
//                 status: 200,
//                 data: []
//             }
//             const requestOptions = { methodType: 'record', travelerId: null }

//             const r = await m.generatePassengersObjectForCCResponse(mockSession, travelersInAllJourneys, flightIdsLinkedToJourneyElements, journey, requestOptions);

//             assert.deepStrictEqual(r, require('../mocks/utils/generatePassengerObjectForCCResponse_expected1.json'));
//         })

//     })

//     describe('generateCCFlightsObject', () => {
//         const mockJourney2 = require('../mocks/utils/journey_mock_2.json');
//         const m = require('../../utils');

//         const r = m.generateCCFlightsObject(mockJourney2);

//         const expectedResponse = [{ "flightNumber": "2646", "date": "2023-04-30", "carrierCode": "MH", "origin": "KUL", "destination": "BKI" }]
//         assert.deepStrictEqual(r,expectedResponse)
//     })
// });

