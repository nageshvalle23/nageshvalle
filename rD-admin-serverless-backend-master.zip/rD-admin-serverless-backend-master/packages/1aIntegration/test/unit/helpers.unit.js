const sinon = require("sinon");
const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");


chai.use(chaiAsPromised);

const assert = chai.assert;

const m = require('../../helpers');


// const placeholderStub = (fnName) => () => {
//     throw new Error("Please stub this function call: " + fnName);
// };

// const createStubs = (customStubs) =>
//     _.defaults({}, customStubs, {
//         ["./api"]: {
//             fetchBoardingPassByJourneyElementId: placeholderStub("fetchBoardingPassByJourneyElementId")
//         }
//     });

describe('helpers', () => {

    describe('handleGender', () => {
        it('should give small case male when gender MALE', () => {
            const r = m.handleGender('MALE');
            assert.deepEqual(r, 'male');
        })

        it('should give small case male when gender FEMALE', () => {
            const r = m.handleGender('FEMALE');
            assert.deepEqual(r, 'female');
        })

        it('should give unspecified when gender X', () => {
            const r = m.handleGender('X');
            assert.deepEqual(r, 'unspecified');
        })

        it('should give unknown when gender U', () => {
            const r = m.handleGender('U');
            assert.deepEqual(r, 'unknown');
        })
    })

    // describe('createPassengerObject', () => {

    //     const fetchBoardingPassByJourneyElementId = sinon.stub();
    //     const n = proxyquire(require('../../helpers'),
    //         createStubs({
    //             ["./api"]: {
    //                 fetchBoardingPassByJourneyElementId
    //             }
    //         })
    //     );
    //     it('should check passenger updated with new coupons', async () => {
    //         fetchBoardingPassByJourneyElementId.returns()
    //         const mockTraveler =
    //             { "id": "510D91E7000292A2", "firstName": "ANNE", "lastName": "ROGERS", "title": "MRS", "flightsInformation": [{ "travelerId": "510D91E7000292A2", "journeyElementId": "500E21E800025FF1", "checkInStatus": "accepted", "boardingPassPrintStatus": "needPrinting", "acceptanceEligibility": "ineligible" }], "journeyId": "B1E6855F11C790391A98316F6B42A8FA10A1D4E21683412071", "ageCatagory": "ADT" }

    //         const r = await n.createPassengerObject(mockTraveler);
    //         console.log(r,'===rrr')
    //     })
    // })

})