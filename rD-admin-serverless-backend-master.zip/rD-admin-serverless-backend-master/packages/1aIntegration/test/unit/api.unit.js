// const _ = require("lodash");
// const proxyquire = require("proxyquire");
// const sinon = require("sinon");
// const chai = require("chai");
// const chaiAsPromised = require("chai-as-promised");
// const { describe } = require("mocha");
// chai.use(chaiAsPromised);
// const assert = chai.assert;
// const moduleName = "../../api.js";

// //get all mocks

// const journeysData = require("../mocks/journeys.json");
// const eligibilityData = require("../mocks/eligibility.json");
// const documentData = require("../mocks/regulatory.json");
// const journeyElementsData = require("../mocks/journey-elements.json");
// const contactsData = require("../mocks/contacts.json");
// const acceptData = require("../mocks/accept.json");
// const boardingPassData = require("../mocks/boradingPass.json");

// const placeholderStub = (fnName) => () => {
//   throw new Error("Please stub this function call: " + fnName);
// };

// const createStubs = (customStubs) =>
//   _.defaults({}, customStubs, {
//     ["axios"]: placeholderStub("params"),
//   });

// describe("API for 1A", () => {
//   const axios = sinon.stub();

//   const m = proxyquire(
//     moduleName,
//     createStubs({
//       ["axios"]: axios,
//     })
//   );

//   describe("get session", () => {
//     after(() => {
//       axios.reset();
//     });

//     it("should return a token object", async () => {
//       const res = {
//         data: {
//           access_token: "1234567890",
//         },
//         status: 200,
//       };

//       axios.returns(res);
//       const session = await m.getSession("MH");
//       //   console.log(session);
//       assert(axios.calledOnce);
//       assert.equal(session.access_token, "1234567890");
//     });

//     it("should throw an error if the response does not have expected values", async () => {
//       const res = {
//         data: {
//           foo: "1234567890",
//         },
//       };

//       axios.returns(res);
//       await assert.isRejected(m.getSession(), Error);
//     });
//   });

//   describe("get journeys", () => {
//     after(() => {
//       axios.reset();
//     });

//     it("should return a journeys object", async () => {
//       axios.returns(journeysData);
//       const res = await m.searchCustomer("access_token", {
//         rloc: "ABCDEF",
//         familyName: "Lever",
//       });
//       assert(axios.calledOnce);
//       assert.deepEqual(res, journeysData);
//     });

//     it("should throw an error if there are missing parameters", async () => {
//       await assert.isRejected(m.searchCustomer("access_token"), Error);
//       await assert.isRejected(
//         m.searchCustomer({ rloc: "ABCDEF", familyName: "Lever" }),
//         Error
//       );
//     });

//     it("should throw an error if the response does not contain a journey id", async () => {
//       axios.returns(journeysData);
//       const res = await m.searchCustomer("access_token", {
//         rloc: "ABCDEF",
//         familyName: "Lever",
//       });
//       const hasJourneyIdProp = res.data.every((journey) =>
//         journey.hasOwnProperty("id")
//       );

//       // Check if hasJourneyIdProp is false and throw an error if it is
//       if (!hasJourneyIdProp) {
//         assert.rejects(() => {
//           throw new Error("Journey ID not found in response");
//         });
//       }
//     });

//     it("should contain journey element id", async () => {
//       axios.returns(journeyElementsData);
//       const res = await m.getJourneyElementsInformationInAJourney(
//         "access_token",
//         "journeyId"
//       );
//       const hasJourneyElementIdProp = res.every((journey) =>
//         journey.hasOwnProperty("id")
//       );
//       assert.equal(hasJourneyElementIdProp, true);
//     });
//   });

//   describe("get and update requirements", () => {
//     after(() => {
//       axios.reset();
//     });

//     it("should return required documents", async () => {
//       axios.returns(eligibilityData);
//       const res = await m.fetchRequiredDocuments(
//         "access_token",
//         "travelerId",
//         "journeyId"
//       );
//       assert(axios.calledOnce);
//       assert.strictEqual(res.data.statusCleared, false);
//       assert(
//         Array.isArray(res.data.missingDetails) &&
//           res.data.missingDetails.length > 0 &&
//           res.data.hasOwnProperty("missingDetails")
//       );
//     });

//     it("should update required documents", async () => {
//       axios.returns(documentData);
//       const res = await m.updateDocs(
//         "access_token",
//         { type: "RESIDENT_ADDRESS", countryOfResidence: "USA" },
//         "travelerId",
//         "journeyId"
//       );
//       assert.strictEqual(res.data.statusCleared, true);
//       assert.equal(res.data.hasOwnProperty("missingDetails"), false);
//     });

//     it("should update contacts information", async () => {
//       axios.returns(contactsData);
//       const response = await m.updateContactInformation(
//         "access_token",
//         "journeyId"
//       );
//       assert.strictEqual(response.hasOwnProperty("contacts"), true);
//       assert.strictEqual(Array.isArray(response.contacts), true);

//       for (const contact of response.contacts) {
//         assert.strictEqual(typeof contact.id, "string");
//         assert.strictEqual(typeof contact.category, "string");
//         assert.strictEqual(typeof contact.contactType, "string");
//         assert.strictEqual(typeof contact.purpose, "string");
//         assert.strictEqual(Array.isArray(contact.travelerIds), true);
//         assert.strictEqual(contact.travelerIds.length, 1);

//         if (contact.contactType === "Email") {
//           assert.strictEqual(typeof contact.address, "string");
//         } else if (contact.contactType === "Phone") {
//           assert.strictEqual(typeof contact.number, "string");
//         }
//       }
//     });
//   });

//   describe("acceptance", () => {
//     after(() => {
//       axios.reset();
//     });

//     it("should succeed", async () => {
//       axios.returns({
//         data: acceptData,
//       });
//       const res = await m.acceptanceByJourneyElementId(
//         "access_token",
//         "journeyElementId"
//       );
//       assert(axios.calledOnce);
//       assert.deepEqual(res, acceptData);
//     });

//     it("should throw an error if there is axios error", async () => {
//       axios.returns({
//         data: "Could not find the data node in getFlightElementIdsOfTraveler function",
//       });
//       const res = await m.acceptanceByJourneyElementId(
//         "token",
//         "journeyElementId"
//       );
//       assert.deepEqual(
//         res,
//         "Could not find the data node in getFlightElementIdsOfTraveler function"
//       );
//     });

//     it("should throw an error if there are missing parameters", async () => {
//       await assert.isRejected(m.acceptanceByJourneyElementId("access_token"));
//       await assert.isRejected(
//         m.acceptanceByJourneyElementId("journeyElementId")
//       );
//     });
//   });

//   describe("boardingpass", () => {
//     after(() => {
//       axios.reset();
//     });

//     it("should throw an error if there are missing parameters", async () => {
//       await assert.isRejected(m.fetchBoardingPass("access_token"));
//       await assert.isRejected(m.fetchBoardingPass("journeyId"));
//     });

//     it("should succeed", async () => {
//       axios.returns(boardingPassData);
//       const formats = await m.fetchBoardingPass("access_token", "journeyId");
//       assert.deepEqual(formats, boardingPassData);
//     });

//     it("should fetch boarding pass for single journey element id", async () => {
//       axios.returns({
//         data: [
//           {
//             journeyElementIds: ["journeyElementId"],
//             result: "inhibited",
//           },
//         ],
//       });
//       const formats = await m.fetchBoardingPassByJourneyElementId("session", "journeyId", "journeyElementId")
      
//       const journeyElementIdsArray = formats[0].journeyElementIds;

//       assert.ok(journeyElementIdsArray.includes('journeyElementId'));
      
//     });

//   });
// });