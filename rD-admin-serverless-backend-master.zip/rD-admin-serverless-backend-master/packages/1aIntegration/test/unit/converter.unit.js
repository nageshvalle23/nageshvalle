// const chai = require('chai');
// const assert = chai.assert;
// const sinon = require("sinon");
// const proxyquire = require("proxyquire");
// const _ = require('lodash');

// const m = require('../../converter');

// const JOURNEY_INFORMATION_1a = require('../mocks/converters/journeyInformation.json');
// const JOURNEY_ELEMENTS_INFORMATION_1a = require('../mocks/converters/getJourneyElementsInformation.json');
// const FLIGHT_INFORMATION_1a = require('../mocks/converters/flightInformation.json');
// const BOARDING_PASS_1a = require('../mocks/converters/boardingpass1a.json');
// const BOARDING_PASS_1a_null = require('../mocks/converters/boardingpass1a_null.json');
// const BOARDING_PASS_cc = require('../mocks/converters/boardingpasscc.json');
// const BOARDING_PASS_cc_null = require('../mocks/converters/boardingpasscc_null.json');
// const ELIGIBILITY_1a_cleared = require('../mocks/converters/eligibility1a_cleared.json');
// const ELIGIBILITY_1a_personalDetails = require('../mocks/converters/eligibility1a_personalDetails.json');
// const ELIGIBILITY_1a_visa_supported = require('../mocks/converters/eligibility1a_visa_supported.json');
// const ELIGIBILITY_1a_visa_not_supported = require('../mocks/converters/eligibility1a_visa_not_supported.json');
// const ELIGIBILITY_1a_identity_document = require('../mocks/converters/eligibility1a_identitydocument.json');
// const ELIGIBILITY_1a_empty = require('../mocks/converters/eligibility1a_empty.json');
// const ELIGIBILITY_1a_visa_stored = require('../mocks/converters/eligibility1a_visa_stored.json');



// const placeholderStub = (fnName) => () => {
//     throw new Error("Please stub this function call: " + fnName);
// };

// const createStubs = (customStubs) =>
//     _.defaults({}, customStubs, {
//         ["./api"]: {
//             fetchBoardingPassByJourneyElementId: placeholderStub("fetchBoardingPassByJourneyElementId")
//         }
//     });


// describe('converters.js', () => {

//     const fetchBoardingPassByJourneyElementId = sinon.stub();
//     // const getJourneyElementsInformationInAJourney = sinon.stub();
//     // const fetchBoardingPassByJourneyElementId = sinon.stub();


//     const myMockModule = proxyquire('../../converter',
//         createStubs({
//             ["./api"]: {
//                 fetchBoardingPassByJourneyElementId: fetchBoardingPassByJourneyElementId
//             }
//         })
//     );

//     describe('getJourneyElementsInformation', () => {
//         it('should get journey elements information when traveler id matches', () => {
//             const travelerId = '510841E50001CA28';
//             const r = m.getJourneyElementsInformation(JOURNEY_INFORMATION_1a, travelerId);
//             assert.deepEqual(r, JOURNEY_ELEMENTS_INFORMATION_1a);
//         });

//         it('should return empty when no traveler id matches', () => {
//             const travelerId = 'XYZ';
//             const r = m.getJourneyElementsInformation(JOURNEY_INFORMATION_1a, travelerId);
//             assert.deepEqual(r, []);
//         })
//     });


//     describe('makeCoupon', () => {
//         it('should return null boarding pass', () => {
//             const flightId = 'MH-642-20230428';
//             const journeyElementId = '500951E5000607DC';
//             const r = m.makeCouponObject(flightId, FLIGHT_INFORMATION_1a, boardingPassInformation = null, checkedInStatus = 'accepted', isCheckInInhibited = false, journeyElementId);
//             const expectedResponse = {
//                 flightNumber: '642',
//                 departureDateTime: '2023-04-28T12:50:00+08:00',
//                 carrierCode: 'MH',
//                 origin: 'SIN',
//                 eTicketNumber: journeyElementId,
//                 destination: 'KCH',
//                 isCheckedIn: true,
//                 isCheckedInInhibited: false,
//                 boardingPass: boardingPassInformation
//             }
//             assert.deepEqual(r, expectedResponse)
//         })

//         it('should return boarding pass object in boardingPass when boarding pass populated', () => {
//             const flightId = 'MH-642-20230428';
//             const journeyElementId = '500951E5000607DC';
//             const mockBoardingPassInformationCC = {
//                 barcodedata: 'pqr',
//                 seatNumber: 'pqr',
//                 passengerClass: 'pqr',
//                 boardingTime: 'pqr',
//                 eTicketNumber: '2322467573693',
//                 frequentFlyerNumber: 'pqr',
//                 gate: 'pqr',
//                 terminal: 'pqr',
//                 securityNumber: null,
//                 boardingGroup: 'pqr',
//                 allowTSA: 'pqr',
//                 allowFastTrack: 'pqr',
//                 mobilewallerURL_ios: null,
//                 mobilewalletURL_android: null
//             }

//             const expectedResponse = {
//                 flightNumber: '642',
//                 departureDateTime: '2023-04-28T12:50:00+08:00',
//                 carrierCode: 'MH',
//                 origin: 'SIN',
//                 eTicketNumber: '2322467573693',
//                 destination: 'KCH',
//                 isCheckedIn: true,
//                 isCheckedInInhibited: false,
//                 boardingPass: mockBoardingPassInformationCC
//             }
//             const r = m.makeCouponObject(flightId, FLIGHT_INFORMATION_1a, mockBoardingPassInformationCC, checkedInStatus = 'accepted', isCheckInInhibited = false, journeyElementId);
//             assert.deepEqual(r, expectedResponse)
//         })
//     })

//     describe('convertToCCBoardingPass', () => {

//         console.info('Testing conversion of cc boarding pass')

//         it('should return cc boarding pass node', () => {
//             const r = m.convertToCCBoardingPass(BOARDING_PASS_1a);
//             assert.deepEqual(r, BOARDING_PASS_cc);
//         })

//         it('should return null value fields when corresponding boarding pass field not present', () => {
//             const r = m.convertToCCBoardingPass(BOARDING_PASS_1a_null);
//             assert.deepEqual(r, BOARDING_PASS_cc_null);
//         })

//     })


//     describe('generateRequiredDocuments', () => {
//         it('should return empty array when statusCleared that is no documents to be updated', () => {
//             const r = m.generateRequiredDocuments({ data: ELIGIBILITY_1a_cleared });
//             assert.deepEqual(r, []);
//         })

//         it('should return empty array when no missing details', () => {
//             const r = m.generateRequiredDocuments({ data: ELIGIBILITY_1a_cleared });
//             assert.deepEqual(r, []);
//         })

//         it('should return PASSPORT and RESIDENT_ADDRESS when personalDetails', () => {
//             const r = m.generateRequiredDocuments({ data: ELIGIBILITY_1a_personalDetails });
//             assert.deepEqual(r, ['PASSPORT', 'RESIDENT_ADDRESS'])
//         })

//         it('should return VISA when required fields within cc visa scope', () => {
//             const r = m.generateRequiredDocuments({ data: ELIGIBILITY_1a_visa_supported });
//             assert.deepEqual(r, ['VISA', 'RESIDENT_ADDRESS'])
//         })

//         it('should return SEE_AGENT when required fields not within cc visa scope', () => {
//             const r = m.generateRequiredDocuments({ data: ELIGIBILITY_1a_visa_not_supported });
//             assert.deepEqual(r, ['SEE_AGENT'])
//         })

//         it('should return PASSPORT when identity document', () => {
//             const r = m.generateRequiredDocuments({ data: ELIGIBILITY_1a_identity_document });
//             assert.deepEqual(r, ['PASSPORT', 'RESIDENT_ADDRESS'])
//         })
//     })

//     describe('generateExistingDocument', () => {
//         it('should return no existing docs when no details are stored', () => {
//             const r = m.generateExistingDocument({ data: ELIGIBILITY_1a_empty });
//             assert.deepEqual(r, []);
//         })

//         it('should return existing docs as personalDetails as PASSPORT and RESIDENT_ADDRESS when details stored', () => {
//             const r = m.generateExistingDocument({ data: ELIGIBILITY_1a_cleared });
//             assert.deepEqual(r, ['PASSPORT', 'RESIDENT_ADDRESS']);
//         })

//         it('should return VISA when visa is stored', () => {
//             const r = m.generateExistingDocument({ data: ELIGIBILITY_1a_visa_stored });
//             assert.deepEqual(r, ['PASSPORT', 'RESIDENT_ADDRESS', 'VISA']);
//         })
//     })


//     describe('createCoupons', () => {
//         it('should return the coupon object with boarding pass object when request type boarding pass and passenger checkedin', async () => {
//             fetchBoardingPassByJourneyElementId.returns(require('../mocks/converters/boardingpass1a_createCoupons.json'));
//             const travelerMock = {
//                 id: "510D91E7000292A3",
//                 firstName: "KENNY",
//                 lastName: "ROGERS",
//                 title: "MR",
//                 flightsInformation: [
//                     {
//                         travelerId: "510D91E7000292A3",
//                         journeyElementId: "500E21E800025FF2",
//                         checkInStatus: "accepted",
//                         boardingPassPrintStatus: "needPrinting",
//                         acceptanceEligibility: "ineligible",
//                     },
//                 ],
//                 journeyId: "3EB01982FBB9B47B2B1F9162B930E7E2B25F0D651683516506",
//                 ageCatagory: "ADT",
//             };

//             const flightIdsLinkedToJourneyElements = {
//                 "500E21E800025FF1": "MH-2646-20230430",
//                 "500E21E800025FF2": "MH-2646-20230430",
//             };

//             const journey = {
//                 data: {
//                     data: [
//                         {
//                             acceptance: {
//                                 checkedInJourneyElements: [
//                                     {
//                                         id: "500E21E800025FF1",
//                                     },
//                                     {
//                                         id: "500E21E800025FF2",
//                                     },
//                                 ],
//                                 isAccepted: true,
//                                 isEligibleForVoluntaryDeniedBoarding: false,
//                                 isPartial: false,
//                                 isVoluntaryDeniedBoarding: false,
//                             },
//                             acceptanceEligibility: {
//                                 eligibilityWindow: {
//                                     closingDateAndTime: "2023-04-30T10:05:00+08:00",
//                                     openingDateAndTime: "2023-04-26T11:35:00+08:00",
//                                 },
//                                 reasons: [
//                                     "flightAcceptanceEligibilityWindow",
//                                 ],
//                                 status: "ineligible",
//                             },
//                             contacts: [
//                                 {
//                                     address: "RIZAL.RAZALI@MALAYSIAAIRLINES.COM",
//                                     category: "personal",
//                                     contactType: "Email",
//                                     id: "510D91E7000292A2_a5feae86",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A2",
//                                     ],
//                                 },
//                                 {
//                                     category: "personal",
//                                     contactType: "Phone",
//                                     id: "510D91E7000292A2_c7803524",
//                                     number: "60133231",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A2",
//                                     ],
//                                 },
//                                 {
//                                     address: "RIZAL.RAZALI@MALAYSIAAIRLINES.COM",
//                                     category: "personal",
//                                     contactType: "Email",
//                                     id: "510D91E7000292A3_a5feae86",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A3",
//                                     ],
//                                 },
//                                 {
//                                     category: "personal",
//                                     contactType: "Phone",
//                                     id: "510D91E7000292A3_c7803524",
//                                     number: "60133231",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A3",
//                                     ],
//                                 },
//                             ],
//                             flights: [
//                                 {
//                                     id: "MH-2646-20230430",
//                                 },
//                             ],
//                             id: "0636772A600A51574BA0D7FBF457CC2AAE1DAE771683517823",
//                             isGroupBooking: false,
//                             journeyElements: [
//                                 {
//                                     id: "500E21E800025FF1",
//                                 },
//                                 {
//                                     id: "500E21E800025FF2",
//                                 },
//                             ],
//                             travelers: [
//                                 {
//                                     dateOfBirth: "1980-07-25",
//                                     gender: "male",
//                                     id: "510D91E7000292A2",
//                                     isPilgrimConfirmationProvided: false,
//                                     names: [
//                                         {
//                                             firstName: "ANNE",
//                                             lastName: "ROGERS",
//                                             nameType: "universal",
//                                             title: "MRS",
//                                         },
//                                     ],
//                                     passengerTypeCode: "ADT",
//                                 },
//                                 {
//                                     dateOfBirth: "1980-07-25",
//                                     gender: "male",
//                                     id: "510D91E7000292A3",
//                                     isPilgrimConfirmationProvided: false,
//                                     names: [
//                                         {
//                                             firstName: "KENNY",
//                                             lastName: "ROGERS",
//                                             nameType: "universal",
//                                             title: "MR",
//                                         },
//                                     ],
//                                     passengerTypeCode: "ADT",
//                                 },
//                             ],
//                             type: "standalone",
//                         },
//                     ],
//                     dictionaries: {
//                         aircraft: {
//                             "333": "AIRBUS A330-300",
//                         },
//                         airline: {
//                             MH: "MALAYSIA AIRLINES",
//                         },
//                         country: {
//                             MY: "MALAYSIA",
//                         },
//                         flight: {
//                             "MH-2646-20230430": {
//                                 acceptanceStatus: "finalized",
//                                 aircraftCode: "333",
//                                 arrival: {
//                                     dateTime: "2023-04-30T14:15:00+08:00",
//                                     locationCode: "BKI",
//                                     terminal: "1",
//                                 },
//                                 departure: {
//                                     dateTime: "2023-04-30T11:35:00+08:00",
//                                     locationCode: "KUL",
//                                     terminal: "1",
//                                 },
//                                 duration: 9600,
//                                 id: "MH-2646-20230430",
//                                 isIATCI: false,
//                                 isPilgrimConfirmationRequired: false,
//                                 marketingAirlineCode: "MH",
//                                 marketingFlightNumber: "2646",
//                                 operatingAirlineCode: "MH",
//                                 operatingAirlineFlightNumber: "2646",
//                                 operatingAirlineName: "MALAYSIA AIRLINES",
//                                 operatingFlightNumber: "2646",
//                                 status: "scheduled",
//                             },
//                         },
//                         journeyElement: {
//                             "500E21E800025FF1": {
//                                 acceptanceEligibility: {
//                                     eligibilityWindow: {
//                                         closingDateAndTime: "2023-04-30T10:05:00+08:00",
//                                         openingDateAndTime: "2023-04-26T11:35:00+08:00",
//                                     },
//                                     reasons: [
//                                         "flightAcceptanceEligibilityWindow",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassEligibility: {
//                                     reasons: [
//                                         "flightEligibilityRule",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassPrintStatus: "needPrinting",
//                                 boardingStatus: "notBoarded",
//                                 cabin: "Y",
//                                 checkInStatus: "accepted",
//                                 flightId: "MH-2646-20230430",
//                                 id: "500E21E800025FF1",
//                                 orderId: "6RCGQ8",
//                                 seat: {
//                                     cabin: "Y",
//                                     isInfantAloneOnSeat: false,
//                                     isInfantOnSeat: false,
//                                     seatAvailabilityStatus: "occupied",
//                                     seatCharacteristicsCodes: [
//                                         "N",
//                                         "W",
//                                     ],
//                                     seatNumber: "16A",
//                                 },
//                                 seatmapEligibility: {
//                                     status: "eligible",
//                                 },
//                                 travelerId: "510D91E7000292A2",
//                             },
//                             "500E21E800025FF2": {
//                                 acceptanceEligibility: {
//                                     eligibilityWindow: {
//                                         closingDateAndTime: "2023-04-30T10:05:00+08:00",
//                                         openingDateAndTime: "2023-04-26T11:35:00+08:00",
//                                     },
//                                     reasons: [
//                                         "flightAcceptanceEligibilityWindow",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassEligibility: {
//                                     reasons: [
//                                         "flightEligibilityRule",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassPrintStatus: "needPrinting",
//                                 boardingStatus: "notBoarded",
//                                 cabin: "Y",
//                                 checkInStatus: "accepted",
//                                 flightId: "MH-2646-20230430",
//                                 id: "500E21E800025FF2",
//                                 orderId: "6RCGQ8",
//                                 seat: {
//                                     cabin: "Y",
//                                     isInfantAloneOnSeat: false,
//                                     isInfantOnSeat: false,
//                                     seatAvailabilityStatus: "occupied",
//                                     seatCharacteristicsCodes: [
//                                         "A",
//                                         "N",
//                                     ],
//                                     seatNumber: "16C",
//                                 },
//                                 seatmapEligibility: {
//                                     status: "eligible",
//                                 },
//                                 travelerId: "510D91E7000292A3",
//                             },
//                         },
//                         location: {
//                             BKI: {
//                                 airportName: "KOTA KINABALU INTERNATIONAL",
//                                 cityCode: "BKI",
//                                 cityName: "KOTA KINABALU",
//                                 countryCode: "MY",
//                                 stateCode: "",
//                                 type: "airport",
//                             },
//                             KUL: {
//                                 airportName: "KUALA LUMPUR I",
//                                 cityCode: "KUL",
//                                 cityName: "KUALA LUMPUR",
//                                 countryCode: "MY",
//                                 stateCode: "",
//                                 type: "airport",
//                             },
//                         },
//                         traveler: {
//                             "510D91E7000292A2": {
//                                 dateOfBirth: "1980-07-25",
//                                 gender: "male",
//                                 id: "510D91E7000292A2",
//                                 isPilgrimConfirmationProvided: false,
//                                 names: [
//                                     {
//                                         firstName: "ANNE",
//                                         lastName: "ROGERS",
//                                         nameType: "universal",
//                                         title: "MRS",
//                                     },
//                                 ],
//                                 passengerTypeCode: "ADT",
//                             },
//                             "510D91E7000292A3": {
//                                 dateOfBirth: "1980-07-25",
//                                 gender: "male",
//                                 id: "510D91E7000292A3",
//                                 isPilgrimConfirmationProvided: false,
//                                 names: [
//                                     {
//                                         firstName: "KENNY",
//                                         lastName: "ROGERS",
//                                         nameType: "universal",
//                                         title: "MR",
//                                     },
//                                 ],
//                                 passengerTypeCode: "ADT",
//                             },
//                         },
//                     },
//                 }
//             }

//             const requestOptions = {
//                 status: "200",
//                 methodType: "boardingpass"
//             }


//             const session = {
//                 session: "abc"
//             }

//             const r = await myMockModule.createCoupons(travelerMock, flightIdsLinkedToJourneyElements, journey, requestOptions, session);

//             assert.deepEqual(r, require('../mocks/converters/coupons_mock_withbp.json'));

//         })

//         it('should return the coupon object with null boarding pass if request type is not boarding pass', async () => {
//             fetchBoardingPassByJourneyElementId.returns(require('../mocks/converters/boardingpass1a_createCoupons.json'));
//             const travelerMock = {
//                 id: "510D91E7000292A3",
//                 firstName: "KENNY",
//                 lastName: "ROGERS",
//                 title: "MR",
//                 flightsInformation: [
//                     {
//                         travelerId: "510D91E7000292A3",
//                         journeyElementId: "500E21E800025FF2",
//                         checkInStatus: "accepted",
//                         boardingPassPrintStatus: "needPrinting",
//                         acceptanceEligibility: "ineligible",
//                     },
//                 ],
//                 journeyId: "3EB01982FBB9B47B2B1F9162B930E7E2B25F0D651683516506",
//                 ageCatagory: "ADT",
//             };

//             const flightIdsLinkedToJourneyElements = {
//                 "500E21E800025FF1": "MH-2646-20230430",
//                 "500E21E800025FF2": "MH-2646-20230430",
//             };

//             const journey = {
//                 data: {
//                     data: [
//                         {
//                             acceptance: {
//                                 checkedInJourneyElements: [
//                                     {
//                                         id: "500E21E800025FF1",
//                                     },
//                                     {
//                                         id: "500E21E800025FF2",
//                                     },
//                                 ],
//                                 isAccepted: false,
//                                 isEligibleForVoluntaryDeniedBoarding: false,
//                                 isPartial: false,
//                                 isVoluntaryDeniedBoarding: false,
//                             },
//                             acceptanceEligibility: {
//                                 eligibilityWindow: {
//                                     closingDateAndTime: "2023-04-30T10:05:00+08:00",
//                                     openingDateAndTime: "2023-04-26T11:35:00+08:00",
//                                 },
//                                 reasons: [
//                                     "flightAcceptanceEligibilityWindow",
//                                 ],
//                                 status: "ineligible",
//                             },
//                             contacts: [
//                                 {
//                                     address: "RIZAL.RAZALI@MALAYSIAAIRLINES.COM",
//                                     category: "personal",
//                                     contactType: "Email",
//                                     id: "510D91E7000292A2_a5feae86",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A2",
//                                     ],
//                                 },
//                                 {
//                                     category: "personal",
//                                     contactType: "Phone",
//                                     id: "510D91E7000292A2_c7803524",
//                                     number: "60133231",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A2",
//                                     ],
//                                 },
//                                 {
//                                     address: "RIZAL.RAZALI@MALAYSIAAIRLINES.COM",
//                                     category: "personal",
//                                     contactType: "Email",
//                                     id: "510D91E7000292A3_a5feae86",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A3",
//                                     ],
//                                 },
//                                 {
//                                     category: "personal",
//                                     contactType: "Phone",
//                                     id: "510D91E7000292A3_c7803524",
//                                     number: "60133231",
//                                     purpose: "notification",
//                                     travelerIds: [
//                                         "510D91E7000292A3",
//                                     ],
//                                 },
//                             ],
//                             flights: [
//                                 {
//                                     id: "MH-2646-20230430",
//                                 },
//                             ],
//                             id: "0636772A600A51574BA0D7FBF457CC2AAE1DAE771683517823",
//                             isGroupBooking: false,
//                             journeyElements: [
//                                 {
//                                     id: "500E21E800025FF1",
//                                 },
//                                 {
//                                     id: "500E21E800025FF2",
//                                 },
//                             ],
//                             travelers: [
//                                 {
//                                     dateOfBirth: "1980-07-25",
//                                     gender: "male",
//                                     id: "510D91E7000292A2",
//                                     isPilgrimConfirmationProvided: false,
//                                     names: [
//                                         {
//                                             firstName: "ANNE",
//                                             lastName: "ROGERS",
//                                             nameType: "universal",
//                                             title: "MRS",
//                                         },
//                                     ],
//                                     passengerTypeCode: "ADT",
//                                 },
//                                 {
//                                     dateOfBirth: "1980-07-25",
//                                     gender: "male",
//                                     id: "510D91E7000292A3",
//                                     isPilgrimConfirmationProvided: false,
//                                     names: [
//                                         {
//                                             firstName: "KENNY",
//                                             lastName: "ROGERS",
//                                             nameType: "universal",
//                                             title: "MR",
//                                         },
//                                     ],
//                                     passengerTypeCode: "ADT",
//                                 },
//                             ],
//                             type: "standalone",
//                         },
//                     ],
//                     dictionaries: {
//                         aircraft: {
//                             "333": "AIRBUS A330-300",
//                         },
//                         airline: {
//                             MH: "MALAYSIA AIRLINES",
//                         },
//                         country: {
//                             MY: "MALAYSIA",
//                         },
//                         flight: {
//                             "MH-2646-20230430": {
//                                 acceptanceStatus: "finalized",
//                                 aircraftCode: "333",
//                                 arrival: {
//                                     dateTime: "2023-04-30T14:15:00+08:00",
//                                     locationCode: "BKI",
//                                     terminal: "1",
//                                 },
//                                 departure: {
//                                     dateTime: "2023-04-30T11:35:00+08:00",
//                                     locationCode: "KUL",
//                                     terminal: "1",
//                                 },
//                                 duration: 9600,
//                                 id: "MH-2646-20230430",
//                                 isIATCI: false,
//                                 isPilgrimConfirmationRequired: false,
//                                 marketingAirlineCode: "MH",
//                                 marketingFlightNumber: "2646",
//                                 operatingAirlineCode: "MH",
//                                 operatingAirlineFlightNumber: "2646",
//                                 operatingAirlineName: "MALAYSIA AIRLINES",
//                                 operatingFlightNumber: "2646",
//                                 status: "scheduled",
//                             },
//                         },
//                         journeyElement: {
//                             "500E21E800025FF1": {
//                                 acceptanceEligibility: {
//                                     eligibilityWindow: {
//                                         closingDateAndTime: "2023-04-30T10:05:00+08:00",
//                                         openingDateAndTime: "2023-04-26T11:35:00+08:00",
//                                     },
//                                     reasons: [
//                                         "flightAcceptanceEligibilityWindow",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassEligibility: {
//                                     reasons: [
//                                         "flightEligibilityRule",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassPrintStatus: "needPrinting",
//                                 boardingStatus: "notBoarded",
//                                 cabin: "Y",
//                                 checkInStatus: "accepted",
//                                 flightId: "MH-2646-20230430",
//                                 id: "500E21E800025FF1",
//                                 orderId: "6RCGQ8",
//                                 seat: {
//                                     cabin: "Y",
//                                     isInfantAloneOnSeat: false,
//                                     isInfantOnSeat: false,
//                                     seatAvailabilityStatus: "occupied",
//                                     seatCharacteristicsCodes: [
//                                         "N",
//                                         "W",
//                                     ],
//                                     seatNumber: "16A",
//                                 },
//                                 seatmapEligibility: {
//                                     status: "eligible",
//                                 },
//                                 travelerId: "510D91E7000292A2",
//                             },
//                             "500E21E800025FF2": {
//                                 acceptanceEligibility: {
//                                     eligibilityWindow: {
//                                         closingDateAndTime: "2023-04-30T10:05:00+08:00",
//                                         openingDateAndTime: "2023-04-26T11:35:00+08:00",
//                                     },
//                                     reasons: [
//                                         "flightAcceptanceEligibilityWindow",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassEligibility: {
//                                     reasons: [
//                                         "flightEligibilityRule",
//                                     ],
//                                     status: "ineligible",
//                                 },
//                                 boardingPassPrintStatus: "needPrinting",
//                                 boardingStatus: "notBoarded",
//                                 cabin: "Y",
//                                 checkInStatus: "accepted",
//                                 flightId: "MH-2646-20230430",
//                                 id: "500E21E800025FF2",
//                                 orderId: "6RCGQ8",
//                                 seat: {
//                                     cabin: "Y",
//                                     isInfantAloneOnSeat: false,
//                                     isInfantOnSeat: false,
//                                     seatAvailabilityStatus: "occupied",
//                                     seatCharacteristicsCodes: [
//                                         "A",
//                                         "N",
//                                     ],
//                                     seatNumber: "16C",
//                                 },
//                                 seatmapEligibility: {
//                                     status: "eligible",
//                                 },
//                                 travelerId: "510D91E7000292A3",
//                             },
//                         },
//                         location: {
//                             BKI: {
//                                 airportName: "KOTA KINABALU INTERNATIONAL",
//                                 cityCode: "BKI",
//                                 cityName: "KOTA KINABALU",
//                                 countryCode: "MY",
//                                 stateCode: "",
//                                 type: "airport",
//                             },
//                             KUL: {
//                                 airportName: "KUALA LUMPUR I",
//                                 cityCode: "KUL",
//                                 cityName: "KUALA LUMPUR",
//                                 countryCode: "MY",
//                                 stateCode: "",
//                                 type: "airport",
//                             },
//                         },
//                         traveler: {
//                             "510D91E7000292A2": {
//                                 dateOfBirth: "1980-07-25",
//                                 gender: "male",
//                                 id: "510D91E7000292A2",
//                                 isPilgrimConfirmationProvided: false,
//                                 names: [
//                                     {
//                                         firstName: "ANNE",
//                                         lastName: "ROGERS",
//                                         nameType: "universal",
//                                         title: "MRS",
//                                     },
//                                 ],
//                                 passengerTypeCode: "ADT",
//                             },
//                             "510D91E7000292A3": {
//                                 dateOfBirth: "1980-07-25",
//                                 gender: "male",
//                                 id: "510D91E7000292A3",
//                                 isPilgrimConfirmationProvided: false,
//                                 names: [
//                                     {
//                                         firstName: "KENNY",
//                                         lastName: "ROGERS",
//                                         nameType: "universal",
//                                         title: "MR",
//                                     },
//                                 ],
//                                 passengerTypeCode: "ADT",
//                             },
//                         },
//                     },
//                 }
//             }

//             const requestOptions = {
//                 status: "200",
//                 methodType: "record"
//             }


//             const session = {
//                 session: "abc"
//             }

//             const r = await myMockModule.createCoupons(travelerMock, flightIdsLinkedToJourneyElements, journey, requestOptions, session);

//             assert.deepEqual(r, require('../mocks/converters/coupons_mock_withoutbp.json'));

//         })

//     })
// });

