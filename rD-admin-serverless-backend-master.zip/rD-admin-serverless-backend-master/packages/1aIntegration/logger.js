const { store } = require('./store');

exports.createLogger = (res) => {
    console.log(JSON.stringify(res.data), 'transaction id --> ', store.transactionId);
    console.log(`${res.headers['ama-gateway-request-id']}= ama-gateway-request-id ${res.headers['ama-request-id']}=ama-request-id ${res.headers['date']}=date`, 'transaction id --> ', store.transactionId)
}


exports.logApiData = (res, methodName, err) => {

    if (err && err.response) {
        res = err.response;
    }

    console.log(`Response Headers for method :- ${methodName}`, 'transaction id --> ', store.transactionId);
    if (res.headers) {
        console.log(`ama-gateway-request-id => ${res.headers['ama-gateway-request-id']} \nama-request-id => ${res.headers['ama-request-id']} \ndate => ${res.headers['date']}`, 'transaction id --> ', store.transactionId)
    } else console.log('No Header data recieved', 'transaction id --> ', store.transactionId);
    if (res.data) {
        console.log(`Response Body for method: ${methodName}: \n ${JSON.stringify(res.data)}`, 'transaction id --> ', store.transactionId);
    } else {
        console.log('No response body for this method', 'transaction id --> ', store.transactionId);
    }
}