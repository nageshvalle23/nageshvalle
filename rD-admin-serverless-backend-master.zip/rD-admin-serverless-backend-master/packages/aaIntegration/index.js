require( "dotenv" ).config();
const axios = require( "axios" );
const { response, body } = require( '@oneworld-digital/integration-utils' ).request;
const _handleErrors = require( './handleErrorsMethod' );
const uuid = require( "uuid" ).v1;
const http_500 = "Internal Server Error!";

/* get auth token */
async function auth( event ) {
  const ccTransactionId = event.headers[ 'x-cc-request-id' ]
  const clientCarrier = event.headers[ 'x-client-carrier' ]

  /* validate configuration */
  if ( typeof process.env.AA_API_AUTH_URL === 'undefined' || typeof process.env.AA_API_URL === 'undefined' || typeof process.env.AA_ENV === 'undefined' || typeof process.env.AA_CLIENT_ID === 'undefined' || typeof process.env.AA_CLIENT_SECRET === 'undefined' || typeof process.env.AA_API_TIMEOUT === 'undefined' ) {
    console.info( '----ERROR:auth missing configuration data' )
    throw new Error( http_500 );
  }

  const options = {
    method: "POST",
    url: process.env.AA_API_AUTH_URL,
    timeout: process.env.AA_API_TIMEOUT,
    headers: {
      'User-Agent': 'carrier-connect',
      'Content-Type': 'application/x-www-form-urlencoded',
      'x-client-carrier': clientCarrier,
      'x-cc-request-id': ccTransactionId,
      'x-cc-client-id': 'CARRIER-CONNECT-' + clientCarrier
    },
    data: {
      'client_secret': process.env.AA_CLIENT_SECRET,
      'client_id': process.env.AA_CLIENT_ID,
      'grant_type': 'client_credentials'
    }
  };
  if ( process.env.AA_ENV !== 'prod' )
    console.info( '\n---REQUEST:auth ', JSON.stringify( options ) )

  let res = null;
  try {
    res = await axios( options );
    if ( process.env.AA_ENV !== 'prod' )
      console.info( '\n---RESPONSE:auth ', res.status, JSON.stringify( res.data ) )
  } catch ( error ) {
    if ( process.env.AA_ENV === 'prod' )
      console.info( '\n---REQUEST:auth ', JSON.stringify( options ) )
      console.error( '\n----RESPONSE:auth', err.response.status, JSON.stringify(err.response.data) )

    throw new Error( http_500 );
  }
  if ( res.status !== 200 || typeof res.data.token !== 'string' ) {
    console.error( '\n----RESPONSE:auth2', res.status, JSON.stringify( res.data ) )
    throw new Error( http_500 );
  }

  return res.data.token;
}

/* handle call */
async function handleRequest( event, cb, url ) {
  let ccTransactionId = null;

  ccTransactionId = event.headers[ 'x-cc-request-id' ]
  const clientCarrier = event.headers[ 'x-client-carrier' ]
  const request_body = body( event );
  const session_token = await auth( event );

  const options = {
    method: "POST",
    url: process.env.AA_API_URL + url,
    timeout: process.env.AA_API_TIMEOUT,
    headers: {
      'User-Agent': 'carrier-connect',
      'Content-Type': 'application/json',
      'x-client-carrier': clientCarrier,
      'x-cc-request-id': ccTransactionId,
      'x-cc-client-id': 'CARRIER-CONNECT-' + clientCarrier,
      'Authorization': 'Bearer ' + session_token
    },
    data: request_body
  };
  if ( process.env.AA_ENV !== 'prod' )
    console.info( '\n---REQUEST: ', JSON.stringify( options ) )
  try {
    const res = await axios( options );
    if ( process.env.AA_ENV !== 'prod' )
      console.info( '\n---RESPONSE: ', res.status, JSON.stringify( res.data ) )
    return cb( null, response( 200, res.data ) );
  } catch ( err ) {
    console.info( '\n----ccTransactionId:', ccTransactionId )

    if ( process.env.AA_ENV === 'prod' )
      console.info( '\n---REQUEST: ', ccTransactionId, JSON.stringify( options ) )

    console.error( '\n----RESPONSE:', ccTransactionId, err.response.status, err.response.data )

    let e = { message: http_500 }

    if ( typeof err.response !== 'undefined' && typeof err.response.status !== 'undefined' && err.response.status < 500 ) {
      if ( typeof err.response.data.errors !== 'undefined' ) {
        e = {
          CARRIER_ERROR_CODE: 502,
          CARRIER_ERROR_MESSAGE: JSON.stringify( {
            id: err.response.data.transactionId,
            message: err.response.data.errors[ 0 ].description,
            code: err.response.data.errors[ 0 ].code
          } )
        }
      } else if ( typeof err.response.data.error !== 'undefined' ) {
        e = {
          CARRIER_ERROR_CODE: 502,
          CARRIER_ERROR_MESSAGE: JSON.stringify( {
            message: err.response.data.error_description,
            code: err.response.data.error
          } )
        }
      } else {
        e = {
          CARRIER_ERROR_CODE: 500,
          CARRIER_ERROR_MESSAGE: JSON.stringify( {
            message: http_500,
            code: 500
          } )
        }
      }
      return _handleErrors( e, cb );
    }

  }
};



exports.record = async ( event, context, cb ) => {
  return await handleRequest( event, cb, '/record' )
};

exports.singleAcceptance = async ( event, context, cb ) => {
  return await handleRequest( event, cb, '/acceptance' )
};

exports.multiAcceptance = async ( event, context, cb ) => {
  return await handleRequest( event, cb, '/multiacceptance' )
};

exports.boardingPass = async ( event, context, cb ) => {
  return await handleRequest( event, cb, '/boardingpass' )
};

exports.multiBoardingPass = async ( event, context, cb ) => {
  return await handleRequest( event, cb, '/multiboardingpass' )
};