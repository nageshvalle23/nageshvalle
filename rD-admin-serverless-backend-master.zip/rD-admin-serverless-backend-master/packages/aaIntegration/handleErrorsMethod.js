const uuid = require("uuid").v1;
const {response } = require("@oneworld-digital/integration-utils").request;

function _handleErrors(err, cb) {
    console.error('\n----ERROR: ',err)
    const body = {
        id: uuid(),
        message: err.CARRIER_ERROR_MESSAGE
            ? `Type: ${err.CARRIER_ERROR_MESSAGE}`
            : err.message,
        type: err.CARRIER_ERROR_CODE || err.statusCode ? "OA" : "Internal",
        code: err.CARRIER_ERROR_CODE || "500",
    };

    let responseCode;

    // TODO: 502 vs 500 may not be sufficient. Do we need to support 400 and others?
    if (err.CARRIER_ERROR_MSG || err.CARRIER_ERROR_CODE) {
        responseCode = 502;
    } else {
        responseCode = 500;
    }

    console.error(`Could not satisfy request ${JSON.stringify(body, null, 2)}`);
    return cb(null, response(responseCode, body));
}


module.exports = _handleErrors;