const { test, assert, mockFn } = require('elmer-fudd');
const { promisify } = require('util')

test({
  name: 'ADDS BASE URL TO LINKS',
  unit: './index.js',
  mock: [
    ['./db', {
      listLinks: mockFn().returns([
        {
          slug: 'link-a',
          carriers: {}
        },
        {
          slug: 'link-b',
          carriers: {}
        },
      ]),
    }],
  ],
  spec: async (lamda) => {
    const res = await promisify(lamda.listLinks)({
      pathParameters: {
        slug: 'link-a'
      },
      queryStringParameters: {
        foo: 'xxxx',
      },
    }, { context: true })

    assert.equal(res.statusCode, 200)
    assert.deepEqual(res.headers, { 'Content-Type': 'application/json' })
    assert.deepEqual(JSON.parse(res.body), [
      {
        slug: 'link-a',
        carriers: {},
        base_url: 'https://stage.link.carrierconnect.co/redirect/link-a',
      },
      {
        slug: 'link-b',
        carriers: {},
        base_url: 'https://stage.link.carrierconnect.co/redirect/link-b',
      }
    ])
  }
})

test({
  name: 'GET LINK FOR ALL CARRIERS',
  unit: './index.js',
  mock: [
    ['./db', {
      getLink: mockFn().will([
        { given: ['link-a'], output: {
          slug: 'link-a',
          carriers: {
            BA: { url: 'https://ba.com/{{foo}}' }
          }
        } }
      ]),
    }],
  ],
  spec: async (lamda) => {
    await lamda.getLink({
      pathParameters: {
        slug: 'link-a'
      },
      queryStringParameters: {
        foo: 'xxxx',
      },
    }, {}, (err, res) => {
      assert.equal(res.statusCode, 200)
      assert.deepEqual(res.headers, { 'Content-Type': 'application/json' })
      assert.deepEqual(JSON.parse(res.body), {
        query: {
          foo: 'xxxx',
        },
        carriers: {
          BA: {
            cc_url: 'https://stage.link.carrierconnect.co/redirect/link-a/ba?foo=xxxx',
            target_url: 'https://ba.com/xxxx',
            target_url_raw: 'https://ba.com/{{foo}}',
          }
        }
      })
    })
  }
});

test({
  name: 'GET LINK FOR SINGLE CARRIER',
  unit: './index.js',
  mock: [
    ['./db', {
      getLink: mockFn().will([
        { given: ['link-a'], output: {
          slug: 'link-a',
          carriers: {
            BA: { url: 'https://ba.com/{{foo}}' }
          }
        } }
      ]),
    }],
  ],
  spec: async (lamda) => {
    await lamda.getLink({
      pathParameters: {
        slug: 'link-a',
        carrier: 'ba',
      },
      queryStringParameters: {
        foo: 'yyy',
      },
    }, {}, (err, res) => {
      assert.equal(res.statusCode, 200)
      assert.deepEqual(res.headers, { 'Content-Type': 'application/json' })
      assert.deepEqual(JSON.parse(res.body), {
        cc_url: 'https://stage.link.carrierconnect.co/redirect/link-a/ba?foo=yyy',
        target_url: 'https://ba.com/yyy',
        target_url_raw: 'https://ba.com/{{foo}}',
      })
    })
  }
});

test({
  name: 'GET REDIRECT',
  unit: './index.js',
  mock: [
    ['./db', {
      getLink: mockFn().will([
        { given: ['link-b'], output: {
          slug: 'link-b',
          carriers: {
            AA: { url: 'https://aa.com/{{ bar }}' }
          }
        } }
      ]),
    }],
  ],
  spec: async (lamda) => {
    await lamda.redirect({
      pathParameters: {
        slug: 'link-b',
        carrier: 'aa',
      },
      queryStringParameters: {
        bar: 'yay',
      },
    }, {}, (err, res) => {
      assert.equal(res.statusCode, 302)
      assert.deepEqual(res.headers, {
        'Location': 'https://aa.com/yay'
      })
    })
  }
})

test({
  name: 'GET REDIRECT FOR MISSING LINK',
  unit: './index.js',
  mock: [
    ['./db', {
      getLink: mockFn().will([
        { given: ['link-b'], output: {
          slug: 'link-b',
          carriers: {
            AA: { url: 'https://aa.com/{{ bar }}' }
          }
        } }
      ]),
    }],
  ],
  spec: async (lamda) => {
    await lamda.redirect({
      pathParameters: {
        slug: 'link-b',
        carrier: 'xx',
      },
      queryStringParameters: {
        bar: 'yay',
      },
    }, {}, (err, res) => {
      assert.equal(res.statusCode, 404)
      console.log(res.body)
    })
  }
})

test({
  name: 'GET REDIRECT FOR INVALID LINK',
  unit: './index.js',
  mock: [
    ['./db', {
      getLink: mockFn().will([
        { given: ['link-b'], output: {
          slug: 'link-b',
          carriers: {
            AA: { url: 'https://aa.com/{{ bar | BAD_FILTER }}/{{ baz | OTHER }}' }
          }
        } }
      ]),
    }],
  ],
  spec: async (lamda) => {
    await lamda.redirect({
      pathParameters: {
        slug: 'link-b',
        carrier: 'aa',
      },
      queryStringParameters: {
        bar: 'yay',
      },
    }, {}, (err, res) => {
      assert.equal(res.statusCode, 500)
      assert.equal(res.body, `<ul><li><pre>Could not apply 'BAD_FILTER' to 'bar' because Unknown filter BAD_FILTER</pre></li><li><pre>Could not apply 'OTHER' to 'baz' because Unknown filter OTHER</pre></li></ul>`)
    })
  }
})