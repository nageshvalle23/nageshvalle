const dedent = require('dedent')
const { test, assert } = require('elmer-fudd');

test({
  name: 'PARAMETER SUBSTITUTION',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(
      compileUrl(`abc/{{ param }}/def`, { param: 'foo' }),
      'abc/foo/def'
    );

    assert.equal(
      compileUrl(`abc/{{param}}/{{other}}/def`, { param: 'bar', other: 'ha' }),
      'abc/bar/ha/def'
    );

    assert.equal(
      compileUrl(`{{x}}abc/def`, { x: 'y' }),
      'yabc/def'
    );

    assert.equal(
      compileUrl(`{{x}}abc/def`, {}),
      'abc/def'
    );

    assert.equal(
      compileUrl(`abc/def/{{z}}`, { z: 'Foo Bar'}),
      'abc/def/Foo%20Bar'
    );
  }
});

test({
  name: 'FORMAT DATE',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(
      compileUrl(`abc/{{ input | FORMAT_DATE LL }}/def`, { input: '2020-05-21' }),
      'abc/05/def'
    );

    assert.equal(
      compileUrl(`abc/{{ input | FORMAT_DATE yyyy%20dd }}/def`, { input: '2020-05-21' }),
      'abc/2020%2021/def'
    );

    assert.equal(
      compileUrl(`abc/{{ input | FORMAT_DATE }}/def`, { input: '2020-05-21' }),
      `abc/{{ERROR:Could%20not%20apply%20'FORMAT_DATE'%20to%20'input'%20because%20'FORMAT_DATE'%20requires%20a%20format}}/def`
    );
  }
});

test({
  name: 'UPPER CASE',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(
      compileUrl(`{{ input | UPPER_CASE }}-wow`, { input: 'xyz' }),
      'XYZ-wow'
    );
  }
});

test({
  name: 'LOWER CASE',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(
      compileUrl(`wow-{{ caps | LOWER_CASE }}`, { caps: 'ABC' }),
      'wow-abc'
    );
  }
});

test({
  name: 'DEFAULT',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(
      compileUrl(`wow-{{ caps | DEFAULT yes }}`, {}),
      'wow-yes'
    );

    assert.equal(
      compileUrl(`wow-{{ caps | DEFAULT ?bar }}`, { bar: 'yo' }),
      'wow-yo'
    );
  }
});

test({
  name: 'MAP VALUE',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    // make sure extra spaces don't cause issues!
    const simple = `awesome-{{ fruit | MAP_VALUE    a :> apples    b :>  bananas    }}`

    assert.equal(compileUrl(simple, { fruit: 'a' }), 'awesome-apples');
    assert.equal(compileUrl(simple, { fruit: 'b' }), 'awesome-bananas');
    assert.equal(compileUrl(simple, { fruit: 'x' }), 'awesome-');

    // how unsafe values should be used
    const special = dedent`awesome-{{ fruit | MAP_VALUE  A%20B:>ab B%20A:>ba }}`

    assert.equal(compileUrl(special, { fruit: 'A B' }), 'awesome-ab');
    assert.equal(compileUrl(special, { fruit: 'B A' }), 'awesome-ba');
    assert.equal(compileUrl(special, { fruit: 'X Y' }), 'awesome-');

    const refs = `ref/to/{{ k | MAP_VALUE foo :> ?foo bar :> ?bar }}`

    assert.equal(compileUrl(refs, { k: 'foo', foo: 'yes', bar: 'no' }), 'ref/to/yes');
    assert.equal(compileUrl(refs, { k: 'bar', foo: 'yes', bar: 'no' }), 'ref/to/no');
  }
});

test({
  name: 'WITH DERIVED PARAMETERS',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    const spec = dedent`
      https://aa.com{{ direction | MAP_VALUE one-way:>?one-way round-trip:>?round-trip }}
      WITH_VALUES
        month := {{ date | FORMAT_DATE LLL }}
        one-way := /path/to/one-way?month={{ month | UPPER_CASE }}
        round-trip := /round-trip/path?M={{ month | LOWER_CASE }}
    `

    assert.equal(
      compileUrl(spec, { date: '2020-06-20', direction: 'one-way' }),
      'https://aa.com/path/to/one-way?month=JUN'
    )

    assert.equal(
      compileUrl(spec, { date: '2020-06-20', direction: 'round-trip' }),
      'https://aa.com/round-trip/path?M=jun'
    )
  }
});

test({
  name: 'DERIVED PARAMETERS WITH SPECIAL CHARACTERS',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    const spec = dedent`
      aa.com{{ lang | MAP_VALUE en :> / | DEFAULT ?local-path }}covid
      WITH_VALUES
        local-path := /{{ lang }}/
    `;

    assert.equal(compileUrl(spec, { lang: 'en' }), 'aa.com/covid')
    assert.equal(compileUrl(spec, { lang: 'fr' }), 'aa.com/fr/covid')
  }
})

test({
  name: 'DERIVED PARAMETERS WITH SPECIAL CHARACTERS IN MAPS',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    const spec = dedent`
      aa.com{{ local-path | MAP_VALUE /en/ :> / | DEFAULT ?local-path }}covid
      WITH_VALUES
        local-path := /{{ lang }}/
    `;

    assert.equal(compileUrl(spec, { lang: 'en' }), 'aa.com/covid')
    assert.equal(compileUrl(spec, { lang: 'fr' }), 'aa.com/fr/covid')
  }
})

test({
  name: 'UNKOWN FILTERS',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(
      compileUrl('{{ a }}/{{ b | BAD_FILTER }}', { a: 'apples', b: 'bananas' }),
      `apples/{{ERROR:Could%20not%20apply%20'BAD_FILTER'%20to%20'b'%20because%20Unknown%20filter%20BAD_FILTER}}`
    )
  }
});

test({
  name: 'DEFAULT PARAMETERS',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    assert.equal(compileUrl('{{ lang }}', {}), 'en')
    assert.equal(compileUrl('{{ country }}', {}), 'US')
  }
});

test({
  name: 'MULTIPLE PIPES',
  unit: './compileUrl.js',
  spec: (compileUrl) => {
    const spec = 'path/{{ fruit | MAP_VALUE apple :> a | DEFAULT b }}'

    assert.equal(compileUrl(spec, { fruit: 'apple' }), 'path/a')
    assert.equal(compileUrl(spec, { fruit: 'other' }), 'path/b')
  }
});