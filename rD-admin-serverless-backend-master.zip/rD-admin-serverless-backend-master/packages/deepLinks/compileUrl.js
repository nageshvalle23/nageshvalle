const filters = {
  MAP_VALUE (raw, arg, query) {
    arg = arg.replace(/\s*:>\s*/g, ':>')

    const parts = arg.split(/\s+/)

    const match = parts.find(a => a.startsWith(`${raw}:>`))
    if (match) {
      const v = match.split(':>')[1]
      return v.startsWith('?') ? query[v.slice(1)] : v
    }
    return ''
  },

  FORMAT_DATE (raw, format) {
    if (!format) throw new Error(`'FORMAT_DATE' requires a format`)
    const [y, m, d] = raw.split('-')
    return require('date-fns').format(new Date(y, m - 1, d), format)
  },

  LOWER_CASE(raw) {
    return raw.toLowerCase()
  },

  UPPER_CASE(raw) {
    return raw.toUpperCase()
  },

  DEFAULT (raw, arg, query) {
    if (raw) return raw
    return arg.startsWith('?') ? query[arg.slice(1)] : arg
  },
}


function doMagic (val, query) {
  val = val.trim()
  const chunks = val.split('|')

  let result
  let chunk
  for (let c = 0; c < chunks.length; c++) {
    chunk = chunks[c].trim()
    if (c === 0) {
      result = query[chunk] || ''
    } else {
      const [, filter, arg] = chunks[c].trim().match(/(\S+)(.*)/)
      try {
        if (!filters[filter]) throw new Error(`Unknown filter ${filter}`)
        result = filters[filter](result.trim(), arg.trim(), query)
      } catch (e) {
        return `{{ERROR:${
          encodeURIComponent(`Could not apply '${filter}' to '${chunks[0].trim()}' because ${e.message}`)
        }}}`
      }
    }
  }

  return result
}

function transform (raw, rawQuery, shouldDerive = true) {
  // DEFAULT PARAMETRS
  const query = {
    lang: 'en',
    country: 'US',
  }

  for (let q in rawQuery) {
    query[q] = encodeURI(rawQuery[q])
  }

  // DERIVE PARAMETERS

  if (shouldDerive) {
    const derivedRegex = /WITH_VALUES([\s\S]*)/m;
    const derived = raw.match(derivedRegex)
    if (derived) {
      derived[1].trim('').split('\n').forEach(def => {
        let [key, v] = def.split(':=')
        key = key.trim()
        if (key && v) {
          query[key] = transform(v.trim(), query, false)
        }
      })
      raw = raw.slice(0, derived.index).trim()
    }
  }

  // MAKE SUBSTITUTIONS
  let reg = /{{(.+?)}}/g
  let result;
  let before = 0;
  let str = [];
  let startBracketSize = '{{'.length
  let endBracketSize = '}}'.length
  
  while((result = reg.exec(raw)) !== null) {
    str.push(raw.slice(before, result.index))
    str.push(doMagic(result[0].slice(startBracketSize, -endBracketSize), query))
    before = result.index + result[0].length
  }
  str.push(raw.slice(before))

  return str.join('')
}

module.exports = transform
