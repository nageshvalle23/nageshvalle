const { test, assert } = require('elmer-fudd');

test({
  name: 'HYDRATE ALL CARRIERS',
  unit: './hydrateLinks.js',
  spec: (hydrateLinks) => {
    const res = hydrateLinks({
      slug: 'example',
      carriers: {
        AA: null,
        OG: {},
        BA: { url: 'ba/{{ foo }}'},
        CX: { url: '{{ foo }}/cx'},
      }
    }, undefined, {
      foo: 'YES WAY'
    })

    assert.deepEqual(res, {
      query: { foo: 'YES WAY' },
      carriers: {
        BA: {
          cc_url: 'https://stage.link.carrierconnect.co/redirect/example/ba?foo=YES%20WAY',
          target_url: 'ba/YES%20WAY',
          target_url_raw: 'ba/{{ foo }}',
        },
        CX: {
          cc_url: 'https://stage.link.carrierconnect.co/redirect/example/cx?foo=YES%20WAY',
          target_url: 'YES%20WAY/cx',
          target_url_raw: '{{ foo }}/cx',
        }
      }
    })
  }
});

test({
  name: 'HYDRATE A SINGLE CARRIER',
  unit: './hydrateLinks.js',
  spec: (hydrateLinks) => {
    const res = hydrateLinks({
      slug: 'example',
      carriers: {
        AA: null,
        OG: {},
        BA: { url: 'ba/{{ foo }}'},
        CX: { url: '{{ foo }}/cx'},
      }
    }, 'ba', {
      foo: 'YES WAY'
    })

    assert.deepEqual(res, {
      cc_url: 'https://stage.link.carrierconnect.co/redirect/example/ba?foo=YES%20WAY',
      target_url: 'ba/YES%20WAY',
      target_url_raw: 'ba/{{ foo }}',
    })
  }
});

test({
  name: 'HYDRATE A MISSING CARRIER',
  unit: './hydrateLinks.js',
  spec: (hydrateLinks) => {
    const res = hydrateLinks({
      slug: 'example',
      carriers: {
        AA: null,
        OG: {},
        BA: { url: 'ba/{{ foo }}'},
        CX: { url: '{{ foo }}/cx'},
      }
    }, 'xx', {
      foo: 'YES WAY'
    })

    assert.equal(typeof res, 'undefined')
  }
});