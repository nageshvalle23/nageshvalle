const path = require('path');
const compileUrl = require('./compileUrl');
const querystring = require('querystring');
const { BASE_URL } = require('./constants');

module.exports = (deepLink, requestCarrier, reqestQuery) => {
  // ensure iata code is always caps!
  if (requestCarrier) requestCarrier = requestCarrier.toUpperCase()

  // create the cc_url and the target)url
  function hydrateLink (cId, cUrl) {
    return {
      cc_url: `${BASE_URL}/${deepLink.slug}/${cId.toLowerCase()}?${querystring.stringify(reqestQuery)}`,
      target_url: compileUrl(cUrl, reqestQuery),
      target_url_raw: cUrl,
    }
  }

  // handle a single link or a whole list!
  if (requestCarrier) {
    const carrier = deepLink.carriers[requestCarrier]
    return carrier && carrier.url && hydrateLink(requestCarrier, carrier.url)
  } else {
    const carriers = {}
    Object.entries(deepLink.carriers).forEach(([cId, carrier]) => {
      if (carrier && carrier.url) {
        carriers[cId] = hydrateLink(cId, carrier.url)
      }
    })
    return {
      query: reqestQuery,
      carriers,
    }
  }
}

