const fudd = require('elmer-fudd');

fudd.run({
  ext: '.test.js',
  root: __dirname,
});