const db = require('./db');
const path = require('path');
const { BASE_URL } = require('./constants');

function body (event) {
  return event.body ? JSON.parse(event.body) : {};
};

function response (status, res) {
  return {
    statusCode: status,
    body: res ? JSON.stringify(res) : '{}',
    headers: {
      'Content-Type': 'application/json',
    },
  };
};

const getClient = event => event.headers['x-client-carrier']

const assertExists = (v) => {
  if (typeof v !== 'undefined') return
  const error = new Error (`Not found`)
  error.status = 404
  throw error
}

const assertOG = (event) => {
  const client = getClient(event)
  if (client === 'OG') return

  const error = new Error (`${client} is not permitted`)
  error.status = 401
  throw error
}

const assertOwner = (event, owner) => {
  const client = getClient(event)
  if (client === 'OG' || client === owner) return

  const error = new Error (`${client} is not permitted`)
  error.status = 401
  throw error
}

const handleErrors = (err, cb) => {
  const status = err.status || 500

  const resBody = {
    code: `${status}`,
    message: err.message,
  };

  console.log(`Could not satisfy request ${JSON.stringify(resBody, null, 2)}`);
  return cb(null, response(status, resBody));
}

exports.listLinks = async (event, context, cb) => {
  try {
    const links = await db.listLinks()

    const linksWithBase = links.map((link) => {
      return {
        ...link,
        base_url: `${BASE_URL}/${link.slug}`,
      }
    })

    cb(null, response(200, linksWithBase));
  } catch (err) {
    return handleErrors(err, cb);
  }
};

exports.getLink = async (event, context, cb) => {
  try {
    const { slug, carrier } = event.pathParameters;
    const link = await db.getLink(slug)

    assertExists(link && link.slug)

    const hydrateLinks = require('./hydrateLinks');
    cb(null, response(200, hydrateLinks(link, carrier, event.queryStringParameters)));
  } catch (err) {
    return handleErrors(err, cb);
  }
};

exports.createLink = async (event, context, cb) => {
  try {
    assertOG(event) // ONLY ALLOW OG

    const linkData = body(event);
    const link = await db.createLink(linkData);
    cb(null, response(200, link));
  } catch (err) {
    return handleErrors(err, cb);
  }
};

exports.updateLink = async (event, context, cb) => {
  try {
    assertOG(event) // ONLY ALLOW OG

    const { slug } = event.pathParameters;
    const linkData = body(event);
    const link = await db.updateLink(slug, linkData);
    cb(null, response(200, link));
  } catch (err) {
    return handleErrors(err, cb);
  }
};

exports.deleteLink = async (event, context, cb) => {
  try {
    assertOG(event) // ONLY ALLOW OG

    const { slug } = event.pathParameters;
    const link = await db.deleteLink(slug);
    cb(null, response(200, link));
  } catch (err) {
    return handleErrors(err, cb);
  }
};

exports.setCarrierLink = async (event, context, cb) => {
  try {
    const { slug, carrier } = event.pathParameters;

    assertOwner(event, carrier) // only allow og or owner

    const val = body(event);
    const link = await db.setCarrierLink(slug, carrier, val);
    cb(null, response(200, link));
  } catch (err) {
    return handleErrors(err, cb);
  }
}

exports.unsetCarrierLink = async (event, context, cb) => {
  try {
    const { slug, carrier } = event.pathParameters;

    assertOwner(event, carrier) // only allow og or owner

    const link = await db.setCarrierLink(slug, carrier);
    cb(null, response(200, link));
  } catch (err) {
    return handleErrors(err, cb);
  }
}

exports.redirect = async (event, context, cb) => {
  try {
    let { slug, carrier } = event.pathParameters;
    const link = await db.getLink(slug)

    carrier = carrier.toUpperCase()

    assertExists(link && link.slug && link.carriers[carrier] && link.carriers[carrier].url)

    const target_url = require('./compileUrl')(
      link.carriers[carrier].url,
      event.queryStringParameters,
    )

    assertExists(target_url)

    let reg = /(?<={{ERROR:)(.+?)(?=}})/g;
    let errors = []
    let result;
    while((result = reg.exec(target_url)) !== null) {
      errors.push(decodeURIComponent(result[0]))
    }

    if (errors.length) {
      cb(null, {
        statusCode: 500,
        body: `<ul>${errors.map(e => `<li><pre>${e}</pre></li>`).join('')}</ul>`,
        headers: {
          'Content-Type': 'text/html',
        }
      });
    } else {
      cb(null, {
        statusCode: 302, // temporary redirect, to be sure no caching on the client
        headers: {
          Location: target_url
        }
      });
    }
  } catch (err) {
    return handleErrors(err, cb)
  }
}