const STAGE = process.env.stage;
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

const db = {}
module.exports = db

const TableName = `rd-deep-links-${STAGE}`

db.listLinks = async () => {
  const params = {
    TableName,
    FilterExpression: 'is_deleted <> :t', // "<>" means not equal
    ExpressionAttributeValues: {
      ':t': true,
    }
  };

  const { Items } = await dynamo.scan(params).promise();

  return Items
}

db.getLink = async (slug) => {
  const { Item } = await dynamo.get({
    TableName,
    Key: { slug },
  }).promise();
  return Item;
}

db.createLink = async (props) => {
  if (!props.title) throw new Error('link.title is required')
  const params = {
    TableName,
    Item: {
      title: props.title,
      description: props.description || null, // needs to be null instead of "" cause dynamo is sad
      carriers: {},
      query_options: props.query_options || {},
      is_deleted: false,
      slug: props.slug || require('slugify')(props.title, {
        lower: true,
        strict: true,
      }),
    },
  };
  return dynamo.put(params).promise();
}

db.updateLink = async (slug, props) => {
  const UpdateExpression = [];
  const ExpressionAttributeValues = {};

  const tokenList = [
    ['title', ':t'],
    ['description', ':d'],
    ['carriers', ':c'],
    ['is_deleted', ':x'],
    ['query_options', ':q']
  ];

  tokenList.forEach(([key, token]) => {
    if (props.hasOwnProperty(key)) {
      const val = props[key] || null // needs to be null instead of "" cause dynamo is sad (this will also make false act weird)
      UpdateExpression.push(`${key}=${token}`)
      ExpressionAttributeValues[token] = val
    }
  });

  const params = {
    TableName,
    Key: { slug },
    UpdateExpression: `set ${UpdateExpression.join(', ')}`,
    ExpressionAttributeValues: ExpressionAttributeValues,
    ReturnValues: 'UPDATED_NEW',
  }

  return dynamo.update(params).promise();
}

db.deleteLink = async function(slug) {
  return db.updateLink(slug, {
    is_deleted: true,
  })
};

db.setCarrierLink = async function(slug, carrier, val = null) {
  const params = {
    TableName,
    Key: { slug },
    UpdateExpression: `set carriers.#carrier=:v`,
    ExpressionAttributeNames: {
      '#carrier': carrier
    },
    ExpressionAttributeValues: {
      ':v': val,
    },
    ReturnValues: 'UPDATED_NEW',
  }
  return dynamo.update(params).promise();
}
