exports.BASE_URL = process.env.stage === 'prod'
  ? 'https://link.carrierconnect.co/redirect'
  : 'https://stage.link.carrierconnect.co/redirect';