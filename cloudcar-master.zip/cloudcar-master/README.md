# Cloud Car ![ci](https://travis-ci.org/nemtsov/express-starter.svg?branch=master)
This a RESTful API for interacting with the Carrier Connect carriers and permissions database

1. Configure the application
```
cp .env.example .env
```

2. Install dependencies
```
npm install
```

3. npm token from npmjs.org (settings/tokens) should be saved in ~/.npmrc and copied to working directory.
```
cp ~/.npmrc .npmrc
```

4. Install docker and build project
```
docker-compose build
```

## Usage

Development:
`docker-compose up`

Testing:
`npm test`

Check coverage:
`npm run test:cover`

Re-run tests when a file changes:
`npm run test:watch`

Production:
`npm install`
`npm start`

### Developing with QA Data

Out of the box, `cloudcar` will run with dummy data specified in `./db/schemas/bootstrap.sql`. This is generally fine, but sometimes it is useful to develop against more realistic data. To develop against data from the QA database, go through the following steps

2. Modify the postgres connection string in `docker-compose.yml` to reference the new database. The new connection string should be `postgres://postgres@db/cloudcar`. *Note:* Don't commit this change

3. Rebuild and start the app

1. Copy the data to a new local database by running `./bin/copy-db.sh**. You will need to provide the QA database password two times.

# Bloxy

## What is Bloxy

Bloxy is the second phase of the CarrierConnect Platform. It's primary distinguishing feature is it provides the airlines the ability to host any arbitrary API while maintaining the access and security features supplied by version 1 of CarrierConnect.

## What does it do?

Bloxy provides a proxy request pipeline comprised of several steps:


*TRIGGERING A BUILD FOR ZEN3 KT*

