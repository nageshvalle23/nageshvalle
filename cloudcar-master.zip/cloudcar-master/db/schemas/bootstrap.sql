CREATE TABLE person (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cognito_sub UUID NOT NULL UNIQUE, -- Cognito user id, should be same as cognito:username
  family_name VARCHAR(80),
  given_name VARCHAR(80),
  email VARCHAR(80),
  phone VARCHAR(20),
  active BOOLEAN DEFAULT true NOT NULL,
  permissions JSONB DEFAULT '[]'::jsonb NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE person_action (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  person_sub UUID REFERENCES person(cognito_sub) NOT NULL,
  action_name TEXT NOT NULL,
  state JSONB NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL
);

-- TODO: should create member and member zone, but for now it is too complicated a migration with everything else in flux
CREATE TABLE carrier (
  id VARCHAR(10) PRIMARY KEY,
  name VARCHAR(80),
  namespace VARCHAR(80) UNIQUE,
  active BOOLEAN DEFAULT true NOT NULL,
  uid UUID DEFAULT gen_random_uuid(),
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE zone (
  id VARCHAR(80) PRIMARY KEY,
  name VARCHAR(80),
  pathname VARCHAR(80) UNIQUE,
  active BOOLEAN DEFAULT true NOT NULL,
  uid UUID DEFAULT gen_random_uuid(),
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

-- (TODO: consider getting rid of this and refactor zones to environments)
CREATE TABLE carrier_zone (
  id VARCHAR(80) PRIMARY KEY,
  carrier_id VARCHAR(10)  REFERENCES carrier(id) NOT NULL,
  zone_id VARCHAR(80)  REFERENCES zone(id) NOT NULL,
  UNIQUE (carrier_id, zone_id),
  active BOOLEAN DEFAULT true NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE carrier_person (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  carrier_id VARCHAR(80) REFERENCES carrier(id) NOT NULL,
  person_id UUID REFERENCES person (id) ON DELETE CASCADE,
  UNIQUE (carrier_id, person_id),
  active BOOLEAN DEFAULT true NOT NULL,
  sort SERIAL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

-- Indicates whether JWT should be generated for specified carrier:zone:person, and if so
-- stores the JWT value
CREATE TABLE accesstoken (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  carrier_zone_id VARCHAR(80) REFERENCES carrier_zone (id) NOT NULL,
  carrier_person_id UUID REFERENCES carrier_person (id) ON DELETE CASCADE,
  UNIQUE (carrier_zone_id, carrier_person_id),
  token VARCHAR(2000),
  active BOOLEAN DEFAULT true NOT NULL, -- active = 'permitted'
  last_used_at TIMESTAMP DEFAULT now() NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

--- New Bloxy tables
CREATE TABLE environment (
  id TEXT PRIMARY KEY,
  name TEXT,
  hostname TEXT UNIQUE,
  zone_id VARCHAR(80)  REFERENCES zone(id) NOT NULL
);

INSERT INTO zone (id, name, pathname)
VALUES ('prov', 'Provisioning', 'sandbox'),
       ('live', 'Live', '');


INSERT INTO environment (id, name, hostname, zone_id)
VALUES ('sandbox', 'Sandbox', 'http://localhost:4000/sandbox', 'prov'),
       ('production', 'Production', 'http://localhost:4000', 'live');

CREATE TABLE service (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id TEXT REFERENCES carrier (id) NOT NULL,
  environment_id TEXT REFERENCES environment (id) NOT NULL,
  base_path TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  read_me TEXT,
  spec TEXT,
  examples JSONB DEFAULT '{}'::JSONB,
  is_active BOOLEAN DEFAULT true NOT NULL,
  is_validated BOOLEAN DEFAULT false NOT NULL,
  is_multi_target BOOLEAN DEFAULT false NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL,
  CONSTRAINT alliance_service_owners CHECK -- Only allow listed carriers to create alliance services
    (
      (is_multi_target is TRUE AND owner_id IN ('OG'))
      OR (is_multi_target is FALSE)
    )
);

CREATE UNIQUE INDEX service_basepath_active_constraint
  ON service (owner_id, environment_id, base_path)
  WHERE is_active;

CREATE TYPE service_target_status AS ENUM ('ENABLED', 'INPROGRESS', 'UNSUPPORTED');

CREATE TABLE service_target (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id TEXT REFERENCES carrier (id) NOT NULL,
  service_id UUID REFERENCES service (id) NOT NULL,
  target_url TEXT,
  headers JSONB DEFAULT '{}'::JSONB,
  permitted_carriers VARCHAR(10)[] DEFAULT ARRAY[]::varchar[] NOT NULL,
  version TEXT,
  status SERVICE_TARGET_STATUS DEFAULT 'UNSUPPORTED' NOT NULL,
  is_managed BOOLEAN DEFAULT false NOT NULL,
  is_active BOOLEAN DEFAULT true NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

-- Only one service target per carrier
CREATE UNIQUE INDEX service_target_owner_active_constraint
  ON service_target (owner_id, service_id)
  WHERE is_active;

INSERT INTO person (cognito_sub, family_name, given_name, email, permissions)
VALUES ('c3a1981f-2518-42ee-b7cc-66d9907788ac', 'SolomonOG', 'Steve', 'steve.solomon@oneworld.com', '[]'::jsonb),
       ('cb79afa7-f092-440f-8544-9e38abd105c8', 'SherlandOG', 'Christian', 'christian.sherland@oneworld.com', '[]'::jsonb),
       ('f50e3d3a-041a-4f6c-a2d7-2f3f33901369', 'SavoOG', 'Amy', 'amy.savo@oneworld.com', '[]'::jsonb),
       ('df1f91a7-3b81-474f-899a-ff938ce2852f', 'KendallOG', 'Joe', 'joe.kendall@oneworld.com', '["carrier_person:READ", "carrier_person:WRITE", "carrier_person_admin:READ", "carrier_person_admin:WRITE"]'::jsonb),


       ('10c7cde7-5741-4dc1-b511-06026ec4fcc8', 'SolomonBA', 'Steve', 'steve@ba.com', '[]'::jsonb),
       ('1947a6d5-5600-44a1-942d-d1b9c543b826', 'KendallAA', 'Joe', 'joe@aa.com', '[]'::jsonb),
       ('5349c1a0-67a6-4dda-96e8-116ac3772710', 'KendallCX', 'Joe', 'joe@cathaypacific.com', '[]'::jsonb),
       ('71551957-9214-4d17-9f01-fa28becb9eed', 'KendallQR', 'Joe', 'joe@qatarairways.com.qa', '[]'::jsonb),
       ('2254983e-d96a-49fe-bce6-598d50790995', 'SparlingOG', 'Erin', 'erin.sparling@oneworld.com', '[]'::jsonb),

       ('c2cf3149-5f51-4790-8264-8de62fa2eb07', 'Zen3OG', 'Narendra', 'narendrau@zen3.co.uk', '["carrier_person:READ", "carrier_person:WRITE", "carrier_person_admin:READ", "carrier_person_admin:WRITE"]'::jsonb);

INSERT INTO carrier (id, name, namespace)
VALUES ('CX', 'Cathay Pacific', 'cx'),
       ('QR', 'Qatar Airways', 'qr'),
       ('IB', 'Iberia Airways', 'ib'),
       ('OG', 'Pangaea Airways', 'oneworld'),
       ('BA', 'British Airways', 'ba'),
       ('AA', 'American Airlines', 'aa'),
       ('MH', 'Malaysia Airlines', 'mh'),
       ('UL', 'SriLankan Airlines', 'ul'),
       ('AT', 'Royal Air Maroc', 'at'),
       ('RJ', 'Royal Jordanian Airlines', 'rj'),
       ('S7', 'S7', 's7'),
       ('QF', 'Qantas', 'qf'),
       ('AY', 'Finnair', 'ay'),
       ('AS', 'Alaska Airlines', 'as'),
       ('JL', 'Japan Airlines', 'jl');

-- carrier zones (removing constraint that OG only has one zone)
INSERT INTO carrier_zone (id, carrier_id, zone_id)
SELECT (carrier.id || '_' || zone.id) as id, carrier.id AS carrier_id, zone.id as zone_id
FROM
    carrier CROSS JOIN zone;

-- carrier persons
INSERT INTO carrier_person (person_id, carrier_id)
SELECT person.id as person_id,
       RIGHT(person.family_name, 2) as carrier_id
FROM person;

-- add accessToken record for all users
INSERT INTO accesstoken (carrier_zone_id, carrier_person_id, token)
SELECT cz.id as carrier_zone_id, cp.id as carrier_person_id, 'PLACEHOLDER' as token
  FROM carrier_zone cz
         INNER JOIN carrier_person cp ON cz.carrier_id = cp.carrier_id;
