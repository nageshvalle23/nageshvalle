-- For: gen_random_uuid()
CREATE EXTENSION pgcrypto;
