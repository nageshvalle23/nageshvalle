-- Tables stored in beanstalk snapshots before being dropped
--      stage: https://console.aws.amazon.com/rds/home?region=us-east-1#db-snapshot:engine=postgres;id=cloud-car-stage-jun-9-2020
--      prod:  https://console.aws.amazon.com/rds/home?region=us-east-1#db-snapshot:engine=postgres;id=cloud-car-prod-jun-9-2020

DROP TABLE carrier_api_zone_header;
DROP TABLE carrier_api_zone;
DROP TABLE carrier_api;
DROP TABLE api_zone;
DROP TABLE api;