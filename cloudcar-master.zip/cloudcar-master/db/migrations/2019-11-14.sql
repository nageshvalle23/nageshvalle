-- Added namespace column to carrier table
ALTER TABLE carrier 
ADD COLUMN namespace VARCHAR(80) UNIQUE;

-- Update carrier rows with namespace values
UPDATE carrier
SET namespace = LOWER(id)
WHERE id != 'OG';

UPDATE carrier
SET namespace = 'oneworld'
WHERE id = 'OG';
