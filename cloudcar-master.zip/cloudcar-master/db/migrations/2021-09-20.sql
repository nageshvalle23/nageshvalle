ALTER TABLE person ADD COLUMN permissions jsonb default '[]'::jsonb NOT NULL;

UPDATE person set permissions = '["carrier_person_admin:WRITE", "carrier_person_admin:READ", "carrier_person:WRITE", "carrier_person:READ"]'::jsonb
 where id = ANY(SELECT person_id from carrier_person WHERE carrier_id = 'OG');
