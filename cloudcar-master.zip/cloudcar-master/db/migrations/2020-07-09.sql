-- See 2020-06-16.sql for references to database backups that include these tables
DROP TABLE carrierservice;
DROP TABLE feature;