ALTER TABLE service
    ADD CONSTRAINT alliance_service_owners CHECK -- Only allow listed carriers to create alliance services
    (
      (is_multi_target is TRUE AND owner_id IN ('OG'))
      OR (is_multi_target is FALSE)
    )
