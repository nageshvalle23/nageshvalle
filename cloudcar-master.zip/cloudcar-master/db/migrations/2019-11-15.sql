-- Add pathname column to zone table
ALTER TABLE zone
ADD COLUMN pathname VARCHAR(80) UNIQUE;

--
UPDATE zone
SET pathname = 'sandbox'
WHERE id = 'prov';

UPDATE zone
SET pathname = ''
WHERE id = 'live';