ALTER TABLE accesstoken ADD COLUMN last_used_at TIMESTAMP default now() not null;
