ALTER TABLE carrier_api DROP CONSTRAINT carrier_id_base_path;

CREATE UNIQUE INDEX carrier_api_basepath_active_constraint
  ON carrier_api (carrier_id, base_path)
  WHERE active;
