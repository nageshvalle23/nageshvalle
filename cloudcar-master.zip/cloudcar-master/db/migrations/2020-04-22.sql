-- Associates zones and environments
ALTER TABLE environment
ADD COLUMN zone_id TEXT;

UPDATE environment
SET
	zone_id = 'prov'
WHERE
	id = 'sandbox';

UPDATE environment
SET
	zone_id = 'live'
WHERE
	id = 'production';

ALTER TABLE environment
ADD CONSTRAINT fk_zone_id
FOREIGN KEY (zone_id)
REFERENCES zone(id);
