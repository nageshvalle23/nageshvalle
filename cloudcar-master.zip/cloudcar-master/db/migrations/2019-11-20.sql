-- API Table replaces carrier api table
CREATE TABLE api (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id VARCHAR(80) REFERENCES carrier (id) NOT NULL,
  base_path TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  active BOOLEAN DEFAULT true NOT NULL,
  shared BOOLEAN DEFAULT false NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL,
  CONSTRAINT owner_id_base_path UNIQUE(owner_id, base_path)
);

-- API zones describe available api environments
CREATE TABLE api_zone (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  api_id UUID REFERENCES api(id) NOT NULL,
  zone_id VARCHAR(80)  REFERENCES zone(id) NOT NULL,
  UNIQUE (api_id, zone_id),
  spec TEXT NOT NULL,
  active BOOLEAN DEFAULT true NOT NULL,
  validate BOOLEAN DEFAULT false NOT NULL,
  version TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL,
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

-- Update carrier api zones to associate an api zone with implementation
ALTER TABLE carrier_api_zone
ADD COLUMN api_zone_id UUID REFERENCES api_zone(id); -- needs NOT NULL but we will add this post migration

ALTER TABLE carrier_api_zone
ADD COLUMN managed BOOLEAN DEFAULT false NOT NULL;

ALTER TABLE carrier_api_zone
ADD COLUMN manager_id VARCHAR(80) REFERENCES carrier(id);

ALTER TABLE carrier_api_zone
ALTER COLUMN version DROP NOT NULL;

ALTER TABLE carrier_api_zone
ALTER COLUMN spec DROP NOT NULL;

-- Migrate carrier_api table to apis
INSERT INTO api (owner_id, base_path, title, description, shared)
SELECT
	carrier_id as owner_id,
  base_path,
  title,
  description,
  public as shared
FROM carrier_api;

-- Associate carrier_api_zone data with api_zones
WITH
  carrier_api AS (
    SELECT
    		api.id as api_id,
        carrier_zone.zone_id as zone_id,
        spec,
        api.active as active,
        validate,
        version
      FROM carrier_api_zone
    		LEFT JOIN carrier_api ON carrier_api_zone.carrier_api_id = carrier_api.id
        LEFT JOIN api ON api.base_path = carrier_api.base_path AND api.owner_id = carrier_api.carrier_id
        LEFT JOIN carrier_zone ON carrier_zone.id = carrier_api_zone.carrier_zone_id
  )
INSERT INTO api_zone (api_id, zone_id, spec, validate, version)
SELECT
	api_id,
  zone_id,
  spec,
  validate,
  version
from carrier_api;

-- Associate carrier_api_zone with an api_zone
WITH
	api_zone_info AS (
		SELECT
    	api_zone.id AS api_zone_id,
    	carrier_api.id AS carrier_api_id,
    	carrier_zone.id AS carrier_zone_id
    FROM api_zone
    	LEFT JOIN api ON api_zone.api_id = api.id
  		LEFT JOIN carrier_api ON carrier_api.carrier_id = api.owner_id AND carrier_api.base_path = api.base_path
    	LEFT JOIN carrier_zone ON api_zone.zone_id = carrier_zone.zone_id AND carrier_api.carrier_id = carrier_zone.carrier_id
  )
UPDATE carrier_api_zone
SET api_zone_id = api_zone_info.api_zone_id
FROM api_zone_info
WHERE carrier_api_zone.carrier_api_id = api_zone_info.carrier_api_id
AND carrier_api_zone.carrier_zone_id = api_zone_info.carrier_zone_id
RETURNING carrier_api_zone.api_zone_id, api_zone_info.carrier_api_id;

-- Add not null constraints now that data is populated
ALTER TABLE carrier_api_zone
ALTER COLUMN api_zone_id SET NOT NULL;
