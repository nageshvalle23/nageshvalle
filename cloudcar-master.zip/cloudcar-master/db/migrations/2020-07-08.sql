-- Adding Alaska Airlines 
INSERT INTO carrier (id, name)
VALUES
	('AS', 'Alaska Airlines');
  
-- Create Zones for AS
INSERT INTO carrier_zone (id,	carrier_id,	zone_id)
VALUES
  ('AS_prov', 'AS', 'prov'),
  ('AS_live', 'AS', 'live');