CREATE TABLE environment (
  id TEXT PRIMARY KEY,
  name TEXT,
  hostname TEXT UNIQUE
);

INSERT INTO environment (id, name, hostname)
VALUES ('sandbox', 'Sandbox', 'https://api.carrierconnect.co/sandbox'),
       ('production', 'Production', 'https://api.carrierconnect.co');

CREATE TABLE service (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id TEXT REFERENCES carrier (id) NOT NULL,
  environment_id TEXT REFERENCES environment (id) NOT NULL,
  base_path TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  spec TEXT,
  is_active BOOLEAN DEFAULT true NOT NULL,
  is_validated BOOLEAN DEFAULT false NOT NULL,
  is_multi_target BOOLEAN DEFAULT false NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL, -- do we care about updated/created?
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX service_basepath_active_constraint
  ON service (owner_id, environment_id, base_path)
  WHERE is_active;

CREATE TYPE service_target_status AS ENUM ('ENABLED', 'INPROGRESS', 'UNSUPPORTED');

CREATE TABLE service_target (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id TEXT REFERENCES carrier (id) NOT NULL,
  service_id UUID REFERENCES service (id) NOT NULL,
  target_url TEXT,
  headers JSONB DEFAULT '{}'::JSONB, -- should we use JSONB? doesn't seem necessary to me
  permitted_carriers VARCHAR(10)[] DEFAULT ARRAY[]::varchar[] NOT NULL,
  version TEXT,
  status SERVICE_TARGET_STATUS DEFAULT 'UNSUPPORTED' NOT NULL,
  is_managed BOOLEAN DEFAULT false NOT NULL,
  is_active BOOLEAN DEFAULT true NOT NULL,
  created_at TIMESTAMP DEFAULT now() NOT NULL, -- do we care about updated/created?
  updated_at TIMESTAMP DEFAULT now() NOT NULL
);

-- Only one service target per carrier
CREATE UNIQUE INDEX service_target_owner_active_constraint
  ON service_target (owner_id, service_id)
  WHERE is_active;
