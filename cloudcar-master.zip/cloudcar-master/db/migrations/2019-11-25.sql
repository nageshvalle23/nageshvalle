ALTER TABLE api DROP CONSTRAINT owner_id_base_path;

CREATE UNIQUE INDEX api_basepath_active_constraint
  ON api (owner_id, base_path)
  WHERE active;
