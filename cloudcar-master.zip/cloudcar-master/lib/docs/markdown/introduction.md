# Introduction to Carrier Connect

![Before Carrier Connect](intro-without-cc.gif)

In the constantly evolving landscape of the connected traveler, creating a seamless travel experience by ensuring that data is shared from one airline to another in the fastest, most secure and consistent way possible is amongst the hardest of challenges that airlines face. In the **one**world Alliance, each member airline may need to:
* support custom data connectivity to every other member airline, while having limited, inconsistent access to each other carrier's back-end systems
* manage multiple booking engines, their nuances and custom semantics
* negotiate local law compliance, and handling broad international initiatives like GDPR processing rules
* comply with goverment-enforced data storage location requirements

Meanwhile, as the popularity of online travel agencies and aggregators makes complicated flight paths, multi-carrier journeys and "hacker fare" more and more common, the need (and subsequent opportunity) to share data across the alliance increases exponentally.

![With Carrier Connect](intro-with-cc.png)

**Carrier Connect** is a platform for helping member airlines of the Oneworld Alliance share data as efficiently as possible and to help the digitally-connected traveller have the best experience. Through a modern approach to uniform data sharing, CarrierConnect enables airlines to dramatically reduce development efforts through efficient transformations, increases the speed at which new carriers can integrate with each other, and defines consistent schemas and clear semantics for future initiatives that are only possible through consistent communication.

## Overview
**Carrier Connect** has two major connections to each member airline:
1. A client interface (the "api") for initiating actions with other carriers (e.g. getting records, checking in, retrieving flight information), at the behest of the traveler.
2. A connection (the "target") for a carrier to allow its systems to be queried and have actions triggered by another carrier via the client api.

## Background Definitions
* **Client Carrier:** *A carrier that is initiating an action on behalf of one of it's customers. These actions are performed by sending a command to the carrierconnect platform, and appropriately handling the response.*

* **Target Carrier:** *A carrier that is responding to a request from the carrierconnect platform. The target receives the request from the carrierconnect platform, uses its own business logic, back-end systems and any other processes necessary to handle the request, and sends the results back to the platform.*

