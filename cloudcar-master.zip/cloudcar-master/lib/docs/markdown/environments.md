# Carrier Connect Environments

Carrier connect provides two environments, sandbox and production.

- **Sandbox** is typically used for testing purposes only and connects to airlines' PDT environment.
- **Production** is generally reserved for live passenger data and must be stable.

## Environment Access

Both environments support the same security and operational characteristics, but the access and configuration is siloed.

As a carrier developer you are given access to one or both of these environments by the oneworld development team depending on your project requirements.

To make requests to the carrier connect platform you must include your carrier access token with your request. You can view your tokens on your [account page](/account).

