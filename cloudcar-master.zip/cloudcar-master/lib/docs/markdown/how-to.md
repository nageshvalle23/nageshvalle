# How To Videos

Below are some guides for doing various things with Carrier Connect. **The Password is "cctv"**

## 1. How to Add a Member Service

<div style="width: 100%; height: 0px; position: relative; padding-bottom: 56.25%;">
    <iframe style="position: absolute; top: 0; bottom: 0; width: 100%; height: 100%;" src="https://player.vimeo.com/video/427510507" width="640" height="360" frameborder="0" allow="fullscreen"></iframe>
</div>

## 2. Alliance Services: What, Why and How?

<div style="width: 100%; height: 0px; position: relative; padding-bottom: 56.25%;">
    <iframe style="position: absolute; top: 0; bottom: 0; width: 100%; height: 100%;" src="https://player.vimeo.com/video/428589585" width="640" height="360" frameborder="0" allow="fullscreen"></iframe>
</div>
