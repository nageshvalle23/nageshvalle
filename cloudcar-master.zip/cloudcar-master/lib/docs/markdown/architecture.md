# System Architecture

* [The Carrier Connect Ecosystem](#carrierconnect-ecosystem)
* [Platform Architecture](#platform-architecture)
* [Security Architecture](#security-architecture)

## CarrierConnect Ecosystem
**Carrier Connect** facilitates the exchange of information between a requesting member carrier (the "client") and the responding member carrier (the "target").

![CarrierConnect Ecosystem](ecosystem_arch.png)

## Platform Architecture
The **Carrier Connect** Platform has a services-based architecture, hosted primarily in Amazon Web Services.

![CarrierConnect Platform Architecture](system_architecture.png)

## Security Architecture
**Carrier Connect** implements a robust security architecture incorporating Amazon Cognito identity services, the Amazon Key Management System (KMS), and JSON Web Tokens (JWT).

![CarrierConnect Security Architecture](security_arch.png)

