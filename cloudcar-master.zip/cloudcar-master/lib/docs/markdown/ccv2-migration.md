# Checkin Services v2 Migration Guide

* [New URLs](#new-urls)
* [Schema Changes](#schema-changes)
* [Procedure Changes](#procedure-changes)
* [New Functionality](#new-functionality)

## New URLs

All methods are now POST requests and are available at the following URLs

```
https://api.carrierconnect.co/oneworld/v2/record/
```

```
https://api.carrierconnect.co/oneworld/v2/passenger/acceptance
```

```
https://api.carrierconnect.co/oneworld/v2/passenger/boardingpass
```

```
https://api.carrierconnect.co/oneworld/v2/passenger/eligibility
```

```
https://api.carrierconnect.co/oneworld/v2/passenger/document
```



## Schema Changes

One important aspect of the upgrade to v2 is changes to the CC data representations. A full documentation of the new spec can be found [here](https://manage.carrierconnect.co/api/catalog/5b1e4db3-c130-4325-a670-497755d9e28e).

A few notes in general on schema changes:

* All references to a carriers two character IATA code is labeled as "carrierCode", previously there was a mix of "iataCode", "carrier", and "carrierCode"
* All dates are now ISO 8601 format.
* "isCheckinInhibited" is removed from the "coupon" schema
* "sequenceNumber" and "qrCodeData" have been removed from the "boardingPass" schema
* "checkinRequest" schema now groups "acceptance" and "acknowledgeDGTerms" in the "requirements" property




## Procedure Changes

The major difference in the CC checkin procedure is in v2 all requests operate on a single passenger at a time. In other words, to checkin in multiple passengers you are required to make one checkin request per passenger. The same process is required for retrieving a boarding pass.

## New Functionality

In addition to streamlining the existing v1 API schemas and process, v2 adds new API endpoints, `/eligibility` and `/document`

The eligibility endpoint checks the checkin eligibility of a single passenger. The document endpoint updates a specific travel document for a specific passenger. The full documentation for these new APIs can be found [here](https://manage.carrierconnect.co/api/catalog/5b1e4db3-c130-4325-a670-497755d9e28e).
