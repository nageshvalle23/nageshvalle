# Supporting Alliance Services

The purpose of this document is to explain what an alliance service is and how your airline can support these services.

The oneworld alliance has agreed on a collection of digital services that mutually benefit the member airlines. These services include pnr retrieval, check-in acceptance, boarding pass retrieval and flight information. 

The current list of supported alliances services can be found in the carrierconnect self-service portal [here].

## What is an alliance service?

An alliance service is a REST API that allows oneworld member airlines to use a standard schema to request information or perform actions on any other participating member airline.

For example, using the alliance service flight information, any member can request the status of a flight of any oneworld carrier. The request schema is the same regardless of which airline is providing the flight status. The same is true of the response. No matter what airline provides the data the response schema is always the same.

In order for this system to work oneworld requires cooperation from the member airlines to create **target** integrations.

## Supporting an alliance service

To support an alliance service you need to build a **target**. A target is an adapter between the carrier connect platform and your own airline's systems. The responsibility of the **target** is to take a request of the specific alliance service schema and produce a response in the specific alliance service schema.

Using flight information as an example again:

Carrierconnect will recieve a request for a flight from your airline. Carrier Connect will recognize that this request should route to your **target**. Here is what carrierconnect will do before sending the request to your **target**:

- Check if the client has a valid token
- Check if the target has allowed requests from the client
- Checks if the request object schema is valid

Once these checks are clear your target will recieve the request in the same schema it was received in carrierconnect. Once your target has received the request it must:

- Use the request provided to retrieve information or perform the requested action on behalf of the client
- Produce a response that conforms to the alliance service specification

### Registering Your Target

Once you have built a target that performs the function of the specific alliance service it is simply a matter of registering that target with the alliance service in the carrierconnect self-service portal. We require a publicly accessible API endpoint. You may configure:

- Custom headers to be added to the request prior to sending to your **target** (examples include API keys, client IDs, etc.)
- A list of carriers permitted to access the **target**. We encourage allowing all especially in sandbox environments.

NOTE: You may also whitelist our platform IPs for added security. Please contact us [here] to request these IP addresses


## Using an alliance service

To use an alliance service there are only a couple requirements:

1. You must have an auth token
2. You must have permission to access the alliance service's participants targets

The auth token is distributed through the carrierconnect self-service portal [here]. This token is distributed for a specific environment and identifies you as an associate of a particular airline.

In general participating carriers are encouraged to allow all members to access their targets. However any carrier may choose to block client requests for whatever reason. If you do not have access to a particular carrier target you will receive a 403 Forbidden response.

NOTE: The Flight information service has a fallback mechanism if a carrier does not permit access to their target or a target does not exist for certain carriers. Therefore it is possible to not have permission but still get a valid flight information response from the flight information service.




