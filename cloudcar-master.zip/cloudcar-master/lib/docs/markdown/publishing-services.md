# Publishing your own Member Service

**Member Services** empower your airline to share internal services with other **one**world members via Carrier Connect.
They are similar to [Alliance Services](/docs/alliance-services), except that _you_ define the specification _and_ the implementation.

## Service Definition

The process for creating a Carrier Service is a little different than supporting an alliance service, but also very simple. To do this:

- A route needs to be specified for where others can access this service, referred to as a **base path**
- An optional specification to document the behavior and structure of the service. The spec is defined in OpenAPI v3 YAML format.

### Service Implementation

Once the service is defined, it needs to be connected to a target. A target is simply the destination of your own internal API that CarrieConnect will route requests to.

The target consists of a few components:
- A target URL, the URL of the API you wish to surface via CarrierConnect
- Optional header values. These header key/value pairs get attached at the carrierconnect layer and are not exposed to any other carrier.

## Testing your service definition

Once you have created a service and completed the requirements above, you have the opportunity to test the service before it is made available to other carriers. The access credential that has been granted to your account automatically has permission to access any of the services created by your carrier.

To make a request of your carrier service you must use the URL provided by CarrierConnect and include your environment specific access token in the **Authorization** header field. 

## Granting access to your services

Once you have created a service and are satisfied that it functions properly you may permit access to this service on a per-carrier basis. Any carrier requests from a carrier not permitted to access the service will not be allowed past the CarrierConnect platform.

## Using others' Carrier Services

Using carrier services defined by other airlines is the same as using an alliance service. 

The requirements are:
1. You must have an auth token
2. You must have permission to access the alliance service's participants targets

The auth token is distributed through the carrierconnect self-service portal [here]. This token is distributed for a specific environment and identifies you as an associate of a particular airline.


