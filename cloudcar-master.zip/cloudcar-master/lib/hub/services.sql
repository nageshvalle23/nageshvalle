SELECT
  title,
  owner_id,
  base_path,
  is_validated,
  environment_id,
  coalesce(service.spec, '') as spec,
  (
    SELECT hostname
    FROM environment
    WHERE environment.id = service.environment_id
  ) as environment_host,
  coalesce((
    SELECT
      json_agg(
        json_build_object(
          'owner_id', service_target.owner_id,
          'target_url', service_target.target_url,
          'headers', service_target.headers,
          'is_managed', service_target.is_managed,
          'status', service_target.status,
          'permitted_carriers', service_target.permitted_carriers
        )
        ORDER BY is_managed DESC
      )
    FROM service_target
    WHERE service_target.service_id = service.id
      AND service_target.is_active
      AND (service_target.status = 'ENABLED' OR service_target.status = 'INPROGRESS')
  ), '[]'::json) as targets
FROM service
WHERE service.is_active
