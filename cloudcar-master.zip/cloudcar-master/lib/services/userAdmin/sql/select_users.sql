WITH user_zones AS (
  SELECT 	tokens.carrier_person_id, cz.carrier_id,
          MIN(CASE WHEN zone_id = 'live' THEN zone_id END) AS live,
          MIN(CASE WHEN zone_id = 'prov' THEN zone_id END) AS prov
    FROM   	accesstoken AS tokens INNER JOIN
              carrier_zone AS cz ON tokens.carrier_zone_id = cz.id
   GROUP BY tokens.carrier_person_id, cz.carrier_id
), user_details AS (
  SELECT 	p.cognito_sub, p.family_name, p.given_name, p.email, p.phone, p.active, p.created_at, uz.carrier_id, uz.live, uz.prov
    FROM person p
           INNER JOIN
           carrier_person cp ON p.id = cp.person_id
           INNER JOIN
           user_zones as uz ON uz.carrier_person_id = cp.id

) SELECT * FROM user_details
