WITH
  add_service_target AS (
    INSERT INTO service_target (
      owner_id,
      service_id,
      target_url,
      headers,
      permitted_carriers,
      status,
      is_managed,
      is_active)
    SELECT
      $1, id, $3, $4, $5, $6, $7, $8
    FROM service
    WHERE id = $2 and owner_id = $1
      OR id = $2 and is_multi_target
    RETURNING *
  )

SELECT
  id as target_id,
  owner_id,
  service_id,
  headers,
  permitted_carriers,
  status,
  is_managed,
  is_active
FROM add_service_target, pg_notify('hub_refresh', 'true');
