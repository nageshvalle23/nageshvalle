WITH
  services AS (
    SELECT service.id,
           base_path,
           title,
           description,
           owner_id,
           is_multi_target,
           spec,
           read_me,
           examples,
           environment.hostname AS environment_hostname,
           environment.id AS environment_id
      FROM service
             LEFT JOIN environment ON service.environment_id = environment.id
     WHERE is_active
       AND ((environment_id = $1 AND owner_id = $2)
            OR
            (environment_id = $1 AND is_multi_target)
            OR
            (environment_id = $1 AND is_multi_target = false)
       )
  ),

  targets AS (
    SELECT
      service_id,
      id AS service_target_id,
      owner_id AS service_target_owner_id,
      status,
      target_url,
      headers,
      permitted_carriers,
      is_managed,
      is_active AS is_active,
      ($2 = owner_id) OR ($2 = ANY(permitted_carriers)) AS permitted
      FROM service_target
     WHERE service_id = ANY (SELECT id FROM services)
       AND is_active
  ),

  updatable_targets AS (
    SELECT service_target_id,
           jsonb_build_object(
             'id', service_target_id,
             'type', 'writable',
             'owner_id', service_target_owner_id,
             'status', status,
             'service_id', service_id,
             'target_url', target_url,
             'headers', headers,
             'permitted_carriers', permitted_carriers,
             'permitted', permitted,
             'is_managed', is_managed) AS obj
      FROM targets
     WHERE (service_target_owner_id = $2 AND is_managed = false)
        OR (is_managed AND $2 = 'OG')

  ),

  readonly_targets AS (
    SELECT service_target_id,
           jsonb_build_object(
             'id', service_target_id,
             'type', 'readable',
             'owner_id', service_target_owner_id,
             'permitted', permitted,
             'status', status) AS obj
      FROM targets
     WHERE status = 'ENABLED'
  ),

  managed_targets AS (
    SELECT service_target_id,
           jsonb_build_object(
             'id', service_target_id,
             'type', 'managed',
             'owner_id', service_target_owner_id,
             'status', status,
             'permitted_carriers', permitted_carriers,
             'permitted', permitted,
             'is_managed', is_managed) AS obj
      FROM targets
     WHERE status = 'ENABLED'
       AND is_managed = true
       AND service_target_owner_id = $2
  ),

  target_agg AS (
    SELECT service_id,
           jsonb_agg(COALESCE(updatable_targets.obj, managed_targets.obj, readonly_targets.obj)) AS targets
      FROM targets
             LEFT JOIN readonly_targets
                 ON targets.service_target_id = readonly_targets.service_target_id
             LEFT JOIN managed_targets
                 ON targets.service_target_id = managed_targets.service_target_id
             LEFT JOIN updatable_targets
                 ON targets.service_target_id = updatable_targets.service_target_id
     WHERE updatable_targets.obj IS NOT NULL
        OR  managed_targets.obj IS NOT NULL
        OR readonly_targets.obj IS NOT NULL
     GROUP BY service_id
  )

SELECT id,
       title,
       base_path,
       description,
       owner_id,
       is_multi_target,
       spec,
       read_me,
       examples,
       environment_id,
       environment_hostname,
       jsonb_strip_nulls(COALESCE(targets, '[]'::jsonb)) as targets
  FROM services
         LEFT JOIN target_agg
             ON services.id = target_agg.service_id
 WHERE owner_id = $2
    OR jsonb_array_length(targets) > 0
 ORDER BY title;
