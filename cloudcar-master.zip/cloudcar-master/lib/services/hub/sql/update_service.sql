WITH update_service AS (
  UPDATE service
  SET
    base_path = $3,
    title = $4,
    description = $5,
    spec = $6,
    is_active = $7,
    is_validated = $8,
    read_me = $9,
    examples = $10,
    updated_at = now()
  WHERE id = $1 AND owner_id = $2 AND is_active
  RETURNING *
)

SELECT
  id as service_id,
  owner_id,
  environment_id,
  base_path,
  title,
  description,
  spec,
  is_validated,
  is_multi_target
FROM update_service, pg_notify('hub_refresh', 'true');
