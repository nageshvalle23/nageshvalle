WITH
  vals (owner_id, environment_id, base_path, title, description, is_multi_target) AS (
    VALUES ($1, $2, $3, $4, $5, $6::boolean)
  ),

  -- Limit number of carrier services to max of 25
  add_service AS (
    INSERT INTO service (owner_id, environment_id, base_path, title, description, is_multi_target)
    SELECT * FROM vals
    WHERE
      (SELECT COUNT(*) FROM service WHERE owner_id = vals.owner_id AND environment_id = vals.environment_id AND service.is_active) < 25
    RETURNING *
  )

SELECT
  id as service_id,
  owner_id,
  environment_id,
  base_path,
  title,
  description,
  spec,
  is_validated,
  is_multi_target
FROM add_service, pg_notify('hub_refresh', 'true');
