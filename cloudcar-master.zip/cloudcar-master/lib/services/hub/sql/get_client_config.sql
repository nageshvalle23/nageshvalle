WITH
  user_info AS (
    SELECT p.given_name,
           p.family_name,
           p.email,
           cp.id as carrier_person_id,
           jsonb_build_object( 'id', cp.carrier_id, 'name', carrier.name ) as carrier,
           p.permissions as permissions,
           p.permissions ?| '{"carrier_person:READ", "carrier_person:WRITE"}'::text[] as is_admin
      FROM person p
             LEFT JOIN carrier_person cp ON cp.person_id = p.id
             LEFT JOIN carrier ON cp.carrier_id = carrier.id
     WHERE p.cognito_sub = $1
     LIMIT 1 -- users can be associated with multiple carriers but not the case at the moment
  ),

  environments AS (
    SELECT
      id,
      name,
      hostname
      FROM environment
  ),

  user_tokens AS (
    SELECT
      accesstoken.token,
      carrier_zone.zone_id
      FROM accesstoken
             LEFT JOIN user_info ON accesstoken.carrier_person_id = user_info.carrier_person_id
             LEFT JOIN carrier_zone ON carrier_zone.id = accesstoken.carrier_zone_id
     WHERE accesstoken.carrier_person_id = user_info.carrier_person_id
  ),

  user_environment AS (
    SELECT
      environment.id,
    	name,
    	hostname,
    	token,
    	user_tokens.zone_id = environment.zone_id AS is_permitted
      FROM environment
    	       LEFT JOIN user_tokens ON user_tokens.zone_id = environment.zone_id
  )

SELECT
  jsonb_build_object(
    'given_name', user_info.given_name,
    'family_name', user_info.family_name,
    'email', user_info.email,
    'carrier', user_info.carrier,
    'is_admin', user_info.is_admin,
    'permissions', user_info.permissions
  ) as user,
	(
    SELECT
    	array_agg(
        jsonb_build_object(
          'id', id,
          'name', name
        )
      )
      FROM carrier
     WHERE active
  ) as carriers,
  (
    SELECT
    	array_agg(
        jsonb_build_object(
          'id', id,
    			'name', name,
    			'hostname', hostname,
    			'token', token,
    			'is_permitted', COALESCE (is_permitted, false)
      	)
      )
      FROM user_environment
  ) as environments
  FROM user_info;
