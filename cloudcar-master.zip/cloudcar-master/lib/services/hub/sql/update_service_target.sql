WITH update_service_target AS (
  UPDATE service_target
  SET
    target_url = $3,
    headers = $4,
    permitted_carriers = $5,
    status = $6,
    is_managed = $7,
    is_active = $8,
    updated_at = now()
  WHERE id = $1 AND owner_id = $2
  RETURNING *
)

SELECT
  id as target_id,
  target_url,
  headers,
  permitted_carriers,
  status,
  is_managed,
  is_active
FROM update_service_target, pg_notify('hub_refresh', 'true');
