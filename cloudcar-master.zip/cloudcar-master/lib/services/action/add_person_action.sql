INSERT INTO person_action (person_sub, action_name, state)
VALUES ($1, $2, $3)
       RETURNING id;
