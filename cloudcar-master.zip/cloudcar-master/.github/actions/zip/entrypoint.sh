#!/bin/sh
set -e

sh -c "zip $*"
