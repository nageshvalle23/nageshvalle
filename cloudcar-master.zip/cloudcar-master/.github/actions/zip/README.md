# zip

## Usage

Executes zip with arguments listed in the Action's `args`.

```
action "Zip up a file" {
  uses = "./github/actions/zip"
  args = ["<filename>"]
}
```
