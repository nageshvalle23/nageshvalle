const chai = require('chai');
const chaiHttp = require('chai-http');

chai.use(chaiHttp);

const createApp = require('../../lib/core/createApp');

module.exports = async function createChaiRequest() {
  const app = await createApp();
  return chai.request(app);
};
