const sinon = require('sinon');

let sandbox;

module.exports = function createCoreStubs() {
  if (sandbox) {
    sandbox.restore();
  } else {
    sandbox = sinon.createSandbox();
  }

  function n() {}

  const pool = sandbox.stub({
    connect: n,
    end: n,
    query: n,
    on: n
  })

  const stubs = {
    config: sandbox.stub({ get: n }),
    db: {
      pool
    },
    loggers: sandbox.stub({ get: n })
  };

  stubs.loggers.get.returns(
    sandbox.stub({error: n, warn: n, info: n}));

  return { sandbox, stubs };
};
