const { pool } = require('../../lib/core/db');

exports.setupDbClient = function (query = () => {}, on = () => {}) {
  pool.connect.returns({
    query,
    on
  })
}

exports.dbReturns = function(criteria, rows) {
  if (arguments.length === 1) {
    rows = criteria;
    criteria = q => q;
  }

  pool.query.returns(Promise.resolve({ rows: [] }));
  criteria(pool.query).returns(Promise.resolve({ rows }));
};

exports.dbReturnsMultiple = function(...returns) {
  for (let i = 0; i < returns.length; i++) {
    pool.query.onCall(i).returns(Promise.resolve({ rows: returns[i] || [] }))
  }
}

exports.dbReturnsThenRejects = function(rows) {
  pool.query.onCall(0).returns(Promise.resolve({ rows }));
  const error = new Error('dbrejects error');
  const promise = Promise.reject(error);
  promise.catch(() => { });
  pool.query.onCall(1).returns(promise);
}

exports.dbRejects = function(errorCode) {
  const error = new Error('dbrejects error');
  error.code = errorCode;
  error.schema = 'sch';
  error.table = 'tbl';
  const promise = Promise.reject(error);
  promise.catch(() => {});
  pool.query.returns(promise);
};

exports.resetDbSpies = function() {
  pool.query.reset && pool.query.reset();
};
