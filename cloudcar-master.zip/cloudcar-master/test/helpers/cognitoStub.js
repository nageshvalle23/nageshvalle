class CognitoExpressStub {
  constructor() {}
  validate(token, callback) {
    return callback(null, 'Valid Response')
  }
}

module.exports = CognitoExpressStub;
