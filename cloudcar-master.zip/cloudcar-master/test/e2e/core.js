const chai = require('chai');

chai.should();

const createChaiRequest = require('../helpers/createChaiRequest');
const { resetDbSpies, dbReturns } = require('../helpers/db');

describe('e2e/core', function () {
  let req;
  before(async function () {
    dbReturns([]);
    // this is to simulate an empty API zone query
    req = (await createChaiRequest()).keepOpen();
  });
  after(function () {
    req.close()
  } );

  afterEach(resetDbSpies);

  it('should respond to /_health', async function() {
    const res = await req.get('/_health');
    res.should.have.status(200);
    res.text.should.equal('ok');
  });

  it('should respond to /favicon.ico', async function() {
    const res = await req.get('/favicon.ico');
    res.should.have.status(200);
    res.text.should.equal('');
  });

  it('should respond to / (for beanstalk health check)', async function () {
    const res = await req.get('/');
    res.should.have.status(200);
    res.text.should.equal('ok');
  });
});
