const dedent = require('dedent');

const ENV_HOST = 'http://api.carrierconnect.co';
const ENV_HOST_SANDBOX = 'http://sandbox.api.carrierconnect.co';
const ALL_CARRIERS = 'CX.QR.IB.BA.AA.MH.UL.LA.AT.RJ.S7.QF.AY.JL.OG'.split('.');

module.exports = [
  // ---------------
  // Example Service
  // ---------------
  {
    title: 'Service Zero',
    description: 'sandbox | oneworld | single-target | has spec',
    owner_id: 'OG',
    base_path: '/service-zero',
    environment_id: 'sandbox',
    environment_host: ENV_HOST_SANDBOX,
    is_validated: false,
    is_multi_target: false,
    spec: dedent`
      paths:
        /foo:
          get:
            parameters:
              - name: test
                in: query
                required: true
                schema:
                  type: string
            responses:
              '200':
                content:
                  application/json:
                    schema:
                      type: object
                      properties:
                          response:
                            type: string
    `,
    targets: [
      {
        owner_id: 'OG',
        target_url: 'http://oneworld.com/path/to/svc',
        permitted_carriers: ALL_CARRIERS,
        status: 'ENABLED',
        headers: {
          'x-foo': 'extra value',
          'x-bar': 'another extra value',
        },
      },
    ]
  },
  // ---------------
  // Example Service
  // ---------------
  {
    title: 'Service One',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/service-one',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'OG',
        target_url: 'http://og.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'CX',
        target_url: 'http://aa.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ['AA'], // EXAMPLE OF BLOCKING TRAFFIC
      },
    ]
  },
  // ---------------
  // Example Service
  // ---------------
  {
    title: 'Service Two',
    description: 'sandbox | carrier | single-target | no spec',
    owner_id: 'BA',
    base_path: '/service-two',
    environment_id: 'sandbox',
    environment_host: ENV_HOST_SANDBOX,
    is_validated: false,
    is_multi_target: false,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
    ]
  },
  // ---------------
  // Example Service
  // ---------------
  {
    title: 'Service Three',
    description: 'production | carrier | single-target | no spec | limited permissions',
    owner_id: 'CX',
    base_path: '/service-three',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: false,
    spec: '',
    targets: [
      {
        owner_id: 'CX',
        target_url: 'http://cx.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ['QR', 'AA'], // NOTE: CX is not listed
      },
    ]
  },
  // ---------------
  // Example Service
  // ---------------
  {
    title: 'Service Four',
    description: 'production | carrier | no-target | no spec',
    owner_id: 'QR',
    base_path: '/service-four',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: false,
    spec: '',
    targets: []
  },

  // ---------------
  // Service with in progress target (target accessible by owner but no one else)
  // ---------------
  {
    title: 'Service Under Construction',
    description: 'Not ready for the public!',
    owner_id: 'BA',
    base_path: '/inprogress',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: false,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/path/to/svc',
        status: 'INPROGRESS', // BA can still access because they are the owner
        permitted_carriers: ['CX', 'AA'], // CX listed but not permitted because status = INPROGRESS
      },
    ]
  },

  // -----------------------------
  // Example Service Flifo Handler
  // -----------------------------
  {
    title: 'Flifo',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/flifo/flights',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'AT',
        target_url: 'https://at.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'CX',
        target_url: 'http://cx.com/path/to/svc',
        status: 'ENABLED',
        permitted_carriers: ['AA'], // EXAMPLE OF BLOCKING TRAFFIC SHOULD RESOLVE TO OAG FOR A CALL FROM ANY CARRIER OTHER THAN AA
      },
      {
        owner_id: 'OG',
        target_url: 'https://flifo.cc.co',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS.filter(c => c !== 'JL'),
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V1 Services (Record)
  // -----------------------------
  {
    title: 'V1 Record',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v1/traveler/record',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/record',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'CX',
        target_url: 'http://cx.com/record',
        status: 'ENABLED',
        permitted_carriers: ['AA'], // EXAMPLE OF BLOCKING TRAFFIC SHOULD RESOLVE TO OAG FOR A CALL FROM ANY CARRIER OTHER THAN AA
      },
    ]
  },
  // -----------------------------
  // Carrier Connect V1 Services (Check-in)
  // -----------------------------
  {
    title: 'V1 Check In',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v1/traveler/checkin',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/checkin',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/checkin',
        status: 'ENABLED',
        permitted_carriers: ['OG'], // EXAMPLE OF BLOCKING TRAFFIC SHOULD RESOLVE TO OAG FOR A CALL FROM ANY CARRIER OTHER THAN AA
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V1 Services (Boarding Pass)
  // -----------------------------
  {
    title: 'V1 Boarding Pass',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v1/traveler/boardingPass',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/boardingpass',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/boardingpass',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Record)
  // -----------------------------
  {
    title: 'CarrierConnect V2 Record',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/record',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/v2/record',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/record',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Eligibility)
  // -----------------------------
  {
    title: 'CarrierConnect V2 Eligibility',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/passenger/eligibility',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/v2/eligibility',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/eligibility',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Acceptance)
  // -----------------------------
  {
    title: 'CarrierConnect V2 Record',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/passenger/acceptance',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/v2/acceptance',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/acceptance',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Document)
  // -----------------------------
  {
    title: 'CarrierConnect V2 Document Update',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/passenger/document',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/v2/document',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/document',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Boarding PAss)
  // -----------------------------
  {
    title: 'CarrierConnect V2 Boarding Pass',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/passenger/boardingpass',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/v2/boardingpass',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/boardingpass',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Multi-Acceptance)
  // -----------------------------
  {
    title: 'CarrierConnect V2 Multi Acceptance',
    description: 'production | oneworld | mutli-target | no spec',
    owner_id: 'OG',
    base_path: '/v2/passenger/multi-acceptance',
    environment_id: 'production',
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: '',
    targets: [
      {
        owner_id: 'BA',
        target_url: 'http://ba.com/v2/multi-acceptance',
        status: 'ENABLED',
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: 'OG',
        target_url: 'http://og.com/multi-acceptance',
        status: 'ENABLED',
        permitted_carriers: ['OG'],
      },
    ]
  },

  // -----------------------------
  // Carrier Connect V2 Services (Multi Eligibility)
  // -----------------------------

  {
    title: "CarrierConnect V2 Multi Eligibility",
    description: "production | oneworld | mutli-target | no spec",
    owner_id: "OG",
    base_path: "/v2/passenger/multi-eligibility",
    environment_id: "production",
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: "",
    targets: [
      {
        owner_id: "BA",
        target_url: "http://ba.com/v2/multi-eligibility",
        status: "ENABLED",
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: "OG",
        target_url: "http://og.com/multi-eligibility",
        status: "ENABLED",
        permitted_carriers: ["OG"],
      },
    ],
  },

    // -----------------------------
  // Carrier Connect V2 Services (Multi Boarding pass)
  // -----------------------------

  {
    title: "CarrierConnect V2 Multi Boarding pass",
    description: "production | oneworld | mutli-target | no spec",
    owner_id: "OG",
    base_path: "/v2/passenger/multi-boardingpass",
    environment_id: "production",
    environment_host: ENV_HOST,
    is_validated: false,
    is_multi_target: true,
    spec: "",
    targets: [
      {
        owner_id: "BA",
        target_url: "http://ba.com/v2/multi-boardingpass",
        status: "ENABLED",
        permitted_carriers: ALL_CARRIERS,
      },
      {
        owner_id: "OG",
        target_url: "http://og.com/multi-boardingpass",
        status: "ENABLED",
        permitted_carriers: ["OG"],
      },
    ],
  },
];