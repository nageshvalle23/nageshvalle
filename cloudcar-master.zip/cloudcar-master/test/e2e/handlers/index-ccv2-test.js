const proxyquire = require('proxyquire');
const sinon = require('sinon');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const { record } = require("../../../lib/hub/handlers/ccv2/index")
chai.use(chaiAsPromised);
const assert = chai.assert;

describe("e2e - ccv2 handler - arrow func args", () => {
    const validate = sinon.stub();
    const makeIntegrationRequest = sinon.stub();
    const event = {
        "recordRequest": {
            "familyName": "Calamandrei",
            "givenName": "Mario",
            "rloc": "WELVAC",
            "carrierCode": "OG"
        }
    }
    const m = proxyquire('../../../lib/hub/handlers/ccv2/index', {
        ['./utils']: {
            validate,
            makeIntegrationRequest
        }
    })
    it('should test the record method', async () => {
        process.env.testing = 'true'
        m.record(event, {}, null, {})
        assert(validate.calledOnce)
        assert(makeIntegrationRequest.calledOnce)
    })
    it('should test the eligibility method', async () => {
        process.env.testing = 'true'
        m.eligibility(event, {}, null, {})
        assert(validate.calledOnce)
        assert(makeIntegrationRequest.calledOnce)
    })
    it('should test the document method', async () => {
        process.env.testing = 'true'
        m.document(event, {}, null, {})
        assert(validate.calledOnce)
        assert(makeIntegrationRequest.calledOnce)
    })
    it('should test the acceptance method', async () => {
        process.env.testing = 'true'
        m.acceptance(event, {}, null, {})
        assert(validate.calledOnce)
        assert(makeIntegrationRequest.calledOnce)
    })
    it('should test the multiacceptance method', async () => {
        process.env.testing = 'true'
        m.multiacceptance(event, {}, null, {})
        assert(validate.calledOnce)
        assert(makeIntegrationRequest.calledOnce)
    })
    it('should test the boardingpass method', async () => {
        process.env.testing = 'true'
        m.boardingpass(event, {}, null, {})
        assert(validate.calledOnce)
        assert(makeIntegrationRequest.calledOnce)
    })
    afterEach(() => {
        delete process.env.testing
        validate.reset()
        makeIntegrationRequest.reset()
    })
})