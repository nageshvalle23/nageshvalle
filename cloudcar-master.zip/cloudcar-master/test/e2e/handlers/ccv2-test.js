const nock = require('nock');
const chai = require('chai');
const createTestableApp = require('../setup');

chai.should();

const RECORD_PATH = '/oneworld/v2/record'
const ELIGIBILITY_PATH = '/oneworld/v2/passenger/eligibility';
const MULTI_ELIGIBILITY_PATH = "/oneworld/v2/passenger/multi-eligibility";
const DOCUMENT_PATH = '/oneworld/v2/passenger/document';
const ACCEPTANCE_PATH = '/oneworld/v2/passenger/acceptance';
const MULTI_ACCEPTANCE_PATH = '/oneworld/v2/passenger/multi-acceptance';
const BOARDINGPASS_PATH = '/oneworld/v2/passenger/boardingpass';
const MULTI_BOARDINGPASS_PATH = '/oneworld/v2/passenger/multi-boardingpass';

describe('e2e - ccv2 handler', function() {
  this.timeout(5000); // The proxyquire call for this setup is super slow, so bumping this timeout

  let app;

  before(async () => {
    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-5.cc.co', // ensures we do not mix key handling with other tests
    });
    await app.open();
  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });

  it('should return a 401 when no api key passed', async function() {
    const resForbidden = (await app.req
      .get(RECORD_PATH)
      .send());
    resForbidden.should.have.status(401);
  });

  it('should return a 403 when not permitted or no target integration exists', async function() {
    const recordRequest = {
      carrierCode: 'OG',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };
    const notPermitted = await app.carrierReq('production', 'QF', RECORD_PATH, 'POST', { recordRequest });
    notPermitted.should.have.status(403);
  });

  it('should return 403 when no target integration exists', async function() {
    const recordRequest = {
      carrierCode: 'QF',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };
    const noTarget = await app.carrierReq('production', 'QR', RECORD_PATH, 'POST', { recordRequest });
    noTarget.should.have.status(403);
  })

  it('should return a 404 when at the base routes no api key passed', async function() {
    (await app.req
      .get('/oneworld/v1/traveler')
      .send()).should.have.status(404);

    (await app.req
      .get('/oneworld/v1/traveler/notreal')
      .send()).should.have.status(404);
  });

  // This test could balloon a little bit depending on how much of our schema validation we want tested
  it('should return a 400 when missing required data', async function() {
    const recordRequest = {
      targetCarrier: 'QF',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };
    const badReq = await app.carrierReq('production', 'QR', RECORD_PATH, 'POST', { recordRequest });
    badReq.should.have.status(400);
  });

  it('should return 502 if target returns error', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };

    nock('http://ba.com/')
      .post('/v2/record', { recordRequest })
      .reply(500, {
        success: false
      })

    const res = await app.carrierReq('production', 'OG', RECORD_PATH, 'POST', { recordRequest });
    res.should.have.status(502);
  });

  it('should return 200 for successful record request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    nock('http://ba.com/')
      .post('/v2/record', { recordRequest })
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', RECORD_PATH, 'POST', { recordRequest });
    res.should.have.status(200);
  });

  it('should return 200 for successful eligibility request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequest = {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
    };

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const reqBody = { recordRequest, passengerRequest, flightRequests }

    nock('http://ba.com/')
      .post('/v2/eligibility', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', ELIGIBILITY_PATH, 'POST', reqBody);
    res.should.have.status(200);
  });

  it("should return 200 for successful multi eligibility request", async function () {
    const recordRequest = {
      carrierCode: "BA",
      rloc: "ABC123",
      givenName: "John",
      familyName: "Smith",
    };

    const passengerRequests = [
      {
        familyName: "Calamandrei",
        givenName: "Mario",
        eTicketNumber: "10249495247990",
      },
      {
        familyName: "Calamandrei",
        givenName: "Mario",
        eTicketNumber: "10249495247990",
      },
    ];

    const flightRequests = [
      {
        destination: "KDW",
        date: "2019-11-16",
        carrierCode: "OG",
        flightNumber: "611",
        origin: "ZUK",
      },
      {
        destination: "KDW",
        date: "2019-11-16",
        carrierCode: "OG",
        flightNumber: "611",
        origin: "ZUK",
      },
    ];

    const reqBody = { recordRequest, passengerRequests, flightRequests };

    nock("http://ba.com/").post("/v2/multi-eligibility", reqBody).reply(200, {
      success: true,
    });

    const res = await app.carrierReq(
      "production",
      "OG",
      MULTI_ELIGIBILITY_PATH,
      "POST",
      reqBody
    );
    res.should.have.status(200);
  });

  it('should return 200 for successful document request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequest = {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
    };

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const document = [{
      type: 'RESIDENT_ADDRESS',
      payload: {
        countryOfResidence: 'USA'
      }
    }]

    const reqBody = { recordRequest, passengerRequest, flightRequests, document }

    nock('http://ba.com/')
      .post('/v2/document', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', DOCUMENT_PATH, 'POST', reqBody);
    res.should.have.status(200);
  });

  it('should return 200 for successful Passport document request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequest = {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
    };

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const document = [{
      type: 'PASSPORT',
      payload: {
        givenName: 'Bob',
        familyName: 'Smith',
        passportNumber: '123456',
        expiryDate: '2036-01-30',
        issueDate: '2020-01-29',
        countryOfIssue: 'USA',
        gender: 'X',
        dateOfBirth: '1945-06-23',
        nationality: 'USA'
      }
    }]

    const reqBody = { recordRequest, passengerRequest, flightRequests, document }

    nock('http://ba.com/')
      .post('/v2/document', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', DOCUMENT_PATH, 'POST', reqBody);
    res.should.have.status(200);
  });

  it('should return 200 for successful acceptance request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequest = {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
    };

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const requirements = {
      acknowledgeDGTerms: true,
      acceptance: true
    }

    const reqBody = { recordRequest, passengerRequest, flightRequests, requirements }

    nock('http://ba.com/')
      .post('/v2/acceptance', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', ACCEPTANCE_PATH, 'POST', reqBody);
    res.should.have.status(200);
  })

  it('should return 502 if target returns error for multi-acceptance request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'C'
    };

    const passengerRequests = [
      {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
      },
      {
        familyName: 'Caleb',
        givenName: 'Bretto',
        eTicketNumber: '10246754647990'
      }
    ];

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const requirements = {
      acknowledgeDGTerms: true,
      acceptance: true
    }

    const reqBody = { recordRequest, passengerRequests, flightRequests, requirements }

    nock('http://ba.com/')
      .post('/v2/multi-acceptance', reqBody)
      .reply(500, {
        success: false
      })

    const res = await app.carrierReq('production', 'OG', MULTI_ACCEPTANCE_PATH, 'POST', reqBody);
    res.should.have.status(502);
  });

  it('should return 200 for successful multi-acceptance request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequests = [
      {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
      },
      {
        familyName: 'Caleb',
        givenName: 'Bretto',
        eTicketNumber: '10246754647990'
      }
    ];

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const requirements = {
      acknowledgeDGTerms: true,
      acceptance: true
    }

    const reqBody = { recordRequest, passengerRequests, flightRequests, requirements }

    nock('http://ba.com/')
      .post('/v2/multi-acceptance', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', MULTI_ACCEPTANCE_PATH, 'POST', reqBody);
    res.should.have.status(200);
  })
  
  it('should return 200 for successful boardingpass request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequest = {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
    };

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const reqBody = { recordRequest, passengerRequest, flightRequests }

    nock('http://ba.com/')
      .post('/v2/boardingpass', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', BOARDINGPASS_PATH, 'POST', reqBody);
    res.should.have.status(200);
  })

  it('should return 200 for successful single segment boardingpass request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequest = {
      familyName: 'Calamandrei',
      givenName: 'Mario',
      eTicketNumber: '10249495247990'
    };

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const reqBody = { recordRequest, passengerRequest, flightRequests }

    nock('http://ba.com/')
      .post('/v2/boardingpass', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', BOARDINGPASS_PATH, 'POST', reqBody);
    res.should.have.status(200);
  })

  it('should return 200 for successful multi boardingpass request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequests = [
      {
        familyName: 'Calamandrei',
        givenName: 'Mario',
        eTicketNumber: '10249495247990'
      },
      {
        familyName: 'Caleb',
        givenName: 'Bretto',
        eTicketNumber: '10246754647990'
      }
    ];

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      },
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const reqBody = { recordRequest, passengerRequests, flightRequests }

    nock('http://ba.com/')
      .post('/v2/multi-boardingpass', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', MULTI_BOARDINGPASS_PATH, 'POST', reqBody);
    res.should.have.status(200);
  })

  it('should return 200 for successful single segment multi boardingpass request', async function () {
    const recordRequest = {
      carrierCode: 'BA',
      rloc: 'ABC123',
      givenName: 'John',
      familyName: 'Smith'
    };

    const passengerRequests = [
      {
        familyName: 'Calamandrei',
        givenName: 'Mario',
        eTicketNumber: '10249495247990'
      },
      {
        familyName: 'Caleb',
        givenName: 'Bretto',
        eTicketNumber: '10246754647990'
      }
    ];

    const flightRequests = [
      {
        destination: 'KDW',
        date: '2019-11-16',
        carrierCode: 'OG',
        flightNumber: '611',
        origin: 'ZUK'
      }
    ]

    const reqBody = { recordRequest, passengerRequests, flightRequests }

    nock('http://ba.com/')
      .post('/v2/multi-boardingpass', reqBody)
      .reply(200, {
        success: true
      })

    const res = await app.carrierReq('production', 'OG', MULTI_BOARDINGPASS_PATH, 'POST', reqBody);
    res.should.have.status(200);
  })
});