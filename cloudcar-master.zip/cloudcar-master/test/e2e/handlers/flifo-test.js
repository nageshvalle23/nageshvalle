const {DateTime} = require('luxon');
const nock = require('nock');
const chai = require('chai');
const createTestableApp = require('../setup');

chai.should();

const FLIFO_PATH = '/oneworld/v2/flifo/flights'

describe('e2e - flifo service handler', function() {
  this.timeout(5000); // The proxyquire call for this setup is super slow, so bumping this timeout

  let app;

  before(async () => {
    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-3.cc.co', // ensures we do not mix key handling with other tests
    });
    await app.open();
  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });


  it('should call flifo and downline target', async () => {
    const lookup = {
      carrierCode: 'BA',
      date: '2020-03-30',
      origin: 'JFK',
      destination: 'OOK',
      flightNumber: '123'
    };

    const scope = nock('http://ba.com')
      .post('/path/to/svc', lookup)
      .times(2)
      .reply(200, {});

    await app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {
      lookups: [
        lookup
      ]
    });

    await app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {
      flight: lookup
    });

    chai.expect(scope.isDone()).to.equal(true);
  });


  it('should result in a 403 when carrier is not allowed OG service', async () => {
    const lookup = {
      carrierCode: 'QR',
      date: '2020-03-30',
      origin: 'JFK',
      destination: 'OOK',
      flightNumber: '123'
    };
    const res = await app.carrierReq('production', 'JL', FLIFO_PATH, 'POST', {
      lookups: [
        lookup
      ]
    });

    res.should.have.status(403)

  });

  it('should call flifo and default target because date is out of range', async () => {
    const lookup = {
      carrierCode: 'BA',
      date: DateTime.local().plus({days:10}).toISODate(), // 10 is the max BA allows so this should go to default handler
      origin: 'JFK',
      destination: 'OOK',
      flightNumber: '123'
    };

    const scope = nock('https://flifo.cc.co')
      .post('/', lookup)
      .times(2)
      .reply(200, {});

    await app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {
      lookups: [
        lookup
      ]
    });

    await app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {
      flight: lookup
    });

    chai.expect(scope.isDone()).to.equal(true);
  });

  it('should return 400 if lookup is missing or doesnt have required fields', async () => {
    const lookupNoDate = {
      carrierCode: 'BA',
      flightNumber: 123
    };

    const lookupNoCarrier = {
      flightNumber: 123,
      date: '2020-03-30'
    }

    const lookupBadCarrier = {
      flightNumber: 123,
      date: '2020-03-30',
      carrierCode: 'XX'
    }

    const responses = await Promise.all([
      app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {}),
      app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', { lookups: [ lookupNoDate ] }),
      app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', { flight: lookupNoDate }),
      app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', { lookups: [ lookupNoCarrier ] }),
      app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', { flight: lookupNoCarrier }),
      app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', { flight: lookupBadCarrier }),
    ])

    responses.every((res) => res.should.have.status(400));
  });

  it('should return 500 for integration errors', async () => {
    const lookup = {
      carrierCode: 'BA',
      date: '2020-03-30',
      origin: 'JFK',
      destination: 'OOK',
      flightNumber: '123'
    };

    nock('http://ba.com')
      .post('/path/to/svc', lookup)
      .reply(500, {});

    const res = await app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {
      lookups: [
        lookup
      ]
    });

    res.should.have.status(500)
  });


  it('should call flifo at target with different payload signature', async () => {
    let scope;
    const lookup = {
      carrierCode: 'AT',
      date: '2020-03-30',
      origin: 'JFK',
      destination: 'OOK',
      flightNumber: '123'
    };

    const promisedAgent = new Promise((resolve) => {
      scope = nock('https://at.com')
        .post('/path/to/svc', {
          flight: lookup
        })
        .reply(function () {
          resolve(this.req._redirectable._options.agent)
        });
    });


    await app.carrierReq('production', 'CX', FLIFO_PATH, 'POST', {
      lookups: [
        lookup
      ]
    });

    const agent = await promisedAgent;
    chai.expect(typeof agent).to.equal('object');
    chai.expect(scope.isDone()).to.equal(true);
  });

  it('should call flifo default url when client not permitted', async () => {
    const scope = nock('https://flifo.cc.co')
      .post('/')
      .reply(200, {});


    await app.carrierReq('production', 'BA', FLIFO_PATH, 'POST', {
      lookups: [
        {
          carrierCode: 'CX',
          date: '2020-03-30',
          origin: 'JFK',
          destination: 'OOK',
          flightNumber: '123'
        }
      ]
    });

    chai.expect(scope.isDone()).to.equal(true);
  });


  it('should call flifo default url when target doesnt exist', async () => {
    const scope = nock('https://flifo.cc.co')
      .post('/')
      .reply(200, {});

    await app.carrierReq('production', 'BA', FLIFO_PATH, 'POST', {
      lookups: [
        {
          carrierCode: 'AA',
          date: '2020-03-30',
          origin: 'JFK',
          destination: 'OOK',
          flightNumber: '123'
        }
      ]
    });

    chai.expect(scope.isDone()).to.equal(true);
  });
})
