const nock = require('nock');
const chai = require('chai');
const qs = require('querystring');
const createTestableApp = require('../setup');

chai.should();

const RECORD_PATH = '/oneworld/v1/traveler/record'
const CHECKIN_PATH = '/oneworld/v1/traveler/checkin';
const BOARDINGPASS_PATH = '/oneworld/v1/traveler/boardingPass';

// Annoying to repeat these
const passengerLookups = [{
  familyName: 'Calamandrei',
  givenName: 'Mario',
  eTicketNumber: '10249495247990'
}];

const flightLookups = [
  {
    destination: 'KDW',
    date: '2019-11-16',
    carrier: 'OG',
    flightNumber: '611',
    origin: 'ZUK'
  },
  {
    destination: 'LHV',
    date: '2019-11-16',
    carrier: 'CX',
    flightNumber: '814',
    origin: 'KDW'
  }
];

function getPath(path, params) {
  return `${path}?${qs.stringify(params)}`
}

describe('e2e - ccv1 handler', function() {
  this.timeout(0); // The proxyquire call for this setup is super slow, so bumping this timeout

  let app;

  before(async () => {
    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-4.cc.co', // ensures we do not mix key handling with other tests
    });
    await app.open();
  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });

  it('should return a 401 when no api key passed', async function() {
    const resForbidden = (await app.req
      .get(RECORD_PATH)
      .send());
    resForbidden.should.have.status(401);
  });

  it('should return a 403 when not permitted or no target integration exists', async function() {
    const lookupNotPermitted = {
      targetAirlineCode: 'CX', // TODO: BUG - the service owner (OG) can access any target regardless of permissions
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };
    const notPermitted = await app.carrierReq('production', 'QF', getPath(RECORD_PATH, lookupNotPermitted));
    notPermitted.should.have.status(403);
  });

  it('should return 403 when no target integration exists', async function() {
    const lookupNoTarget = {
      targetAirlineCode: 'OG',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };
    const noTarget = await app.carrierReq('production', 'QR', getPath(RECORD_PATH, lookupNoTarget));
    noTarget.should.have.status(403);
  })

  it('should return a 404 when at the base routes no api key passed', async function() {
    (await app.req
      .get('/oneworld/v1/traveler')
      .send()).should.have.status(404);

    (await app.req
      .get('/oneworld/v1/traveler/notreal')
      .send()).should.have.status(404);
  });

  it('should return a 400 when missing required data', async function() {
    const lookup = {
      targetAirlineCode: 'OG',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };
    const responses = await Promise.all([
      app.carrierReq('production', 'OG', RECORD_PATH),
      app.carrierReq('production', 'OG', CHECKIN_PATH, 'PUT', { passengerLookups, flightLookups }),
      app.carrierReq('production', 'OG', getPath(CHECKIN_PATH, lookup), 'PUT', { passengerLookups }),
      app.carrierReq('production', 'OG', getPath(CHECKIN_PATH, lookup), 'PUT', { flightLookups }),
      app.carrierReq('production', 'OG', BOARDINGPASS_PATH, 'POST', { passengerLookups, flightLookups }),
      app.carrierReq('production', 'OG', getPath(BOARDINGPASS_PATH, lookup), 'POST', { passengerLookups}),
      app.carrierReq('production', 'OG', getPath(BOARDINGPASS_PATH, lookup), 'POST', { flightLookups }),
    ])
    responses.every((res) => res.should.have.status(400));
  });

  it('should return status of integration failures', async function () {
    const lookup = {
      targetAirlineCode: 'BA',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };

    nock('http://ba.com/')
      .get('/record')
      .query(Object.assign({}, lookup, {requestingCarrier: 'OG'}))
      .reply(500, {
        success: false
      })

    const res = await app.carrierReq('production', 'OG', getPath(RECORD_PATH, lookup));
    res.should.have.status(500);
  });

  it('should return 200 for successful record request', async function () {
    const lookup = {
      targetAirlineCode: 'BA',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };

    nock('http://ba.com')
      .get('/record')
      .query(Object.assign({}, lookup, {requestingCarrier: 'OG'}))
      .reply(200, {
        success: false
      })

    const res = await app.carrierReq('production', 'OG', getPath(RECORD_PATH, lookup));
    res.should.have.status(200);
  });

  it('should return 200 for successful checkin request', async function () {
    this.timeout(10000)

    const lookup = {
      targetAirlineCode: 'BA',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };

    nock('http://ba.com')
      .put('/checkin')
      .query(Object.assign({}, lookup, {requestingCarrier: 'OG'}))
      .reply(200, {
        success: false
      })

    const res = await app.carrierReq('production', 'OG', getPath(CHECKIN_PATH, lookup), 'PUT', { passengerLookups, flightLookups, checkIn: true, requirements: { acknowledgeDGTerms: true } });
    res.should.have.status(200);
  })

  it('should return 200 for successful boardingpass request', async function () {
    this.timeout(5000)
    const lookup = {
      targetAirlineCode: 'BA',
      rloc: 'ABCDEF',
      givenName: 'Mario',
      familyName: 'C'
    };

    nock('http://ba.com')
      .put('/boardingpass') // Requests to boardingpass integrations are PUT (see: method override todo)
      .query(Object.assign({}, lookup, {requestingCarrier: 'OG'}))
      .reply(200, {
        success: false
      })

    const res = await app.carrierReq('production', 'OG', getPath(BOARDINGPASS_PATH, lookup), 'POST', { passengerLookups, flightLookups });
    res.should.have.status(200);
  })

});
