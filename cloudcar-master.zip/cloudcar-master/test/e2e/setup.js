const jwt = require('jsonwebtoken');
const dlv = require('dlv');
const path = require('path');
const chai = require('chai');
const nock = require('nock');
const sinon = require('sinon');
const chaiHttp = require('chai-http');
const proxyquire = require('proxyquire').noCallThru();
const secureRandom = require('secure-random');

const fakeDb = require('./fake.db');

chai.use(chaiHttp);

// Create something like a real app
// But mock the behavior of anything that makes it hard to test

module.exports = function createTestableApp(fakeEnv = {}, overrides = {}) {
  const mockLogger = {
    info: dlv(overrides, 'logger.info') || sinon.spy(),
    error: dlv(overrides, 'logger.error') || sinon.stub() // .callsFake(e => console.log(e)),
  };

  const mockAnalytics = {
    createEvent: dlv(overrides, 'analytics.createEvent') || sinon.spy(),
    getData: dlv(overrides, 'analytics.getData') || sinon.stub().returns([1, 1, 1]),
    getWOWData: dlv(overrides, 'analytics.getWOWData') || sinon.stub().returns([2, 2, 2]),
  }

  const mockDb = {
    on: dlv(overrides, 'db.on') || sinon.stub(),
    end: dlv(overrides, 'db.end') || sinon.stub(),
    query: dlv(overrides, 'db.query') || sinon.stub().callsFake(fakeDb.query),
    connect: dlv(overrides, 'db.connect') || sinon.stub(),
  };

  const mockUserSvc = {
    validateUserToken: dlv(overrides, 'user.validateUserToken') || sinon.stub().returns({ valid: true }),
    getCarrierPerson: dlv(overrides, 'user.getCarrierPerson') || sinon.stub().returns({ iata_code: 'OG' }),
  };

  const mockAdmin = {
    listUsers: dlv(overrides, 'admin.listUsers') || sinon.stub().returns([]),
    createUser: dlv(overrides, 'admin.createUser') || sinon.stub().returns({}),
  }

  mockDb.connect.returns({
    query: mockDb.query,
    on: mockDb.on,
  });

  const PATH_LIB = path.join(__dirname, '..', '..', 'lib');
  const PATH_DB = path.join(PATH_LIB, 'core', 'db.js');
  const PATH_CONFIG = path.join(PATH_LIB, 'core', 'config.js');
  const PATH_LOGGERS = path.join(PATH_LIB, 'core', 'loggers.js');
  const PATH_USER_SVC = path.join(PATH_LIB, 'services', 'user');
  const PATH_CREATE_APP = path.join(PATH_LIB, 'core', 'createApp');
  const PATH_ANALYTICS = path.join(PATH_LIB, 'services', 'analytics.js');
  const PATH_ADMIN = path.join(PATH_LIB, 'services', 'userAdmin', 'index.js');

  const fakeConfig = {
    get: (key) => fakeEnv[key] || process.env[key]
  }

  const createApp = proxyquire(PATH_CREATE_APP, {
    fs: {
      '@global': true,
      readFileSync: (filePath) => path.relative(PATH_LIB, filePath),
    },
    [PATH_DB]: {
      '@global': true,
      pool: mockDb,
    },
    [PATH_CONFIG]: {
      '@global': true,
      ...fakeConfig, // doing this and default has to do with some typescript craziness
      default: fakeConfig,
    },
    [PATH_LOGGERS]: {
      '@global': true,
      get() { return mockLogger }
    },
    [PATH_ANALYTICS]: {
      '@global': true,
      ...mockAnalytics,
    },
    [PATH_USER_SVC]: {
      '@global': true,
      ...mockUserSvc,
    },
    [PATH_ADMIN]: {
      '@global': true,
      ...mockAdmin,
    }
  });

  const app = {
    db: mockDb,
    logger: mockLogger,
    userSvc: mockUserSvc,
    analytics: mockAnalytics,
    admin: mockAdmin,
  };

  app.open = async () => {
    try {
      app.req = chai.request(await createApp()).keepOpen();
    } catch (err) {
      console.log(`\nProblem creating app!\n\n${err.stack}\n`);
      process.exit(1);
    }
  };

  let kid = 0;

  app.carrierReq = async (zone, carrier, path, method = 'GET', data) => {
    if (zone === 'sandbox') zone = 'provision';
    if (zone === 'prov') zone = 'provision';
    if (zone === 'live') zone = 'production';

    const fullKid = `${zone}-${carrier}-${kid++}`;
    const signingKey = secureRandom(256, { type: 'Buffer' });

    const authToken = jwt.sign({
      iata_code: carrier,
      sub: '12345',
      iss: 'rD-admin',
      scope: [ `cc:client:internal:${zone}` ],
    }, signingKey, {
      header: {
        kid: fullKid
      }
    });

    const key_api_url = fakeConfig.get('JWT_KID_API_URL');
    const key_api_headers = { 'x-api-key': fakeConfig.get('JWT_KID_API_KEY') };

    // Ensures nock only returns the signingKey that matches this token
    nock(key_api_url, { reqheaders: key_api_headers })
      .post('/signwith', { blob: fullKid })
      .reply(200, { key: signingKey });

    // Execute the HTTP request
    return app.req[method.toLowerCase()](path)
      .set('authorization', 'Bearer ' + authToken)
      .send(data);
  };

  app.resetMocks = () => {
    mockLogger.info.resetHistory();
    mockLogger.error.reset();
    mockAnalytics.createEvent.resetHistory();
  };

  app.close = () => {
    if (app.req) app.req.close();
  };

  return app;
};
