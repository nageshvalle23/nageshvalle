const nock = require('nock');
const chai = require('chai');
const createTestableApp = require('../setup');

chai.should();

describe('e2e - service middleware', function() {
  this.timeout(5000); // The proxyquire call for this setup is super slow, so bumping this timeout

  let app;

  before(async () => {
    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-2.cc.co', // ensures we do not mix key handling with hub-test.js
    });
    await app.open();
  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });

  it('should log the routes as they mount', async () => {
    chai.expect(app.logger.info.args).to.deep.include(['mounted route: http://sandbox.api.carrierconnect.co/oneworld/service-zero']);
    chai.expect(app.logger.info.args).to.deep.include(['mounted route: http://api.carrierconnect.co/oneworld/service-one']);
    chai.expect(app.logger.info.args).to.deep.include(['mounted route: http://sandbox.api.carrierconnect.co/ba/service-two']);
    chai.expect(app.logger.info.args).to.deep.include(['mounted route: http://api.carrierconnect.co/cx/service-three']);
  });

  it('should 404 when there is not a matching service', async () => {
    const res = await app.carrierReq('sandbox', 'CX', '/oneworld/blah/blah');
    res.should.have.status(404);
  });

  it('should 404 when the service does not have a target yet', async () => {
    const res = await app.carrierReq('production', 'QR', '/qr/service-four');
    res.should.have.status(404);
  });

  it('should 401 if token and environment do not agree', async () => {
    const responses = await Promise.all([
      app.carrierReq('production', 'OG', '/sandbox/oneworld/service-zero/api.json'),
      app.carrierReq('sandbox', 'OG', '/oneworld/service-one/api.json'),
    ]);
    responses[0].should.have.status(401);
    responses[1].should.have.status(401);
  });

  it('should 401 if auth token is missing or invalid', async () => {
    const responses = await Promise.all([
      app.req.get('/sandbox/oneworld/service-zero/api.json').send(),
      app.req.get('/sandbox/oneworld/service-zero/api.json').set('authorization', 'wrong').send(),
      app.req.get('/sandbox/oneworld/service-zero/api.json').set('authorization', 'still wrong').send(),
    ]);
    responses[0].should.have.status(401);
    responses[1].should.have.status(401);
    responses[2].should.have.status(401);
  });

  it('should return swagger json', async () => {
    const res = await app.carrierReq('sandbox', 'OG', '/sandbox/oneworld/service-zero/api.json');
    res.should.have.status(200);
    res.body.should.deep.equal({
      openapi: '3.0.0',
      info: { title: 'Service Zero' },
      servers: [ { url: 'http://sandbox.api.carrierconnect.co/oneworld/service-zero' } ],
      security: [ { bearerAuth: [] } ],
      components: {
        securitySchemes: {
          bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
        },
      },
      paths: {
        '/foo': {
          get: {
            parameters: [
              { in: 'query', name: 'test', required: true, schema: { type: 'string' } }
            ],
            responses: {
              '200': {
                content: {
                  'application/json': {
                    schema: {
                      properties: { response: { type: 'string' } },
                      type: 'object'
                    }
                  }
                }
              }
            }
          }
        }
      },
    });
  });

  it('should proxy carrier service', async () => {
    const postData = { call: 'asfsvkjhsdf;' };
    const resData = { foo: true };

    nock('http://ba.com')
      .post('/path/to/svc', postData)
      .reply(200, resData);

    const res = await app.carrierReq('sandbox', 'CX', '/sandbox/ba/service-two', 'POST', postData);

    res.should.have.status(200);
    chai.expect(res.body).to.deep.equal(resData);
  });

  it('should proxy carrier service with deeper path', async () => {
    const ccPath = '/sandbox/ba/service-two/more/segments?qs=true';
    const postData = { call: 'asdasdsadd' };
    const resData = { foo: true };

    nock('http://ba.com')
      .post('/path/to/svc/more/segments?qs=true', postData)
      .reply(200, resData);

    const res = await app.carrierReq('sandbox', 'CX', ccPath, 'POST', postData);

    res.should.have.status(200);
    chai.expect(res.body).to.deep.equal(resData);
  });

  it('should allow access to owner and permitted carriers only', async () => {
    const ccPath = '/cx/service-three';

    nock('http://cx.com') // http://cx.com/path/to/svc
      .get('/path/to/svc')
      .times(3) // ensure nock gives back all three successes!
      .reply(200, {});

    const [BA, OG, CX, QR, AA] = await Promise.all([
      app.carrierReq('production', 'OG', ccPath),
      app.carrierReq('production', 'BA', ccPath),
      app.carrierReq('production', 'CX', ccPath),
      app.carrierReq('production', 'QR', ccPath),
      app.carrierReq('production', 'AA', ccPath),
    ]);

    OG.should.have.status(403); // not listed
    BA.should.have.status(403); // not listed
    CX.should.have.status(200); // owner
    QR.should.have.status(200); // listed
    AA.should.have.status(200); // listed
  });

  it('should only allow owner to access targets that are in progress', async () => {
    const ccPath = '/ba/inprogress';

    nock('http://ba.com')
      .get('/path/to/svc')
      .reply(200, {});

    const [BA, CX, OG] = await Promise.all([
      app.carrierReq('production', 'BA', ccPath),
      app.carrierReq('production', 'CX', ccPath),
      app.carrierReq('production', 'OG', ccPath),
    ]);

    BA.should.have.status(200); // owner
    CX.should.have.status(403); // listed
    OG.should.have.status(403); // not listed
  });

  it('should forward target status', async () => {
    nock('http://cx.com').get('/path/to/svc').reply(500, {});
    nock('http://cx.com').get('/path/to/svc').reply(404, {});

    const [errReq, notFoundReq] = await Promise.all([
      app.carrierReq('production', 'CX', '/cx/service-three'),
      app.carrierReq('production', 'CX', '/cx/service-three')
    ]);

    errReq.should.have.status(500);
    notFoundReq.should.have.status(404);
  });

  it('should create analytics events', async () => {
    nock('http://cx.com').get('/path/to/svc/foo').reply(200, {});
    nock('http://cx.com').get('/path/to/svc/bar').reply(413, {});

    await Promise.all([
      app.carrierReq('production', 'CX', '/cx/service-three/foo'),
      app.carrierReq('production', 'AA', '/cx/service-three/bar')
    ]);

    for (const i of app.analytics.createEvent.args) {
      for (const j of i) {
        if (typeof (j) === 'object') {
          j.transactionId = 'abcd';
          j.responseTime = 5;
        }
      }
    }

    chai.expect(app.analytics.createEvent.args).to.deep.equal([
      [
        '/cx/service-three',
        {
          requestUrl: '/cx/service-three/foo',
          clientCarrier: 'CX',
          responseStatus: 200,
          responseTime: 5,
          targetCarrier: 'CX',
          serviceType: 'CARRIER',
          environment: 'production',
          transactionId: 'abcd'
        }
      ],
      [
        '/cx/service-three',
        {
          requestUrl: '/cx/service-three/bar',
          clientCarrier: 'AA',
          responseStatus: 413,
          responseTime: 5,
          targetCarrier: 'CX',
          serviceType: 'CARRIER',
          environment: 'production',
          transactionId: 'abcd'

        }
      ]
    ]);
  })

  it('should strip cc auth token from headers before calling target', async () => {
    // TODO: this also needs to be tested for calls (ie flifo) not just proxies

    let scope;

    const promisedHeaders = new Promise((resolve) => {
      scope = nock('http://cx.com')
        .get('/path/to/svc')
        .reply(function () {
          resolve(this.req.headers);
        });
    });

    await app.carrierReq('production', 'CX', '/cx/service-three');

    chai.expect(scope.isDone()).to.equal(true);

    const headers = await promisedHeaders;

    chai.expect(headers.authorization).to.be.an('undefined');
  });

  // This test is redundant but leaving it in as a reminder that if we don't strip the auth header for
  // oneworld owned targets we will leak the header to the server we point to with the managed target
  // (managed target server isn't always our server - See AT flifo))
  it('should strip cc auth token from headers if target belongs to oneworld', async () => {
    // TODO: this also needs to be tested for calls (ie flifo) not just proxies

    let scope;

    const promisedHeaders = new Promise((resolve) => {
      scope = nock('http://oneworld.com')
        .get('/path/to/svc')
        .reply(function () {
          resolve(this.req.headers);
        });
    });

    await app.carrierReq('sandbox', 'CX', '/sandbox/oneworld/service-zero');

    chai.expect(scope.isDone()).to.equal(true);
    const headers = await promisedHeaders;
    chai.expect(headers.authorization).to.be.an('undefined');
  });

  it('should add a custom header for the client carrier for targets to use', async () => {
    let scope;

    const promisedHeaders = new Promise((resolve) => {
      scope = nock('http://oneworld.com')
        .get('/path/to/svc')
        .reply(function () {
          resolve(this.req.headers);
        });
    });

    await app.carrierReq('sandbox', 'CX', '/sandbox/oneworld/service-zero');

    chai.expect(scope.isDone()).to.equal(true);
    const headers = await promisedHeaders;
    chai.expect(headers['x-client-carrier']).to.equal('CX');
  });

  it('should add custom headers when proxying to target', async () => {
    // TODO: this also needs to be tested for calls (ie flifo) not just proxies
    let scope;

    const promisedHeaders = new Promise((resolve) => {
      scope = nock('http://oneworld.com')
        .get('/path/to/svc')
        .reply(function () {
          resolve(this.req.headers);
        });
    });

    await app.carrierReq('sandbox', 'CX', '/sandbox/oneworld/service-zero');

    chai.expect(scope.isDone()).to.equal(true);
    const headers = await promisedHeaders;
    chai.expect(headers['x-foo']).to.equal('extra value');
    chai.expect(headers['x-bar']).to.equal('another extra value');
  });

  // TODO: Handles bad network call to target
  // TODO: Handles invalid yml config
  // TODO: Error messages are descriptive
  // TODO: updates routes on db changes
  // TODO: oneworld services (mocked or not?)
  // TODO: what else...?
});
