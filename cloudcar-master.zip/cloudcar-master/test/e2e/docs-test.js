const chai = require('chai');
const createTestableApp = require('./setup');

chai.should();

describe('e2e/docs', function() {
  let app;
  this.timeout(5000)

  beforeEach(function () {});

  before(async () => {


    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-2.cc.co', // ensures we do not mix key handling with hub-test.js
    });
    await app.open();

  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });

  describe('Docs', function () {
    it('Should return 200 for a valid docs page', async function () {
      const res = await app.req.get('/docs/introduction')
                           .set('authorization', 'Bearer foo');

      res.should.have.status(200);
    })

    it('Should return 200 for a valid docs nav', async function () {
      const res = await app.req.get('/docs/')
                           .set('authorization', 'Bearer foo');

      res.body.length.should.equal(7);
      res.should.have.status(200);
    })

    it('Should return 404 for an unknown docs page', async function () {
      const res = await app.req.get('/docs/foobar')
                           .set('authorization', 'Bearer foo');

      res.should.have.status(404);
    })
  })

});
