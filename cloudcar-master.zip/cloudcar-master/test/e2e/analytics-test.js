const chai = require('chai');
const createTestableApp = require('./setup');
const sinon = require('sinon');

chai.should();

describe('e2e/analytics', function() {
  let app;
  const getCarrierPerson = sinon.stub();
  this.timeout(5000)

  before(async () => {
    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-2.cc.co', // ensures we do not mix key handling with hub-test.js
    }, {
      user: {
        getCarrierPerson
      }
    });
    await app.open();

  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });

  describe('Analytics resource', () => {
    it('Should return 200 for a valid analytics request', async function () {
      getCarrierPerson.returns({ iata_code: 'OG' })
      const res = await app.req.post('/__internal__/analytics')
                           .send({
                             name: 'foo',
                             props: {bar: 'baz'},
                             range: 'year'
                           })
                           .set('authorization', 'Bearer foo');

      res.should.have.status(200);
    })

    it('Should return 400 for an ivalid analytics request', async function () {
      getCarrierPerson.returns({ iata_code: 'OG' })
      const res = await app.req.post('/__internal__/analytics')
                           .send({
                             foo: 'foo',
                             props: {bar: 'baz'},
                             range: 'year'
                           })
                           .set('authorization', 'Bearer foo');

      res.should.have.status(400);
    })

    it('Should return 403 for a request from a carrier person other than OG', async function () {
      getCarrierPerson.returns({ iata_code: 'AA' })
      const res = await app.req.post('/__internal__/analytics')
                           .send({
                             foo: 'foo',
                             props: {bar: 'baz'},
                             range: 'year'
                           })
                           .set('authorization', 'Bearer foo');

      res.should.have.status(403);
    })

    it('Should return 403 for a request from a carrier person other than OG', async function () {
      getCarrierPerson.returns({ iata_code: 'AA' })
      const res = await app.req.post('/__internal__/analytics/foo')
                           .send({})
                           .set('authorization', 'Bearer foo');

      res.should.have.status(403);
    })

    it('Should return 200 for a valid analytics request', async function () {
      getCarrierPerson.returns({ iata_code: 'OG' })
      const res = await app.req.post('/analytics/foo')
                           .send({
                             method: 'foo', environment: 'sandbox', serviceType: 'bar', carrierCode: 'OG'
                           })
                           .set('authorization', 'Bearer foo');

      res.should.have.status(200);
    })

  });
});
