const fakeServices = require('./fake.services');

exports.query = (qs, /* params */) => {
  let result = null;

  switch (qs) {
    case 'LISTEN hub_refresh':
      break;
    case 'hub/services.sql':
      result = fakeServices;
      break;
    default:
      throw new Error(`Missing fake for query: ${qs}`);
  }

  return Promise.resolve({
    rows: Array.isArray(result) ? result : [result],
  });
}
