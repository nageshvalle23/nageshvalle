const chai = require('chai');
const createTestableApp = require('./setup');
const sinon = require('sinon');

chai.should();

describe('e2e/admin', function() {
  let app;
  const getCarrierPerson = sinon.stub();
  this.timeout(5000)
  before(async () => {
    app = createTestableApp({
      JWT_KID_API_URL: 'https://key-2.cc.co', // ensures we do not mix key handling with hub-test.js
    }, {
      user: {
        getCarrierPerson
      }
    });
    await app.open();

  });

  after(() => {
    app.close();
  });

  afterEach(() => {
    app.resetMocks();
  });


  describe('Admin resource', () => {
    it('Should return 403 if the user does not have the correct permissions', async function () {
      getCarrierPerson.returns({ iata_code: 'OG', permissions: [] })
      const res = await app.req.get('/admin/users')
                           .set('authorization', 'Bearer foo');

      res.should.have.status(403);
    })

    it('Should return 200 if the user has the correct permissions', async function () {
      getCarrierPerson.returns({ iata_code: 'OG', permissions: ['carrier_person:READ'] })
      const res = await app.req.get('/admin/users')
                           .set('authorization', 'Bearer foo');

      res.should.have.status(200);
    })

    it('Should return 400 if anything blows up inside the req handler', async function () {
      getCarrierPerson.throws();
      const res = await app.req.get('/admin/users')
                           .set('authorization', 'Bearer foo');

      res.should.have.status(400);
    })

    it('Should return 200 if the user has permission to create the cp and the payload is correct', async function () {

    })

    it('Should return 200 if the user has permission to delete the cp', async function () {

    })
  })



});
