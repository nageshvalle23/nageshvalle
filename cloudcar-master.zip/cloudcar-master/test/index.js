const chai = require('chai');
const chaiHttp = require('chai-http');
const chaiSinon = require('sinon-chai');

chai.should();
chai.use(chaiHttp);
chai.use(chaiSinon);

const ENV_VARS = {
  COGNITO_USER_POOL_ID: 'asdf',
  COGNITO_REGION: 'us-east-1',
  API_KEY: 'oneworld',
  PLATFORM_STAGE: 'internal',
  API_HUB_URL: 'http://api.cc.co',
  API_HUB_URL_SANDBOX: 'http://api.cc.co',
  JWT_KID_API_URL: 'https://key.cc.co',
  JWT_KID_API_KEY: 'asdf',
  DEFAULT_FLIFO_API_URL: 'https://flifo.cc.co',
  FLIFO_API_KEY: 'foo',
  ANALYTICS_QUEUE_KEY: 'ANALYTICS_QUEUE_KEY',
};

Object.keys(ENV_VARS).forEach(key => (process.env[key] = ENV_VARS[key]));
