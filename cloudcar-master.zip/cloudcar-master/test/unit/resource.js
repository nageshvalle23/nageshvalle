const proxyquire = require('proxyquire');
const { stub } = require('sinon');
const { expect } = require('chai');
proxyquire.noCallThru();

// This test is here to test the external service resources
// With the current setup there is not an obvious way to test
// external services via an e2e test, this test is designed to ensure
// coverage over those modules
describe('external/resource', function() {
  beforeEach(function() {
    this.validateAnalyticsOptions = (req, res, next) => {
      res.locals = {}
      res.locals.user = 'foo'
      next()
    };

    const status = stub();
    const json = stub();

    const res = {
      status,
      json
    }

    status.returns(res);
    json.returns(res);

    this.analytics = { getData: stub() };

    this.user = { getCarrierPerson: stub() }

    this.req = { method: 'POST' };
    this.res = res;
    this.createError = stub();

    this.unit = proxyquire('../../lib/resources/external/analytics', {
      '../../middleware/cognitoAuth':  this.validateAnalyticsOptions,
      '../../services/analytics': this.analytics,
      '../../services/user': this.user,
      'http-errors': this.createError
    })
  });

  it('should get analytics response', function(done) {
    this.analytics.getData
        .returns(Promise.resolve(['a', 'b']));

    this.user.getCarrierPerson
        .returns(Promise.resolve({iata_code: 'OG'}))

    this.req.url = '/';
    this.req.body = {options: {caller: 'OG'}, zone: 'prov', range: 'day'}

    this.res.json = (data) => {
      expect(data).to.eql(['a', 'b']);
      done();
    };

    this.unit(this.req, this.res, done);
  });

  it('should return a 400 if options not specified', function(done) {
    this.analytics.getData.withArgs('n')
        .returns(Promise.resolve(['a', 'b']));

    this.user.getCarrierPerson
        .returns(Promise.resolve({iata_code: 'OG'}))

    this.req.url = '/';
    this.req.body = {options: {caller: 'OG'}, zone: 'foo', range: 'day'}

    this.unit(this.req, this.res, done);

    expect(this.createError.calledWith(400, 'Bad request'))
  });
});
