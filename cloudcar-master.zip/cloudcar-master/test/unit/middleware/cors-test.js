const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const sinon = require('sinon');
const sinonChai = require('sinon-chai');
const { expect, assert } = require('chai');
chai.use(sinonChai);

const moduleName = '../../../lib/middleware/cors';
const middleware = proxyquire(moduleName, {});

const req = {
  method: 'GET',
  get: sinon.stub()
};
const res = {
  set: sinon.spy(function() {
    return this;
  }),
  sendStatus: sinon.spy(function() {
    return this;
  }),
  locals: { user: '' },
};

const next = sinon.stub();

describe('middleware/cors', function() {
  afterEach(function() {
    res.set.resetHistory();
    res.sendStatus.resetHistory();
    req.get.resetHistory();
    next.resetHistory();
  });

  it('should set cors headers and call next', function() {
    req.get.returns('https://manage.carrierconnect.co')
    middleware(req, res, next);
    assert(
      res.set.calledWith({
        'Access-Control-Allow-Origin': 'https://manage.carrierconnect.co',
        'Access-Control-Allow-Methods': 'GET,OPTIONS,PUT,POST,DELETE',
        'Access-Control-Allow-Headers':
          'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-api-key',
      })
    );
    expect(next).to.have.been.calledOnce;
  });

  it('should set cors headers and respond with 200 for OPTIONS requests', function() {
    req.method = 'OPTIONS'
    req.get.returns('https://manage.carrierconnect.co')
    middleware(req, res, next);
    assert(
      res.set.calledWith({
        'Access-Control-Allow-Origin': 'https://manage.carrierconnect.co',
        'Access-Control-Allow-Methods': 'GET,OPTIONS,PUT,POST,DELETE',
        'Access-Control-Allow-Headers':
          'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-api-key',
      })
    );
    assert(res.sendStatus.calledWith(200));
  });

});
