const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const sinon = require('sinon');
const sinonChai = require('sinon-chai');
const { expect, assert } = require('chai');
chai.use(sinonChai);

const moduleName = '../../../lib/middleware/apiKeyAuth';
const middleware = proxyquire(moduleName, {});

const req = { headers: {} };
const res = {
  status: sinon.spy(function() {
    return this;
  }),
  send: sinon.spy(function() {
    return this;
  }),
  locals: { user: '' },
};

const next = sinon.stub();

describe('middleware/apiKeyAuth', function() {
  afterEach(function() {
    res.status.resetHistory();
    res.send.resetHistory();
    next.resetHistory();
  });

  it('should call next for requests with valid API keys', function() {
    req.headers['x-api-key'] = 'oneworld';
    middleware(req, res, next);
    expect(next).to.have.been.calledOnce;
  });

  it('should block requests with an invalid API key', function() {
    req.headers['x-api-key'] = 'garbage';
    middleware(req, res, next);
    assert(res.status.calledWith(403));
    assert(res.send.calledWith('Forbidden'));
  });

  it('should block requests with no API key', function() {
    middleware(req, res, next);
    assert(res.status.calledWith(403));
    assert(res.send.calledWith('Forbidden'));
  });
});
