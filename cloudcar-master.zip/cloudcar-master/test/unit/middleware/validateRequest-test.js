const proxyquire = require('proxyquire');
const chai = require('chai');
const sinon = require('sinon');
const sinonChai = require('sinon-chai');
const { dbReturns, dbReturnsMultiple } = require('../../helpers/db');
const { assert } = require('chai');
chai.use(sinonChai);

const createError = sinon.stub();
const validateEmail = sinon.stub();
const validateTextEntry = sinon.stub();
const validatePhoneNumber = sinon.stub();
const validatePassword = sinon.stub();

const m = proxyquire('../../../lib/middleware/validateRequest', {
  'http-errors': createError,
  ['../services/userAdmin/validators']: {
    'validateEmail': validateEmail,
    'validateTextEntry': validateTextEntry,
    'validatePhoneNumber': validatePhoneNumber,
    'validatePassword': validatePassword
  }
});

let req;
const res = {
  status: sinon.spy(function() {
    return this;
  }),
  send: sinon.spy(function() {
    return this;
  }),
  locals: { user: '' },
};

const next = sinon.spy();

describe('middleware/validateRequest', function() {

  describe('validateCreateUser', function() {
    const user = {
      email: 'test@test.com',
      phoneNumber: '+0987654321',
      iataCode: 'OG',
      givenName: 'Daniel',
      familyName: 'Tiger',
      tempPass: 'Password123!',
      zones: ['prov'],
      requestingUserCognitoSub: '12345678901234567890'
    }

    afterEach(function() {
      res.status.resetHistory();
      next.resetHistory();
      createError.reset();
    });

    it('Should continue request chain when user attributes are valid', async function() {

      validateEmail.returns(true);
      validateTextEntry.returns(true);
      validatePhoneNumber.returns(true);
      validatePassword.returns(true);
      req = { body: user};
      dbReturnsMultiple([{zone_id: "prov"}], [{iata_code: 'OG'}]);

      await m.validateCreateUser(req, res, next);
      assert(next.calledOnce);
      assert(next.calledWith());
    });

    it('Should return 400 when user email is invalid', async function() {

      validateEmail.returns(false);
      validateTextEntry.returns(true);
      validatePhoneNumber.returns(true);
      validatePassword.returns(true);
      req = { body: user};
      dbReturns([{zone_id: "prov"}]);

      await m.validateCreateUser(req, res, next);
      assert(next.calledOnce);
      assert(createError.calledWith(400, 'Missing / Invalid Parameters'));
    })

    it('Should return 400 when user text is invalid', async function() {

      validateEmail.returns(true);
      validateTextEntry.returns(false);
      validatePhoneNumber.returns(true);
      validatePassword.returns(true);
      req = { body: user};
      dbReturnsMultiple([{zone_id: "prov"}], [{iata_code: 'OG'}]);

      await m.validateCreateUser(req, res, next);
      assert(next.calledOnce);
      assert(createError.calledWith(400, 'Missing / Invalid Parameters'));
    })

    it('Should return 400 when user phone number is invalid', async function() {

      validateEmail.returns(true);
      validateTextEntry.returns(true);
      validatePhoneNumber.returns(false);
      validatePassword.returns(true);
      req = { body: user};
      dbReturnsMultiple([{zone_id: "prov"}], [{iata_code: 'OG'}]);

      await m.validateCreateUser(req, res, next);
      assert(next.calledOnce);
      assert(createError.calledWith(400, 'Missing / Invalid Parameters'));
    })

    it('Should return 400 when user password is invalid', async function() {

      validateEmail.returns(true);
      validateTextEntry.returns(true);
      validatePhoneNumber.returns(true);
      validatePassword.returns(false);
      req = { body: user};
      dbReturnsMultiple([{zone_id: "prov"}], [{iata_code: 'OG'}]);

      await m.validateCreateUser(req, res, next);
      assert(next.calledOnce);
      assert(createError.calledWith(400, 'Missing / Invalid Parameters'));
    })

  })

  describe('validateUpdateUser', function() {
    const user = {
      cognitoId: '12345678901234567890',
      iataCode: 'OG',
      zones: ['live']
    }

    afterEach(function() {
      res.status.resetHistory();
      next.resetHistory();
      createError.reset();
    });

    it('Should continue request chain when user attributes are valid', async function() {

      req = { body: user};
      dbReturns([{'zone_id': 'live'}]);

      await m.validateUpdateUser(req, res, next);
      assert(next.calledOnce);
      assert(next.calledWith());
    });

    it('Should return 400 when delete user is invalid', async function() {

      user.cognitoId = '';
      req = { body: user};
      dbReturnsMultiple(['live', 'prov']);

      await m.validateUpdateUser(req, res, next);
      assert(next.calledOnce);
      assert(createError.calledWith(400, 'Missing / Invalid Parameters'));
    })

  })
});
