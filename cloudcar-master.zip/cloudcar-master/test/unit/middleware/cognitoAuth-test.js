const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const sinon = require('sinon');
const sinonChai = require('sinon-chai');
const { expect, assert } = require('chai');
chai.use(sinonChai);

const moduleName = '../../../lib/middleware/cognitoAuth';

const createCognitoStub = failureReason => class CognitoExpressStub {
    constructor() {}
    validate(token, callback) {
      if (failureReason) {
        return callback(failureReason, null);
      }
      return callback(null, 'Valid Response');
    }
  };

const req = { headers: {} };
const res = {
  status: sinon.spy(function() {
    return this;
  }),
  send: sinon.spy(function() {
    return this;
  }),
  locals: { user: '' },
};

const next = sinon.stub();

describe('middleware/cognitoAuth', function() {
  afterEach(function() {
    res.status.resetHistory();
    res.send.resetHistory();
    next.resetHistory();
  });

  it('should return status 401 Unauthorized if token missing', function() {
    const middleware = proxyquire(moduleName, {
      '../../test/helpers/cognitoStub': createCognitoStub(),
    });
    middleware(req, res, next);
    assert(res.status.calledWith(401));
    assert(res.send.calledWith('Unauthorized'));
  });

  it('should return status 401 Unauthorized if token malformed', function() {
    const middleware = proxyquire(moduleName, {
      '../../test/helpers/cognitoStub': createCognitoStub(),
    });
    req.headers.authorization = 'oneinvalidvalue';
    middleware(req, res, next);
    assert(res.status.calledWith(401));
    assert(res.send.calledWith('Unauthorized'));
  });

  it('should return status 401 Invalid Token', function() {
    const middleware = proxyquire(moduleName, {
      '../../test/helpers/cognitoStub': createCognitoStub('Invalid Token'),
    });
    req.headers.authorization = 'bearer invalidtoken';
    middleware(req, res, next);
    assert(res.status.calledWith(401));
    assert(res.send.calledWith('Invalid Token'));
  });

  it('should call next if cognito authenticates successfully', function() {
    const middleware = proxyquire(moduleName, {
      '../../test/helpers/cognitoStub': createCognitoStub(),
    });
    req.headers.authorization = 'bearer sometoken';
    middleware(req, res, next);
    expect(res.locals.user).to.equal('Valid Response');
  });
});
