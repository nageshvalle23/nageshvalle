const proxyquire = require('proxyquire');
const chai = require('chai');
const sinon = require('sinon');
const sinonChai = require('sinon-chai');
const { dbReturns } = require('../../helpers/db');
const { assert } = require('chai');
chai.use(sinonChai);

const createError = sinon.stub();
const validateEmail = sinon.stub();
const validateTextEntry = sinon.stub();
const validatePhoneNumber = sinon.stub();
const validatePassword = sinon.stub();

const m = proxyquire('../../../lib/middleware/validateCarrier', {
  'http-errors': createError, 
  ['../services/userAdmin/validators']: { 
    'validateEmail': validateEmail, 
    'validateTextEntry': validateTextEntry, 
    'validatePhoneNumber': validatePhoneNumber, 
    'validatePassword': validatePassword
  }  
});

let req;
const res = {
  status: sinon.spy(function() {
    return this;
  }),
  send: sinon.spy(function() {
    return this;
  }),
  locals: { user: '' },
};

const next = sinon.spy();

describe('middleware/validateCarrier', function() {

  describe('validateCarrier', function () {
    afterEach(function() {
      res.status.resetHistory();
      next.resetHistory();
      createError.reset();
    });

    it('Should return 400 when iata is missing', async function() {
      req = { query: '' };
      await m.validateCarrier(req, res, next);
      assert(createError.calledWith(400, 'Bad Request'));
      assert(next.calledOnce);
    });

    it('Should return 403 when record does not exist', async function() {
      req = { query: { iata: 'AA' } };
      dbReturns([[]]);
      await m.validateCarrier(req, res, next);
      assert(createError.calledWith(403, 'Forbidden'));
      assert(next.calledOnce);
    });

    it('Should call next when record exists', async function() {
      req = { query: { iata: 'AA' } };
      dbReturns([{ exists: true }]);
      await m.validateCarrier(req, res, next);
      assert(next.calledOnce);
      assert(next.calledWithExactly());
    });
  })

  describe('validateAnalyticsOptions', function() {
    afterEach(function() {
      res.status.resetHistory();
      next.resetHistory();
      createError.reset();
    });

    it('Should return 400 when iata is missing', async function() {
      req = { body: {options: {}}};
      await m.validateAnalyticsOptions(req, res, next);
      assert(createError.calledWith(400, 'Bad Request'));
      assert(next.calledOnce);
    });

    it('Should return 403 when record does not exist', async function() {
      req = { body: {options: {caller: 'CX'}}};
      dbReturns([]);
      await m.validateAnalyticsOptions(req, res, next);
      assert(createError.calledWith(403, 'Forbidden'));
      assert(next.calledOnce);
    });

    it('Should continue request chain when OG is calling for OA', async function() {
      req = { body: {options: {caller: 'CX'}}};
      dbReturns([{iata_code: 'OG'}]);
      await m.validateAnalyticsOptions(req, res, next);
      assert(next.calledOnce);
      assert(next.calledWithExactly());
    });

    it('Should continue request chain when user requests OA they belong to', async function() {
      req = { body: {options: {caller: 'CX'}}};
      dbReturns([{iata_code: 'CX'}]);
      await m.validateAnalyticsOptions(req, res, next);
      assert(next.calledOnce);
      assert(next.calledWithExactly());
    });
  })

  describe('authorizeAdmin', function() {
    afterEach(function() {
      res.status.resetHistory();
      next.resetHistory();
      createError.reset();
    });

    it('Should call next without an error if user is an admin (OG)', async function() {
      res.locals.user.sub = '1234567890';
      dbReturns([{iata_code: 'OG'}]);
 
      await m.authorizeAdmin(req, res, next);
      assert(next.calledOnce);
      assert(next.calledWithExactly());
    });

    it('Should return 403 when requesting user is not authorized', async function() {
      res.locals.user.sub = '1234567890';
      dbReturns([{iata_code: 'CX'}]);
 
      await m.authorizeAdmin(req, res, next);
      assert(next.calledOnce);
      assert(createError.calledWith(403, 'Forbidden'));
    });
  })
});
