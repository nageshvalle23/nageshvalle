const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const { expect } = chai;
const chaiAsPromised = require('chai-as-promised');
const { dbReturns, resetDbSpies } = require('../../helpers/db');

chai.use(chaiAsPromised);

const sinon = require('sinon');

describe('services/action', async () => {
  const stub = sinon.stub();

  const module = require('../../../lib/services/action/index.js');

  describe('log', async () => {
    beforeEach (() => {
      stub.reset();
      resetDbSpies();
    });

    it('should throw an error if an unsupported user action is specified', async () => {
      const log =  module.log('123', 'asdf', {});
      return expect(Promise.resolve(log)).to.be.rejectedWith(Error);
    });

    it('should log the user action', async () => {
      dbReturns(
        [{ foo: 'bar' }]
      );
      const log = await module.log('123', 'CREATE_USER', {})

      return expect(log).to.eql({foo: 'bar'});
    });
  });
});
