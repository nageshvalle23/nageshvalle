const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { dbReturns, resetDbSpies } = require('../../helpers/db');

describe('services/user', async () => {
  const module = proxyquire('../../../lib/services/user.js', {});

  afterEach(() => {
    resetDbSpies();
  });

  describe('validateAccessToken', async () => {
    it('should return true if the key id matches the database value', async () => {
      dbReturns([
        {token: 'eyJraWQiOiJ0ZXN0In0=.eyJ2YWwiOiJ0ZXN0In0='},
      ]);
      const valid = await module.validateUserToken('OG', 'prov', 'uuid', 'test' /* keyId */);
      expect(valid).to.eql({ valid: true });
    });

    it('should return false if the keyId does not match the database entry', async () => {
      dbReturns([
        { token: 'eyJraWQiOiJ0ZXN0In0=.eyJ2YWwiOiJ0ZXN0In0=' }
      ]);
      const valid = await module.validateUserToken('OG', 'prov', 'uuid', 'wrong' /* keyId */);
      expect(valid).to.eql({valid: false});
    });


    it('should return false if the database returns no token', async () => {
      dbReturns([]);
      const valid = await module.validateUserToken('OG', 'prov', 'uuid', 'test' /* keyId */);
      expect(valid).to.eql({ valid: false });
    })

    it('should return false if the database returns a malformed token', async () => {
      dbReturns([{token: 'gibberish'}]);
      const valid = await module.validateUserToken('OG', 'prov', 'uuid', 'test' /* keyId */);
      expect(valid).to.eql({ valid: false });
    })
  });
});
