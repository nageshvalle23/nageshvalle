const proxyquire = require('proxyquire').noCallThru();
const { assert } = require('chai');

describe('services/userAdmin/db', async () => {
  const module = proxyquire('../../../../lib/services/userAdmin/validators.js', {});

  describe('validatePassword', async () => {

    it('should pass validation', async () => {
      const password = 'Asdf123!';
      assert.isTrue(await module.validatePassword(password));
    });

    it('should fail validation', async () => {
      let password = 'T00short';
      assert.isFalse(await module.validatePassword(''));
      assert.isFalse(await module.validatePassword(undefined));

      assert.isFalse(await module.validatePassword(password));

      password = 'nocap12!';
      assert.isFalse(await module.validatePassword(password));

      password = 'Nonumber!';
      assert.isFalse(await module.validatePassword(password));

      password = 'NOLOWER12!!';
      assert.isFalse(await module.validatePassword(password));

      password = 'NoSymb0l';
      assert.isFalse(await module.validatePassword(password));
    });

  });


  describe('validatePhoneNumber', async () => {

    it('should pass validation', async () => {
      const phone = '+12345678';
      assert.isTrue(await module.validatePhoneNumber(phone));
    });

    it('should fail validation', async () => {
      let phone = '12345678';
      assert.isFalse(await module.validatePhoneNumber(''));
      assert.isFalse(await module.validatePhoneNumber(undefined));      
      assert.isFalse(await module.validatePhoneNumber(phone));

      phone = '+1234';
      assert.isFalse(await module.validatePhoneNumber(phone));

      phone = '+1234567890123456';
      assert.isFalse(await module.validatePhoneNumber(phone));
    });

  });  

  describe('validateEmail', async () => {

    it('should pass validation', async () => {
      const email = 'test@test.com';
      assert.isTrue(await module.validateEmail(email));
    });

    it('should fail validation', async () => {
      let email = 'a@a.c';
      assert.isFalse(await module.validateEmail(''));
      assert.isFalse(await module.validateEmail(undefined));         
      assert.isFalse(await module.validateEmail(email));

      email = 'a@a';
      assert.isFalse(await module.validateEmail(email));

      email = '@a.co';
      assert.isFalse(await module.validateEmail(email));
    });

  });  

  describe('validateTextEntry', async () => {

    it('should pass validation', async () => {
      const text = 'anyString';
      assert.isTrue(await module.validateTextEntry(text));
      assert.isTrue(await module.validateTextEntry(' b'));
      assert.isTrue(await module.validateTextEntry('hypenated-name'));
    });

    it('should fail validation', async () => {
      assert.isFalse(await module.validateTextEntry(''));
      assert.isFalse(await module.validateTextEntry(' '));
      assert.isFalse(await module.validateTextEntry(null));
      assert.isFalse(await module.validateTextEntry(undefined));
      assert.isFalse(await module.validateTextEntry('<script></script>'));
    });

  });  

});
