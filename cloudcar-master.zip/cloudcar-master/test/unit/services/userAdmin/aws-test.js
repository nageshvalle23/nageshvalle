const proxyquire = require('proxyquire');
const sinon = require('sinon');
const moduleName = '../../../../lib/services/userAdmin/aws.js'

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
const assert = chai.assert;

const get = sinon.stub();
const secureRandom = sinon.stub();
const setExpiration = sinon.stub();
const setHeader = sinon.stub();
const compact = sinon.stub();
const describeKey = sinon.stub();
const encrypt = sinon.stub();
const adminCreateUser = sinon.stub();
const adminDeleteUser = sinon.stub();
const listUsers = sinon.stub();

const m = proxyquire(moduleName, {
  ['../../core/config']: { 'get': get },
  ['secure-random']: secureRandom ,   
  ['njwt']: { 
    'create': () => ({
      'setExpiration': setExpiration,
      'setHeader': setHeader,
      'compact': compact
    })
  },
  ['aws-sdk']: {
    'KMS': function() { 
      this.describeKey = () => ({ 'promise': describeKey }), 
      this.encrypt = () => ({ 'promise': encrypt })
    },
    'CognitoIdentityServiceProvider': function() {
      this.adminCreateUser = () => ({ 'promise': adminCreateUser }),
      this.adminDeleteUser = () => ({ 'promise': adminDeleteUser })
      this.listUsers = () => ({ 'promise': listUsers })
    }
  }
});

describe('services/userAdmin/aws', async () => {

  const user = {
    email: 'tester@test.com', 
    iataCode: 'OG', givenName: 'Tester', 
    familyName: 'TestaLot', 
    phoneNumber: '+10987654321', 
    tempPass: 'Password123!', zones: ['prov'] 
  }  

  describe('createCognitoUser', async () => {
    it('create should succeed', async () => {

      const data = { User: {Username: 'TesterUuid'}};
      adminCreateUser.returns(data);

      const carriers = await m.createCognitoUser(user, 'cognitoSub');
      assert.equal(carriers, 'TesterUuid');
    });

    it('should return an error if user was not created', async function() {

      adminCreateUser.returns({error: 'error occurred.'});
      await assert.isRejected(m.createCognitoUser(user, 'cognitoSub'), Error);
    });    
  });

  describe('generateZoneJWT', async () => {
    it('create should succeed', async () => {
      secureRandom.returns('asdfkjlafy56778');
      get.returns('internal');
      setExpiration.returns(true);
      setHeader.returns(true);
      compact.returns(true);
      encrypt.returns({CiphertextBlob: 'asjdfklsaufiotq3u4859'});
      const key = {
        KeyMetadata: {Arn: 'KeyArn'}
      }
      describeKey.returns(key);

      const result = await m.generateZoneJWT('OG', 'sub', 'prov');
      assert.equal(result, true);
    });

  });    

  describe('deleteCognitoUser', async () => {
    it('delete should succeed', async () => {

      const user = {cognitoId: '1234567890'};

      adminCreateUser.returns('success');
      await m.deleteCognitoUser(user, 'cognitoSub');
    });

    it('should return an error if user was not deleted', async function() {

      adminDeleteUser.throws();
      await assert.isRejected(m.deleteCognitoUser({}, 'cognitoSub'));
    });    
  }); 
  
  describe('listCognitoUsers', async () => {

    const userList = {
      Users: [
        { 
          Username: 'e6fbf374-8b42-4934-952c-fb3ae7683b6a',
          Attributes: [
            { Name: 'family_name', Value: 'James'}, 
            { Name: 'given_name', Value: 'Jesse'}, 
            { Name: 'email', Value: 'Jesse@James.com'}
          ],
          UserCreateDate: '2019-04-30T14:13:47.832Z',
          UserLastModifiedDate: '2019-04-30T14:13:47.832Z',
          Enabled: true,
          UserStatus: 'FORCE_CHANGE_PASSWORD' 
        },
        { 
          Username: 'e94cbf81-061d-4e19-91b3-4838f2d9bdef',
          Attributes: [
            { Name: 'family_name', Value: 'James'}, 
            { Name: 'given_name', Value: 'Jesse'}, 
            { Name: 'email', Value: 'Jesse@James.com'}
          ],          
          UserCreateDate: '2018-09-13T14:52:19.735Z',
          UserLastModifiedDate: '2019-03-26T14:49:10.948Z',
          Enabled: true,
          UserStatus: 'CONFIRMED'
        },
        { 
          Username: 'e97338b7-9fd5-4009-b954-24d63a6a483f',
          Attributes: [
            { Name: 'family_name', Value: 'James'}, 
            { Name: 'given_name', Value: 'Jesse'}, 
            { Name: 'email', Value: 'Jesse@James.com'}
          ],          
          UserCreateDate: '2019-04-12T19:37:11.760Z',
          UserLastModifiedDate: '2019-04-12T19:37:51.369Z',
          Enabled: true,
          UserStatus: 'CONFIRMED' 
        }
      ]
    };
    it('list should succeed - no pagination', async () => {
      const user = {cognitoId: '1234567890'};

      listUsers.returns(userList);
      await m.listCognitoUsers(user, 'cognitoSub');
    });

    it('should return an error if user was not created', async function() {

      listUsers.throws();
      await assert.isRejected(m.listCognitoUsers(user, 'cognitoSub'));
    });    

  });    
});
