const proxyquire = require('proxyquire');
const sinon = require('sinon');
const moduleName = '../../../../lib/services/userAdmin/index.js'

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
const assert = chai.assert;

const createCognitoUser = sinon.stub();
const listCognitoUsers = sinon.stub();
const deleteCognitoUser = sinon.stub();
const generateZoneJWT = sinon.stub();

const createCloudCarUser = sinon.stub();
const deleteCloudCarUser = sinon.stub();
const listCloudCarUsers = sinon.stub();
const get = sinon.stub();

const m = proxyquire(moduleName, {
  ['./aws']: {
    'createCognitoUser': createCognitoUser,
    'generateZoneJWT': generateZoneJWT,
    'deleteCognitoUser': deleteCognitoUser,
    'listCognitoUsers': listCognitoUsers
  },
  ['./db']: {
    'createCloudCarUser': createCloudCarUser,
    'deleteCloudCarUser': deleteCloudCarUser,
    'listCloudCarUsers': listCloudCarUsers
  },
  ['../../core/config']: { 'get': get }
});

describe('userAdmin/index', async () => {

  const user = {
    email: 'tester@test.com',
    iataCode: 'OG',
    givenName: 'Tester',
    familyName: 'TestaLot',
    phoneNumber: '+10987654321',
    tempPass: 'Password123!',
    zones: ['prov', 'live']
  }

  describe('createUser', async () => {

    it('create should succeed', async () => {
      get.returns('pool-id');
      createCognitoUser.returns('cognitoUserId');
      createCloudCarUser.returns(true);
      generateZoneJWT.resolves('abcdef12345')
      await m.createUser(user);
    });

  });

  describe('listUsers', async () => {

    const cognitoUsers = {
      'e6fbf374-8b42-4934-952c-fb3ae7683b6a':
      {
        user_name: 'e6fbf374-8b42-4934-952c-fb3ae7683b6a',
        family_name: 'James',
        given_name: 'Jesse',
        email: 'Jesse@James.com',
        user_status: 'FORCE CHANGE PASSWORD'
      },
      'e94cbf81-061d-4e19-91b3-4838f2d9bdef':
      {
        user_name: 'e94cbf81-061d-4e19-91b3-4838f2d9bdef',
        family_name: 'James',
        given_name: 'Julie',
        email: 'Julie@James.com',
        user_status: 'CONFIRMED'
      },
      'e97338b7-9fd5-4009-b954-24d63a6a483f':
      {
        user_name: 'e97338b7-9fd5-4009-b954-24d63a6a483f',
        family_name: 'James',
        given_name: 'Jenn',
        email: 'Jenn@James.com',
        user_status: 'CONFIRMED'
      },
      'extraAWSuser-9fd5-4009-b954-24d63a6a483f':
      {
        user_name: 'extraAWSuser-9fd5-4009-b954-24d63a6a483f',
        family_name: 'notINcloudCAR',
        given_name: 'iAMnotINdb',
        email: 'orphan@awsUser.com',
        user_status: 'CONFIRMED'
      }
    };

    const cloudCarUsers =
    [
      {
        live: 'live',
        prov: 'prov',
        cognito_sub: 'e6fbf374-8b42-4934-952c-fb3ae7683b6a',
        family_name: 'James',
        given_name: 'Jesse',
        email: 'Jesse@James.com',
        phone: '+1234567890',
        permissions: [],
        active: true,
        carrier_id: 'CX'
      }, {
        live: null,
        prov: 'prov',
        cognito_sub: 'e94cbf81-061d-4e19-91b3-4838f2d9bdef',
        family_name: 'James',
        given_name: 'Julie',
        email: 'Julie@James.com',
        phone: '+1234567890',
        permissions: [],
        active: true,
        carrier_id: 'QR'
      }, {
        live: null,
        prov: 'prov',
        cognito_sub: 'e97338b7-9fd5-4009-b954-24d63a6a483f',
        family_name: 'James',
        given_name: 'Jenn',
        email: 'Jenn@James.com',
        phone: '+1234567890',
        permissions: [],
        active: true,
        carrier_id: 'QR'
      }, {
        live: 'live',
        prov: 'prov',
        cognito_sub: 'orphanCloudCar-9fd5-4009-b954-24d63a6a483f',
        family_name: 'User',
        given_name: 'CloudCarOrphan',
        email: 'Orphan@CloudCar.com',
        phone: '+1234567890',
        permissions: [],
        active: true,
        carrier_id: 'IB'
      }
    ];

    const combinedUsers =
    [
      {
        cognitoId: 'e6fbf374-8b42-4934-952c-fb3ae7683b6a',
        familyName: 'James',
        givenName: 'Jesse',
        email: 'Jesse@James.com',
        phone: '+1234567890',
        ccActive: true,
        iataCode: 'CX',
        zones: ['live','prov'],
        isAdmin: false,
        permissions: [],
        awsStatus: 'FORCE CHANGE PASSWORD'
      }, {
        cognitoId: 'e94cbf81-061d-4e19-91b3-4838f2d9bdef',
        familyName: 'James',
        givenName: 'Julie',
        email: 'Julie@James.com',
        phone: '+1234567890',
        ccActive: true,
        iataCode: 'QR',
        zones: ['prov'],
        isAdmin: false,
        permissions: [],
        awsStatus: 'CONFIRMED'
      }, {
        cognitoId: 'e97338b7-9fd5-4009-b954-24d63a6a483f',
        familyName: 'James',
        givenName: 'Jenn',
        email: 'Jenn@James.com',
        phone: '+1234567890',
        ccActive: true,
        iataCode: 'QR',
        zones: ['prov'],
        isAdmin: false,
        permissions: [],
        awsStatus: 'CONFIRMED'
      }, {
        cognitoId: 'orphanCloudCar-9fd5-4009-b954-24d63a6a483f',
        familyName: 'User',
        givenName: 'CloudCarOrphan',
        email: 'Orphan@CloudCar.com',
        phone: '+1234567890',
        ccActive: true,
        iataCode: 'IB',
        zones: ['live','prov'],
        isAdmin: false,
        permissions: [],
        awsStatus: 'N/A'
      }
    ]
    it('list user should succeed', async () => {
      get.returns('pool-id');
      listCognitoUsers.returns(cognitoUsers);
      listCloudCarUsers.returns(cloudCarUsers);
      assert.deepEqual(await m.listUsers(user), combinedUsers);
    });

  });

  describe('deleteUser', async () => {

    it('delete should succeed', async () => {
      get.returns('pool-id');
      deleteCognitoUser.returns(true);
      deleteCloudCarUser.returns(true);
      await m.deleteUser(user);
    });

  });
});
