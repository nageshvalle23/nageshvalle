const proxyquire = require('proxyquire').noCallThru();
const sinon = require('sinon');
const { assert } = require('chai');
const { dbReturnsMultiple, dbReturns, resetDbSpies, dbRejects } = require('../../../helpers/db');

const loggers = require('../../../../lib/core/loggers');
const logger = loggers.get('core/errorHandler');

describe('services/userAdmin/db', async () => {

  const generateZoneJWT = sinon.stub();

  const module = proxyquire('../../../../lib/services/userAdmin/db.js', {
    ['./aws']: {
      'generateZoneJWT': generateZoneJWT,
    }
  });

  afterEach(() => {
    resetDbSpies();
  });

  const id = '12345678'
  const accessTokens = [{ zone: 'prov', token: 'asdfjklqertio' }]
  const user = {
    email: 'tester@test.com',
    iataCode: 'OG', givenName: 'Tester',
    familyName: 'TestaLot',
    phoneNumber: '+10987654321',
    tempPass: 'Password123!', zones: ['prov'],
    cognitoId: '1234567890'
  }
  const insertUserResult = [{ id: 1234 }]
  const carrierUserResult = [{ id: 9876 }]
  const accessTokenResult = [{ id: 56789 }]

  describe('createCloudCarUser', async () => {
    logger.error('createCloudCarUser')

    it('should create the user', async () => {
      dbReturnsMultiple(insertUserResult, carrierUserResult, accessTokenResult);
      await module.createCloudCarUser(id, user, accessTokens);

    });

    it('create should fail and throw exception', async () => {
      dbRejects(55);
      await assert.isRejected(module.createCloudCarUser(id, user, accessTokens), Error);

    });
  });

  describe('listCloudCarUsers', async () => {
    logger.error('listCloudCarUsers')

    it('should list the users', async () => {
      const userList = [{
        email: 'tester1@test.com',
        iataCode: 'OG', givenName: 'Tester',
        familyName: 'TestaLot',
        phoneNumber: '+10987654321',
        tempPass: 'Password123!', zones: ['prov']
      }, {
        email: 'tester2@test.com',
        iataCode: 'OG', givenName: 'Tester',
        familyName: 'TestaLot',
        phoneNumber: '+10987654321',
        tempPass: 'Password123!', zones: ['prov']
      }]

      dbReturns(userList);
      await module.listCloudCarUsers();

    });

    it('create should fail and throw exception', async () => {
      dbRejects(55);
      await assert.isRejected(module.listCloudCarUsers(), Error);
    });
  });

  describe('deleteCloudCarUser', async () => {
    logger.error('deleteCloudCarUser')

    it('should delete the user', async () => {
      await module.deleteCloudCarUser(user);

    });

    it('create should fail and throw exception', async () => {
      dbRejects(55);
      await assert.isRejected(module.deleteCloudCarUser(user), Error);

    });

  });

  describe('updateCloudCarUser', async () => {
    logger.error('updateCloudCarUser')

    const user = {
      cognitoId: '1234567890',
      zones: ['live']
    };

    it('should update the user', async () => {

      const userCurrentZones = ['prov', 'live'];

      dbReturnsMultiple(userCurrentZones, 'beginTransaction', true, 'commitTransaction');
      generateZoneJWT.resolves('abcdef12345');

      await module.updateCloudCarUser(user.cognitoId, user.iataCode, user.zones);

    });
  });

});
