const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const { expect } = chai;
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const sinon = require('sinon');

describe('services/analytics', async () => {
  const stub = sinon.stub();

  const module = proxyquire('../../../lib/services/analytics.js', {
    'axios': {
      post: stub
    }
  });

  describe('getData', async () => {
    beforeEach (() => {
      stub.reset();
    });

    it('should throw an error if an unsupported path is specified', async () => {
      const run = async function () { await module.getData('foo', {}, 'foo') };
      return expect(Promise.resolve(run())).to.be.rejectedWith(Error);
    });

    it('should throw an error if axios borks', async () => {
      stub.throws(new Error())

      const run = async function () { return await module.getData('foo', {}, 'day') };
      return expect(Promise.resolve(run())).to.be.rejectedWith(Error);
    });

    it('should return a successful api call', async () => {
      stub.returns({data: [{foo: 'bar'}]})

      const run = async function () { return await module.getData('foo', {}, 'day') };
      return expect(Promise.resolve(await run())).to.eventually.eql([{foo: 'bar'}]);
    });
  });


  describe('getWOWData', async () => {
    beforeEach (() => {
      stub.reset();
    });

    it('should throw an error if any params are missing', async () => {
      const run = async function () { await module.getWOWData() };
      return expect(Promise.resolve(run())).to.be.rejectedWith(Error);
    });

    it('should throw an error if axios borks', async () => {
      stub.throws(new Error())

      const run = async function () { return await module.getWOWData('foo', 'bar', 'baz', 'qux') };
      return expect(Promise.resolve(run())).to.be.rejectedWith(Error);
    });

    it('should return a successful api call', async () => {
      stub.returns({data: [{foo: 'bar'}]})

      const run = async function () { return await module.getWOWData('foo', 'bar', 'baz', 'qux') };
      return expect(Promise.resolve(await run())).to.eventually.eql([{foo: 'bar'}]);
    });
  });
});
