const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { dbReturns, resetDbSpies } = require('../../helpers/db');

describe('services/carriers', async () => {
  const module = proxyquire('../../../lib/services/carriers.js', {});

  afterEach(() => {
    resetDbSpies();
  });

  describe('all services', async () => {
    it('should only return the first associated carrier', async () => {
      dbReturns([
        {
          service_owner_id: 'OG',
          service_base_path: '/alliance-example',
          service_target_owner_id: 'CX',
          service_target_permitted_carriers: ['CX', 'IB'],
        },
        {
          service_owner_id: 'OG',
          service_base_path: '/alliance-example',
          service_target_owner_id: 'IB',
          service_target_permitted_carriers: [], // IB should still be able to access
        },
        {
          service_owner_id: 'BA',
          service_base_path: '/ba-example',
          service_target_owner_id: 'BA',
          service_target_permitted_carriers: ['CX'],
        },
        {
          service_owner_id: 'IB',
          service_base_path: '/ib-example',
          service_target_owner_id: 'IB',
          service_target_permitted_carriers: [],
        }
      ]);

      const featureMap = await module.getCarrierFeatureMap('production', 'IB', false);

      expect(featureMap).to.eql(
        [{
          code: 'CX',
          supportedServices: ['oneworld/alliance-example']
        },
        {
          code: 'IB',
          supportedServices: ['oneworld/alliance-example', 'ib/ib-example']
        }
        ]);
      });
    });

  describe('legacy traveler', async () => {
    it('should only return the first associated carrier', async () => {
      dbReturns([
        {
          service_owner_id: 'OG',
          service_base_path: 'v1/traveler/record',
          service_target_owner_id: 'CX',
          service_target_permitted_carriers: ['IB'],
        },
        {
          service_owner_id: 'OG',
          service_base_path: 'v1/traveler/boardingPass',
          service_target_owner_id: 'BA',
          service_target_permitted_carriers: ['IB'],
        },
        {
          service_owner_id: 'OG',
          service_base_path: 'v1/traveler/checkin',
          service_target_owner_id: 'BA',
          service_target_permitted_carriers: [],
        },
      ]);

      const featureMap = await module.getCarrierFeatureMap('production', 'IB', true);

      expect(featureMap).to.eql(
        [{ code: 'CX',
        supportedServices: ['RECORD']
      },
      {
        code: 'BA',
        supportedServices: ['BOARDINGPASS']
      }])
    });
  });
});
