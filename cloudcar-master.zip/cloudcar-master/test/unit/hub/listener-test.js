const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const { expect } = chai;
const chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const sinon = require('sinon');

describe('listener', async () => {
  const appStub = {
    use: sinon.stub()
  };
  const serviceMiddlewareStub = sinon.stub();
  const hubListener = () => cb => {
    cb();
  }

  const module = proxyquire('../../../lib/hub/listener.js', {
    './': {
      listenNotifications: hubListener()
    },
    './createServiceMiddleware': serviceMiddlewareStub,
  });

  describe('hub listener', async () => {
    it('should call the launch twice because the listener gets fired manually once', async () => {
      await module(appStub)
      hubListener()
      expect(appStub.use).to.be.calledOnce;
      expect(serviceMiddlewareStub).to.be.calledTwice;
    });
  });
});
