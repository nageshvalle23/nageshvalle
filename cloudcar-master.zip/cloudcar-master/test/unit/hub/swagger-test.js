const proxyquire = require('proxyquire').noCallThru();
const chai = require('chai');
const { expect } = chai;
const sinon = require('sinon');


describe('openapi builder', () => {
  const load = sinon.stub();

  const module = proxyquire('../../../lib/hub/swagger', {
    'js-yaml': {
      load
    }
  })

  describe('build openapi', async () => {
    beforeEach(() => {
      load.reset();
    })

    it('should return a valid api representation even if safeload returns null', () => {
      load.returns(null)

      const out = module('foo', ``, 'Foo', '1.0.0', 'https://foo.bar.baz');

      expect(out.components).to.be.an('object');
    });

    it('should return a valid api representation even if safeload throws an error', () => {
      load.throws('bad')

      expect(() => { module('foo', ``, 'Foo', '1.0.0', 'https://foo.bar.baz') }).to.throw();
    });
  });
});
