const { expect } = require('chai');
const { isPersonAllowedToEditUser, isPersonAllowedToViewUsers } = require('../../../lib/resources/helpers.js')

describe('resources/helpers', async () => {

  describe('isPersonAllowedToEditUser', async () => {
    it('should fail because there is no carrier code', () => {
      expect(
        isPersonAllowedToEditUser(
          '',
          ['carrier_person:WRITE', 'carrier_person_admin:WRITE'],
          {iataCode: 'OG', email: 'foo@cathaypacific.com'}))
        .to.equal(false);
    });

    it('should fail because the WRITE permission does not exist', () => {
      expect(
        isPersonAllowedToEditUser(
          'CX',
          [],
          {iataCode: 'CX', email: 'foo@cathaypacific.com'}))
        .to.equal(false);
    });

    it('should fail because the email is wrong', () => {
      expect(
        isPersonAllowedToEditUser(
          'CX',
          ['carrier_person:WRITE'],
          {iataCode: 'CX', email: 'foo@bar.com'}))
        .to.equal(false);
    });

    it('should succeed because all the conditions are met', () => {
      expect(
        isPersonAllowedToEditUser(
          'CX',
          ['carrier_person:WRITE'],
          {iataCode: 'CX', email: 'foo@bar.com'}))
        .to.equal(false);
    });

    it('should succeed because either email is valid', () => {
      expect(
        isPersonAllowedToEditUser(
          'BA',
          ['carrier_person:WRITE'],
          {iataCode: 'BA', email: 'foo@iairgroup.com'}))
        .to.equal(true);

      expect(
        isPersonAllowedToEditUser(
          'BA',
          ['carrier_person:WRITE'],
          {iataCode: 'BA', email: 'foo@ba.com'}))
        .to.equal(true);
    });

    it('should succeed because all the conditions are met', () => {
      expect(
        isPersonAllowedToEditUser(
          'CX',
          ['carrier_person:WRITE'],
          {iataCode: 'CX', email: 'foo@cathaypacific.com'}))
        .to.equal(true);

    });

    it('should succeed because OG is allowed to create other carriers', () => {
      expect(
        isPersonAllowedToEditUser(
          'OG',
          ['carrier_person:WRITE'],
          {iataCode: 'CX', email: 'foo@cathaypacific.com'}))
        .to.equal(true);
    });

    it('should fail because the carrier person is not allowed to create an admin', () => {
      expect(
        isPersonAllowedToEditUser(
          'CX',
          ['carrier_person:WRITE'],
          {iataCode: 'CX', email: 'foo@cathaypacific.com', isAdmin: true}))
        .to.equal(false);
    });

    it('should succeed because the carrier person is allowed to create an admin', () => {
      expect(
        isPersonAllowedToEditUser(
          'CX',
          ['carrier_person:WRITE', 'carrier_person_admin:WRITE'],
          {iataCode: 'CX', email: 'foo@cathaypacific.com', isAdmin: true}))
        .to.equal(true);
    });

    it('should fail because the OG admin is not allowed to create an admin', () => {
      expect(
        isPersonAllowedToEditUser(
          'OG',
          ['carrier_person:WRITE'],
          {iataCode: 'CX', email: 'foo@cathaypacific.com', isAdmin: true}))
        .to.equal(false);
    });
  });

  describe('Is person allowed to view users', () => {
    it('should fail because the correct permission is not present', () => {
      expect(isPersonAllowedToViewUsers(['FOO'])).to.equal(false);
    });

    it('should succeed because the correct permission is present', () => {
      expect(isPersonAllowedToViewUsers(['carrier_person:READ'])).to.equal(true);
    });
  })
})
